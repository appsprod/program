package main

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"log"
	"net"
	"net/http"
	"sort"
	"strconv"
	"strings"
	"time"

	"golang.org/x/crypto/bcrypt"
)

// ============================================================================
// HANDLER STRUCT & UTILITIES
// ============================================================================

type Handler struct {
	repo         Repository
	sessionStore *AuthSessionStore
}

func NewHandler(repo Repository, sessionStore *AuthSessionStore) *Handler {
	return &Handler{
		repo:         repo,
		sessionStore: sessionStore,
	}
}

type JSONResponse struct {
	Success bool        `json:"success"`
	Message string      `json:"message,omitempty"`
	Data    interface{} `json:"data,omitempty"`
	Error   string      `json:"error,omitempty"`
}

func writeJSON(w http.ResponseWriter, status int, data interface{}) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	json.NewEncoder(w).Encode(data)
}

func writeError(w http.ResponseWriter, status int, message string) {
	writeJSON(w, status, JSONResponse{
		Success: false,
		Error:   message,
	})
}

func (h *Handler) getAuthenticatedUser(r *http.Request) (*User, error) {
	fmt.Printf("[AUTH DEBUG] Cookie header: %q\n", r.Header.Get("Cookie"))

	cookie, err := r.Cookie("session_token")
	if err != nil {
		fmt.Printf("[AUTH DEBUG] session_token NOT FOUND: %v\n", err)
		return nil, errors.New("unauthenticated")
	}

	fmt.Printf("[AUTH DEBUG] session_token received: %q\n", cookie.Value)

	sess, ok := h.sessionStore.GetSession(cookie.Value)
	if !ok {
		fmt.Printf("[AUTH DEBUG] GetSession FAILED token=%q\n", cookie.Value)
		return nil, errors.New("session expired or invalid")
	}

	fmt.Printf(
		"[AUTH DEBUG] GetSession OK userID=%q role=%q department=%q\n",
		sess.UserID,
		sess.Role,
		sess.Department,
	)

	user, err := h.repo.FindUserByID(r.Context(), sess.UserID)
	if err != nil {
		fmt.Printf(
			"[AUTH DEBUG] FindUserByID FAILED userID=%q error=%v\n",
			sess.UserID,
			err,
		)
		return nil, errors.New("user inactive or not found")
	}

	fmt.Printf(
		"[AUTH DEBUG] User FOUND id=%q username=%q status=%q\n",
		user.ID,
		user.Username,
		user.Status,
	)

	if user.Status != UserStatusActive {
		fmt.Printf(
			"[AUTH DEBUG] User STATUS INVALID expected=%q actual=%q\n",
			UserStatusActive,
			user.Status,
		)
		return nil, errors.New("user inactive or not found")
	}

	return user, nil
}

func getIPAddress(r *http.Request) string {
	for _, header := range []string{"X-Client-IP", "X-Real-IP", "CF-Connecting-IP", "True-Client-IP"} {
		if ip := firstForwardedIP(r.Header.Get(header)); ip != "" {
			return ip
		}
	}

	if forwarded := r.Header.Get("X-Forwarded-For"); forwarded != "" {
		if clientIP := firstForwardedIP(forwarded); clientIP != "" {
			return clientIP
		}
	}

	if host, _, err := net.SplitHostPort(strings.TrimSpace(r.RemoteAddr)); err == nil {
		if net.ParseIP(host) != nil {
			return host
		}
	}

	remoteIP := strings.Trim(strings.TrimSpace(r.RemoteAddr), "[]")
	if net.ParseIP(remoteIP) != nil {
		return remoteIP
	}

	return "unknown"
}

func firstForwardedIP(value string) string {
	for _, candidate := range strings.Split(value, ",") {
		candidate = strings.TrimSpace(candidate)
		if net.ParseIP(candidate) != nil {
			return candidate
		}
	}
	return ""
}

func validatePasswordComplexity(password string) error {
	if len(password) < 8 {
		return errors.New("password minimal harus 8 karakter")
	}
	var hasUpper, hasLower, hasNumber, hasSpecial bool
	for _, ch := range password {
		switch {
		case ch >= 'A' && ch <= 'Z':
			hasUpper = true
		case ch >= 'a' && ch <= 'z':
			hasLower = true
		case ch >= '0' && ch <= '9':
			hasNumber = true
		case strings.ContainsRune("!@#$%^&*()_+-=[]{}|;:,.<>?", ch):
			hasSpecial = true
		}
	}
	if !hasUpper || !hasLower || !hasNumber || !hasSpecial {
		return errors.New("password harus menggabungkan huruf besar, huruf kecil, angka, dan karakter khusus")
	}
	return nil
}

// ============================================================================
// AUTHENTICATION HANDLERS
// ============================================================================

type LoginRequest struct {
	Username string `json:"username"`
	Password string `json:"password"`
}

func (h *Handler) Login(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		writeError(w, http.StatusMethodNotAllowed, "Method not allowed")
		return
	}

	var req LoginRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeError(w, http.StatusBadRequest, "Invalid request body")
		return
	}

	user, err := h.repo.FindUserByUsername(r.Context(), req.Username)
	if err != nil {
		writeError(w, http.StatusUnauthorized, "Username atau password salah")
		return
	}

	// Status Verification
	if user.Status == UserStatusInactive {
		writeError(w, http.StatusForbidden, "Akun tidak aktif, silakan hubungi Administrator")
		return
	}
	if user.Status == UserStatusBlocked {
		writeError(w, http.StatusForbidden, "Akun terblokir dikarenakan 3x gagal login. Hubungi Admin")
		return
	}

	// Password Verification
	err = bcrypt.CompareHashAndPassword([]byte(user.PasswordHash), []byte(req.Password))
	if err != nil {
		// Handle Failed Attempts
		user.FailedAttempts++
		newStatus := user.Status
		if user.FailedAttempts >= 3 {
			newStatus = UserStatusBlocked
		}
		_ = h.repo.UpdateFailedAttempts(r.Context(), user.ID, user.FailedAttempts, newStatus)

		_ = h.repo.CreateAuditLog(r.Context(), &AuditLog{
			ID:        fmt.Sprintf("AUD-%d", time.Now().UnixNano()),
			User:      user.Username,
			Action:    AuditActionAuthSecurity,
			Detail:    fmt.Sprintf("Failed login attempt (%d/3)", user.FailedAttempts),
			IPAddress: getIPAddress(r),
		})

		if newStatus == UserStatusBlocked {
			writeError(w, http.StatusForbidden, "Akun Anda telah terblokir karena 3 kali percobaan gagal")
		} else {
			writeError(w, http.StatusUnauthorized, "Username atau password salah")
		}
		return
	}

	// Reset Failed Attempts on Success
	if user.FailedAttempts > 0 {
		_ = h.repo.UpdateFailedAttempts(r.Context(), user.ID, 0, UserStatusActive)
	}

	// Create Session
	_, token := h.sessionStore.CreateSession(
		user.ID,
		user.Role,
		user.Department,
	)

	http.SetCookie(w, sessionCookie(r, token))

	writeJSON(w, http.StatusOK, JSONResponse{
		Success: true,
		Message: "Login berhasil",
		Data:    user.ToResponse(),
	})
}

func (h *Handler) GetSession(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		writeError(w, http.StatusMethodNotAllowed, "Method not allowed")
		return
	}

	if cookie, err := r.Cookie("session_token"); err == nil {
		if _, active := h.sessionStore.GetSession(cookie.Value); !active {
			if sess, resumable := h.sessionStore.GetSessionForResume(cookie.Value); resumable {
				user, userErr := h.repo.FindUserByID(r.Context(), sess.UserID)
				if userErr == nil && user.Status == UserStatusActive {
					writeJSON(w, StatusSessionExpired, map[string]interface{}{
						"authenticated":  false,
						"sessionExpired": true,
						"user":           user.ToResponse(),
					})
					return
				}
				h.sessionStore.DeleteSession(cookie.Value)
			}
		}
	}

	user, err := h.getAuthenticatedUser(r)
	if err != nil {
		writeJSON(w, http.StatusUnauthorized, map[string]interface{}{
			"authenticated": false,
			"error":         err.Error(),
		})
		return
	}

	writeJSON(w, http.StatusOK, map[string]interface{}{
		"authenticated": true,
		"user":          user.ToResponse(),
	})
}

func (h *Handler) Logout(w http.ResponseWriter, r *http.Request) {
	cookie, err := r.Cookie("session_token")
	if err == nil {
		h.sessionStore.DeleteSession(cookie.Value)
	}

	http.SetCookie(w, &http.Cookie{
		Name:     "session_token",
		Value:    "",
		Expires:  time.Now().Add(-1 * time.Hour),
		HttpOnly: true,
		Path:     "/",
	})

	writeJSON(w, http.StatusOK, JSONResponse{
		Success: true,
		Message: "Logout berhasil",
	})
}

type ContinueSessionRequest struct {
	Password string `json:"password"`
}

func (h *Handler) ContinueSession(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		writeError(w, http.StatusMethodNotAllowed, "Method not allowed")
		return
	}

	cookie, err := r.Cookie("session_token")
	if err != nil || cookie.Value == "" {
		writeError(w, http.StatusUnauthorized, "Sesi tidak tersedia. Silakan login kembali.")
		return
	}

	if _, active := h.sessionStore.GetSession(cookie.Value); active {
		writeError(w, http.StatusConflict, "Sesi masih aktif. Muat ulang halaman dan lanjutkan.")
		return
	}

	sess, resumable := h.sessionStore.GetSessionForResume(cookie.Value)
	if !resumable {
		h.sessionStore.DeleteSession(cookie.Value)
		http.SetCookie(w, expiredSessionCookie(r))
		writeError(w, http.StatusUnauthorized, "Sesi tidak lagi dapat dilanjutkan. Silakan login kembali.")
		return
	}

	var req ContinueSessionRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeError(w, http.StatusBadRequest, "Permintaan tidak valid.")
		return
	}
	if req.Password == "" {
		writeError(w, http.StatusBadRequest, "Password wajib diisi.")
		return
	}

	user, err := h.repo.FindUserByID(r.Context(), sess.UserID)
	if err != nil || user.Status != UserStatusActive {
		h.sessionStore.DeleteSession(cookie.Value)
		http.SetCookie(w, expiredSessionCookie(r))
		writeError(w, http.StatusUnauthorized, "Akun tidak aktif atau tidak ditemukan. Silakan hubungi Administrator.")
		return
	}

	if !CheckPasswordHash(req.Password, user.PasswordHash) {
		user.FailedAttempts++
		newStatus := user.Status
		if user.FailedAttempts >= MaxFailedAttempts {
			newStatus = UserStatusBlocked
		}
		if err := h.repo.UpdateFailedAttempts(r.Context(), user.ID, user.FailedAttempts, newStatus); err != nil {
			writeError(w, http.StatusInternalServerError, "Gagal mencatat percobaan password. Silakan coba lagi.")
			return
		}
		_ = h.repo.CreateAuditLog(r.Context(), &AuditLog{
			ID:        fmt.Sprintf("AUD-%d", time.Now().UnixNano()),
			User:      user.Username,
			Action:    AuditActionAuthSecurity,
			Detail:    fmt.Sprintf("Failed session continuation attempt (%d/%d)", user.FailedAttempts, MaxFailedAttempts),
			IPAddress: getIPAddress(r),
		})
		if newStatus == UserStatusBlocked {
			h.sessionStore.DeleteSession(cookie.Value)
			http.SetCookie(w, expiredSessionCookie(r))
			writeError(w, http.StatusForbidden, "Akun terblokir karena terlalu banyak percobaan gagal. Hubungi Administrator.")
			return
		}
		writeError(w, http.StatusUnauthorized, "Password salah. Silakan coba lagi.")
		return
	}

	if user.FailedAttempts > 0 {
		if err := h.repo.UpdateFailedAttempts(r.Context(), user.ID, 0, UserStatusActive); err != nil {
			writeError(w, http.StatusInternalServerError, "Gagal memperbarui status login. Silakan coba lagi.")
			return
		}
	}

	h.sessionStore.DeleteSession(cookie.Value)
	_, token := h.sessionStore.CreateSession(user.ID, user.Role, user.Department)
	http.SetCookie(w, sessionCookie(r, token))
	_ = h.repo.CreateAuditLog(r.Context(), &AuditLog{
		ID:        fmt.Sprintf("AUD-%d", time.Now().UnixNano()),
		User:      user.Username,
		Action:    AuditActionAuthSecurity,
		Detail:    "Session continued after inactivity timeout",
		IPAddress: getIPAddress(r),
	})

	writeJSON(w, http.StatusOK, JSONResponse{
		Success: true,
		Message: "Sesi berhasil dilanjutkan.",
		Data:    user.ToResponse(),
	})
}

func sessionCookie(r *http.Request, token string) *http.Cookie {
	return &http.Cookie{
		Name:     "session_token",
		Value:    token,
		Expires:  time.Now().Add(SessionResumeWindow),
		HttpOnly: true,
		Path:     "/",
		SameSite: http.SameSiteLaxMode,
		Secure:   r.TLS != nil || r.Header.Get("X-Forwarded-Proto") == "https",
	}
}

func expiredSessionCookie(r *http.Request) *http.Cookie {
	return &http.Cookie{
		Name:     "session_token",
		Value:    "",
		Expires:  time.Unix(0, 0),
		HttpOnly: true,
		Path:     "/",
		SameSite: http.SameSiteLaxMode,
		Secure:   r.TLS != nil || r.Header.Get("X-Forwarded-Proto") == "https",
	}
}

type ReLoginRequest struct {
	Password string `json:"password"`
}

func (h *Handler) ReLoginVerify(r *http.Request, user *User, password string) bool {
	err := bcrypt.CompareHashAndPassword([]byte(user.PasswordHash), []byte(password))
	return err == nil
}

// ============================================================================
// MASTER DATA HANDLERS
// ============================================================================

func (h *Handler) GetLocations(w http.ResponseWriter, r *http.Request) {
	_, err := h.getAuthenticatedUser(r)
	if err != nil {
		writeError(w, http.StatusUnauthorized, "Sesi tidak valid")
		return
	}

	locations, err := h.repo.GetLocations(r.Context())
	if err != nil {
		writeError(w, http.StatusInternalServerError, "Gagal mengambil data lokasi")
		return
	}
	writeJSON(w, http.StatusOK, JSONResponse{Success: true, Data: locations})
}

func (h *Handler) GetDepartments(w http.ResponseWriter, r *http.Request) {
	_, err := h.getAuthenticatedUser(r)
	if err != nil {
		writeError(w, http.StatusUnauthorized, "Sesi tidak valid")
		return
	}

	departments, err := h.repo.GetDepartments(r.Context())
	if err != nil {
		writeError(w, http.StatusInternalServerError, "Gagal mengambil data departemen")
		return
	}
	writeJSON(w, http.StatusOK, JSONResponse{Success: true, Data: departments})
}

func (h *Handler) GetSites(w http.ResponseWriter, r *http.Request) {
	_, err := h.getAuthenticatedUser(r)
	if err != nil {
		writeError(w, http.StatusUnauthorized, "Sesi tidak valid")
		return
	}

	sites, err := h.repo.GetSites(r.Context())
	if err != nil {
		writeError(w, http.StatusInternalServerError, "Gagal mengambil data site")
		return
	}
	writeJSON(w, http.StatusOK, JSONResponse{Success: true, Data: sites})
}

// ============================================================================
// INSPECTION HANDLERS
// ============================================================================

func jakartaLocation() *time.Location {
	if loc, err := time.LoadLocation("Asia/Jakarta"); err == nil {
		return loc
	}
	return time.FixedZone("WIB", 7*60*60)
}

func getWeekStart(date time.Time) time.Time {
	date = date.In(jakartaLocation())
	weekday := int(date.Weekday())
	if weekday == 0 {
		weekday = 7
	}
	localMidnight := time.Date(date.Year(), date.Month(), date.Day(), 0, 0, 0, 0, jakartaLocation())
	return localMidnight.AddDate(0, 0, -(weekday - 1))
}

func normalizeInspectionDate(dateInput string, fallback time.Time) time.Time {
	fallback = fallback.In(jakartaLocation())
	if dateInput == "" {
		return fallback
	}

	parsed, err := time.ParseInLocation("2006-01-02", dateInput, jakartaLocation())
	if err != nil {
		return fallback
	}
	return parsed.In(jakartaLocation())
}

func getCurrentShift(now time.Time) (string, time.Time) {
	localNow := now.In(jakartaLocation())
	inspectionDate := time.Date(localNow.Year(), localNow.Month(), localNow.Day(), 0, 0, 0, 0, jakartaLocation())
	minutes := localNow.Hour()*60 + localNow.Minute()

	switch {
	case minutes >= 6*60+45 && minutes < 15*60+15:
		return "1", inspectionDate
	case minutes >= 15*60+15 && minutes < 22*60+30:
		return "2", inspectionDate
	case minutes >= 22*60+30:
		return "3", inspectionDate
	default:
		return "3", inspectionDate.AddDate(0, 0, -1)
	}
}

func inspectionDisplayDateTime(inspection Inspection) time.Time {
	if !inspection.MissedEntry {
		return inspection.CreatedAt.In(jakartaLocation())
	}

	shiftStart, ok := map[string][2]int{
		"1": {6, 45},
		"2": {15, 15},
		"3": {22, 30},
	}[inspection.Shift]
	if !ok {
		return inspection.CreatedAt.In(jakartaLocation())
	}

	date := inspection.Date.In(jakartaLocation())
	return time.Date(date.Year(), date.Month(), date.Day(), shiftStart[0], shiftStart[1], 0, 0, jakartaLocation())
}

func getAvailableShiftsForWeek(inspections []Inspection, referenceDate time.Time) []string {
	weekStart := getWeekStart(referenceDate)
	weekEnd := weekStart.AddDate(0, 0, 7)
	filled := map[string]bool{}
	for _, inspection := range inspections {
		date := inspection.Date.In(jakartaLocation())
		if !date.Before(weekStart) && date.Before(weekEnd) {
			filled[inspection.Shift] = true
		}
	}

	available := make([]string, 0, 3)
	for _, shift := range []string{"1", "2", "3"} {
		if !filled[shift] {
			available = append(available, shift)
		}
	}
	return available
}

// shiftWindowEnd mengembalikan akhir jendela waktu sebuah shift pada
// tanggal inspeksi (tanggal mulai shift) yang diberikan, dalam WIB.
func shiftWindowEnd(shift string, date time.Time) (time.Time, bool) {
	date = date.In(jakartaLocation())
	day := time.Date(date.Year(), date.Month(), date.Day(), 0, 0, 0, 0, jakartaLocation())
	switch shift {
	case "1":
		return day.Add(15*time.Hour + 15*time.Minute), true
	case "2":
		return day.Add(22*time.Hour + 30*time.Minute), true
	case "3":
		return day.AddDate(0, 0, 1).Add(6*time.Hour + 45*time.Minute), true
	}
	return time.Time{}, false
}

// inspectionCreatedBefore menentukan record mana yang diinput lebih dulu.
// CreatedAt adalah urutan input yang sebenarnya; bila CreatedAt tidak
// tersedia (nol) atau sama, tanggal inspeksi lalu nomor shift dipakai
// sebagai penentu agar hasilnya deterministik.
func inspectionCreatedBefore(a, b Inspection) bool {
	aCreated, bCreated := a.CreatedAt, b.CreatedAt
	if !aCreated.IsZero() && !bCreated.IsZero() && !aCreated.Equal(bCreated) {
		return aCreated.Before(bCreated)
	}
	aDate := a.Date.In(jakartaLocation())
	bDate := b.Date.In(jakartaLocation())
	if !aDate.Equal(bDate) {
		return aDate.Before(bDate)
	}
	return a.Shift < b.Shift
}

// weekAnchorDate mengembalikan tanggal inspeksi dari record yang pertama
// kali diinput dalam minggu yang diberikan. Tanggal inilah "hari
// pengisian" minggu tersebut: seluruh pengisian minggu itu harus
// bertanggal sama dengan tanggal ini. Minggu tanpa record tidak punya
// tanggal anchor.
func weekAnchorDate(inspections []Inspection, weekStart time.Time) (time.Time, bool) {
	weekStart = getWeekStart(weekStart)
	weekEnd := weekStart.AddDate(0, 0, 7)
	var first *Inspection
	for i := range inspections {
		insp := &inspections[i]
		date := insp.Date.In(jakartaLocation())
		if date.Before(weekStart) || !date.Before(weekEnd) {
			continue
		}
		if first == nil || inspectionCreatedBefore(*insp, *first) {
			first = insp
		}
	}
	if first == nil {
		return time.Time{}, false
	}
	date := first.Date.In(jakartaLocation())
	return time.Date(date.Year(), date.Month(), date.Day(), 0, 0, 0, 0, jakartaLocation()), true
}

func filledShiftsForWeek(inspections []Inspection, weekStart time.Time) map[string]bool {
	weekStart = getWeekStart(weekStart)
	weekEnd := weekStart.AddDate(0, 0, 7)
	filled := map[string]bool{}
	for _, inspection := range inspections {
		date := inspection.Date.In(jakartaLocation())
		if !date.Before(weekStart) && date.Before(weekEnd) {
			filled[inspection.Shift] = true
		}
	}
	return filled
}

// shiftDebt adalah satu shift yang sudah terlewat dan menjadi tanggungan:
// shift tersebut belum terisi, jendela waktunya pada tanggal anchor sudah
// berakhir, dan catatannya harus dibuat sebagai Shift Terlewat bertanggal
// anchor tersebut.
type shiftDebt struct {
	Shift     string
	Date      time.Time
	WeekStart time.Time
}

// oldestDueShiftDebt mencari tanggungan shift terlewat yang paling lama:
// minggu paling lama dulu, lalu nomor shift paling kecil. Shift yang
// jendela waktunya pada tanggal anchor belum berakhir bukan tanggungan
// (masih bisa diisi normal pada tanggal anchor itu sendiri).
func oldestDueShiftDebt(inspections []Inspection, now time.Time) (shiftDebt, bool) {
	_, inspectionDate := getCurrentShift(now)
	currentWeekStart := getWeekStart(inspectionDate)
	localNow := now.In(jakartaLocation())

	earliest := earliestInspectionDate(inspections)
	if earliest.IsZero() {
		return shiftDebt{}, false
	}
	for weekStart := getWeekStart(earliest); !weekStart.After(currentWeekStart); weekStart = weekStart.AddDate(0, 0, 7) {
		anchor, ok := weekAnchorDate(inspections, weekStart)
		if !ok {
			continue
		}
		filled := filledShiftsForWeek(inspections, weekStart)
		for _, shift := range []string{"1", "2", "3"} {
			if filled[shift] {
				continue
			}
			end, ok := shiftWindowEnd(shift, anchor)
			if !ok {
				continue
			}
			if !localNow.Before(end) {
				return shiftDebt{Shift: shift, Date: anchor, WeekStart: weekStart}, true
			}
		}
	}
	return shiftDebt{}, false
}

func weekHasInspection(inspections []Inspection, weekStart time.Time) bool {
	weekStart = getWeekStart(weekStart)
	weekEnd := weekStart.AddDate(0, 0, 7)
	for _, inspection := range inspections {
		date := inspection.Date.In(jakartaLocation())
		if !date.Before(weekStart) && date.Before(weekEnd) {
			return true
		}
	}
	return false
}

func earliestWeeklyMissedWeek(inspections []Inspection, machineCreatedAt, currentWeekStart time.Time) (time.Time, bool) {
	if machineCreatedAt.IsZero() {
		machineCreatedAt = earliestInspectionDate(inspections)
	}
	if machineCreatedAt.IsZero() {
		return time.Time{}, false
	}

	for weekStart := getWeekStart(machineCreatedAt); weekStart.Before(currentWeekStart); weekStart = weekStart.AddDate(0, 0, 7) {
		if !weekHasInspection(inspections, weekStart) {
			return weekStart, true
		}
	}
	return time.Time{}, false
}

func getInspectionProgress(inspections []Inspection, now time.Time, machineCreatedAt ...time.Time) map[string]interface{} {
	activeShift, inspectionDate := getCurrentShift(now)
	currentWeekStart := getWeekStart(inspectionDate)
	shiftOrder := []string{"1", "2", "3"}
	shiftIndex := map[string]int{"1": 0, "2": 1, "3": 2}

	var createdAt time.Time
	if len(machineCreatedAt) > 0 {
		createdAt = machineCreatedAt[0]
	}

	// Tanggungan diurutkan dari yang paling lama: minggu paling lama
	// dulu. Tanggungan shift terlewat dari minggu yang lebih lama
	// didahulukan atas Entry Terlewat Mingguan dari minggu yang lebih
	// baru, dan sebaliknya.
	debt, hasDebt := oldestDueShiftDebt(inspections, now)
	weeklyMissedWeek, hasWeeklyMissedWeek := earliestWeeklyMissedWeek(inspections, createdAt, currentWeekStart)
	if hasDebt && (!hasWeeklyMissedWeek || debt.WeekStart.Before(weeklyMissedWeek)) {
		isCarryover := debt.WeekStart.Before(currentWeekStart)
		message := fmt.Sprintf("Shift %s tanggal %s terlewat. Lengkapi Shift Terlewat terlebih dahulu sebelum mengisi inspeksi.",
			debt.Shift, debt.Date.Format("02/01/2006"))
		if isCarryover {
			message = fmt.Sprintf("Shift %s tanggal %s masih menjadi tanggungan dari minggu lalu. Selesaikan sebelum melanjutkan inspeksi.",
				debt.Shift, debt.Date.Format("02/01/2006"))
		}
		return map[string]interface{}{
			"hasHistory": true, "requiresMissed": true, "missedType": "shift",
			"missingShift": debt.Shift, "missingDate": debt.Date.Format("2006-01-02"),
			"missedWeekStart": debt.WeekStart.Format("2006-01-02"),
			"missedWeekEnd":   debt.WeekStart.AddDate(0, 0, 6).Format("2006-01-02"),
			"activeShift":     activeShift, "inspectionDate": inspectionDate.Format("2006-01-02"),
			"activeShiftAvailable": false, "nextShift": "",
			"shiftThreeCarryover":               isCarryover,
			"pendingShiftThree":                 true,
			"pendingShiftThreeShift":            debt.Shift,
			"pendingShiftThreeDate":             debt.Date.Format("2006-01-02"),
			"pendingShiftThreeWeekStart":        debt.WeekStart.Format("2006-01-02"),
			"pendingShiftThreeWeekEnd":          debt.WeekStart.AddDate(0, 0, 6).Format("2006-01-02"),
			"pendingShiftThreeAvailableFrom":    debt.Date.AddDate(0, 0, 1).Format("2006-01-02"),
			"pendingShiftThreeAvailableThrough": inspectionDate.Format("2006-01-02"),
			"message":                           message,
		}
	}

	if hasWeeklyMissedWeek {
		weekEnd := weeklyMissedWeek.AddDate(0, 0, 6)
		return map[string]interface{}{
			"hasHistory": true, "requiresMissed": true, "missedType": "weekly",
			"missingDate":     weeklyMissedWeek.Format("2006-01-02"),
			"missedWeekStart": weeklyMissedWeek.Format("2006-01-02"),
			"missedWeekEnd":   weekEnd.Format("2006-01-02"),
			"activeShift":     activeShift, "inspectionDate": inspectionDate.Format("2006-01-02"),
			"activeShiftAvailable": false, "nextShift": "",
			"message": fmt.Sprintf("Minggu %s sampai %s belum memiliki inspeksi untuk mesin ini. Selesaikan Entry Terlewat Mingguan terlebih dahulu.",
				weeklyMissedWeek.Format("02/01/2006"), weekEnd.Format("02/01/2006")),
		}
	}

	// Belum ada tanggungan: shift yang lebih dulu dari shift aktif pada
	// hari pengisian minggu ini harus sudah terisi (normal atau
	// terlewat). Bila minggu ini belum dimulai, tanggal yang dipakai
	// adalah tanggal hari ini; bila sudah dimulai, tanggal anchor.
	anchor, hasAnchor := weekAnchorDate(inspections, currentWeekStart)
	missingDate := inspectionDate
	if hasAnchor {
		missingDate = anchor
	}
	currentWeekFilled := filledShiftsForWeek(inspections, currentWeekStart)
	for _, shift := range shiftOrder[:shiftIndex[activeShift]] {
		if !currentWeekFilled[shift] {
			return map[string]interface{}{
				"hasHistory": true, "requiresMissed": true, "missedType": "shift",
				"missingShift": shift, "missingDate": missingDate.Format("2006-01-02"),
				"missedWeekStart": currentWeekStart.Format("2006-01-02"),
				"missedWeekEnd":   currentWeekStart.AddDate(0, 0, 6).Format("2006-01-02"),
				"activeShift":     activeShift, "inspectionDate": inspectionDate.Format("2006-01-02"),
				"activeShiftAvailable": false, "nextShift": "",
				"message": fmt.Sprintf("Shift %s tanggal %s terlewat. Lengkapi terlebih dahulu sebelum mengisi Shift %s.",
					shift, missingDate.Format("02/01/2006"), activeShift),
			}
		}
	}

	// Pengisian normal hanya boleh dilakukan pada tanggal anchor minggu
	// ini. Di tanggal lain, sisa shift minggu ini hanya bisa dicatat
	// sebagai Shift Terlewat bertanggal anchor.
	available := getAvailableShiftsForWeek(inspections, inspectionDate)
	activeAvailable := containsString(available, activeShift)
	if hasAnchor && !inspectionDate.Equal(anchor) {
		activeAvailable = false
	}
	message := fmt.Sprintf("Jadwal saat ini Shift %s.", activeShift)
	if !activeAvailable {
		if hasAnchor && !inspectionDate.Equal(anchor) {
			message = fmt.Sprintf("Minggu ini sudah dimulai tanggal %s. Sisa shift hanya dapat dicatat sebagai Shift Terlewat tanggal tersebut.",
				anchor.Format("02/01/2006"))
		} else {
			message = fmt.Sprintf("Shift %s tanggal ini sudah memiliki record. Tidak ada pengisian kedua untuk shift yang sama.", activeShift)
		}
	}
	nextShift := ""
	if activeAvailable {
		nextShift = activeShift
	}
	return map[string]interface{}{
		"hasHistory": len(inspections) > 0, "requiresMissed": false,
		"nextShift":            nextShift,
		"activeShift":          activeShift,
		"inspectionDate":       inspectionDate.Format("2006-01-02"),
		"activeShiftAvailable": activeAvailable,
		"completedToday":       len(available) == 0,
		"message":              message,
	}
}

func earliestInspectionDate(inspections []Inspection) time.Time {
	var earliest time.Time
	for _, inspection := range inspections {
		date := inspection.Date.In(jakartaLocation())
		if earliest.IsZero() || date.Before(earliest) {
			earliest = date
		}
	}
	return earliest
}

func (h *Handler) getLocationCreatedAt(ctx context.Context, locationID string) (time.Time, error) {
	locations, err := h.repo.GetLocations(ctx)
	if err != nil {
		return time.Time{}, fmt.Errorf("gagal memeriksa tanggal mulai mesin: %w", err)
	}
	for _, location := range locations {
		if location.ID == locationID {
			return location.CreatedAt, nil
		}
	}
	return time.Time{}, fmt.Errorf("mesin %q tidak ditemukan", locationID)
}

func (h *Handler) GetInspectionProgress(w http.ResponseWriter, r *http.Request) {
	if _, err := h.getAuthenticatedUser(r); err != nil {
		writeError(w, http.StatusUnauthorized, "Sesi tidak valid")
		return
	}

	locationID := strings.TrimSpace(r.URL.Query().Get("locationId"))
	if locationID == "" {
		writeError(w, http.StatusBadRequest, "Lokasi wajib dipilih")
		return
	}

	inspections, err := h.repo.ListInspections(r.Context(), InspectionFilter{LocationID: &locationID})
	if err != nil {
		writeError(w, http.StatusInternalServerError, "Gagal memeriksa progres inspeksi lokasi")
		return
	}
	locationCreatedAt, err := h.getLocationCreatedAt(r.Context(), locationID)
	if err != nil {
		writeError(w, http.StatusInternalServerError, err.Error())
		return
	}

	writeJSON(w, http.StatusOK, JSONResponse{Success: true, Data: getInspectionProgress(inspections, time.Now(), locationCreatedAt)})
}

func (h *Handler) validateInspectionSequence(ctx context.Context, locationID, requestedShift string, inspectionDate time.Time) error {
	if requestedShift != "1" && requestedShift != "2" && requestedShift != "3" {
		return errors.New("shift inspeksi tidak valid")
	}

	inspections, err := h.repo.ListInspections(ctx, InspectionFilter{LocationID: &locationID})
	if err != nil {
		return fmt.Errorf("gagal memeriksa urutan shift: %w", err)
	}

	available := getAvailableShiftsForWeek(inspections, inspectionDate)
	if len(available) == 0 {
		return errors.New("Shift 1, Shift 2, dan Shift 3 untuk minggu ini sudah lengkap")
	}

	if !containsString(available, requestedShift) {
		return fmt.Errorf("shift %s tidak tersedia untuk lokasi ini pada tanggal ini; shift yang masih terbuka: %s", requestedShift, strings.Join(available, ", "))
	}

	// Pengisian normal hanya boleh pada tanggal anchor minggu ini
	// (tanggal record pertama yang diinput minggu itu). Di tanggal
	// lain, sisa shift hanya bisa dicatat sebagai Shift Terlewat.
	if anchor, ok := weekAnchorDate(inspections, inspectionDate); ok && !inspectionDate.Equal(anchor) {
		return fmt.Errorf("minggu ini sudah dimulai tanggal %s; sisa shift hanya dapat dicatat sebagai Shift Terlewat tanggal %s",
			anchor.Format("02/01/2006"), anchor.Format("02/01/2006"))
	}
	return nil
}

func containsString(items []string, target string) bool {
	for _, item := range items {
		if item == target {
			return true
		}
	}
	return false
}

func hasInspectionForDateAndShift(inspections []Inspection, date time.Time, shift string) bool {
	dateKey := date.In(jakartaLocation()).Format("2006-01-02")
	for _, inspection := range inspections {
		if inspection.Shift == shift && inspection.Date.In(jakartaLocation()).Format("2006-01-02") == dateKey {
			return true
		}
	}
	return false
}

type CreateInspectionInput struct {
	LocationID     string  `json:"locationId"`
	Shift          string  `json:"shift"`
	CheckPersonel  string  `json:"checkPersonel"`
	CheckRuangan   string  `json:"checkRuangan"`
	CheckPeralatan string  `json:"checkPeralatan"`
	KetPersonel    *string `json:"ketPersonel"`
	KetRuangan     *string `json:"ketRuangan"`
	KetPeralatan   *string `json:"ketPeralatan"`
	Date           string  `json:"date"`
}

func (h *Handler) CreateInspection(w http.ResponseWriter, r *http.Request) {
	user, err := h.getAuthenticatedUser(r)
	if err != nil {
		writeError(w, http.StatusUnauthorized, "Sesi tidak valid")
		return
	}

	if user.Role != RoleStaff && user.Role != RoleAdministrator {
		writeError(w, http.StatusForbidden, "Hanya Staff/Admin yang dapat membuat laporan inspeksi")
		return
	}

	var input CreateInspectionInput
	if err := json.NewDecoder(r.Body).Decode(&input); err != nil {
		writeError(w, http.StatusBadRequest, "Invalid JSON input")
		return
	}

	// Field Validation
	if input.LocationID == "" || input.Shift == "" || input.CheckPersonel == "" || input.CheckRuangan == "" || input.CheckPeralatan == "" {
		writeError(w, http.StatusBadRequest, "Lokasi, Shift, dan Seluruh Check Item wajib diisi")
		return
	}
	if !validInspectionCheck(input.CheckPersonel) || !validInspectionCheck(input.CheckRuangan) || !validInspectionCheck(input.CheckPeralatan) {
		writeError(w, http.StatusBadRequest, "Status pemeriksaan hanya boleh OK atau NOK")
		return
	}

	// Mandatory explanation if NOK
	if input.CheckPersonel == "NOK" && (input.KetPersonel == nil || *input.KetPersonel == "") {
		writeError(w, http.StatusBadRequest, "Keterangan personel wajib diisi jika status NOK")
		return
	}
	if input.CheckRuangan == "NOK" && (input.KetRuangan == nil || *input.KetRuangan == "") {
		writeError(w, http.StatusBadRequest, "Keterangan ruangan wajib diisi jika status NOK")
		return
	}
	if input.CheckPeralatan == "NOK" && (input.KetPeralatan == nil || *input.KetPeralatan == "") {
		writeError(w, http.StatusBadRequest, "Keterangan peralatan wajib diisi jika status NOK")
		return
	}
	activeShift, inspDate := getCurrentShift(time.Now())
	if input.Shift != activeShift {
		writeError(w, http.StatusBadRequest, fmt.Sprintf("Saat ini jadwal Shift %s. Pengisian Shift %s tidak dapat dilakukan sekarang.", activeShift, input.Shift))
		return
	}
	locationInspections, err := h.repo.ListInspections(r.Context(), InspectionFilter{LocationID: &input.LocationID})
	if err != nil {
		writeError(w, http.StatusInternalServerError, "Gagal memeriksa progres inspeksi lokasi")
		return
	}
	locationCreatedAt, err := h.getLocationCreatedAt(r.Context(), input.LocationID)
	if err != nil {
		writeError(w, http.StatusInternalServerError, err.Error())
		return
	}
	progress := getInspectionProgress(locationInspections, time.Now(), locationCreatedAt)
	if progress["requiresMissed"] == true {
		writeError(w, http.StatusConflict, fmt.Sprint(progress["message"]))
		return
	}
	if err := h.validateInspectionSequence(r.Context(), input.LocationID, input.Shift, inspDate); err != nil {
		writeError(w, http.StatusBadRequest, err.Error())
		return
	}

	inspectionID, err := h.repo.GenerateInspectionID(r.Context(), inspDate)
	if err != nil {
		writeError(w, http.StatusInternalServerError, "Gagal membuat ID inspeksi")
		return
	}

	insp := &Inspection{
		ID:             inspectionID,
		LocationID:     input.LocationID,
		Shift:          input.Shift,
		CheckPersonel:  input.CheckPersonel,
		CheckRuangan:   input.CheckRuangan,
		CheckPeralatan: input.CheckPeralatan,
		KetPersonel:    input.KetPersonel,
		KetRuangan:     input.KetRuangan,
		KetPeralatan:   input.KetPeralatan,
		Date:           inspDate,
		CreatedBy:      user.ID, // Server Controlled User Identity
	}

	if err := h.repo.CreateInspection(r.Context(), insp); err != nil {
		if errors.Is(err, ErrDuplicateInspectionSlot) {
			writeError(w, http.StatusConflict, "Data inspeksi untuk mesin, tanggal, dan shift ini sudah ada")
			return
		}
		writeError(w, http.StatusInternalServerError, "Gagal menyimpan inspeksi ke database")
		return
	}

	_ = h.repo.CreateAuditLog(r.Context(), &AuditLog{
		ID:        fmt.Sprintf("AUD-%d", time.Now().UnixNano()),
		User:      user.Username,
		Action:    AuditActionCreate,
		Detail:    fmt.Sprintf("Created Inspection %s for location %s", insp.ID, insp.LocationID),
		IPAddress: getIPAddress(r),
	})

	writeJSON(w, http.StatusCreated, JSONResponse{Success: true, Message: "Inspeksi berhasil disimpan", Data: insp})
}

type MissedEntryInput struct {
	EntryType    string `json:"entryType"`
	LocationID   string `json:"locationId"`
	Shift        string `json:"shift"`
	Date         string `json:"date"`
	MissedReason string `json:"missedReason"`
	WeekStart    string `json:"weekStart"`
	WeekEnd      string `json:"weekEnd"`
}

func (h *Handler) CreateMissedEntry(w http.ResponseWriter, r *http.Request) {
	user, err := h.getAuthenticatedUser(r)
	if err != nil {
		writeError(w, http.StatusUnauthorized, "Sesi tidak valid")
		return
	}

	var input MissedEntryInput
	if err := json.NewDecoder(r.Body).Decode(&input); err != nil || input.LocationID == "" {
		writeError(w, http.StatusBadRequest, "Lokasi dan alasan Entry Terlewat wajib diisi")
		return
	}
	if input.MissedReason != "Lupa" && input.MissedReason != "Hari Libur" && input.MissedReason != "Tidak dilakukan" {
		writeError(w, http.StatusBadRequest, "Alasan Entry Terlewat hanya boleh Lupa, Hari Libur, atau Tidak dilakukan")
		return
	}
	inspections, err := h.repo.ListInspections(r.Context(), InspectionFilter{LocationID: &input.LocationID})
	if err != nil {
		writeError(w, http.StatusInternalServerError, "Gagal memeriksa riwayat Entry Terlewat")
		return
	}
	locationCreatedAt, err := h.getLocationCreatedAt(r.Context(), input.LocationID)
	if err != nil {
		writeError(w, http.StatusInternalServerError, err.Error())
		return
	}
	progress := getInspectionProgress(inspections, time.Now(), locationCreatedAt)

	if input.EntryType == "weekly" {
		if progress["missedType"] != "weekly" {
			writeError(w, http.StatusBadRequest, "Tidak ada Entry Terlewat Mingguan yang dapat diselesaikan untuk mesin ini saat ini")
			return
		}
		weekStart, err := time.ParseInLocation("2006-01-02", fmt.Sprint(progress["missedWeekStart"]), jakartaLocation())
		if err != nil {
			writeError(w, http.StatusInternalServerError, "Periode Entry Terlewat Mingguan tidak valid")
			return
		}
		weekEnd := weekStart.AddDate(0, 0, 6)
		if input.WeekStart != weekStart.Format("2006-01-02") || input.WeekEnd != weekEnd.Format("2006-01-02") {
			writeError(w, http.StatusBadRequest, "Entry Terlewat Mingguan harus diselesaikan mulai dari periode terlewat yang paling lama")
			return
		}
		inspDate, err := time.ParseInLocation("2006-01-02", input.Date, jakartaLocation())
		if err != nil || inspDate.Before(weekStart) || inspDate.After(weekEnd) {
			writeError(w, http.StatusBadRequest, "Tanggal harus berada dalam periode Entry Terlewat Mingguan yang dipilih")
			return
		}

		weeklyRecords := make([]*Inspection, 0, 3)
		for _, shift := range []string{"1", "2", "3"} {
			id, err := h.repo.GenerateInspectionID(r.Context(), inspDate)
			if err != nil {
				writeError(w, http.StatusInternalServerError, "Gagal membuat ID Entry Terlewat Mingguan")
				return
			}
			reason := input.MissedReason
			weeklyRecords = append(weeklyRecords, &Inspection{
				ID: id, LocationID: input.LocationID, Shift: shift, Date: inspDate,
				CreatedBy: user.ID, MissedReason: &reason,
			})
		}
		if err := h.repo.CreateWeeklyMissedEntries(r.Context(), weeklyRecords); err != nil {
			if errors.Is(err, ErrDuplicateInspectionSlot) {
				writeError(w, http.StatusConflict, "Salah satu shift pada Entry Terlewat Mingguan ini sudah memiliki record untuk mesin ini")
				return
			}
			writeError(w, http.StatusInternalServerError, "Gagal menyimpan seluruh catatan Entry Terlewat Mingguan")
			return
		}
		_ = h.repo.CreateAuditLog(r.Context(), &AuditLog{
			ID: fmt.Sprintf("AUD-%d", time.Now().UnixNano()), User: user.Username, Action: AuditActionCreate,
			Detail: fmt.Sprintf("Mengirim Entry Terlewat Mingguan untuk mesin %s, minggu %s sampai %s. Alasan: %s",
				input.LocationID, weekStart.Format("2006-01-02"), weekEnd.Format("2006-01-02"), input.MissedReason),
			IPAddress: getIPAddress(r),
		})
		writeJSON(w, http.StatusCreated, JSONResponse{Success: true, Message: "Entry Terlewat Mingguan berhasil diselesaikan dengan 3 catatan shift", Data: weeklyRecords})
		return
	}

	if input.Shift != "1" && input.Shift != "2" && input.Shift != "3" {
		writeError(w, http.StatusBadRequest, "Shift pada Entry Terlewat tidak valid")
		return
	}
	inspDate, err := time.ParseInLocation("2006-01-02", input.Date, jakartaLocation())
	if err != nil {
		writeError(w, http.StatusBadRequest, "Tanggal Shift Terlewat tidak valid")
		return
	}
	// Satu-satunya tanggungan Shift Terlewat yang boleh dicatat adalah
	// tanggungan yang paling lama. Tanggal yang dikirim harus tanggal
	// tanggungan itu sendiri (tanggal anchor), atau tanggal penyelesaian
	// sesudahnya sampai tanggal hari ini; tanggal penyelesaian selalu
	// ditulis ulang menjadi tanggal tanggungan, karena record terlewat
	// bertanggal hari pengisian minggu tersebut, bukan hari
	// penyelesaiannya.
	if progress["requiresMissed"] == true && progress["missedType"] == "weekly" {
		writeError(w, http.StatusBadRequest, "Selesaikan Entry Terlewat Mingguan yang paling lama untuk mesin ini terlebih dahulu")
		return
	}
	debt, hasDebt := oldestDueShiftDebt(inspections, time.Now())
	if !hasDebt {
		writeError(w, http.StatusBadRequest, "Tidak ada Shift Terlewat yang harus diselesaikan untuk mesin ini saat ini")
		return
	}
	if input.Shift != debt.Shift {
		writeError(w, http.StatusBadRequest, fmt.Sprintf("Selesaikan Shift Terlewat yang paling lama terlebih dahulu: Shift %s tanggal %s",
			debt.Shift, debt.Date.Format("02/01/2006")))
		return
	}
	_, todayDate := getCurrentShift(time.Now())
	if inspDate.Before(debt.Date) || inspDate.After(todayDate) {
		writeError(w, http.StatusBadRequest, fmt.Sprintf("Tanggal Shift Terlewat harus tanggal %s atau tanggal penyelesaian sampai %s",
			debt.Date.Format("02/01/2006"), todayDate.Format("02/01/2006")))
		return
	}
	inspDate = debt.Date

	if hasInspectionForDateAndShift(inspections, inspDate, input.Shift) {
		writeError(w, http.StatusConflict, fmt.Sprintf("Shift %s pada tanggal tersebut sudah memiliki record untuk mesin ini", input.Shift))
		return
	}

	insp := &Inspection{
		ID: fmt.Sprintf("MISSED-%d", time.Now().UnixNano()), LocationID: input.LocationID,
		Shift: input.Shift, Date: inspDate, CreatedBy: user.ID, MissedReason: &input.MissedReason,
	}
	if err := h.repo.CreateMissedEntry(r.Context(), insp); err != nil {
		if errors.Is(err, ErrDuplicateInspectionSlot) {
			writeError(w, http.StatusConflict, fmt.Sprintf("Shift %s pada tanggal tersebut sudah memiliki record untuk mesin ini", input.Shift))
			return
		}
		writeError(w, http.StatusInternalServerError, "Gagal mencatat Shift Terlewat")
		return
	}

	_ = h.repo.CreateAuditLog(r.Context(), &AuditLog{
		ID: fmt.Sprintf("AUD-%d", time.Now().UnixNano()), User: user.Username, Action: AuditActionCreate,
		Detail:    fmt.Sprintf("Mengirim Shift Terlewat %s untuk mesin %s. Alasan: %s", insp.Shift, insp.LocationID, input.MissedReason),
		IPAddress: getIPAddress(r),
	})

	writeJSON(w, http.StatusCreated, JSONResponse{Success: true, Message: "Shift Terlewat berhasil dicatat", Data: insp})
}

// ============================================================================
// APPROVAL WORKFLOW HANDLERS
// ============================================================================

type ApprovalRequest struct {
	Password string `json:"password"` // Re-login verification
}

func (h *Handler) ApproveSupervisor(w http.ResponseWriter, r *http.Request, id string) {
	user, err := h.getAuthenticatedUser(r)
	if err != nil {
		writeError(w, http.StatusUnauthorized, "Sesi tidak valid")
		return
	}

	if user.Role != RoleSupervisor && user.Role != RoleAdministrator {
		writeError(w, http.StatusForbidden, "Hanya Supervisor/Admin yang berwenang melakukan verifikasi tingkat 1")
		return
	}

	var req ApprovalRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil || req.Password == "" {
		writeError(w, http.StatusBadRequest, "Verifikasi password (re-login) diperlukan untuk approval")
		return
	}

	if !h.ReLoginVerify(r, user, req.Password) {
		writeError(w, http.StatusUnauthorized, "Password verifikasi re-login salah")
		return
	}

	audit := &AuditLog{
		ID:        fmt.Sprintf("AUD-%d", time.Now().UnixNano()),
		User:      user.Username,
		Action:    AuditActionApproval,
		Detail:    fmt.Sprintf("Supervisor approval executed for Inspection ID: %s", id),
		IPAddress: getIPAddress(r),
	}

	err = h.repo.ApproveSupervisor(r.Context(), id, user.ID, audit)
	if err != nil {
		if errors.Is(err, ErrInvalidStatusTransition) {
			writeError(w, http.StatusConflict, "Inspeksi tidak berada dalam status SUBMITTED atau telah dipproses")
			return
		}
		writeError(w, http.StatusInternalServerError, "Gagal memproses supervisor approval")
		return
	}

	writeJSON(w, http.StatusOK, JSONResponse{Success: true, Message: "Berhasil melakukan approval Supervisor (APPROVED)"})
}

// ============================================================================
// REVISION HANDLERS
// ============================================================================

type RevisionRequest struct {
	Password string `json:"password"`
}

func (h *Handler) RequestRevision(w http.ResponseWriter, r *http.Request, id string) {
	user, err := h.getAuthenticatedUser(r)
	if err != nil {
		writeError(w, http.StatusUnauthorized, "Sesi tidak valid")
		return
	}

	if user.Role != RoleSupervisor && user.Role != RoleAdministrator {
		writeError(w, http.StatusForbidden, "Akses otorisasi revisi ditolak")
		return
	}

	var req RevisionRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil || req.Password == "" {
		writeError(w, http.StatusBadRequest, "Verifikasi password (re-login) wajib diisi")
		return
	}

	if !h.ReLoginVerify(r, user, req.Password) {
		writeError(w, http.StatusUnauthorized, "Password verifikasi re-login salah")
		return
	}

	_ = h.repo.CreateAuditLog(r.Context(), &AuditLog{
		ID:        fmt.Sprintf("AUD-%d", time.Now().UnixNano()),
		User:      user.Username,
		Action:    AuditActionRevision,
		Detail:    fmt.Sprintf("Authorized revision granted for Inspection ID: %s", id),
		IPAddress: getIPAddress(r),
	})

	writeJSON(w, http.StatusOK, JSONResponse{
		Success: true,
		Message: "Otorisasi revisi disetujui. Anda sekarang dapat memperbarui data inspeksi.",
	})
}

// UpdateInspection (PUT) - Mengubah data inspeksi dan mengembalikan status ke SUBMITTED
// GetInspection (GET) - Mengambil detail satu inspeksi untuk halaman edit
func (h *Handler) GetInspection(w http.ResponseWriter, r *http.Request, id string) {
	_, err := h.getAuthenticatedUser(r)
	if err != nil {
		writeError(w, http.StatusUnauthorized, "Sesi tidak valid")
		return
	}

	insp, err := h.repo.GetInspection(r.Context(), id)
	if err != nil {
		if errors.Is(err, ErrNotFound) {
			writeError(w, http.StatusNotFound, "Data inspeksi tidak ditemukan")
			return
		}
		log.Printf("GetInspection failed for ID %s: %v", id, err)
		writeError(w, http.StatusInternalServerError, "Gagal memuat detail data inspeksi")
		return
	}

	writeJSON(w, http.StatusOK, JSONResponse{
		Success: true,
		Data:    insp,
	})
}
func (h *Handler) UpdateInspection(w http.ResponseWriter, r *http.Request, id string) {
	user, err := h.getAuthenticatedUser(r)
	if err != nil {
		writeError(w, http.StatusUnauthorized, "Sesi tidak valid")
		return
	}
	if user.Role != RoleSupervisor && user.Role != RoleAdministrator {
		writeError(w, http.StatusForbidden, "Hanya Supervisor/Admin yang dapat mengedit inspeksi")
		return
	}

	var input CreateInspectionInput
	if err := json.NewDecoder(r.Body).Decode(&input); err != nil {
		writeError(w, http.StatusBadRequest, "Invalid JSON input")
		return
	}

	if input.LocationID == "" || input.Shift == "" || !validInspectionCheck(input.CheckPersonel) || !validInspectionCheck(input.CheckRuangan) || !validInspectionCheck(input.CheckPeralatan) {
		writeError(w, http.StatusBadRequest, "Lokasi, Shift, dan status pemeriksaan OK/NOK wajib diisi")
		return
	}

	existing, err := h.repo.GetInspection(r.Context(), id)
	if err != nil {
		writeError(w, http.StatusNotFound, "Data inspeksi tidak ditemukan")
		return
	}

	inspDate := existing.Date
	if input.Date != "" {
		if parsed, err := time.Parse("2006-01-02", input.Date); err == nil {
			inspDate = parsed
		}
	}

	updatedInsp := &Inspection{
		ID:             id,
		LocationID:     input.LocationID,
		Shift:          input.Shift,
		CheckPersonel:  input.CheckPersonel,
		CheckRuangan:   input.CheckRuangan,
		CheckPeralatan: input.CheckPeralatan,
		KetPersonel:    input.KetPersonel,
		KetRuangan:     input.KetRuangan,
		KetPeralatan:   input.KetPeralatan,
		Date:           inspDate,
		LastEditedByID: user.ID,
	}

	audit := &AuditLog{
		ID:        fmt.Sprintf("AUD-%d", time.Now().UnixNano()),
		User:      user.Username,
		Action:    AuditActionUpdate,
		Detail:    fmt.Sprintf("Revision update executed on inspection %s", id),
		IPAddress: getIPAddress(r),
	}

	err = h.repo.UpdateInspectionForRevision(r.Context(), updatedInsp, audit)
	if err != nil {
		log.Printf("UpdateInspection revision failed for ID %s: %v", id, err)
		writeError(w, http.StatusInternalServerError, fmt.Sprintf("Gagal mengupdate revisi inspeksi: %v", err))
		return
	}

	writeJSON(w, http.StatusOK, JSONResponse{
		Success: true,
		Message: "Data inspeksi berhasil direvisi. Status dikembalikan ke SUBMITTED untuk verifikasi ulang.",
	})
}

func validInspectionCheck(value string) bool {
	return value == "OK" || value == "NOK"
}

// ============================================================================
// USER MANAGEMENT HANDLERS (ADMIN ONLY)
// ============================================================================

type CreateUserRequest struct {
	FullName    string   `json:"fullName"`
	Username    string   `json:"username"`
	Password    string   `json:"password"`
	OldPassword string   `json:"oldPassword"`
	Role        UserRole `json:"role"`
	Department  string   `json:"department"`
	Site        string   `json:"site"`
	Status      string   `json:"status"`
}

const defaultUserPassword = "Bintang7!@#"

func (h *Handler) GetUsers(w http.ResponseWriter, r *http.Request) {
	admin, err := h.getAuthenticatedUser(r)
	if err != nil || admin.Role != RoleAdministrator {
		writeError(w, http.StatusForbidden, "Akses khusus Administrator")
		return
	}

	users, err := h.repo.GetUsers(r.Context())
	if err != nil {
		writeError(w, http.StatusInternalServerError, "Gagal memuat daftar pengguna")
		return
	}

	data := make([]UserResponse, 0, len(users))

	for i := range users {
		data = append(data, users[i].ToResponse())
	}

	writeJSON(w, http.StatusOK, JSONResponse{
		Success: true,
		Data:    data,
	})
}

func (h *Handler) CreateUser(w http.ResponseWriter, r *http.Request) {
	admin, err := h.getAuthenticatedUser(r)
	if err != nil || admin.Role != RoleAdministrator {
		writeError(w, http.StatusForbidden, "Akses khusus Administrator")
		return
	}

	var req CreateUserRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeError(w, http.StatusBadRequest, "Invalid JSON input")
		return
	}

	switch strings.ToLower(strings.TrimSpace(string(req.Role))) {
	case "administrator":
		req.Role = RoleAdministrator
	case "manager":
		req.Role = RoleManager
	case "supervisor":
		req.Role = RoleSupervisor
	case "staff":
		req.Role = RoleStaff
	default:
		writeError(w, http.StatusBadRequest, "Role tidak valid")
		return
	}

	if err := validatePasswordComplexity(req.Password); err != nil {
		writeError(w, http.StatusBadRequest, err.Error())
		return
	}

	hash, err := bcrypt.GenerateFromPassword([]byte(req.Password), bcrypt.DefaultCost)
	if err != nil {
		writeError(w, http.StatusInternalServerError, "Gagal mengamankan password")
		return
	}

	newUser := &User{
		ID:             fmt.Sprintf("USR-%d", time.Now().UnixNano()),
		FullName:       req.FullName,
		Username:       req.Username,
		PasswordHash:   string(hash),
		Role:           req.Role,
		Department:     req.Department,
		Site:           req.Site,
		Status:         UserStatusActive,
		FailedAttempts: 0,
	}

	if err := h.repo.CreateUser(r.Context(), newUser); err != nil {
		log.Printf("[CREATE USER ERROR] username=%q role=%q department=%q site=%q: %v",
			newUser.Username,
			newUser.Role,
			newUser.Department,
			newUser.Site,
			err,
		)

		writeError(w, http.StatusInternalServerError, err.Error())
		return
	}

	_ = h.repo.CreateAuditLog(r.Context(), &AuditLog{
		ID:        fmt.Sprintf("AUD-%d", time.Now().UnixNano()),
		User:      admin.Username,
		Action:    AuditActionCreate,
		Detail:    fmt.Sprintf("Created new user %s with role %s", newUser.Username, newUser.Role),
		IPAddress: getIPAddress(r),
	})

	writeJSON(w, http.StatusCreated, JSONResponse{Success: true, Message: "User berhasil dibuat", Data: newUser.ToResponse()})
}

func (h *Handler) UpdateUser(w http.ResponseWriter, r *http.Request, id string) {
	admin, err := h.getAuthenticatedUser(r)
	if err != nil || admin.Role != RoleAdministrator {
		writeError(w, http.StatusForbidden, "Akses khusus Administrator")
		return
	}

	var req CreateUserRequest

	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeError(w, http.StatusBadRequest, "Invalid JSON input")
		return
	}

	if strings.TrimSpace(req.FullName) == "" ||
		strings.TrimSpace(req.Username) == "" ||
		strings.TrimSpace(req.Department) == "" ||
		strings.TrimSpace(req.Site) == "" {
		writeError(w, http.StatusBadRequest, "Data user wajib diisi lengkap")
		return
	}

	switch strings.ToLower(strings.TrimSpace(string(req.Role))) {
	case "administrator":
		req.Role = RoleAdministrator
	case "manager":
		req.Role = RoleManager
	case "supervisor":
		req.Role = RoleSupervisor
	case "staff":
		req.Role = RoleStaff
	default:
		writeError(w, http.StatusBadRequest, "Role tidak valid")
		return
	}

	user, err := h.repo.FindUserByID(r.Context(), id)
	if err != nil {
		writeError(w, http.StatusNotFound, "User tidak ditemukan")
		return
	}
	if req.Password != "" && !CheckPasswordHash(req.OldPassword, user.PasswordHash) {
		writeError(w, http.StatusBadRequest, "Password lama akun tidak sesuai")
		return
	}

	user.FullName = strings.TrimSpace(req.FullName)
	user.Username = strings.TrimSpace(req.Username)
	user.Role = req.Role
	user.Department = strings.TrimSpace(req.Department)
	user.Site = strings.TrimSpace(req.Site)

	if req.Password != "" {
		if err := validatePasswordComplexity(req.Password); err != nil {
			writeError(w, http.StatusBadRequest, err.Error())
			return
		}

		hash, err := bcrypt.GenerateFromPassword(
			[]byte(req.Password),
			bcrypt.DefaultCost,
		)
		if err != nil {
			writeError(w, http.StatusInternalServerError, "Gagal mengamankan password")
			return
		}

		user.PasswordHash = string(hash)
	} else {
		user.PasswordHash = ""
	}

	if req.Status != "" {
		user.Status = UserStatus(strings.ToUpper(strings.TrimSpace(req.Status)))
	}

	if err := h.repo.UpdateUser(r.Context(), user); err != nil {
		writeError(w, http.StatusInternalServerError, "Gagal memperbarui data pengguna")
		return
	}

	_ = h.repo.CreateAuditLog(r.Context(), &AuditLog{
		ID:        fmt.Sprintf("AUD-%d", time.Now().UnixNano()),
		User:      admin.Username,
		Action:    AuditActionUpdate,
		Detail:    fmt.Sprintf("Updated user ID: %s", id),
		IPAddress: getIPAddress(r),
	})

	writeJSON(w, http.StatusOK, JSONResponse{
		Success: true,
		Message: "Data user berhasil diperbarui",
		Data:    user.ToResponse(),
	})
}

func (h *Handler) ResetUserPassword(w http.ResponseWriter, r *http.Request, id string) {
	admin, err := h.getAuthenticatedUser(r)
	if err != nil || admin.Role != RoleAdministrator {
		writeError(w, http.StatusForbidden, "Akses khusus Administrator")
		return
	}

	user, err := h.repo.FindUserByID(r.Context(), id)
	if err != nil {
		writeError(w, http.StatusNotFound, "Pengguna tidak ditemukan")
		return
	}

	hash, err := bcrypt.GenerateFromPassword([]byte(defaultUserPassword), bcrypt.DefaultCost)
	if err != nil {
		writeError(w, http.StatusInternalServerError, "Gagal mengamankan password default")
		return
	}
	user.PasswordHash = string(hash)
	if err := h.repo.UpdateUser(r.Context(), user); err != nil {
		writeError(w, http.StatusInternalServerError, "Gagal mereset password pengguna")
		return
	}

	if err := h.repo.CreateAuditLog(r.Context(), &AuditLog{
		ID:        fmt.Sprintf("AUD-%d", time.Now().UnixNano()),
		User:      admin.Username,
		Action:    AuditActionUpdate,
		Detail:    fmt.Sprintf("Password pengguna %s direset ke password default oleh administrator", user.Username),
		IPAddress: getIPAddress(r),
	}); err != nil {
		log.Printf("Gagal mencatat audit reset password untuk pengguna %s: %v", id, err)
	}

	writeJSON(w, http.StatusOK, JSONResponse{
		Success: true,
		Message: "Password pengguna berhasil direset ke password default",
	})
}

func (h *Handler) DeactivateUser(w http.ResponseWriter, r *http.Request, id string) {
	admin, err := h.getAuthenticatedUser(r)
	if err != nil || admin.Role != RoleAdministrator {
		writeError(w, http.StatusForbidden, "Akses khusus Administrator")
		return
	}

	if err := h.repo.DeactivateUser(r.Context(), id); err != nil {
		writeError(w, http.StatusInternalServerError, "Gagal menonaktifkan akun user")
		return
	}

	_ = h.repo.CreateAuditLog(r.Context(), &AuditLog{
		ID:        fmt.Sprintf("AUD-%d", time.Now().UnixNano()),
		User:      admin.Username,
		Action:    AuditActionDeactivate,
		Detail:    fmt.Sprintf("Deactivated user ID: %s (Status set to INACTIVE)", id),
		IPAddress: getIPAddress(r),
	})

	writeJSON(w, http.StatusOK, JSONResponse{Success: true, Message: "Akun user berhasil dinonaktifkan"})
}

// ============================================================================
// REPORT & AUDIT HANDLERS
// ============================================================================

func (h *Handler) GetReports(w http.ResponseWriter, r *http.Request) {
	_, err := h.getAuthenticatedUser(r)
	if err != nil {
		writeError(w, http.StatusUnauthorized, "Sesi tidak valid")
		return
	}

	filter := InspectionFilter{}
	if status := strings.TrimSpace(r.URL.Query().Get("status")); status != "" {
		filter.Status = &status
	}
	if locationID := strings.TrimSpace(r.URL.Query().Get("location")); locationID != "" {
		filter.LocationID = &locationID
	} else if locationID := strings.TrimSpace(r.URL.Query().Get("locationId")); locationID != "" {
		filter.LocationID = &locationID
	}
	if dateValue := strings.TrimSpace(r.URL.Query().Get("date")); dateValue != "" {
		date, err := time.ParseInLocation("2006-01-02", dateValue, jakartaLocation())
		if err != nil {
			writeError(w, http.StatusBadRequest, "Format tanggal filter tidak valid")
			return
		}
		filter.Date = &date
	}
	if monthStr := r.URL.Query().Get("month"); monthStr != "" {
		if m, err := strconv.Atoi(monthStr); err == nil {
			filter.Month = &m
		}
	}
	if yearStr := r.URL.Query().Get("year"); yearStr != "" {
		if y, err := strconv.Atoi(yearStr); err == nil {
			filter.Year = &y
		}
	}
	if loc := r.URL.Query().Get("locationId"); loc != "" {
		filter.LocationID = &loc
	}

	reports, err := h.repo.GetInspectionReport(r.Context(), filter)
	if err != nil {
		writeError(w, http.StatusInternalServerError, "Gagal mengambil data laporan")
		return
	}
	sortInspectionReport(reports, reportSortOrderFromQuery(r))

	w.Header().Set("Cache-Control", "no-store, no-cache, must-revalidate")
	w.Header().Set("Pragma", "no-cache")
	w.Header().Set("Expires", "0")
	writeJSON(w, http.StatusOK, JSONResponse{Success: true, Data: reports})
}

func reportSortOrderFromQuery(r *http.Request) string {
	if r.URL.Query().Get("sortOrder") == "newest" {
		return "newest"
	}
	return "oldest"
}

func sortInspectionReport(reports []Inspection, sortOrder string) {
	sort.SliceStable(reports, func(i, j int) bool {
		return inspectionReportLess(reports[i], reports[j], sortOrder)
	})
}

func inspectionReportLess(left, right Inspection, sortOrder string) bool {
	leftDate := left.Date.In(jakartaLocation()).Format("2006-01-02")
	rightDate := right.Date.In(jakartaLocation()).Format("2006-01-02")
	if leftDate != rightDate {
		if sortOrder == "newest" {
			return leftDate > rightDate
		}
		return leftDate < rightDate
	}

	leftShift := strings.TrimSpace(left.Shift)
	rightShift := strings.TrimSpace(right.Shift)
	leftShiftNumber, leftErr := strconv.Atoi(leftShift)
	rightShiftNumber, rightErr := strconv.Atoi(rightShift)
	if leftErr == nil && rightErr == nil && leftShiftNumber != rightShiftNumber {
		return leftShiftNumber < rightShiftNumber
	}
	return leftShift < rightShift
}

func (h *Handler) ExportInspectionPDF(w http.ResponseWriter, r *http.Request) {
	user, err := h.getAuthenticatedUser(r)
	if err != nil {
		writeError(w, http.StatusUnauthorized, "Sesi tidak valid")
		return
	}

	monthStr := r.URL.Query().Get("month")
	yearStr := r.URL.Query().Get("year")

	month, err := strconv.Atoi(monthStr)
	if err != nil || month < 1 || month > 12 {
		writeError(w, http.StatusBadRequest, "Parameter month tidak valid")
		return
	}

	year, err := strconv.Atoi(yearStr)
	if err != nil || year < 2000 {
		writeError(w, http.StatusBadRequest, "Parameter year tidak valid")
		return
	}

	filter := InspectionFilter{
		Month: &month,
		Year:  &year,
	}

	locationID := r.URL.Query().Get("locationId")
	if locationID != "" {
		filter.LocationID = &locationID
	}

	reports, err := h.repo.GetInspectionReport(r.Context(), filter)
	if err != nil {
		writeError(w, http.StatusInternalServerError, "Gagal mengambil data laporan")
		return
	}
	sortInspectionReport(reports, "oldest")

	// Konversi []Inspection menjadi []*Inspection
	inspectionPtrs := make([]*Inspection, len(reports))
	for i := range reports {
		inspectionPtrs[i] = &reports[i]
	}

	locationName := ""
	if locationID != "" {
		locations, err := h.repo.GetLocations(r.Context())
		if err == nil {
			for _, loc := range locations {
				if loc.ID == locationID {
					locationName = loc.Name
					break
				}
			}
		}
	}

	printedBy := user.Username
	if user.FullName != "" {
		printedBy = user.FullName
	}

	pdfBytes, err := GenerateInspectionPDFReport(
		inspectionPtrs,
		PDFReportRequest{
			Month:     month,
			Year:      year,
			Location:  locationName,
			PrintedBy: printedBy,
		},
	)
	if err != nil {
		writeError(w, http.StatusInternalServerError, "Gagal membuat PDF laporan")
		return
	}

	w.Header().Set("Content-Type", "application/pdf")
	w.Header().Set("Cache-Control", "no-store, no-cache, must-revalidate")
	w.Header().Set("Pragma", "no-cache")
	w.Header().Set("Expires", "0")
	w.Header().Set(
		"Content-Disposition",
		fmt.Sprintf(`inline; filename="laporan-inspeksi-%04d-%02d.pdf"`, year, month),
	)
	w.WriteHeader(http.StatusOK)

	if err := WritePDFResponse(w, pdfBytes); err != nil {
		return
	}
}

func (h *Handler) GetAuditLogs(w http.ResponseWriter, r *http.Request) {
	user, err := h.getAuthenticatedUser(r)
	if err != nil {
		writeError(w, http.StatusUnauthorized, "Sesi tidak valid")
		return
	}

	if user.Role != RoleSupervisor &&
		user.Role != RoleManager &&
		user.Role != RoleAdministrator {
		writeError(w, http.StatusForbidden, "Akses Audit Trail dibatasi")
		return
	}

	const limit = 50

	page := 1
	if rawPage := r.URL.Query().Get("page"); rawPage != "" {
		if parsed, err := strconv.Atoi(rawPage); err == nil && parsed > 0 {
			page = parsed
		}
	}

	offset := (page - 1) * limit

	userFilter := strings.TrimSpace(r.URL.Query().Get("user"))

	logs, err := h.repo.GetAuditLogs(
		r.Context(),
		limit,
		offset,
		userFilter,
	)
	if err != nil {
		writeError(w, http.StatusInternalServerError, "Gagal mengambil audit trail")
		return
	}

	total, err := h.repo.GetAuditLogsCount(
		r.Context(),
		userFilter,
	)
	if err != nil {
		writeError(w, http.StatusInternalServerError, "Gagal menghitung audit trail")
		return
	}

	totalPages := 0
	if total > 0 {
		totalPages = (total + limit - 1) / limit
	}

	writeJSON(w, http.StatusOK, map[string]interface{}{
		"success": true,
		"data":    logs,
		"pagination": map[string]interface{}{
			"page":       page,
			"limit":      limit,
			"total":      total,
			"totalPages": totalPages,
		},
	})
}
