'use client';

import React, { useState, useEffect, FormEvent, ChangeEvent, Suspense } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Sidebar from '../sidebar';

interface MissedEntryFormContentProps {
  entryType: 'weekly' | 'shift';
  initialShift: string;
  initialDate: string;
  lastShift: string;
  lastDate: string;
  locationId: string;
  weekStart: string;
  weekEnd: string;
  flexibleShiftThree: boolean;
  availableFrom: string;
  availableThrough: string;
}

interface Location {
  id: string;
  name: string;
}

function MissedEntryFormContent({
  entryType,
  initialShift,
  initialDate,
  lastShift,
  lastDate,
  locationId,
  weekStart,
  weekEnd,
  flexibleShiftThree,
  availableFrom,
  availableThrough,
}: MissedEntryFormContentProps) {
  const router = useRouter();
  const isWeekly = entryType === 'weekly';

  // Redirect ke pemilihan lokasi jika locationId kosong
  useEffect(() => {
    if (!locationId) {
      router.replace('/selectlokasi?next=keterangan');
    }
  }, [locationId, router]);

  // Form States
  const [date, setDate] = useState<string>('');
  const [shift, setShift] = useState<string>(initialShift);
  const [reason, setReason] = useState<string>('');
  const [locationName, setLocationName] = useState<string>('Memuat lokasi...');

  // UI States
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  // Set default tanggal hari ini (YYYY-MM-DD) berdasarkan GMT+7
  useEffect(() => {
    const today = new Date();
    // Menggunakan offset Jakarta (GMT+7)
    const options: Intl.DateTimeFormatOptions = {
      timeZone: 'Asia/Jakarta',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
    };
    const formatter = new Intl.DateTimeFormat('en-CA', options); // Format YYYY-MM-DD
    setDate(initialDate || formatter.format(today));
  }, [initialDate]);

  useEffect(() => {
    if (!locationId) return;

    const fetchLocationName = async () => {
      try {
        const response = await fetch('/api/locations');
        if (!response.ok) return;

        const result: { success: boolean; data: Location[] } = await response.json();
        const location = result.data?.find((item) => item.id === locationId);
        setLocationName(location?.name || locationId);
      } catch (error) {
        setLocationName(locationId);
      }
    };

    fetchLocationName();
  }, [locationId]);

  const validateForm = (): boolean => {
    if (!locationId) {
      return false;
    }

    if (!date) {
      setError('Tanggal wajib diisi.');
      return false;
    }

    if (!isWeekly && !shift) {
      setError('Shift yang terlewat wajib dipilih.');
      return false;
    }

    if (isWeekly && (date < weekStart || date > weekEnd)) {
      setError('Tanggal harus berada dalam periode Entry Terlewat Mingguan yang ditampilkan.');
      return false;
    }

    if (flexibleShiftThree && (date < availableFrom || date > availableThrough)) {
      setError('Tanggal penyelesaian Shift 3 harus berada dalam rentang yang ditampilkan.');
      return false;
    }

    if (reason !== 'Lupa' && reason !== 'Hari Libur' && reason !== 'Tidak dilakukan') {
      setError('Alasan terlewatnya inspeksi wajib diisi.');
      return false;
    }

    return true;
  };

  const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setError(null);

    if (!validateForm()) {
      return;
    }

    setIsSubmitting(true);

    const payload = {
      entryType,
      locationId: locationId,
      date: date,
      shift: shift,
      missedReason: reason.trim(),
      weekStart,
      weekEnd,
    };

    try {
      const response = await fetch('/api/inspections/missed-entry', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      });

      if (response.status === 401) {
        router.push('/login');
        return;
      }

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        setError(errorData.error || errorData.message || 'Gagal menyimpan Entry Terlewat.');
        setIsSubmitting(false);
        return;
      }

      router.push('/selectlokasi');
    } catch (err) {
      setError('Terjadi kesalahan koneksi ke server. Silakan coba lagi.');
      setIsSubmitting(false);
    }
  };

  return (
    <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200/80 shadow-sm max-w-2xl">
      {/* Header Form */}
      <div className="pb-6 border-b border-slate-100">
        <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
          {isWeekly ? 'Form Entry Terlewat Mingguan' : 'Form Shift Terlewat Inspeksi'}
        </h1>
        <p className="text-sm text-slate-500 mt-1">
          {isWeekly
            ? `Minggu ${weekStart.split('-').reverse().join('/')} sampai ${weekEnd.split('-').reverse().join('/')}. Satu kali pengiriman membuat catatan Shift 1, 2, dan 3.`
            : flexibleShiftThree
            ? `Shift 3 terlewat ini dapat dilengkapi pada tanggal ${availableFrom.split('-').reverse().join('/')} sampai ${availableThrough.split('-').reverse().join('/')}. Catatan tetap terkait dengan tanggal Shift 3 yang terlewat.`
            : 'Catat shift yang terlewat terlebih dahulu; setelah itu shift aktif dapat diisi seperti biasa.'}
        </p>
      </div>

      {/* Error Alert */}
      {error && (
        <div className="mt-6 bg-rose-50 border border-rose-200 text-rose-700 p-4 rounded-xl text-sm">
          <p className="font-semibold">Validasi Gagal</p>
          <p className="mt-0.5">{error}</p>
        </div>
      )}

      <form onSubmit={handleSubmit} className="mt-6 space-y-6">
        {!isWeekly && lastShift && lastDate && (
          <div className="rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-900">
            Anda terakhir melakukan pengisian shift {lastShift} tanggal {lastDate.split('-').reverse().join('/')}.
            Shift {shift} belum diisi.
          </div>
        )}

        {/* Lokasi */}
        <div>
          <label htmlFor="locationName" className="block text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1.5">
            Lokasi <span className="text-rose-500">*</span>
          </label>
          <input
            type="text"
            id="locationName"
            value={locationName}
            disabled
            readOnly
            className="w-full rounded-xl border border-slate-300 bg-slate-100 px-3.5 py-2.5 text-slate-700 text-sm font-medium"
          />
        </div>

        {/* Tanggal Terlewat */}
        <div>
          <label htmlFor="date" className="block text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1.5">
            Tanggal Terlewat <span className="text-rose-500">*</span>
          </label>
          <input
            type="date"
            id="date"
            name="date"
            value={date}
            onChange={(e: ChangeEvent<HTMLInputElement>) => setDate(e.target.value)}
            min={isWeekly ? weekStart : flexibleShiftThree ? availableFrom : undefined}
            max={isWeekly ? weekEnd : flexibleShiftThree ? availableThrough : undefined}
            disabled={!isWeekly && !flexibleShiftThree}
            className="w-full rounded-xl border border-slate-300 bg-white px-3.5 py-2.5 text-slate-800 text-sm focus:border-sky-500 focus:ring-2 focus:ring-sky-500/20 focus:outline-none disabled:bg-slate-100 transition-all"
          />
        </div>

        {/* Shift Terlewat */}
        {!isWeekly && <div>
          <label htmlFor="shift" className="block text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1.5">
            Shift Terlewat <span className="text-rose-500">*</span>
          </label>
          <select
            id="shift"
            name="shift"
            value={shift}
            onChange={(e: ChangeEvent<HTMLSelectElement>) => setShift(e.target.value)}
            disabled
            className="w-full rounded-xl border border-slate-300 bg-white px-3.5 py-2.5 text-slate-800 text-sm focus:border-sky-500 focus:ring-2 focus:ring-sky-500/20 focus:outline-none disabled:bg-slate-100 transition-all"
          >
            <option value="">-- Pilih Shift --</option>
            <option value="1">Shift 1</option>
            <option value="2">Shift 2</option>
            <option value="3">Shift 3</option>
          </select>
        </div>}

        {/* Alasan Terlewat */}
        <div>
          <label htmlFor="reason" className="block text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1.5">
            Alasan Terlewat <span className="text-rose-500">*</span>
          </label>
          <select
            id="reason"
            name="reason"
            value={reason}
            onChange={(e: ChangeEvent<HTMLSelectElement>) => setReason(e.target.value)}
            disabled={isSubmitting}
            className="w-full rounded-xl border border-slate-300 bg-white px-3.5 py-2.5 text-slate-800 text-sm focus:border-sky-500 focus:ring-2 focus:ring-sky-500/20 focus:outline-none disabled:bg-slate-100 transition-all"
          >
            <option value="">-- Pilih Alasan --</option>
            <option value="Lupa">Lupa</option>
            <option value="Hari Libur">Hari Libur</option>
            <option value="Tidak dilakukan">Tidak dilakukan</option>
          </select>
        </div>

        {/* Action Buttons */}
        <div className="pt-4 flex items-center justify-end gap-3 border-t border-slate-100">
          <button
            type="button"
            onClick={() => router.push('/dashboard')}
            disabled={isSubmitting}
            className="px-5 py-2.5 border border-slate-300 rounded-xl text-sm font-semibold text-slate-700 bg-white hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-sky-500/20 disabled:opacity-50 transition-all"
          >
            Batal
          </button>
          <button
            type="submit"
            disabled={isSubmitting}
            className="px-6 py-2.5 rounded-xl text-sm font-semibold text-white bg-sky-600 hover:bg-sky-700 focus:outline-none focus:ring-2 focus:ring-sky-500/20 disabled:bg-slate-300 transition-all shadow-sm"
          >
            {isSubmitting ? 'Menyimpan...' : isWeekly ? 'Selesaikan Entry Terlewat Mingguan' : 'Simpan Shift Terlewat'}
          </button>
        </div>
      </form>
    </div>
  );
}

function KeteranganPageWrapper() {
  const searchParams = useSearchParams();
  const shiftQuery = searchParams.get('shift') || '';
  const dateQuery = searchParams.get('date') || '';
  const entryTypeQuery = searchParams.get('entryType') === 'weekly' ? 'weekly' : 'shift';
  const lastShiftQuery = searchParams.get('lastShift') || '';
  const lastDateQuery = searchParams.get('lastDate') || '';
  const locationId = searchParams.get('locationId') || '';
  const weekStart = searchParams.get('weekStart') || '';
  const weekEnd = searchParams.get('weekEnd') || '';
  const flexibleShiftThree = searchParams.get('flexibleShiftThree') === 'true';
  const availableFrom = searchParams.get('availableFrom') || '';
  const availableThrough = searchParams.get('availableThrough') || '';

  return (
    <MissedEntryFormContent
      entryType={entryTypeQuery}
      initialShift={shiftQuery}
      initialDate={dateQuery}
      lastShift={lastShiftQuery}
      lastDate={lastDateQuery}
      locationId={locationId}
      weekStart={weekStart}
      weekEnd={weekEnd}
      flexibleShiftThree={flexibleShiftThree}
      availableFrom={availableFrom}
      availableThrough={availableThrough}
    />
  );
}

export default function KeteranganPage() {
  return (
    <div className="min-h-screen bg-slate-50">
      {/* Sidebar Navigation */}
      <Suspense fallback={null}>
        <Sidebar />
      </Suspense>

      {/* Main Area */}
      <div className="lg:ml-72 min-h-screen transition-all duration-300">
        <main className="p-4 sm:p-6 lg:p-8">
          <Suspense
            fallback={
              <div className="bg-white p-8 rounded-2xl border border-slate-200/80 shadow-sm text-center py-12 max-w-2xl">
                <p className="text-sm text-slate-500 font-medium">Memuat formulir Entry Terlewat...</p>
              </div>
            }
          >
            <KeteranganPageWrapper />
          </Suspense>
        </main>
      </div>
    </div>
  );
}