package main

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"time"

	"github.com/lib/pq"
)

// Standard Domain Errors for Repository Layer
var (
	ErrNotFound                = errors.New("record not found")
	ErrInvalidStatusTransition = errors.New("invalid inspection status transition")
	ErrDatabaseOp              = errors.New("database operation failed")
	// ErrDuplicateInspectionSlot: slot (lokasi, tanggal, shift) sudah terisi.
	// Muncul dari unique index uq_inspections_location_date_shift (PostgreSQL
	// 23505) — pagar terakhir untuk submit ganda yang balapan (race condition):
	// dua request bersamaan bisa sama-sama lolos cek "sudah terisi" sebelum
	// salah satu menyimpan, jadi database yang memutuskan satu pemenang.
	ErrDuplicateInspectionSlot = errors.New("inspection slot already exists")
)

// isUniqueViolation melaporkan apakah err adalah unique_violation PostgreSQL (23505).
func isUniqueViolation(err error) bool {
	var pqErr *pq.Error
	return errors.As(err, &pqErr) && pqErr.Code == "23505"
}

// InspectionFilter struct untuk parameter pencarian & filter laporan
type InspectionFilter struct {
	LocationID *string
	Shift      *string
	Status     *string
	Department *string
	CreatedBy  *string
	Date       *time.Time
	Month      *int
	Year       *int
	StartDate  *time.Time
	EndDate    *time.Time
	MissedType *string
}

// Repository interface mendefinisikan seluruh kontrak akses database
type Repository interface {
	// AUTH / USER
	FindUserByUsername(ctx context.Context, username string) (*User, error)
	FindUserByID(ctx context.Context, id string) (*User, error)
	GetUsers(ctx context.Context) ([]User, error)
	CreateUser(ctx context.Context, user *User) error
	UpdateUser(ctx context.Context, user *User) error
	DeactivateUser(ctx context.Context, id string) error
	UpdateFailedAttempts(ctx context.Context, userID string, attempts int, status UserStatus) error

	// MASTER DATA
	GetLocations(ctx context.Context) ([]Location, error)
	GetDepartments(ctx context.Context) ([]Department, error)
	GetSites(ctx context.Context) ([]Site, error)

	// INSPECTION
	GenerateInspectionID(ctx context.Context, inspDate time.Time) (string, error)
	GetLatestInspectionForLocation(ctx context.Context, locationID string) (time.Time, string, error)
	CreateInspection(ctx context.Context, insp *Inspection) error
	GetInspection(ctx context.Context, id string) (*Inspection, error)
	ListInspections(ctx context.Context, filter InspectionFilter) ([]Inspection, error)
	UpdateInspectionForRevision(ctx context.Context, insp *Inspection, audit *AuditLog) error

	// APPROVAL
	ApproveSupervisor(ctx context.Context, id string, supervisorID string, audit *AuditLog) error

	// MISSED ENTRY
	CreateMissedEntry(ctx context.Context, insp *Inspection) error
	CreateWeeklyMissedEntries(ctx context.Context, inspections []*Inspection) error
	UpdateMissedEntry(ctx context.Context, id string, reason string, newDate *time.Time, editorID string, audit *AuditLog) (int, error)

	// AUDIT
	CreateAuditLog(ctx context.Context, log *AuditLog) error
	GetAuditLogs(ctx context.Context, limit int, offset int, userFilter string, dateFilter string, actionFilter string) ([]AuditLog, error)
	GetAuditLogsCount(ctx context.Context, userFilter string, dateFilter string, actionFilter string) (int, error)

	// REPORT
	GetInspectionReport(ctx context.Context, filter InspectionFilter) ([]Inspection, error)
}

func (r *PostgresRepository) GetLatestInspectionForLocation(ctx context.Context, locationID string) (time.Time, string, error) {
	query := `
        SELECT date, shift
        FROM inspections
        WHERE location_id = $1
        ORDER BY date DESC, created_at DESC, id DESC
        LIMIT 1
    `

	var lastDate time.Time
	var lastShift string
	err := r.db.QueryRowContext(ctx, query, locationID).Scan(&lastDate, &lastShift)
	if err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return time.Time{}, "", ErrNotFound
		}
		return time.Time{}, "", fmt.Errorf("GetLatestInspectionForLocation error: %w", err)
	}
	return lastDate, lastShift, nil
}

// PostgresRepository implementasi Repository menggunakan *sql.DB
type PostgresRepository struct {
	db *sql.DB
}

// NewPostgresRepository membuat instance PostgresRepository baru
func NewPostgresRepository(db *sql.DB) *PostgresRepository {
	return &PostgresRepository{db: db}
}

// ============================================================================
// AUTH & USER OPERATIONS
// ============================================================================

func (r *PostgresRepository) FindUserByUsername(ctx context.Context, username string) (*User, error) {
	query := `
        SELECT
            u.id,
            u.full_name,
            u.username,
            u.password_hash,
            u.role,
            COALESCE(d.name, '') AS department,
            COALESCE(s.name, '') AS site,
            u.status,
            u.failed_attempts,
            u.created_at,
            u.updated_at
        FROM users u
        LEFT JOIN departments d ON d.id = u.department_id
        LEFT JOIN sites s ON s.id = u.site_id
        WHERE LOWER(u.username) = LOWER($1)
    `
	user := &User{}
	err := r.db.QueryRowContext(ctx, query, username).Scan(
		&user.ID,
		&user.FullName,
		&user.Username,
		&user.PasswordHash,
		&user.Role,
		&user.Department,
		&user.Site,
		&user.Status,
		&user.FailedAttempts,
		&user.CreatedAt,
		&user.UpdatedAt,
	)
	if err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, ErrNotFound
		}
		return nil, fmt.Errorf("FindUserByUsername error: %w", err)
	}
	return user, nil
}

func (r *PostgresRepository) FindUserByID(ctx context.Context, id string) (*User, error) {
	query := `
        SELECT
            u.id,
            u.full_name,
            u.username,
            u.password_hash,
            u.role,
            COALESCE(d.name, '') AS department,
            COALESCE(s.name, '') AS site,
            u.status,
            u.failed_attempts,
            u.created_at,
            u.updated_at
        FROM users u
        LEFT JOIN departments d ON d.id = u.department_id
        LEFT JOIN sites s ON s.id = u.site_id
        WHERE u.id = $1
    `
	user := &User{}
	err := r.db.QueryRowContext(ctx, query, id).Scan(
		&user.ID,
		&user.FullName,
		&user.Username,
		&user.PasswordHash,
		&user.Role,
		&user.Department,
		&user.Site,
		&user.Status,
		&user.FailedAttempts,
		&user.CreatedAt,
		&user.UpdatedAt,
	)
	if err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, ErrNotFound
		}
		return nil, fmt.Errorf("FindUserByID error: %w", err)
	}
	return user, nil
}

func (r *PostgresRepository) GetUsers(ctx context.Context) ([]User, error) {
	query := `
        SELECT
            u.id,
            u.full_name,
            u.username,
            u.password_hash,
            u.role,
            COALESCE(d.name, '') AS department,
            COALESCE(s.name, '') AS site,
            u.status,
            u.failed_attempts,
            u.created_at,
            u.updated_at
        FROM users u
        LEFT JOIN departments d ON d.id = u.department_id
        LEFT JOIN sites s ON s.id = u.site_id
        ORDER BY u.created_at DESC
    `

	rows, err := r.db.QueryContext(ctx, query)
	if err != nil {
		return nil, fmt.Errorf("GetUsers error: %w", err)
	}
	defer rows.Close()

	users := make([]User, 0)

	for rows.Next() {
		var user User

		if err := rows.Scan(
			&user.ID,
			&user.FullName,
			&user.Username,
			&user.PasswordHash,
			&user.Role,
			&user.Department,
			&user.Site,
			&user.Status,
			&user.FailedAttempts,
			&user.CreatedAt,
			&user.UpdatedAt,
		); err != nil {
			return nil, fmt.Errorf("GetUsers scan error: %w", err)
		}

		users = append(users, user)
	}

	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("GetUsers rows error: %w", err)
	}

	return users, nil
}

func (r *PostgresRepository) CreateUser(ctx context.Context, user *User) error {
	query := `
        INSERT INTO users (
            id,
            full_name,
            username,
            password_hash,
            role,
            department_id,
            site_id,
            status,
            failed_attempts,
            created_at,
            updated_at
        )
        SELECT
            $1,
            $2,
            $3,
            $4,
            $5,
            d.id,
            s.id,
            $8,
            $9,
            $10,
            $11
        FROM departments d
        JOIN sites s ON s.name = $7
        WHERE d.name = $6
    `

	now := time.Now().UTC()
	user.CreatedAt = now
	user.UpdatedAt = now

	res, err := r.db.ExecContext(
		ctx,
		query,
		user.ID,
		user.FullName,
		user.Username,
		user.PasswordHash,
		user.Role,
		user.Department,
		user.Site,
		user.Status,
		user.FailedAttempts,
		user.CreatedAt,
		user.UpdatedAt,
	)

	if err != nil {
		return fmt.Errorf("CreateUser error: %w", err)
	}

	if rows, err := res.RowsAffected(); err != nil || rows == 0 {
		if err != nil {
			return fmt.Errorf("CreateUser rows affected error: %w", err)
		}
		return fmt.Errorf("department atau site tidak ditemukan")
	}

	return nil
}

func (r *PostgresRepository) UpdateUser(ctx context.Context, user *User) error {
	now := time.Now().UTC()

	var query string
	var args []interface{}

	if user.PasswordHash != "" {
		query = `
            UPDATE users u
            SET
                full_name = $1,
                role = $2,
                password_hash = $3,
                department_id = (
                    SELECT id FROM departments WHERE name = $4
                ),
                site_id = (
                    SELECT id FROM sites WHERE name = $5
                ),
                status = $6,
                updated_at = $7
            WHERE u.id = $8
        `

		args = []interface{}{
			user.FullName,
			user.Role,
			user.PasswordHash,
			user.Department,
			user.Site,
			user.Status,
			now,
			user.ID,
		}
	} else {
		query = `
            UPDATE users u
            SET
                full_name = $1,
                role = $2,
                department_id = (
                    SELECT id FROM departments WHERE name = $3
                ),
                site_id = (
                    SELECT id FROM sites WHERE name = $4
                ),
                status = $5,
                updated_at = $6
            WHERE u.id = $7
        `

		args = []interface{}{
			user.FullName,
			user.Role,
			user.Department,
			user.Site,
			user.Status,
			now,
			user.ID,
		}
	}

	res, err := r.db.ExecContext(ctx, query, args...)
	if err != nil {
		return fmt.Errorf("UpdateUser error: %w", err)
	}

	rows, err := res.RowsAffected()
	if err != nil {
		return fmt.Errorf("UpdateUser rows affected error: %w", err)
	}

	if rows == 0 {
		return ErrNotFound
	}

	user.UpdatedAt = now
	return nil
}

func (r *PostgresRepository) DeactivateUser(ctx context.Context, id string) error {
	query := `
        UPDATE users
        SET status = $1, updated_at = $2
        WHERE id = $3
    `
	res, err := r.db.ExecContext(ctx, query, UserStatusInactive, time.Now().UTC(), id)
	if err != nil {
		return fmt.Errorf("DeactivateUser error: %w", err)
	}
	rows, err := res.RowsAffected()
	if err != nil || rows == 0 {
		return ErrNotFound
	}
	return nil
}

func (r *PostgresRepository) UpdateFailedAttempts(ctx context.Context, userID string, attempts int, status UserStatus) error {
	query := `
        UPDATE users
        SET failed_attempts = $1, status = $2, updated_at = $3
        WHERE id = $4
    `
	_, err := r.db.ExecContext(ctx, query, attempts, status, time.Now().UTC(), userID)
	if err != nil {
		return fmt.Errorf("UpdateFailedAttempts error: %w", err)
	}
	return nil
}

// ============================================================================
// MASTER DATA OPERATIONS
// ============================================================================

func (r *PostgresRepository) GetLocations(ctx context.Context) ([]Location, error) {
	query := `SELECT id, name, created_at FROM locations ORDER BY name ASC`

	rows, err := r.db.QueryContext(ctx, query)
	if err != nil {
		return nil, fmt.Errorf("GetLocations error: %w", err)
	}
	defer rows.Close()

	var list []Location

	for rows.Next() {
		var loc Location

		if err := rows.Scan(
			&loc.ID,
			&loc.Name,
			&loc.CreatedAt,
		); err != nil {
			return nil, err
		}

		// locations pada schema saat ini tidak memiliki kolom status/updated_at.
		loc.Status = "ACTIVE"
		loc.UpdatedAt = loc.CreatedAt

		list = append(list, loc)
	}

	if err := rows.Err(); err != nil {
		return nil, err
	}

	return list, nil
}

func (r *PostgresRepository) GetDepartments(ctx context.Context) ([]Department, error) {
	query := `SELECT id, name, status, created_at, updated_at FROM departments WHERE status = 'ACTIVE' ORDER BY name ASC`
	rows, err := r.db.QueryContext(ctx, query)
	if err != nil {
		return nil, fmt.Errorf("GetDepartments error: %w", err)
	}
	defer rows.Close()

	var list []Department
	for rows.Next() {
		var dept Department
		if err := rows.Scan(&dept.ID, &dept.Name, &dept.Status, &dept.CreatedAt, &dept.UpdatedAt); err != nil {
			return nil, err
		}
		list = append(list, dept)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("GetDepartments rows error: %w", err)
	}
	return list, nil
}

func (r *PostgresRepository) GetSites(ctx context.Context) ([]Site, error) {
	query := `SELECT id, name, status, created_at, updated_at FROM sites WHERE status = 'ACTIVE' ORDER BY name ASC`
	rows, err := r.db.QueryContext(ctx, query)
	if err != nil {
		return nil, fmt.Errorf("GetSites error: %w", err)
	}
	defer rows.Close()

	var list []Site
	for rows.Next() {
		var st Site
		if err := rows.Scan(&st.ID, &st.Name, &st.Status, &st.CreatedAt, &st.UpdatedAt); err != nil {
			return nil, err
		}
		list = append(list, st)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("GetSites rows error: %w", err)
	}
	return list, nil
}

// ============================================================================
// INSPECTION OPERATIONS
// ============================================================================

func (r *PostgresRepository) GenerateInspectionID(ctx context.Context, inspDate time.Time) (string, error) {
	var sequence int

	query := `
        INSERT INTO inspection_daily_counters (
            inspection_date,
            last_number
        )
        VALUES ($1, 1)
        ON CONFLICT (inspection_date)
        DO UPDATE SET
            last_number = inspection_daily_counters.last_number + 1
        RETURNING last_number
    `

	err := r.db.QueryRowContext(
		ctx,
		query,
		inspDate.Format("2006-01-02"),
	).Scan(&sequence)

	if err != nil {
		return "", fmt.Errorf("GenerateInspectionID error: %w", err)
	}

	return fmt.Sprintf(
		"INSP-%s-%03d",
		inspDate.Format("20060102"),
		sequence,
	), nil
}

func (r *PostgresRepository) CreateInspection(ctx context.Context, insp *Inspection) error {
	query := `
        INSERT INTO inspections (
            id, location_id, shift, check_personel, check_ruangan, check_peralatan,
            ket_personel, ket_ruangan, ket_peralatan, date, created_by,
            status, missed_entry, missed_reason, created_at, updated_at
        ) VALUES (
            $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16
        )
    `
	now := time.Now().UTC()
	insp.Status = InspectionStatusSubmitted
	insp.MissedEntry = false
	insp.CreatedAt = now
	insp.UpdatedAt = now

	_, err := r.db.ExecContext(ctx, query,
		insp.ID,
		insp.LocationID,
		insp.Shift,
		insp.CheckPersonel,
		insp.CheckRuangan,
		insp.CheckPeralatan,
		insp.KetPersonel,
		insp.KetRuangan,
		insp.KetPeralatan,
		insp.Date,
		insp.CreatedBy,
		insp.Status,
		insp.MissedEntry,
		insp.MissedReason,
		insp.CreatedAt,
		insp.UpdatedAt,
	)
	if err != nil {
		if isUniqueViolation(err) {
			return fmt.Errorf("%w (lokasi %s, tanggal %s, shift %s)", ErrDuplicateInspectionSlot, insp.LocationID, insp.Date.Format("2006-01-02"), insp.Shift)
		}
		return fmt.Errorf("CreateInspection error: %w", err)
	}
	return nil
}

func (r *PostgresRepository) CreateMissedEntry(ctx context.Context, insp *Inspection) error {
	query := `
        INSERT INTO inspections (
            id,
            location_id,
            shift,
            check_personel,
            check_ruangan,
            check_peralatan,
            date,
            created_by,
            status,
            missed_entry,
            missed_reason,
            missed_type,
            created_at,
            updated_at
        ) VALUES (
            $1,
            $2,
            $3,
            NULL,
            NULL,
            NULL,
            $4,
            $5,
            $6,
            true,
            $7,
            'shift',
            $8,
            $9
        )
    `

	now := time.Now().UTC()

	insp.Status = InspectionStatusSubmitted
	insp.MissedEntry = true
	insp.CreatedAt = now
	insp.UpdatedAt = now

	_, err := r.db.ExecContext(
		ctx,
		query,
		insp.ID,
		insp.LocationID,
		insp.Shift,
		insp.Date,
		insp.CreatedBy,
		insp.Status,
		insp.MissedReason,
		insp.CreatedAt,
		insp.UpdatedAt,
	)

	if err != nil {
		if isUniqueViolation(err) {
			return fmt.Errorf("%w (lokasi %s, tanggal %s, shift %s)", ErrDuplicateInspectionSlot, insp.LocationID, insp.Date.Format("2006-01-02"), insp.Shift)
		}
		return fmt.Errorf("CreateMissedEntry error: %w", err)
	}

	return nil
}

func (r *PostgresRepository) CreateWeeklyMissedEntries(ctx context.Context, inspections []*Inspection) error {
	if len(inspections) != 3 {
		return fmt.Errorf("Entry Terlewat Mingguan harus memiliki tepat 3 catatan shift")
	}

	tx, err := r.db.BeginTx(ctx, nil)
	if err != nil {
		return fmt.Errorf("gagal memulai transaksi Entry Terlewat Mingguan: %w", err)
	}
	defer tx.Rollback()

	query := `
		INSERT INTO inspections (
			id, location_id, shift, check_personel, check_ruangan, check_peralatan,
			date, created_by, status, missed_entry, missed_reason, missed_type, created_at, updated_at
		) VALUES ($1, $2, $3, NULL, NULL, NULL, $4, $5, $6, TRUE, $7, 'weekly', $8, $8)
	`
	now := time.Now().UTC()
	for _, insp := range inspections {
		insp.Status = InspectionStatusSubmitted
		insp.MissedEntry = true
		insp.CreatedAt = now
		insp.UpdatedAt = now

		if _, err := tx.ExecContext(ctx, query,
			insp.ID, insp.LocationID, insp.Shift, insp.Date, insp.CreatedBy,
			insp.Status, insp.MissedReason, now,
		); err != nil {
			if isUniqueViolation(err) {
				return fmt.Errorf("%w (lokasi %s, tanggal %s, shift %s)", ErrDuplicateInspectionSlot, insp.LocationID, insp.Date.Format("2006-01-02"), insp.Shift)
			}
			return fmt.Errorf("gagal menyimpan Shift %s pada Entry Terlewat Mingguan: %w", insp.Shift, err)
		}
	}

	if err := tx.Commit(); err != nil {
		return fmt.Errorf("gagal menyelesaikan transaksi Entry Terlewat Mingguan: %w", err)
	}
	return nil
}

// UpdateMissedEntry mengubah alasan (dan tanggal, khusus mingguan) sebuah
// Entry Terlewat. Untuk mingguan, perubahan diterapkan ke ketiga shift
// (1, 2, 3) sekaligus dalam satu transaksi dengan jam edit yang sama.
// Mengembalikan jumlah record yang diperbarui.
func (r *PostgresRepository) UpdateMissedEntry(ctx context.Context, id string, reason string, newDate *time.Time, editorID string, audit *AuditLog) (int, error) {
	tx, err := r.db.BeginTx(ctx, nil)
	if err != nil {
		return 0, fmt.Errorf("begin tx error: %w", err)
	}
	defer tx.Rollback()

	var locationID string
	var origDate time.Time
	var missedType sql.NullString
	err = tx.QueryRowContext(ctx, `SELECT location_id, date, missed_type FROM inspections WHERE id = $1 FOR UPDATE`, id).Scan(&locationID, &origDate, &missedType)
	if err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return 0, ErrNotFound
		}
		return 0, fmt.Errorf("UpdateMissedEntry lookup error: %w", err)
	}

	now := time.Now().UTC()
	var res sql.Result
	if missedType.Valid && missedType.String == "weekly" {
		targetDate := origDate
		if newDate != nil {
			targetDate = *newDate
		}
		res, err = tx.ExecContext(ctx, `
			UPDATE inspections
			SET date = $1, missed_reason = $2, status = $3,
			    supervisor_approved_by = NULL, supervisor_approved_at = NULL,
			    manager_approved_by = NULL, manager_approved_at = NULL,
			    updated_at = $4, last_edited_by = $5, last_edited_at = $4,
			    edit_count = edit_count + 1
			WHERE location_id = $6 AND date = $7 AND missed_entry = TRUE
			    AND missed_type = 'weekly'
		`, targetDate.Format("2006-01-02"), reason, InspectionStatusSubmitted, now, editorID, locationID, origDate.Format("2006-01-02"))
	} else {
		res, err = tx.ExecContext(ctx, `
			UPDATE inspections
			SET missed_reason = $1, status = $2,
			    supervisor_approved_by = NULL, supervisor_approved_at = NULL,
			    manager_approved_by = NULL, manager_approved_at = NULL,
			    updated_at = $3, last_edited_by = $4, last_edited_at = $3,
			    edit_count = edit_count + 1
			WHERE id = $5
		`, reason, InspectionStatusSubmitted, now, editorID, id)
	}
	if err != nil {
		if isUniqueViolation(err) {
			return 0, ErrDuplicateInspectionSlot
		}
		return 0, fmt.Errorf("UpdateMissedEntry error: %w", err)
	}
	affected, err := res.RowsAffected()
	if err != nil || affected == 0 {
		return 0, ErrNotFound
	}

	if audit != nil {
		auditQuery := `
			INSERT INTO audit_logs (
				id,
				user_id,
				action,
				detail,
				ip_address,
				created_at
			)
			VALUES ($1, $2, $3, $4, $5, $6)
		`
		if _, err := tx.ExecContext(ctx, auditQuery,
			audit.ID, audit.User, audit.Action, audit.Detail, audit.IPAddress, now,
		); err != nil {
			return 0, fmt.Errorf("audit log error in UpdateMissedEntry: %w", err)
		}
	}

	if err := tx.Commit(); err != nil {
		return 0, fmt.Errorf("gagal menyelesaikan transaksi UpdateMissedEntry: %w", err)
	}
	return int(affected), nil
}

func (r *PostgresRepository) GetInspection(ctx context.Context, id string) (*Inspection, error) {
	query := `
		SELECT id, location_id, shift,
		       COALESCE(check_personel, ''), COALESCE(check_ruangan, ''), COALESCE(check_peralatan, ''),
               ket_personel, ket_ruangan, ket_peralatan, date, created_by,
               supervisor_approved_by, supervisor_approved_at,
               manager_approved_by, manager_approved_at,
               status, missed_entry, missed_reason, missed_type, created_at, updated_at
        FROM inspections
        WHERE id = $1
    `
	insp := &Inspection{}
	err := r.db.QueryRowContext(ctx, query, id).Scan(
		&insp.ID,
		&insp.LocationID,
		&insp.Shift,
		&insp.CheckPersonel,
		&insp.CheckRuangan,
		&insp.CheckPeralatan,
		&insp.KetPersonel,
		&insp.KetRuangan,
		&insp.KetPeralatan,
		&insp.Date,
		&insp.CreatedBy,
		&insp.SupervisorApprovedBy,
		&insp.SupervisorApprovedAt,
		&insp.ManagerApprovedBy,
		&insp.ManagerApprovedAt,
		&insp.Status,
		&insp.MissedEntry,
		&insp.MissedReason,
		&insp.MissedType,
		&insp.CreatedAt,
		&insp.UpdatedAt,
	)
	if err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, ErrNotFound
		}
		return nil, fmt.Errorf("GetInspection error: %w", err)
	}
	return insp, nil
}

func (r *PostgresRepository) ListInspections(ctx context.Context, filter InspectionFilter) ([]Inspection, error) {
	query := `
        SELECT
            i.id,
            i.location_id,
            i.shift,
            COALESCE(i.check_personel, '') AS check_personel,
            COALESCE(i.check_ruangan, '') AS check_ruangan,
            COALESCE(i.check_peralatan, '') AS check_peralatan,
            i.ket_personel,
            i.ket_ruangan,
            i.ket_peralatan,
            i.date,
            i.created_by,
            i.supervisor_approved_by,
            i.supervisor_approved_at,
            i.manager_approved_by,
            i.manager_approved_at,
            i.status,
            i.missed_entry,
            i.missed_reason,
            i.missed_type,
            i.created_at,
            i.updated_at,
            COALESCE(staff.full_name, staff.username, '') AS staff_name,
            COALESCE(staff.username, '') AS staff_username,
            COALESCE(spv.full_name, spv.username, '') AS supervisor_name,
            COALESCE(spv.username, '') AS supervisor_username,
			COALESCE(mgr.full_name, mgr.username, '') AS manager_name,
			COALESCE(loc.name, '') AS location_name,
            COALESCE(editor.username, '') AS last_edited_by_username,
            i.last_edited_at,
            i.edit_count
        FROM inspections i
		LEFT JOIN locations loc
			ON i.location_id = loc.id
        LEFT JOIN users staff
            ON i.created_by = staff.id
        LEFT JOIN users spv
            ON i.supervisor_approved_by = spv.id
        LEFT JOIN users mgr
            ON i.manager_approved_by = mgr.id
        LEFT JOIN users editor
            ON i.last_edited_by = editor.id
        WHERE 1=1
    `
	var args []interface{}
	argIdx := 1

	if filter.LocationID != nil {
		query += fmt.Sprintf(" AND i.location_id = $%d", argIdx)
		args = append(args, *filter.LocationID)
		argIdx++
	}
	if filter.Shift != nil {
		query += fmt.Sprintf(" AND i.shift = $%d", argIdx)
		args = append(args, *filter.Shift)
		argIdx++
	}
	if filter.Status != nil {
		query += fmt.Sprintf(" AND i.status = $%d", argIdx)
		args = append(args, *filter.Status)
		argIdx++
	}
	if filter.CreatedBy != nil {
		query += fmt.Sprintf(" AND i.created_by = $%d", argIdx)
		args = append(args, *filter.CreatedBy)
		argIdx++
	}
	if filter.Department != nil {
		query += fmt.Sprintf(" AND staff.department_id = (SELECT id FROM departments WHERE name = $%d)", argIdx)
		args = append(args, *filter.Department)
		argIdx++
	}
	if filter.Date != nil {
		query += fmt.Sprintf(" AND i.date = $%d", argIdx)
		args = append(args, filter.Date.Format("2006-01-02"))
		argIdx++
	}
	if filter.Month != nil {
		query += fmt.Sprintf(" AND EXTRACT(MONTH FROM i.date) = $%d", argIdx)
		args = append(args, *filter.Month)
		argIdx++
	}
	if filter.Year != nil {
		query += fmt.Sprintf(" AND EXTRACT(YEAR FROM i.date) = $%d", argIdx)
		args = append(args, *filter.Year)
		argIdx++
	}
	if filter.MissedType != nil {
		switch *filter.MissedType {
		case "any":
			query += " AND i.missed_entry = TRUE"
		case "shift", "weekly":
			query += fmt.Sprintf(" AND i.missed_entry = TRUE AND i.missed_type = $%d", argIdx)
			args = append(args, *filter.MissedType)
			argIdx++
		}
	}

	query += " ORDER BY i.created_at DESC"

	rows, err := r.db.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, fmt.Errorf("ListInspections error: %w", err)
	}
	defer rows.Close()

	var list []Inspection
	for rows.Next() {
		var insp Inspection
		err := rows.Scan(
			&insp.ID,
			&insp.LocationID,
			&insp.Shift,
			&insp.CheckPersonel,
			&insp.CheckRuangan,
			&insp.CheckPeralatan,
			&insp.KetPersonel,
			&insp.KetRuangan,
			&insp.KetPeralatan,
			&insp.Date,
			&insp.CreatedBy,
			&insp.SupervisorApprovedBy,
			&insp.SupervisorApprovedAt,
			&insp.ManagerApprovedBy,
			&insp.ManagerApprovedAt,
			&insp.Status,
			&insp.MissedEntry,
			&insp.MissedReason,
			&insp.MissedType,
			&insp.CreatedAt,
			&insp.UpdatedAt,
			&insp.StaffName,
			&insp.CreatedByUsername,
			&insp.SupervisorName,
			&insp.SupervisorUsername,
			&insp.ManagerName,
			&insp.LocationName,
			&insp.LastEditedByUsername,
			&insp.LastEditedAt,
			&insp.EditCount,
		)
		if err != nil {
			return nil, err
		}
		list = append(list, insp)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("ListInspections rows error: %w", err)
	}
	return list, nil
}

// UpdateInspectionForRevision mengeksekusi revisi inspeksi dan audit log dalam satu transaksi
func (r *PostgresRepository) UpdateInspectionForRevision(ctx context.Context, insp *Inspection, audit *AuditLog) error {
	tx, err := r.db.BeginTx(ctx, nil)
	if err != nil {
		return fmt.Errorf("begin tx error: %w", err)
	}
	defer tx.Rollback()

	// 1. Reset Status kembali ke SUBMITTED dan bersihkan approval saat revisi
	updateQuery := `
        UPDATE inspections
        SET location_id = $1, shift = $2, check_personel = $3, check_ruangan = $4, check_peralatan = $5,
            ket_personel = $6, ket_ruangan = $7, ket_peralatan = $8, date = $9,
            status = $10, supervisor_approved_by = NULL, supervisor_approved_at = NULL,
            manager_approved_by = NULL, manager_approved_at = NULL, updated_at = $11,
            last_edited_by = $12, last_edited_at = $11, edit_count = edit_count + 1
        WHERE id = $13
    `
	now := time.Now().UTC()
	res, err := tx.ExecContext(ctx, updateQuery,
		insp.LocationID,
		insp.Shift,
		insp.CheckPersonel,
		insp.CheckRuangan,
		insp.CheckPeralatan,
		insp.KetPersonel,
		insp.KetRuangan,
		insp.KetPeralatan,
		insp.Date,
		InspectionStatusSubmitted,
		now,
		insp.LastEditedByID,
		insp.ID,
	)
	if err != nil {
		return fmt.Errorf("revision update error: %w", err)
	}
	rows, err := res.RowsAffected()
	if err != nil || rows == 0 {
		return ErrNotFound
	}

	// 2. Simpan Audit Log sesuai schema audit_logs baru
	auditQuery := `
        INSERT INTO audit_logs (
            id,
            user_id,
            action,
            detail,
            old_value,
            new_value,
            ip_address,
            created_at
        )
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
    `
	_, err = tx.ExecContext(
		ctx,
		auditQuery,
		audit.ID,
		audit.User,
		AuditActionRevision,
		audit.Detail,
		audit.OldValue,
		audit.NewValue,
		audit.IPAddress,
		now,
	)
	if err != nil {
		return fmt.Errorf("audit insertion in revision tx error: %w", err)
	}

	return tx.Commit()
}

// ============================================================================
// APPROVAL WORKFLOW OPERATIONS (ATOMIC TRANSACTION & STATE VALIDATION)
// ============================================================================

func (r *PostgresRepository) ApproveSupervisor(ctx context.Context, id string, supervisorID string, audit *AuditLog) error {
	tx, err := r.db.BeginTx(ctx, nil)
	if err != nil {
		return fmt.Errorf("begin tx error: %w", err)
	}
	defer tx.Rollback()

	// Atomic validation: approval Supervisor menyelesaikan inspeksi.
	query := `
        UPDATE inspections
        SET status = $1, supervisor_approved_by = $2, supervisor_approved_at = $3, updated_at = $4
        WHERE id = $5 AND status = $6
    `
	now := time.Now().UTC()
	res, err := tx.ExecContext(ctx, query,
		InspectionStatusApproved,
		supervisorID,
		now,
		now,
		id,
		InspectionStatusSubmitted,
	)
	if err != nil {
		return fmt.Errorf("ApproveSupervisor query error: %w", err)
	}
	rows, err := res.RowsAffected()
	if err != nil {
		return err
	}
	if rows == 0 {
		return ErrInvalidStatusTransition
	}

	// Insert Audit Log sesuai schema audit_logs baru
	auditQuery := `
        INSERT INTO audit_logs (
            id,
            user_id,
            action,
            detail,
            ip_address,
            created_at
        )
        VALUES ($1, $2, $3, $4, $5, $6)
    `
	_, err = tx.ExecContext(
		ctx,
		auditQuery,
		audit.ID,
		audit.User,
		AuditActionApproval,
		audit.Detail,
		audit.IPAddress,
		now,
	)
	if err != nil {
		return fmt.Errorf("audit log error in ApproveSupervisor: %w", err)
	}

	return tx.Commit()
}

// ============================================================================
// AUDIT LOG OPERATIONS (IMMUTABLE LOGGING)
// ============================================================================

func (r *PostgresRepository) CreateAuditLog(ctx context.Context, log *AuditLog) error {
	query := `
        INSERT INTO audit_logs (
            id,
            user_id,
            action,
            detail,
            old_value,
            new_value,
            ip_address,
            created_at
        )
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
    `

	log.Timestamp = time.Now().UTC()

	_, err := r.db.ExecContext(
		ctx,
		query,
		log.ID,
		log.User,
		log.Action,
		log.Detail,
		log.OldValue,
		log.NewValue,
		log.IPAddress,
		log.Timestamp,
	)

	if err != nil {
		return fmt.Errorf("CreateAuditLog error: %w", err)
	}

	return nil
}

func (r *PostgresRepository) GetAuditLogs(
	ctx context.Context,
	limit int,
	offset int,
	userFilter string,
	dateFilter string,
	actionFilter string,
) ([]AuditLog, error) {
	if limit <= 0 {
		limit = 50
	}

	query := `
        SELECT
            id,
            created_at,
            user_id,
            action,
            detail,
            old_value,
            new_value,
            ip_address
        FROM audit_logs
        WHERE 1=1
    `

	args := []interface{}{}
	argIndex := 1

	if userFilter != "" {
		query += fmt.Sprintf(
			" AND user_id ILIKE $%d",
			argIndex,
		)
		args = append(args, "%"+userFilter+"%")
		argIndex++
	}

	// Tanggal dipilih user dalam zona Asia/Jakarta; created_at tersimpan UTC.
	if dateFilter != "" {
		query += fmt.Sprintf(
			" AND (created_at AT TIME ZONE 'Asia/Jakarta')::date = $%d",
			argIndex,
		)
		args = append(args, dateFilter)
		argIndex++
	}

	if actionFilter != "" {
		query += fmt.Sprintf(
			" AND action = $%d",
			argIndex,
		)
		args = append(args, actionFilter)
		argIndex++
	}

	query += fmt.Sprintf(
		" ORDER BY created_at DESC LIMIT $%d OFFSET $%d",
		argIndex,
		argIndex+1,
	)
	args = append(args, limit, offset)

	rows, err := r.db.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, fmt.Errorf("GetAuditLogs error: %w", err)
	}
	defer rows.Close()

	var logs []AuditLog

	for rows.Next() {
		var al AuditLog

		if err := rows.Scan(
			&al.ID,
			&al.Timestamp,
			&al.User,
			&al.Action,
			&al.Detail,
			&al.OldValue,
			&al.NewValue,
			&al.IPAddress,
		); err != nil {
			return nil, fmt.Errorf("GetAuditLogs scan error: %w", err)
		}

		logs = append(logs, al)
	}

	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("GetAuditLogs rows error: %w", err)
	}

	return logs, nil
}

func (r *PostgresRepository) GetAuditLogsCount(
	ctx context.Context,
	userFilter string,
	dateFilter string,
	actionFilter string,
) (int, error) {
	query := `
        SELECT COUNT(*)
        FROM audit_logs
        WHERE 1=1
    `

	args := []interface{}{}
	argIndex := 1

	if userFilter != "" {
		query += fmt.Sprintf(" AND user_id ILIKE $%d", argIndex)
		args = append(args, "%"+userFilter+"%")
		argIndex++
	}

	if dateFilter != "" {
		query += fmt.Sprintf(" AND (created_at AT TIME ZONE 'Asia/Jakarta')::date = $%d", argIndex)
		args = append(args, dateFilter)
		argIndex++
	}

	if actionFilter != "" {
		query += fmt.Sprintf(" AND action = $%d", argIndex)
		args = append(args, actionFilter)
		argIndex++
	}

	var total int

	err := r.db.QueryRowContext(
		ctx,
		query,
		args...,
	).Scan(&total)

	if err != nil {
		return 0, fmt.Errorf("GetAuditLogsCount error: %w", err)
	}

	return total, nil
}

// ============================================================================
// REPORT OPERATIONS
// ============================================================================

func (r *PostgresRepository) GetInspectionReport(ctx context.Context, filter InspectionFilter) ([]Inspection, error) {
	return r.ListInspections(ctx, filter)
}
