package main

import (
	"net/http"
	"testing"
)

// checkAuthorizer adalah keputusan murni otorisasi revisi: hanya akun aktif
// ber-role Supervisor/Administrator dengan password yang cocok yang boleh
// mengotorisasi. Staff yang mengetikkan passwordnya sendiri yang benar pun
// tetap ditolak (403), dan password yang salah selalu 401.
func TestCheckAuthorizer(t *testing.T) {
	hash, err := HashPassword("rahasia123")
	if err != nil {
		t.Fatalf("HashPassword: %v", err)
	}
	base := &User{Username: "yudha", PasswordHash: hash, Status: UserStatusActive}

	supervisor := *base
	supervisor.Role = RoleSupervisor
	admin := *base
	admin.Username = "admin"
	admin.Role = RoleAdministrator
	staff := *base
	staff.Username = "nanda"
	staff.Role = RoleStaff
	inactiveSup := *base
	inactiveSup.Username = "yudha2"
	inactiveSup.Status = UserStatusInactive

	cases := []struct {
		name     string
		user     *User
		password string
		wantOK   bool
		wantCode int
	}{
		{"supervisor password benar", &supervisor, "rahasia123", true, http.StatusOK},
		{"admin password benar", &admin, "rahasia123", true, http.StatusOK},
		{"supervisor password salah", &supervisor, "salah", false, http.StatusUnauthorized},
		{"staff password benar tetap ditolak", &staff, "rahasia123", false, http.StatusForbidden},
		{"supervisor nonaktif ditolak", &inactiveSup, "rahasia123", false, http.StatusUnauthorized},
		{"user tidak ada ditolak", nil, "rahasia123", false, http.StatusUnauthorized},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			code, err := checkAuthorizer(tc.user, tc.password)
			if tc.wantOK && err != nil {
				t.Fatalf("expected ok, got error: %v", err)
			}
			if !tc.wantOK && err == nil {
				t.Fatalf("expected error, got ok")
			}
			if code != tc.wantCode {
				t.Fatalf("expected status %d, got %d", tc.wantCode, code)
			}
		})
	}
}
