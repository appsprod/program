﻿package main

import (
    "context"
    "encoding/json"
    "errors"
    "fmt"
    "net/http"
    "strings"
    "time"
)

type ReloginRequest struct {
    Username string `json:"username"`
    Password string `json:"password"`
}

// checkAuthorizer adalah keputusan murni (tanpa DB): apakah kredensial milik
// akun yang diberikan berhak mengotorisasi revisi. Mengembalikan status HTTP
// yang sesuai (401 kredensial tidak valid, 403 role bukan Supervisor/Admin).
func checkAuthorizer(authorizer *User, password string) (int, error) {
    if authorizer == nil {
        return http.StatusUnauthorized, errors.New("username atau password tidak valid")
    }
    if authorizer.Status != UserStatusActive {
        return http.StatusUnauthorized, errors.New("username atau password tidak valid")
    }
    if authorizer.Role != RoleSupervisor && authorizer.Role != RoleAdministrator {
        return http.StatusForbidden, errors.New("hanya akun Supervisor atau Administrator yang dapat memberikan otorisasi")
    }
    if !CheckPasswordHash(password, authorizer.PasswordHash) {
        return http.StatusUnauthorized, errors.New("username atau password tidak valid")
    }
    return http.StatusOK, nil
}

// verifyAuthorizer memeriksa kredensial akun yang NAMANYA diketik di form
// re-login (bukan akun yang sedang login). Dipakai saat seorang staff meminta
// Supervisor/Administrator mengetikkan kredensialnya untuk otorisasi revisi.
func (h *Handler) verifyAuthorizer(ctx context.Context, username, password string) (*User, int, error) {
    username = strings.TrimSpace(username)
    if username == "" || password == "" {
        return nil, http.StatusBadRequest, errors.New("username dan password wajib diisi")
    }
    authorizer, err := h.repo.FindUserByUsername(ctx, username)
    if err != nil {
        return nil, http.StatusUnauthorized, errors.New("username atau password tidak valid")
    }
    if status, err := checkAuthorizer(authorizer, password); err != nil {
        return nil, status, err
    }
    return authorizer, http.StatusOK, nil
}

func (h *Handler) Relogin(w http.ResponseWriter, r *http.Request) {
    if r.Method != http.MethodPost {
        writeError(w, http.StatusMethodNotAllowed, "Method not allowed")
        return
    }

    // Sesi siapa pun yang sedang login boleh meminta otorisasi; yang
    // diverifikasi adalah kredensial akun yang diketik di form (otorisator),
    // bukan akun session. Ini yang memungkinkan staff meminta Supervisor /
    // Administrator mengetikkan kredensialnya untuk membuka akses edit.
    if _, err := h.getAuthenticatedUser(r); err != nil {
        writeError(w, http.StatusUnauthorized, "Session tidak valid atau sudah berakhir")
        return
    }

    var req ReloginRequest
    if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
        writeError(w, http.StatusBadRequest, "Invalid request body")
        return
    }

    authorizer, status, err := h.verifyAuthorizer(r.Context(), req.Username, req.Password)
    if err != nil {
        _ = h.repo.CreateAuditLog(r.Context(), &AuditLog{
            ID:        fmt.Sprintf("AUD-%d", time.Now().UnixNano()),
            User:      strings.TrimSpace(req.Username),
            Action:    AuditActionAuthSecurity,
            Detail:    "Failed re-login verification for approval",
            IPAddress: getIPAddress(r),
        })

        writeError(w, status, err.Error())
        return
    }

    _ = h.repo.CreateAuditLog(r.Context(), &AuditLog{
        ID:        fmt.Sprintf("AUD-%d", time.Now().UnixNano()),
        User:      authorizer.Username,
        Action:    AuditActionAuthSecurity,
        Detail:    "Successful re-login verification for approval",
        IPAddress: getIPAddress(r),
    })

    writeJSON(w, http.StatusOK, JSONResponse{
        Success: true,
        Message: "Verifikasi re-login berhasil",
        Data: map[string]string{
            "username": authorizer.Username,
            "role":     string(authorizer.Role),
        },
    })
}
