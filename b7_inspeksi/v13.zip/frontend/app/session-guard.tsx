'use client';

import React, { FormEvent, useEffect, useRef, useState } from 'react';

interface SessionUser {
  fullName?: string;
  name?: string;
  username: string;
  role?: string;
}

interface SessionResponse {
  error?: string;
  user?: SessionUser;
}

interface PendingResume {
  promise: Promise<boolean>;
  resolve: (resumed: boolean) => void;
}

export default function SessionGuard() {
  const [user, setUser] = useState<SessionUser | null>(null);
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const pendingResume = useRef<PendingResume | null>(null);
  const originalFetch = useRef<typeof fetch | null>(null);

  useEffect(() => {
    const nativeFetch = window.fetch;
    const invokeNativeFetch: typeof fetch = (input, init) =>
      nativeFetch.call(window, input, init);
    originalFetch.current = invokeNativeFetch;

    const guardedFetch = async (input: RequestInfo | URL, init?: RequestInit) => {
      const request = new Request(input, init);
      const response = await invokeNativeFetch(request.clone());

      if (response.status !== 440 || window.location.pathname === '/login') {
        return response;
      }

      let session: SessionResponse = {};
      try {
        session = await response.clone().json();
      } catch {
        session = {};
      }

      if (!pendingResume.current) {
        let resolveResume!: (resumed: boolean) => void;
        const promise = new Promise<boolean>((resolve) => {
          resolveResume = resolve;
        });
        pendingResume.current = { promise, resolve: resolveResume };
        setUser(session.user || null);
        setPassword('');
        setShowPassword(false);
        setError(null);
      }

      const resumed = await pendingResume.current.promise;
      if (resumed) {
        return invokeNativeFetch(request.clone());
      }

      return response;
    };
    window.fetch = guardedFetch;

    return () => {
      if (window.fetch === guardedFetch) {
        window.fetch = nativeFetch;
      }
      pendingResume.current?.resolve(false);
      pendingResume.current = null;
    };
  }, []);

  const handleContinue = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!password) {
      setError('Password wajib diisi.');
      return;
    }

    setIsLoading(true);
    setError(null);
    try {
      const response = await originalFetch.current?.('/api/auth/continue', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password }),
      });
      const data = response ? await response.json().catch(() => ({})) : {};

      if (!response?.ok) {
        const message = data.error || data.message || 'Sesi tidak dapat dilanjutkan.';
        setError(message);
        if (response?.status === 403 || (response?.status === 401 && !message.includes('Password salah'))) {
          pendingResume.current?.resolve(false);
          pendingResume.current = null;
          window.location.assign('/login');
        }
        return;
      }

      const waiter = pendingResume.current;
      pendingResume.current = null;
      setPassword('');
      setShowPassword(false);
      setUser(null);
      waiter?.resolve(true);
    } catch {
      setError('Terjadi kesalahan koneksi. Silakan coba lagi.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogout = async () => {
    try {
      await originalFetch.current?.('/api/auth/logout', { method: 'POST' });
    } finally {
      const waiter = pendingResume.current;
      pendingResume.current = null;
      waiter?.resolve(false);
      window.location.assign('/login');
    }
  };

  if (!user) {
    return null;
  }

  const displayName = user.fullName || user.name || user.username;
  const initial = displayName.trim().charAt(0).toUpperCase() || 'U';

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-950/60 p-4 backdrop-blur-sm">
      <section
        aria-labelledby="session-expired-title"
        aria-modal="true"
        className="w-full max-w-md overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-2xl"
        role="dialog"
      >
        <div className="border-b border-slate-100 px-6 py-5">
          <h2 id="session-expired-title" className="text-lg font-bold text-slate-900">
            Sesi Berakhir
          </h2>
          <p className="mt-1 text-sm text-slate-500">
            Sesi login Anda telah habis masa berlakunya.
          </p>
        </div>

        <form onSubmit={handleContinue} className="space-y-5 p-6">
          <div className="flex items-center gap-3 rounded-xl bg-slate-50 p-4">
            <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-sky-100 text-base font-bold text-sky-700">
              {initial}
            </div>
            <div className="min-w-0">
              <p className="text-xs font-medium uppercase tracking-wide text-slate-400">
                Akun
              </p>
              <p className="truncate text-sm font-semibold text-slate-900">{displayName}</p>
              <p className="truncate text-xs text-slate-500">{user.username}</p>
            </div>
          </div>

          <div>
            <label htmlFor="session-resume-password" className="mb-1.5 block text-sm font-medium text-slate-700">
              Masukkan Password untuk Melanjutkan
            </label>
            <div className="relative">
              <input
                autoComplete="current-password"
                autoFocus
                id="session-resume-password"
                onChange={(event) => setPassword(event.target.value)}
                type={showPassword ? 'text' : 'password'}
                value={password}
                disabled={isLoading}
                className="w-full rounded-lg border border-slate-300 py-2.5 pl-3 pr-11 text-sm text-slate-900 shadow-sm outline-none transition focus:border-sky-500 focus:ring-2 focus:ring-sky-500/20 disabled:bg-slate-100"
                placeholder="Masukkan password Anda"
              />
              <button
                type="button"
                onClick={() => setShowPassword((visible) => !visible)}
                disabled={isLoading}
                className="absolute inset-y-0 right-0 flex items-center pr-3.5 text-slate-400 transition-colors hover:text-slate-600 focus:outline-none disabled:cursor-not-allowed"
                tabIndex={-1}
                aria-label={showPassword ? 'Sembunyikan password' : 'Tampilkan password'}
                aria-pressed={showPassword}
              >
                {showPassword ? (
                  /* Icon Eye Off */
                  <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={1.8}
                      d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858-5.908a10.016 10.016 0 013.682-.763c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m-1.565 1.565L3 3l18 18"
                    />
                  </svg>
                ) : (
                  /* Icon Eye On */
                  <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={1.8}
                      d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"
                    />
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={1.8}
                      d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"
                    />
                  </svg>
                )}
              </button>
            </div>
          </div>

          {error && (
            <p role="alert" className="rounded-lg border border-rose-200 bg-rose-50 p-3 text-sm text-rose-700">
              {error}
            </p>
          )}

          <div className="flex items-center justify-between gap-3 border-t border-slate-100 pt-4">
            <button
              type="button"
              onClick={handleLogout}
              disabled={isLoading}
              className="rounded-lg px-4 py-2 text-sm font-medium text-slate-600 transition hover:bg-slate-100 hover:text-slate-900 disabled:opacity-50"
            >
              Logout
            </button>
            <button
              type="submit"
              disabled={isLoading}
              className="rounded-lg bg-sky-600 px-5 py-2 text-sm font-semibold text-white shadow-sm transition hover:bg-sky-700 disabled:cursor-not-allowed disabled:bg-sky-300"
            >
              {isLoading ? 'Memverifikasi...' : 'Continue'}
            </button>
          </div>
        </form>
      </section>
    </div>
  );
}
