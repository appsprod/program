'use client';

import React, { Suspense, useState, useEffect, FormEvent, ChangeEvent } from 'react';
import { useRouter } from 'next/navigation';
import Sidebar from '../sidebar';

interface UserSession {
  id: string;
  name: string;
  username: string;
  role: string;
  department: string;
  site: string;
}

interface Location {
  id: string;
  name: string;
}

interface InspectionData {
  id: string;
  date: string;
  shift: string;
  locationId: string;
  locationName?: string;
  checkPersonel: 'OK' | 'NOK';
  checkRuangan: 'OK' | 'NOK';
  checkPeralatan: 'OK' | 'NOK';
  ketPersonel: string;
  ketRuangan: string;
  ketPeralatan: string;
  status: 'SUBMITTED' | 'SUPERVISOR_APPROVED' | 'APPROVED';
  staffName?: string;
  supervisorName?: string;
  managerName?: string;
  missedEntry?: boolean;
  missedReason?: string;
  missedType?: string;
}

export default function EditInspectionPage() {
  const router = useRouter();

  const [inspectionId, setInspectionId] = useState<string | null>(null);

  // URL kembali ke laporan dengan filter yang sama seperti sebelum edit
  // (hanya terisi bila halaman edit dibuka dari /report_inspeksi).
  const [reportReturnUrl, setReportReturnUrl] = useState<string>('/report_inspeksi');

  // Session & Master Data
  const [currentUser, setCurrentUser] = useState<UserSession | null>(null);
  const [locations, setLocations] = useState<Location[]>([]);

  // State Monitoring Otorisasi Revisi
  const [isAuthorizedForEdit, setIsAuthorizedForEdit] =
    useState<boolean>(false);

  // Form State Data Inspeksi
  const [date, setDate] = useState<string>('');
  const [shift, setShift] = useState<string>('1');
  const [locationId, setLocationId] = useState<string>('');
  const [checkPersonel, setCheckPersonel] = useState<'OK' | 'NOK'>('OK');
  const [checkRuangan, setCheckRuangan] = useState<'OK' | 'NOK'>('OK');
  const [checkPeralatan, setCheckPeralatan] = useState<'OK' | 'NOK'>('OK');
  const [ketPersonel, setKetPersonel] = useState<string>('');
  const [ketRuangan, setKetRuangan] = useState<string>('');
  const [ketPeralatan, setKetPeralatan] = useState<string>('');
  const [currentStatus, setCurrentStatus] = useState<string>('');

  // State Entry Terlewat (khusus edit missed entry)
  const [missedEntry, setMissedEntry] = useState<boolean>(false);
  const [missedReason, setMissedReason] = useState<string>('');
  const [missedType, setMissedType] = useState<string>('');
  const [missedDate, setMissedDate] = useState<string>('');
  const [originalMissedDate, setOriginalMissedDate] = useState<string>('');

  // UI & Loading States
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [validationErrors, setValidationErrors] = useState<Record<string, string>>({});

  // Modal Re-login / Authorization States
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);
  const [reloginUsername, setReloginUsername] = useState<string>('');
  const [reloginPassword, setReloginPassword] = useState<string>('');
  const [showReloginPassword, setShowReloginPassword] = useState<boolean>(false);
  const [reloginError, setReloginError] = useState<string | null>(null);
  const [isVerifyingAuth, setIsVerifyingAuth] = useState<boolean>(false);

  // Load Initial Session, Locations, & Inspection Data
  useEffect(() => {
    const initData = async () => {
      const params = new URLSearchParams(window.location.search);
      const id = params.get('id');
      setInspectionId(id);

      // Bila dibuka dari laporan inspeksi, simpan filter laporan supaya
      // setelah edit selesai (atau batal) user kembali dengan filter yang sama.
      if (params.get('from') === 'report') {
        const returnParams = new URLSearchParams();
        const month = params.get('month');
        const year = params.get('year');
        if (month) returnParams.set('month', month);
        if (year) returnParams.set('year', year);
        const locationId = params.get('locationId');
        if (locationId) returnParams.set('locationId', locationId);
        const date = params.get('date');
        if (date) returnParams.set('date', date);
        const missedType = params.get('missedType');
        if (missedType) returnParams.set('missedType', missedType);
        const sortOrder = params.get('sortOrder');
        if (sortOrder) returnParams.set('sortOrder', sortOrder);
        setReportReturnUrl(`/report_inspeksi?${returnParams.toString()}`);
      }

      if (!id) {
        setError('ID Inspeksi tidak ditemukan dalam parameter URL.');
        setIsLoading(false);
        return;
      }
      try {
        // Fetch User Session
        const sessionRes = await fetch('/api/auth/session');
        if (sessionRes.status === 401) {
          router.push('/login');
          return;
        }
        if (sessionRes.ok) {
          const sessionData = await sessionRes.json();
          setCurrentUser(sessionData.user || null);
        }

        // Fetch Locations Master Data
        const locRes = await fetch('/api/locations');
        if (locRes.ok) {
          const locData: { success: boolean; data: Location[] } = await locRes.json();
          setLocations(locData.data || []);
        }

        // Fetch Inspection Detail
        const inspectionRes = await fetch(`/api/inspections/${id}`);
        if (inspectionRes.status === 401) {
          router.push('/login');
          return;
        }
        if (inspectionRes.status === 404) {
          setError('Data inspeksi tidak ditemukan.');
          setIsLoading(false);
          return;
        }
        if (!inspectionRes.ok) {
          const errorData = await inspectionRes.json().catch(() => ({}));
          setError(errorData.error || errorData.message || 'Gagal memuat detail data inspeksi.');
          setIsLoading(false);
          return;
        }
        const result: { success: boolean; data: InspectionData } =
          await inspectionRes.json();
        const data = result.data;
        if (!data) {
          setError('Respons detail inspeksi tidak berisi data.');
          setIsLoading(false);
          return;
        }
        setDate(
          typeof data.date === 'string' ? data.date.split('T')[0] : ''
        );
        setShift(data.shift);
        setLocationId(data.locationId);
        setCheckPersonel(data.checkPersonel);
        setCheckRuangan(data.checkRuangan);
        setCheckPeralatan(data.checkPeralatan);
        setKetPersonel(data.ketPersonel || '');
        setKetRuangan(data.ketRuangan || '');
        setKetPeralatan(data.ketPeralatan || '');
        setCurrentStatus(data.status);
        setMissedEntry(Boolean(data.missedEntry));
        setMissedReason(data.missedReason || '');
        setMissedType(data.missedType || '');
        const loadedDate =
          typeof data.date === 'string' ? data.date.split('T')[0] : '';
        setMissedDate(loadedDate);
        setOriginalMissedDate(loadedDate);

      } catch (err) {
        setError('Terjadi kesalahan sistem saat memuat data.');
      } finally {
        setIsLoading(false);
      }
    };
    initData();
  }, [router]);

  // Handler Buka Modal Re-login
  const handleOpenAuthModal = () => {
    setReloginUsername('');
    setReloginPassword('');
    setShowReloginPassword(false);
    setReloginError(null);
    setIsAuthModalOpen(true);
  };

  // Handler Verifikasi Re-login & Minta Otorisasi Revisi ke Backend
  const handleAuthSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!reloginUsername.trim() || !reloginPassword) {
      setReloginError('Username dan password wajib diisi untuk otorisasi.');
      return;
    }
    setIsVerifyingAuth(true);
    setReloginError(null);
    try {
      // Step 1: Re-login Credential Verification
      const reloginRes = await fetch('/api/auth/relogin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username: reloginUsername.trim(),
          password: reloginPassword,
        }),
      });
      if (!reloginRes.ok) {
        const errData = await reloginRes.json().catch(() => ({}));
        setReloginError(
          errData.error || errData.message || 'Kredensial re-login tidak valid.'
        );
        setIsVerifyingAuth(false);
        return;
      }

      // Step 2: Request Revision Authorization to Backend
      const revisionRes = await fetch(
        `/api/inspections/${inspectionId}/revision`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            username: reloginUsername.trim(),
            password: reloginPassword,
          }),
        }
      );
      if (!revisionRes.ok) {
        const errData = await revisionRes.json().catch(() => ({}));
        setReloginError(
          errData.error || errData.message || 'Anda tidak memiliki hak otorisasi untuk melakukan revisi.'
        );
        setIsVerifyingAuth(false);
        return;
      }

      // Authorization granted. Password otorisator sengaja TIDAK dihapus
      // di sini: dipakai lagi sebagai kredensial otorisasi saat submit PUT,
      // lalu dihapus setelah submit berhasil.
      setIsAuthorizedForEdit(true);
      setIsAuthModalOpen(false);
      setShowReloginPassword(false);
    } catch (err) {
      setReloginError(
        'Terjadi kesalahan koneksi saat memverifikasi otorisasi.'
      );
    } finally {
      setIsVerifyingAuth(false);
    }
  };

  // Client Validation Logic
  const validateForm = (): boolean => {
    const errors: Record<string, string> = {};
    if (!locationId) errors.locationId = 'Lokasi wajib dipilih.';
    if (!shift) errors.shift = 'Shift wajib dipilih.';
    if (!checkPersonel) errors.checkPersonel = 'Status kebersihan personel wajib dipilih.';
    if (!checkRuangan) errors.checkRuangan = 'Status kebersihan ruangan wajib dipilih.';
    if (!checkPeralatan) errors.checkPeralatan = 'Status kebersihan peralatan wajib dipilih.';

    if (checkPersonel === 'NOK' && !ketPersonel.trim()) {
      errors.ketPersonel = 'Keterangan wajib diisi jika status NOK.';
    }
    if (checkRuangan === 'NOK' && !ketRuangan.trim()) {
      errors.ketRuangan = 'Keterangan wajib diisi jika status NOK.';
    }
    if (checkPeralatan === 'NOK' && !ketPeralatan.trim()) {
      errors.ketPeralatan = 'Keterangan wajib diisi jika status NOK.';
    }

    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };

  // Cek apakah dua tanggal berada dalam minggu yang sama (Senin-Minggu)
  const isSameWeek = (a: string, b: string): boolean => {
    const da = new Date(`${a}T00:00:00`);
    const db = new Date(`${b}T00:00:00`);
    if (Number.isNaN(da.getTime()) || Number.isNaN(db.getTime())) return false;
    const mondayOf = (d: Date) => {
      const x = new Date(d);
      const day = (x.getDay() + 6) % 7;
      x.setDate(x.getDate() - day);
      x.setHours(0, 0, 0, 0);
      return x.getTime();
    };
    return mondayOf(da) === mondayOf(db);
  };

  // Handler Submit Edit Entry Terlewat (PUT Request, khusus missed entry)
  const handleSubmitMissedForm = async () => {
    const errors: Record<string, string> = {};
    if (!missedReason) errors.missedReason = 'Alasan wajib dipilih.';
    const isWeekly = missedType === 'weekly';
    if (isWeekly) {
      if (!missedDate) {
        errors.missedDate = 'Tanggal wajib diisi.';
      } else if (!isSameWeek(missedDate, originalMissedDate)) {
        errors.missedDate =
          'Tanggal baru harus berada dalam minggu yang sama dengan tanggal semula.';
      }
    }
    setValidationErrors(errors);
    if (Object.keys(errors).length > 0) return;

    setIsSubmitting(true);
    setError(null);
    try {
      const res = await fetch(`/api/inspections/${inspectionId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          missedReason,
          ...(isWeekly ? { date: missedDate } : {}),
          authorizerUsername: reloginUsername.trim(),
          authorizerPassword: reloginPassword,
        }),
      });
      if (res.status === 401) {
        router.push('/login');
        return;
      }
      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        setError(
          errData.error || errData.message || 'Gagal menyimpan perubahan entry terlewat.'
        );
        setIsSubmitting(false);
        return;
      }
      setReloginPassword('');
      router.push(reportReturnUrl);
    } catch (err) {
      setError('Terjadi kesalahan sistem saat mengirimkan data perubahan.');
      setIsSubmitting(false);
    }
  };

  // Handler Submit Form Edit Inspeksi (PUT Request)
  const handleSubmitForm = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!isAuthorizedForEdit) return;
    if (missedEntry) {
      await handleSubmitMissedForm();
      return;
    }
    if (!validateForm()) return;

    setIsSubmitting(true);
    setError(null);

    const payload = {
      locationId,
      shift,
      checkPersonel,
      checkRuangan,
      checkPeralatan,
      ketPersonel: ketPersonel.trim() || undefined,
      ketRuangan: ketRuangan.trim() || undefined,
      ketPeralatan: ketPeralatan.trim() || undefined,
      authorizerUsername: reloginUsername.trim(),
      authorizerPassword: reloginPassword,
    };

    try {
      const res = await fetch(`/api/inspections/${inspectionId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      if (res.status === 401) {
        router.push('/login');
        return;
      }

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        setError(errData.error || errData.message || 'Gagal menyimpan perubahan revisi inspeksi.');
        setIsSubmitting(false);
        return;
      }

      // Success -> Redirect to Inspection Report Page
      setReloginPassword('');
      router.push(reportReturnUrl);
    } catch (err) {
      setError('Terjadi kesalahan sistem saat mengirimkan data perubahan.');
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <Suspense fallback={null}>
        <Sidebar />
      </Suspense>
      <div className="lg:ml-72 min-h-screen transition-all duration-300">
        <main className="p-4 sm:p-6 lg:p-8">
          {isLoading ? (
            <div className="flex items-center justify-center p-12">
              <p className="text-sm text-gray-500 font-medium">Memuat data inspeksi...</p>
            </div>
          ) : (
            <div className="w-full bg-white p-6 sm:p-8 rounded-2xl border border-slate-200/80 shadow-sm">
              {/* Header Bar */}
              <div className="pb-6 border-b border-slate-100">
                <div>
                  <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
                    {missedEntry
                      ? missedType === 'weekly'
                        ? 'Edit Entry Terlewat Mingguan'
                        : 'Edit Shift Terlewat'
                      : 'Edit Form Inspeksi Kebersihan'}
                  </h1>
                  <p className="text-sm text-slate-500 mt-1">
                    {missedEntry
                      ? missedType === 'weekly'
                        ? 'Perbarui tanggal dan alasan entry terlewat (Status akan kembali menjadi Menunggu Supervisor).'
                        : 'Perbarui alasan entry terlewat (Status akan kembali menjadi Menunggu Supervisor).'
                      : 'Perbarui rekaman inspeksi (Status akan kembali menjadi Menunggu Supervisor).'}
                  </p>
                </div>
              </div>

              {/* Banner Alert Failure/Error */}
              {error && (
                <div className="mt-6 bg-rose-50 border border-rose-200 text-rose-700 p-4 rounded-xl text-sm">
                  <p className="font-semibold">Validasi Gagal</p>
                  <p className="mt-1">{error}</p>
                </div>
              )}

              {/* Lock State Banner - Need Authorization */}
              {!isAuthorizedForEdit && (
                <div className="mt-6 bg-amber-50 border border-amber-200 p-4 rounded-xl text-amber-900 space-y-3">
                  <h2 className="font-bold text-sm">Otorisasi Edit Diperlukan</h2>
                  <p className="text-sm">
                    Data inspeksi ini berstatus <strong className="uppercase">{currentStatus}</strong>. Untuk dapat melakukan pengubahan data, diperlukan re-login akun Supervisor atau Administrator.
                  </p>
                  {currentUser?.role === 'staff' || currentUser?.role === 'manager' ? (
                    <p className="text-xs text-red-600 font-semibold italic">
                      Akses terbatas: akun ini hanya dapat memonitor data dan tidak dapat mengotorisasi perubahan sendiri — minta Supervisor atau Administrator mengetikkan kredensialnya di bawah ini.
                    </p>
                  ) : null}
                  <button
                    type="button"
                    onClick={handleOpenAuthModal}
                    className="px-5 py-2.5 rounded-xl text-sm font-semibold text-white bg-amber-600 hover:bg-amber-700 focus:outline-none focus:ring-2 focus:ring-amber-500/20 transition-all shadow-sm"
                  >
                    Minta Otorisasi Revisi (Re-login)
                  </button>
                </div>
              )}

              {/* Main Editable Form */}
              <div className="mt-6">
                <form onSubmit={handleSubmitForm} className="space-y-6">
                  {/* Field Read-only Info */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pb-2">
                    <div>
                      <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1.5">Tanggal Inspeksi</label>
                      {missedEntry && missedType === 'weekly' ? (
                        <>
                          <input
                            type="date"
                            value={missedDate}
                            onChange={(e: ChangeEvent<HTMLInputElement>) => setMissedDate(e.target.value)}
                            disabled={!isAuthorizedForEdit || isSubmitting}
                            className="w-full rounded-xl border border-slate-300 bg-white px-3.5 py-2.5 text-slate-800 text-sm focus:border-sky-500 focus:ring-2 focus:ring-sky-500/20 focus:outline-none disabled:bg-slate-100 transition-all"
                          />
                          {validationErrors.missedDate && (
                            <p className="mt-1 text-xs text-red-600">{validationErrors.missedDate}</p>
                          )}
                        </>
                      ) : (
                        <input
                          type="text"
                          value={date}
                          disabled
                          className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-slate-700 text-sm font-medium"
                        />
                      )}
                    </div>
                    <div>
                      <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1.5">Status Dokumen Saat Ini</label>
                      <input
                        type="text"
                        value={
                          currentStatus === 'SUBMITTED'
                            ? 'Menunggu Supervisor'
                            : currentStatus === 'SUPERVISOR_APPROVED'
                            ? 'Approved oleh Supervisor'
                            : 'Approved / Final'
                        }
                        disabled
                        className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-slate-700 text-sm font-medium"
                      />
                    </div>
                  </div>

                  {/* Field Location & Shift */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1.5">Lokasi Area <span className="text-rose-500">*</span></label>
                      <select
                        value={locationId}
                        onChange={(e: ChangeEvent<HTMLSelectElement>) => setLocationId(e.target.value)}
                        disabled
                        className="w-full rounded-xl border border-slate-300 bg-white px-3.5 py-2.5 text-slate-800 text-sm focus:border-sky-500 focus:ring-2 focus:ring-sky-500/20 focus:outline-none disabled:bg-slate-100 transition-all"
                      >
                        <option value="">-- Pilih Lokasi --</option>
                        {locations.map((loc) => (
                          <option key={loc.id} value={loc.id}>
                            {loc.name}
                          </option>
                        ))}
                      </select>
                      {validationErrors.locationId && (
                        <p className="mt-1 text-xs text-red-600">{validationErrors.locationId}</p>
                      )}
                    </div>
                    <div>
                      <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1.5">Shift <span className="text-rose-500">*</span></label>
                      <select
                        value={shift}
                        onChange={(e: ChangeEvent<HTMLSelectElement>) => setShift(e.target.value)}
                        disabled
                        className="w-full rounded-xl border border-slate-300 bg-white px-3.5 py-2.5 text-slate-800 text-sm focus:border-sky-500 focus:ring-2 focus:ring-sky-500/20 focus:outline-none disabled:bg-slate-100 transition-all"
                      >
                        <option value="1">Shift 1</option>
                        <option value="2">Shift 2</option>
                        <option value="3">Shift 3</option>
                      </select>
                      {validationErrors.shift && (
                        <p className="mt-1 text-xs text-red-600">{validationErrors.shift}</p>
                      )}
                    </div>
                  </div>

                  {missedEntry ? (
                    /* Alasan Entry Terlewat */
                    <div className="space-y-4 pt-2">
                      <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider border-b border-slate-100 pb-3">
                        Alasan Entry Terlewat
                      </h3>
                      <div>
                        <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1.5">
                          Alasan <span className="text-rose-500">*</span>
                        </label>
                        <select
                          value={missedReason}
                          onChange={(e: ChangeEvent<HTMLSelectElement>) => setMissedReason(e.target.value)}
                          disabled={!isAuthorizedForEdit || isSubmitting}
                          className="w-full rounded-xl border border-slate-300 bg-white px-3.5 py-2.5 text-slate-800 text-sm focus:border-sky-500 focus:ring-2 focus:ring-sky-500/20 focus:outline-none disabled:bg-slate-100 transition-all"
                        >
                          <option value="">-- Pilih Alasan --</option>
                          <option value="Lupa">Lupa</option>
                          <option value="Hari Libur">Hari Libur</option>
                          <option value="Tidak dilakukan">Tidak dilakukan</option>
                        </select>
                        {validationErrors.missedReason && (
                          <p className="mt-1 text-xs text-red-600">{validationErrors.missedReason}</p>
                        )}
                      </div>
                      {missedType === 'weekly' && (
                        <p className="text-xs text-slate-500">
                          Perubahan tanggal dan alasan diterapkan ke ketiga shift (1, 2, 3) sekaligus dengan jam edit yang sama.
                        </p>
                      )}
                    </div>
                  ) : (
                    /* Checklist Section */
                    <div className="space-y-4 pt-2">
                    <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider border-b border-slate-100 pb-3">
                      Pemeriksaan Kebersihan
                    </h3>

                    {/* 1. Personel */}
                    <div className="p-4 sm:p-5 rounded-2xl border border-slate-200/80 bg-slate-50/50 space-y-3">
                      <div className="space-y-3">
                        <label className="text-sm font-semibold text-slate-800">1. Kebersihan Personel <span className="text-rose-500">*</span></label>
                        <div className="grid grid-cols-2 gap-3 w-full sm:max-w-md">
                          {(['OK', 'NOK'] as const).map((value) => (
                            <label key={value} className={`flex items-center justify-center gap-2 p-2.5 rounded-xl border text-sm font-semibold cursor-pointer transition-all ${checkPersonel === value ? (value === 'OK' ? 'bg-emerald-50 border-emerald-500 text-emerald-700 shadow-sm' : 'bg-rose-50 border-rose-500 text-rose-700 shadow-sm') : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'}`}>
                              <input type="radio" name="checkPersonel" value={value} checked={checkPersonel === value} onChange={() => { setCheckPersonel(value); if (value === 'OK') setKetPersonel(''); }} disabled={!isAuthorizedForEdit || isSubmitting} className="sr-only" />
                              <span>{value === 'OK' ? '✓ OK' : '✕ NOK (Not OK)'}</span>
                            </label>
                          ))}
                        </div>
                      </div>
                      {checkPersonel === 'NOK' && (
                        <div className="pt-2">
                          <label className="block text-xs font-semibold text-rose-700 mb-1">
                            Keterangan Personel (Wajib diisi bila NOK) *
                          </label>
                          <textarea
                            rows={2}
                            value={ketPersonel}
                            onChange={(e: ChangeEvent<HTMLTextAreaElement>) => setKetPersonel(e.target.value)}
                            disabled={!isAuthorizedForEdit || isSubmitting}
                            placeholder="Jelaskan alasan/penemuan NOK personel..."
                            className="w-full rounded-xl border border-rose-300 p-3 text-sm text-slate-800 focus:border-rose-500 focus:ring-2 focus:ring-rose-500/20 focus:outline-none disabled:bg-slate-100"
                          />
                          {validationErrors.ketPersonel && (
                            <p className="mt-1 text-xs text-red-600">{validationErrors.ketPersonel}</p>
                          )}
                        </div>
                      )}
                    </div>

                    {/* 2. Ruangan */}
                    <div className="p-4 sm:p-5 rounded-2xl border border-slate-200/80 bg-slate-50/50 space-y-3">
                      <div className="space-y-3">
                        <label className="text-sm font-semibold text-slate-800">2. Kebersihan Ruangan <span className="text-rose-500">*</span></label>
                        <div className="grid grid-cols-2 gap-3 w-full sm:max-w-md">
                          {(['OK', 'NOK'] as const).map((value) => (
                            <label key={value} className={`flex items-center justify-center gap-2 p-2.5 rounded-xl border text-sm font-semibold cursor-pointer transition-all ${checkRuangan === value ? (value === 'OK' ? 'bg-emerald-50 border-emerald-500 text-emerald-700 shadow-sm' : 'bg-rose-50 border-rose-500 text-rose-700 shadow-sm') : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'}`}>
                              <input type="radio" name="checkRuangan" value={value} checked={checkRuangan === value} onChange={() => { setCheckRuangan(value); if (value === 'OK') setKetRuangan(''); }} disabled={!isAuthorizedForEdit || isSubmitting} className="sr-only" />
                              <span>{value === 'OK' ? '✓ OK' : '✕ NOK (Not OK)'}</span>
                            </label>
                          ))}
                        </div>
                      </div>
                      {checkRuangan === 'NOK' && (
                        <div className="pt-2">
                          <label className="block text-xs font-semibold text-rose-700 mb-1">
                            Keterangan Ruangan (Wajib diisi bila NOK) *
                          </label>
                          <textarea
                            rows={2}
                            value={ketRuangan}
                            onChange={(e: ChangeEvent<HTMLTextAreaElement>) => setKetRuangan(e.target.value)}
                            disabled={!isAuthorizedForEdit || isSubmitting}
                            placeholder="Jelaskan alasan/penemuan NOK ruangan..."
                            className="w-full rounded-xl border border-rose-300 p-3 text-sm text-slate-800 focus:border-rose-500 focus:ring-2 focus:ring-rose-500/20 focus:outline-none disabled:bg-slate-100"
                          />
                          {validationErrors.ketRuangan && (
                            <p className="mt-1 text-xs text-red-600">{validationErrors.ketRuangan}</p>
                          )}
                        </div>
                      )}
                    </div>

                    {/* 3. Peralatan */}
                    <div className="p-4 sm:p-5 rounded-2xl border border-slate-200/80 bg-slate-50/50 space-y-3">
                      <div className="space-y-3">
                        <label className="text-sm font-semibold text-slate-800">3. Kebersihan Peralatan <span className="text-rose-500">*</span></label>
                        <div className="grid grid-cols-2 gap-3 w-full sm:max-w-md">
                          {(['OK', 'NOK'] as const).map((value) => (
                            <label key={value} className={`flex items-center justify-center gap-2 p-2.5 rounded-xl border text-sm font-semibold cursor-pointer transition-all ${checkPeralatan === value ? (value === 'OK' ? 'bg-emerald-50 border-emerald-500 text-emerald-700 shadow-sm' : 'bg-rose-50 border-rose-500 text-rose-700 shadow-sm') : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'}`}>
                              <input type="radio" name="checkPeralatan" value={value} checked={checkPeralatan === value} onChange={() => { setCheckPeralatan(value); if (value === 'OK') setKetPeralatan(''); }} disabled={!isAuthorizedForEdit || isSubmitting} className="sr-only" />
                              <span>{value === 'OK' ? '✓ OK' : '✕ NOK (Not OK)'}</span>
                            </label>
                          ))}
                        </div>
                      </div>
                      {checkPeralatan === 'NOK' && (
                        <div className="pt-2">
                          <label className="block text-xs font-semibold text-rose-700 mb-1">
                            Keterangan Peralatan (Wajib diisi bila NOK) *
                          </label>
                          <textarea
                            rows={2}
                            value={ketPeralatan}
                            onChange={(e: ChangeEvent<HTMLTextAreaElement>) => setKetPeralatan(e.target.value)}
                            disabled={!isAuthorizedForEdit || isSubmitting}
                            placeholder="Jelaskan alasan/penemuan NOK peralatan..."
                            className="w-full rounded-xl border border-rose-300 p-3 text-sm text-slate-800 focus:border-rose-500 focus:ring-2 focus:ring-rose-500/20 focus:outline-none disabled:bg-slate-100"
                          />
                          {validationErrors.ketPeralatan && (
                            <p className="mt-1 text-xs text-red-600">{validationErrors.ketPeralatan}</p>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                  )}

                  {/* Action Buttons */}
                  <div className="pt-4 border-t border-gray-200 flex justify-end space-x-3">
                    <button
                      type="button"
                      onClick={() => router.push(reportReturnUrl)}
                      disabled={isSubmitting}
                      className="px-5 py-2.5 border border-slate-300 rounded-xl text-sm font-semibold text-slate-700 bg-white hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-sky-500/20 disabled:opacity-50 transition-all"
                    >
                      Batal
                    </button>
                    <button
                      type="submit"
                      disabled={!isAuthorizedForEdit || isSubmitting}
                      className="px-6 py-2.5 rounded-xl text-sm font-semibold text-white bg-sky-600 hover:bg-sky-700 focus:outline-none focus:ring-2 focus:ring-sky-500/20 disabled:bg-slate-300 transition-all shadow-sm"
                    >
                      {isSubmitting ? 'Menyimpan Revisi...' : 'Simpan Revisi Inspection'}
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}
        </main>
      </div>

      {/* Modal Re-login Otorisasi Revisi */}
      {isAuthModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg border border-gray-200 shadow-md max-w-md w-full p-6 space-y-4">
            <h3 className="text-lg font-bold text-slate-900 border-b border-slate-100 pb-3">
              Konfirmasi Otorisasi Revisi
            </h3>
            <p className="text-sm text-slate-500">
              Masukkan username dan password akun Supervisor atau Administrator untuk membuka akses edit.
            </p>
            {reloginError && (
              <div className="bg-red-50 border border-red-200 text-red-700 p-3 rounded text-xs">
                {reloginError}
              </div>
            )}
            <form onSubmit={handleAuthSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-gray-700">Username Otorisator</label>
                <input
                  type="text"
                  value={reloginUsername}
                  onChange={(e: ChangeEvent<HTMLInputElement>) => setReloginUsername(e.target.value)}
                  disabled={isVerifyingAuth}
                  className="w-full rounded-xl border border-slate-300 px-3.5 py-2.5 text-sm text-slate-800 focus:border-sky-500 focus:ring-2 focus:ring-sky-500/20 focus:outline-none disabled:bg-slate-100"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700">Password</label>
                <div className="relative">
                  <input
                    type={showReloginPassword ? 'text' : 'password'}
                    value={reloginPassword}
                    onChange={(e: ChangeEvent<HTMLInputElement>) => setReloginPassword(e.target.value)}
                    disabled={isVerifyingAuth}
                    placeholder="Masukkan password Anda"
                    className="w-full rounded-xl border border-slate-300 px-3.5 py-2.5 pr-10 text-sm text-slate-800 focus:border-sky-500 focus:ring-2 focus:ring-sky-500/20 focus:outline-none disabled:bg-slate-100"
                  />
                  <button
                    type="button"
                    onClick={() => setShowReloginPassword((visible) => !visible)}
                    disabled={isVerifyingAuth}
                    className="absolute inset-y-0 right-0 flex items-center px-3 text-slate-400 transition-colors hover:text-slate-600 focus:outline-none disabled:cursor-not-allowed"
                    aria-label={showReloginPassword ? 'Sembunyikan password' : 'Tampilkan password'}
                    aria-pressed={showReloginPassword}
                  >
                    {showReloginPassword ? (<svg
                        xmlns="http://www.w3.org/2000/svg"
                        fill="none"
                        viewBox="0 0 24 24"
                        strokeWidth={1.8}
                        stroke="currentColor"
                        className="h-5 w-5"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="M3.98 8.223A10.477 10.477 0 001.934 12C3.226 16.338 7.244 19.5 12 19.5c.993 0 1.953-.138 2.863-.395M6.228 6.228A10.45 10.45 0 0112 4.5c4.756 0 8.773 3.162 10.065 7.498a10.523 10.523 0 01-4.293 5.774M6.228 6.228L3 3m3.228 3.228l3.65 3.65m7.894 7.894L21 21m-3.228-3.228l-3.65-3.65m0 0a3 3 0 10-4.243-4.243m4.242 4.242L9.88 9.88"
                        />
                      </svg>) : (<svg
                        xmlns="http://www.w3.org/2000/svg"
                        fill="none"
                        viewBox="0 0 24 24"
                        strokeWidth={1.8}
                        stroke="currentColor"
                        className="h-5 w-5"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="M2.036 12.322a1.012 1.012 0 010-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.01 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.01-9.963-7.178z"
                        />
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"
                        />
                      </svg>)}
                  </button>
                </div>
              </div>
              <div className="flex justify-end space-x-2 pt-2 border-t border-gray-200">
                <button
                  type="button"
                  onClick={() => setIsAuthModalOpen(false)}
                  disabled={isVerifyingAuth}
                  className="px-4 py-2.5 border border-slate-300 rounded-xl text-sm font-semibold text-slate-700 bg-white hover:bg-slate-50 transition-all disabled:opacity-50"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={isVerifyingAuth}
                  className="px-5 py-2.5 rounded-xl text-sm font-semibold text-white bg-sky-600 hover:bg-sky-700 transition-all disabled:bg-slate-300"
                >
                  {isVerifyingAuth ? 'Memverifikasi...' : 'Verifikasi & Edit'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}