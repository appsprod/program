﻿'use client';

import React, { useState, useEffect, Suspense } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Sidebar from '../sidebar';

interface Location {
  id: string;
  name: string;
  code?: string;
  site?: string;
  department?: string;
}

interface InspectionProgress {
  hasHistory: boolean;
  nextShift?: string;
  missingDate?: string;
  missingShift?: string;
  requiresMissed?: boolean;
  missedType?: 'weekly' | 'shift';
  missedWeekStart?: string;
  missedWeekEnd?: string;
  activeShift?: string;
  inspectionDate?: string;
  activeShiftAvailable?: boolean;
  completedToday?: boolean;
  pendingShiftThree?: boolean;
  pendingShiftThreeDate?: string;
  pendingShiftThreeWeekStart?: string;
  pendingShiftThreeWeekEnd?: string;
  pendingShiftThreeAvailableFrom?: string;
  pendingShiftThreeAvailableThrough?: string;
  message: string;
  initialSubmitInfo?: string;
}

interface SubmittedNoticeInfo {
  type: 'shift' | 'weekly';
  date: string;
  shift: string;
  weekStart: string;
  weekEnd: string;
  locationId: string;
}

function formatNoticeDate(value: string): string {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return value;
  const [year, month, day] = value.split('-');
  return `${day}/${month}/${year}`;
}

function buildSubmittedNotice(info: SubmittedNoticeInfo, locations: Location[]): string {
  const locationName =
    locations.find((loc) => loc.id === info.locationId)?.name || info.locationId;
  const target = locationName ? ` untuk mesin ${locationName}` : '';
  const dateText = formatNoticeDate(info.date);
  if (info.type === 'weekly') {
    const range =
      info.weekStart && info.weekEnd
        ? ` (minggu ${formatNoticeDate(info.weekStart)} – ${formatNoticeDate(info.weekEnd)})`
        : '';
    return `Entry Terlewat Mingguan tanggal ${dateText}${range}${target} berhasil disimpan. Silakan pilih kembali area produksi untuk melanjutkan pengisian.`;
  }
  return `Shift ${info.shift} Terlewat tanggal ${dateText}${target} berhasil disimpan. Silakan pilih kembali area produksi untuk melanjutkan pengisian.`;
}

function SelectLocationContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const nextPage = searchParams.get('next');

  const [locations, setLocations] = useState<Location[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedLocationId, setSelectedLocationId] = useState<string>('');
  const [progress, setProgress] = useState<InspectionProgress | null>(null);
  const [isCheckingProgress, setIsCheckingProgress] = useState<boolean>(false);
  const [submittedInfo, setSubmittedInfo] = useState<SubmittedNoticeInfo | null>(null);

  useEffect(() => {
    fetchLocations();
  }, []);

  // Notifikasi sekali tampil setelah submit Entry Terlewat dari /keterangan.
  // Parameter URL dibersihkan supaya notifikasi tidak muncul lagi saat refresh.
  useEffect(() => {
    const submitted = searchParams.get('submitted');
    if (submitted !== 'shift' && submitted !== 'weekly') return;
    setSubmittedInfo({
      type: submitted,
      date: searchParams.get('date') || '',
      shift: searchParams.get('shift') || '',
      weekStart: searchParams.get('weekStart') || '',
      weekEnd: searchParams.get('weekEnd') || '',
      locationId: searchParams.get('locationId') || '',
    });
    const next = searchParams.get('next');
    router.replace(
      next ? `/selectlokasi?next=${encodeURIComponent(next)}` : '/selectlokasi'
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const fetchLocations = async () => {
    setIsLoading(true);
    setError(null);

    try {
      const response = await fetch('/api/locations', {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (response.status === 401) {
        router.push('/login');
        return;
      }

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        setError(errorData.message || 'Gagal mengambil daftar lokasi.');
        setIsLoading(false);
        return;
      }

      const result: { success: boolean; data: Location[] } = await response.json();
      setLocations(result.data || []);
    } catch (err) {
      setError('Terjadi kesalahan koneksi ke server. Silakan coba lagi.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSelectLocation = async (locationId: string, resolvePendingShiftThree = false) => {
    if (!locationId) return;

    setIsCheckingProgress(true);
    setError(null);
    try {
      const response = await fetch(`/api/inspections/progress?locationId=${encodeURIComponent(locationId)}`);
      if (response.status === 401) {
        router.push('/login');
        return;
      }

      const result: { success: boolean; data: InspectionProgress; message?: string } = await response.json();
      if (!response.ok || !result.success) {
        setError(result.message || 'Gagal memeriksa progres inspeksi lokasi.');
        return;
      }

      setProgress(result.data);
      if (nextPage === 'keterangan') {
        if (result.data.requiresMissed) {
          const params = new URLSearchParams({
            locationId,
            entryType: result.data.missedType || 'shift',
            date: result.data.missingDate || '',
            shift: result.data.missingShift || '',
            weekStart: result.data.missedWeekStart || '',
            weekEnd: result.data.missedWeekEnd || '',
          });
          router.push(`/keterangan?${params.toString()}`);
          return;
        }
        if (!result.data.pendingShiftThree) {
          setError('Tidak ada Entry Terlewat yang perlu diselesaikan untuk mesin ini.');
          return;
        }
        const params = new URLSearchParams({
          locationId,
          entryType: 'shift',
          date: result.data.pendingShiftThreeAvailableFrom || '',
          shift: '3',
          weekStart: result.data.pendingShiftThreeWeekStart || '',
          weekEnd: result.data.pendingShiftThreeWeekEnd || '',
          flexibleShiftThree: 'true',
          availableFrom: result.data.pendingShiftThreeAvailableFrom || '',
          availableThrough: result.data.pendingShiftThreeAvailableThrough || '',
        });
        router.push(`/keterangan?${params.toString()}`);
        return;
      }
      if (resolvePendingShiftThree) {
        if (!result.data.pendingShiftThree) {
          setError('Tidak ada tanggungan Shift 3 yang dapat diselesaikan untuk mesin ini.');
          return;
        }
        const params = new URLSearchParams({
          locationId,
          entryType: 'shift',
          date: result.data.pendingShiftThreeAvailableFrom || '',
          shift: '3',
          weekStart: result.data.pendingShiftThreeWeekStart || '',
          weekEnd: result.data.pendingShiftThreeWeekEnd || '',
          flexibleShiftThree: 'true',
          availableFrom: result.data.pendingShiftThreeAvailableFrom || '',
          availableThrough: result.data.pendingShiftThreeAvailableThrough || '',
        });
        router.push(`/keterangan?${params.toString()}`);
        return;
      }
      if (result.data.requiresMissed) {
        const params = new URLSearchParams({
          locationId,
          entryType: result.data.missedType || 'shift',
          date: result.data.missingDate || '',
          shift: result.data.missingShift || '',
          weekStart: result.data.missedWeekStart || '',
          weekEnd: result.data.missedWeekEnd || '',
        });
        router.push(`/keterangan?${params.toString()}`);
        return;
      }
      if (!result.data.activeShiftAvailable) return;

      router.push(`/form_inspeksi?lokasi=${encodeURIComponent(locationId)}&shift=${result.data.nextShift || ''}&date=${result.data.inspectionDate || ''}`);
    } catch (err) {
      setError('Terjadi kesalahan koneksi saat memeriksa progres inspeksi.');
    } finally {
      setIsCheckingProgress(false);
    }
  };

  const submittedNoticeText = submittedInfo
    ? buildSubmittedNotice(submittedInfo, locations)
    : null;

  return (
    <div className="space-y-6">
      {/* Header Page */}
      <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200/80 shadow-sm">
        <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
          Pilih Lokasi Inspeksi
        </h1>
        <p className="text-sm text-slate-500 mt-1">
          Silakan pilih lokasi area produksi yang akan dilakukan inspeksi kebersihan.
        </p>
      </div>

      {/* Form / Selection Card */}
      <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200/80 shadow-sm max-w-2xl">
        {/* Loading State */}
        {isLoading && (
          <div className="text-center py-12">
            <p className="text-sm text-slate-500 font-medium">Memuat daftar lokasi...</p>
          </div>
        )}

        {/* Error State */}
        {!isLoading && error && (
          <div className="bg-rose-50 border border-rose-200 text-rose-700 p-4 rounded-xl text-sm space-y-3">
            <div>
              <p className="font-semibold">Terjadi Kesalahan</p>
              <p className="mt-0.5">{error}</p>
            </div>
            <button
              onClick={fetchLocations}
              className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-semibold transition-all shadow-sm"
            >
              Coba Lagi
            </button>
          </div>
        )}

        {/* Empty State */}
        {!isLoading && !error && locations.length === 0 && (
          <div className="text-center py-10 bg-slate-50 rounded-xl border border-dashed border-slate-300 p-6">
            <p className="text-sm text-slate-700 font-semibold">Tidak ada lokasi yang tersedia.</p>
            <p className="text-xs text-slate-500 mt-1">
              Anda tidak memiliki akses ke lokasi manapun atau data lokasi belum dikonfigurasi.
            </p>
          </div>
        )}

        {/* Dropdown Select Location */}
        {!isLoading && !error && locations.length > 0 && (
          <div className="space-y-6">
            <div>
              <label
                htmlFor="locationSelect"
                className="block text-xs font-semibold uppercase tracking-wider text-slate-500 mb-2"
              >
                Area Lokasi Produksi <span className="text-rose-500">*</span>
              </label>
              <select
                id="locationSelect"
                value={selectedLocationId}
                onChange={(e) => {
                  setSelectedLocationId(e.target.value);
                  setProgress(null);
                }}
                className="w-full rounded-xl border border-slate-300 bg-white px-3.5 py-2.5 text-slate-800 text-sm focus:border-sky-500 focus:ring-2 focus:ring-sky-500/20 focus:outline-none transition-all"
              >
                <option value="">-- Pilih Lokasi --</option>
                {locations.map((loc) => {
                  const details = [
                    loc.code ? `Kode: ${loc.code}` : null,
                    loc.department ? `Dept: ${loc.department}` : null,
                  ]
                    .filter(Boolean)
                    .join(' | ');

                  return (
                    <option key={loc.id} value={loc.id}>
                      {loc.name} {details ? `(${details})` : ''}
                    </option>
                  );
                })}
              </select>
            </div>

            {submittedNoticeText && !isLoading && (
              <div className="rounded-xl border border-sky-200 bg-sky-50 p-4 text-sm text-sky-900">
                <div className="flex items-start justify-between gap-3">
                  <p>{submittedNoticeText}</p>
                  <button
                    type="button"
                    onClick={() => setSubmittedInfo(null)}
                    aria-label="Tutup notifikasi"
                    className="shrink-0 rounded-md px-2 py-0.5 text-base font-bold leading-none text-sky-700 hover:bg-sky-100"
                  >
                    ×
                  </button>
                </div>
              </div>
            )}

            {progress && (
              <div className={`rounded-xl border p-4 text-sm ${
                progress.requiresMissed || progress.completedToday
                  ? 'border-amber-200 bg-amber-50 text-amber-900'
                  : 'border-sky-200 bg-sky-50 text-sky-900'
              }`}>
                {progress.initialSubmitInfo && <p>{progress.initialSubmitInfo}</p>}
                {progress.message}
              </div>
            )}

            <div className="pt-2 border-t border-slate-100 flex justify-end">
              <button
                disabled={!selectedLocationId || isCheckingProgress || Boolean(progress && !progress.requiresMissed && !progress.activeShiftAvailable && nextPage !== 'keterangan')}
                onClick={() => handleSelectLocation(selectedLocationId)}
                className="w-full sm:w-auto px-6 py-2.5 bg-sky-600 hover:bg-sky-700 disabled:bg-slate-300 disabled:cursor-not-allowed text-white font-semibold text-sm rounded-xl transition-all shadow-sm"
              >
                {isCheckingProgress
                  ? 'Memeriksa...'
                  : progress?.requiresMissed && nextPage !== 'keterangan'
                  ? progress.missedType === 'weekly' ? 'Selesaikan Entry Terlewat Mingguan' : 'Lengkapi Shift Terlewat'
                  : 'Lanjutkan Inspeksi'}
              </button>
            </div>
            {progress?.pendingShiftThree && !progress.requiresMissed && nextPage !== 'keterangan' && (
              <div className="flex justify-end">
                <button
                  type="button"
                  disabled={!selectedLocationId || isCheckingProgress}
                  onClick={() => handleSelectLocation(selectedLocationId, true)}
                  className="w-full sm:w-auto px-6 py-2.5 border border-amber-300 bg-amber-50 hover:bg-amber-100 disabled:bg-slate-100 disabled:cursor-not-allowed text-amber-900 font-semibold text-sm rounded-xl transition-all"
                >
                  Catat Shift 3 Terlewat
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

export default function SelectLocationPage() {
  return (
    <div className="min-h-screen bg-slate-50">
      {/* Sidebar Navigation */}
      <Suspense fallback={null}>
        <Sidebar />
      </Suspense>

      {/* Main Content Area */}
      <div className="lg:ml-72 min-h-screen transition-all duration-300">
        <main className="p-4 sm:p-6 lg:p-8">
          <Suspense
            fallback={
              <div className="bg-white p-8 rounded-2xl border border-slate-200/80 shadow-sm text-center py-12 max-w-2xl">
                <p className="text-sm text-slate-500 font-medium">Memuat halaman lokasi...</p>
              </div>
            }
          >
            <SelectLocationContent />
          </Suspense>
        </main>
      </div>
    </div>
  );
}