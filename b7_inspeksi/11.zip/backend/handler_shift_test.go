package main

import (
	"reflect"
	"testing"
	"time"
)

func TestShiftClockBoundaries(t *testing.T) {
	t.Run("uses Jakarta calendar weeks", func(t *testing.T) {
		refDate := time.Date(2026, 10, 15, 22, 30, 0, 0, time.UTC)
		got := getWeekStart(refDate)
		want := time.Date(2026, 10, 12, 0, 0, 0, 0, jakartaLocation())
		if !got.Equal(want) {
			t.Fatalf("getWeekStart(...) = %s, want %s", got.Format(time.RFC3339), want.Format(time.RFC3339))
		}

		parsedDate := normalizeInspectionDate("2026-10-15", refDate)
		if parsedDate.Location().String() != jakartaLocation().String() || parsedDate.Day() != 15 || parsedDate.Month() != time.October {
			t.Fatalf("normalizeInspectionDate(...) = %s, want 2026-10-15 in Asia/Jakarta", parsedDate.Format(time.RFC3339))
		}
	})

	t.Run("maps clock boundaries to shifts and start dates", func(t *testing.T) {
		tests := []struct {
			name      string
			localTime time.Time
			wantShift string
			wantDate  string
		}{
			{"before shift 1 starts", time.Date(2026, 10, 13, 6, 44, 59, 0, jakartaLocation()), "3", "2026-10-12"},
			{"shift 1 starts", time.Date(2026, 10, 13, 6, 45, 0, 0, jakartaLocation()), "1", "2026-10-13"},
			{"shift 1 ends", time.Date(2026, 10, 13, 15, 14, 59, 0, jakartaLocation()), "1", "2026-10-13"},
			{"shift 2 starts", time.Date(2026, 10, 13, 15, 15, 0, 0, jakartaLocation()), "2", "2026-10-13"},
			{"shift 2 ends", time.Date(2026, 10, 13, 22, 29, 59, 0, jakartaLocation()), "2", "2026-10-13"},
			{"shift 3 starts", time.Date(2026, 10, 13, 22, 30, 0, 0, jakartaLocation()), "3", "2026-10-13"},
			{"early shift 3", time.Date(2026, 10, 13, 1, 37, 0, 0, jakartaLocation()), "3", "2026-10-12"},
		}
		for _, test := range tests {
			t.Run(test.name, func(t *testing.T) {
				gotShift, gotDate := getCurrentShift(test.localTime)
				if gotShift != test.wantShift {
					t.Errorf("shift = %s, want %s", gotShift, test.wantShift)
				}
				if got := gotDate.Format("2006-01-02"); got != test.wantDate {
					t.Errorf("date = %s, want %s", got, test.wantDate)
				}
			})
		}
	})
}

func TestGetAvailableShiftsForWeek(t *testing.T) {
	jakarta := jakartaLocation()
	weekDate := time.Date(2026, 10, 21, 0, 0, 0, 0, jakarta)
	inspections := []Inspection{
		{Date: time.Date(2026, 10, 19, 0, 0, 0, 0, jakarta), Shift: "1"},
		{Date: time.Date(2026, 10, 20, 0, 0, 0, 0, jakarta), Shift: "2"},
	}
	got := getAvailableShiftsForWeek(inspections, weekDate)
	want := []string{"3"}
	if !reflect.DeepEqual(got, want) {
		t.Fatalf("getAvailableShiftsForWeek() = %#v, want %#v", got, want)
	}
}

// inspek builds a fixture record. createdAt is the input order: the
// anchor date of a week is the Date of the record input first.
func inspek(jakarta *time.Location, year int, month time.Month, day int, shift string, createdHour, createdMinute int, missed bool) Inspection {
	return Inspection{
		Date:        time.Date(year, month, day, 0, 0, 0, 0, jakarta),
		Shift:       shift,
		CreatedAt:   time.Date(year, month, day, createdHour, createdMinute, 0, 0, jakarta),
		MissedEntry: missed,
	}
}

func TestWeekAnchorDate(t *testing.T) {
	jakarta := jakartaLocation()
	weekStart := time.Date(2026, 10, 19, 0, 0, 0, 0, jakarta)

	t.Run("no records means no anchor date", func(t *testing.T) {
		if _, ok := weekAnchorDate(nil, weekStart); ok {
			t.Fatal("weekAnchorDate(nil) returned an anchor date, want none")
		}
	})

	t.Run("anchor is the date of the first input record", func(t *testing.T) {
		inspections := []Inspection{
			inspek(jakarta, 2026, 10, 20, "2", 16, 0, false),
			inspek(jakarta, 2026, 10, 19, "1", 7, 0, false),
		}
		got, ok := weekAnchorDate(inspections, weekStart)
		if !ok || got.Format("2006-01-02") != "2026-10-19" {
			t.Fatalf("weekAnchorDate() = %s, %t; want 2026-10-19, true", got.Format("2006-01-02"), ok)
		}
	})

	t.Run("anchor follows input order, not the earliest calendar date", func(t *testing.T) {
		// The Oct 19 record was only input on Oct 21, after the Oct 20
		// record was already input on Oct 20: the week started Oct 20.
		inspections := []Inspection{
			{Date: time.Date(2026, 10, 19, 0, 0, 0, 0, jakarta), Shift: "1",
				CreatedAt: time.Date(2026, 10, 21, 9, 0, 0, 0, jakarta)},
			{Date: time.Date(2026, 10, 20, 0, 0, 0, 0, jakarta), Shift: "2",
				CreatedAt: time.Date(2026, 10, 20, 16, 0, 0, 0, jakarta)},
		}
		got, ok := weekAnchorDate(inspections, weekStart)
		if !ok || got.Format("2006-01-02") != "2026-10-20" {
			t.Fatalf("weekAnchorDate() = %s, %t; want 2026-10-20, true", got.Format("2006-01-02"), ok)
		}
	})

	t.Run("a missed entry also starts the week", func(t *testing.T) {
		inspections := []Inspection{
			inspek(jakarta, 2026, 10, 20, "1", 10, 0, true),
		}
		got, ok := weekAnchorDate(inspections, weekStart)
		if !ok || got.Format("2006-01-02") != "2026-10-20" {
			t.Fatalf("weekAnchorDate() = %s, %t; want 2026-10-20, true", got.Format("2006-01-02"), ok)
		}
	})
}

func TestOldestDueShiftDebt(t *testing.T) {
	jakarta := jakartaLocation()

	t.Run("shift three becomes a debt the morning after its anchor date", func(t *testing.T) {
		inspections := []Inspection{
			inspek(jakarta, 2026, 10, 20, "1", 7, 0, false),
			inspek(jakarta, 2026, 10, 20, "2", 16, 0, false),
		}
		now := time.Date(2026, 10, 21, 7, 0, 0, 0, jakarta)
		debt, ok := oldestDueShiftDebt(inspections, now)
		if !ok || debt.Shift != "3" || debt.Date.Format("2006-01-02") != "2026-10-20" {
			t.Fatalf("oldestDueShiftDebt() = %#v, %t; want Shift 3 dated 2026-10-20", debt, ok)
		}
	})

	t.Run("only shift one filled leaves shift two as the oldest debt", func(t *testing.T) {
		inspections := []Inspection{
			inspek(jakarta, 2026, 10, 20, "1", 7, 0, false),
		}
		now := time.Date(2026, 10, 21, 7, 0, 0, 0, jakarta)
		debt, ok := oldestDueShiftDebt(inspections, now)
		if !ok || debt.Shift != "2" || debt.Date.Format("2006-01-02") != "2026-10-20" {
			t.Fatalf("oldestDueShiftDebt() = %#v, %t; want Shift 2 dated 2026-10-20", debt, ok)
		}
	})

	t.Run("a missed shift one still leaves an unfilled shift three as a debt", func(t *testing.T) {
		inspections := []Inspection{
			inspek(jakarta, 2026, 10, 20, "1", 10, 0, true),
			inspek(jakarta, 2026, 10, 20, "2", 16, 0, false),
		}
		now := time.Date(2026, 10, 21, 7, 0, 0, 0, jakarta)
		debt, ok := oldestDueShiftDebt(inspections, now)
		if !ok || debt.Shift != "3" || debt.Date.Format("2006-01-02") != "2026-10-20" {
			t.Fatalf("oldestDueShiftDebt() = %#v, %t; want Shift 3 dated 2026-10-20", debt, ok)
		}
	})

	t.Run("no debt while the shift three window is still open", func(t *testing.T) {
		inspections := []Inspection{
			inspek(jakarta, 2026, 10, 20, "1", 7, 0, false),
			inspek(jakarta, 2026, 10, 20, "2", 16, 0, false),
		}
		now := time.Date(2026, 10, 20, 16, 0, 0, 0, jakarta)
		if _, ok := oldestDueShiftDebt(inspections, now); ok {
			t.Fatal("oldestDueShiftDebt() found a debt before the Shift 3 window ended")
		}
		// 06:40 the next morning is still inside the Shift 3 window.
		now = time.Date(2026, 10, 21, 6, 40, 0, 0, jakarta)
		if _, ok := oldestDueShiftDebt(inspections, now); ok {
			t.Fatal("oldestDueShiftDebt() found a debt at 06:40, before the Shift 3 window ended at 06:45")
		}
		// One minute past the window end, the debt is due.
		now = time.Date(2026, 10, 21, 6, 46, 0, 0, jakarta)
		if _, ok := oldestDueShiftDebt(inspections, now); !ok {
			t.Fatal("oldestDueShiftDebt() found no debt at 06:46, after the Shift 3 window ended")
		}
	})

	t.Run("no debt when all three shifts are filled", func(t *testing.T) {
		inspections := []Inspection{
			inspek(jakarta, 2026, 10, 20, "1", 7, 0, false),
			inspek(jakarta, 2026, 10, 20, "2", 16, 0, false),
			inspek(jakarta, 2026, 10, 20, "3", 23, 0, false),
		}
		now := time.Date(2026, 10, 21, 7, 0, 0, 0, jakarta)
		if _, ok := oldestDueShiftDebt(inspections, now); ok {
			t.Fatal("oldestDueShiftDebt() found a debt in a complete week")
		}
	})

	t.Run("the oldest week's debt wins over a newer week's debt", func(t *testing.T) {
		inspections := []Inspection{
			inspek(jakarta, 2026, 10, 19, "1", 7, 0, false),
			inspek(jakarta, 2026, 10, 26, "1", 7, 0, false),
		}
		now := time.Date(2026, 10, 27, 7, 0, 0, 0, jakarta)
		debt, ok := oldestDueShiftDebt(inspections, now)
		if !ok || debt.Shift != "2" || debt.Date.Format("2006-01-02") != "2026-10-19" {
			t.Fatalf("oldestDueShiftDebt() = %#v, %t; want Shift 2 dated 2026-10-19", debt, ok)
		}
	})
}

func TestAnchorlessCurrentWeekShiftDebt(t *testing.T) {
	jakarta := jakartaLocation()

	// Skenario laporan 30 Okt 2026 15:23 (Shift 2): minggu-minggu lama
	// lengkap, minggu berjalan 26 Okt-1 Nov belum ada isian sama sekali.
	// Progress sudah mengarahkan ke Shift Terlewat Shift 1 tanggal
	// 30 Okt, jadi submit harus menerimanya, bukan menolak dengan
	// "Tidak ada Shift Terlewat".
	priorWeeks := []Inspection{
		inspek(jakarta, 2026, 10, 5, "1", 7, 0, true),
		inspek(jakarta, 2026, 10, 5, "2", 16, 0, true),
		inspek(jakarta, 2026, 10, 5, "3", 23, 0, true),
		inspek(jakarta, 2026, 10, 12, "1", 7, 0, true),
		inspek(jakarta, 2026, 10, 12, "2", 16, 0, true),
		inspek(jakarta, 2026, 10, 12, "3", 23, 0, true),
		inspek(jakarta, 2026, 10, 21, "1", 7, 0, true),
		inspek(jakarta, 2026, 10, 21, "2", 16, 0, false),
		inspek(jakarta, 2026, 10, 21, "3", 23, 0, true),
	}
	createdAt := time.Date(2026, 10, 5, 0, 0, 0, 0, jakarta)

	t.Run("shift one is a debt in an unstarted week once its window ends", func(t *testing.T) {
		now := time.Date(2026, 10, 30, 15, 23, 0, 0, jakarta)
		debt, ok := oldestDueShiftDebt(priorWeeks, now)
		if !ok || debt.Shift != "1" || debt.Date.Format("2006-01-02") != "2026-10-30" ||
			debt.WeekStart.Format("2006-01-02") != "2026-10-26" {
			t.Fatalf("oldestDueShiftDebt() = %#v, %t; want Shift 1 dated 2026-10-30, week 2026-10-26", debt, ok)
		}
		// Progress dan submit harus sepakat: progress mengarahkan ke
		// tanggungan yang sama.
		got := getInspectionProgress(priorWeeks, now, createdAt)
		if got["requiresMissed"] != true || got["missedType"] != "shift" ||
			got["missingShift"] != "1" || got["missingDate"] != "2026-10-30" {
			t.Fatalf("getInspectionProgress() = %#v; want requiresMissed Shift 1 dated 2026-10-30", got)
		}
	})

	t.Run("no debt in an unstarted week while the shift one window is still open", func(t *testing.T) {
		now := time.Date(2026, 10, 30, 10, 0, 0, 0, jakarta)
		if _, ok := oldestDueShiftDebt(priorWeeks, now); ok {
			t.Fatal("oldestDueShiftDebt() found a debt at 10:00, before the Shift 1 window ended")
		}
		got := getInspectionProgress(priorWeeks, now, createdAt)
		if got["requiresMissed"] == true || got["activeShiftAvailable"] != true || got["nextShift"] != "1" {
			t.Fatalf("getInspectionProgress() = %#v; want normal Shift 1 available at 10:00", got)
		}
	})

	t.Run("a brand-new machine can file shift one missed in shift two", func(t *testing.T) {
		now := time.Date(2026, 10, 30, 15, 23, 0, 0, jakarta)
		debt, ok := oldestDueShiftDebt(nil, now)
		if !ok || debt.Shift != "1" || debt.Date.Format("2006-01-02") != "2026-10-30" {
			t.Fatalf("oldestDueShiftDebt() = %#v, %t; want Shift 1 dated 2026-10-30", debt, ok)
		}
	})

	t.Run("shift one is the oldest debt late in the day", func(t *testing.T) {
		now := time.Date(2026, 10, 30, 23, 0, 0, 0, jakarta)
		debt, ok := oldestDueShiftDebt(nil, now)
		if !ok || debt.Shift != "1" || debt.Date.Format("2006-01-02") != "2026-10-30" {
			t.Fatalf("oldestDueShiftDebt() = %#v, %t; want Shift 1 dated 2026-10-30, not Shift 2", debt, ok)
		}
	})

	t.Run("an empty older week is still a weekly debt, not a shift debt", func(t *testing.T) {
		inspections := []Inspection{
			inspek(jakarta, 2026, 10, 5, "1", 7, 0, true),
			inspek(jakarta, 2026, 10, 5, "2", 16, 0, true),
			inspek(jakarta, 2026, 10, 5, "3", 23, 0, true),
		}
		now := time.Date(2026, 10, 30, 15, 23, 0, 0, jakarta)
		// Tidak ada tanggungan shift dari minggu 12 Okt yang kosong.
		debt, ok := oldestDueShiftDebt(inspections, now)
		if !ok || debt.WeekStart.Format("2006-01-02") != "2026-10-26" {
			t.Fatalf("oldestDueShiftDebt() = %#v, %t; want only the current-week debt", debt, ok)
		}
		// Progress tetap mendahulukan Entry Terlewat Mingguan minggu
		// 12 Okt yang paling lama.
		got := getInspectionProgress(inspections, now, createdAt)
		if got["missedType"] != "weekly" || got["missedWeekStart"] != "2026-10-12" {
			t.Fatalf("getInspectionProgress() = %#v; want weekly debt for week 2026-10-12 first", got)
		}
	})
}

func TestGetInspectionProgressMissedEntryOrdering(t *testing.T) {
	jakarta := jakartaLocation()
	currentTime := time.Date(2026, 10, 26, 16, 0, 0, 0, jakarta)

	t.Run("requires first missed shift before active shift", func(t *testing.T) {
		inspections := []Inspection{
			{Date: time.Date(2026, 10, 26, 0, 0, 0, 0, jakarta), Shift: "2"},
		}
		got := getInspectionProgress(inspections, currentTime)
		if got["missedType"] != "shift" || got["missingShift"] != "1" {
			t.Fatalf("getInspectionProgress() = %#v, want missed Shift 1 before active Shift 2", got)
		}
	})

	t.Run("assigns pre-0645 shift 3 to its start date", func(t *testing.T) {
		inspections := []Inspection{
			{Date: time.Date(2026, 10, 12, 0, 0, 0, 0, jakarta), Shift: "1"},
		}
		now := time.Date(2026, 10, 13, 1, 37, 0, 0, jakarta)
		got := getInspectionProgress(inspections, now)
		if got["missedType"] != "shift" || got["missingShift"] != "2" || got["inspectionDate"] != "2026-10-12" {
			t.Fatalf("getInspectionProgress() = %#v, want Shift 2 missed in shift-start date 2026-10-12", got)
		}
	})

	t.Run("a missing earlier shift on the anchor date blocks the next day as a missed debt", func(t *testing.T) {
		// Only Shift 2 was ever input, on Oct 26. Shift 1 of that same
		// anchor date is a debt the next day: it must be filed as a
		// missed entry dated Oct 26, never as a normal Oct 27 fill.
		inspections := []Inspection{
			inspek(jakarta, 2026, 10, 26, "2", 16, 0, false),
		}
		now := time.Date(2026, 10, 27, 7, 0, 0, 0, jakarta)
		got := getInspectionProgress(inspections, now)
		if got["requiresMissed"] != true || got["missingShift"] != "1" || got["missingDate"] != "2026-10-26" {
			t.Fatalf("getInspectionProgress() = %#v, want missed Shift 1 dated 2026-10-26", got)
		}
		if got["activeShiftAvailable"] != false {
			t.Fatalf("getInspectionProgress() = %#v, want no normal fill on 2026-10-27", got)
		}
	})

	t.Run("does not allow weekly shifts to be repeated on the next day", func(t *testing.T) {
		inspections := []Inspection{
			{Date: time.Date(2026, 10, 20, 0, 0, 0, 0, jakarta), Shift: "1"},
			{Date: time.Date(2026, 10, 20, 0, 0, 0, 0, jakarta), Shift: "2"},
			{Date: time.Date(2026, 10, 20, 0, 0, 0, 0, jakarta), Shift: "3"},
		}
		now := time.Date(2026, 10, 21, 7, 0, 0, 0, jakarta)
		got := getInspectionProgress(inspections, now)
		if got["requiresMissed"] == true || got["activeShiftAvailable"] != false || got["nextShift"] != "" {
			t.Fatalf("getInspectionProgress() = %#v, want filled weekly Shift 1 unavailable on 2026-10-21", got)
		}
	})

	t.Run("a complete week leaves no normal fill the next day", func(t *testing.T) {
		// User's example 1A: Shift 1 missed, Shift 2 and 3 normal, all
		// on Oct 7. On Oct 8 there is no fill option left.
		inspections := []Inspection{
			inspek(jakarta, 2026, 10, 7, "1", 10, 0, true),
			inspek(jakarta, 2026, 10, 7, "2", 16, 0, false),
			inspek(jakarta, 2026, 10, 7, "3", 23, 0, false),
		}
		now := time.Date(2026, 10, 8, 7, 0, 0, 0, jakarta)
		got := getInspectionProgress(inspections, now)
		if got["requiresMissed"] == true || got["activeShiftAvailable"] != false || got["nextShift"] != "" {
			t.Fatalf("getInspectionProgress() = %#v, want no fill option on 2026-10-08", got)
		}
	})

	t.Run("only shift one filled makes the rest missed debts the next day", func(t *testing.T) {
		// User's example 1C: Shift 1 filled Oct 7, Shift 2 and 3
		// forgotten. From Oct 8 they are missed entries dated Oct 7,
		// never normal fills.
		inspections := []Inspection{
			inspek(jakarta, 2026, 10, 7, "1", 7, 0, false),
		}
		now := time.Date(2026, 10, 8, 7, 0, 0, 0, jakarta)
		got := getInspectionProgress(inspections, now)
		if got["requiresMissed"] != true || got["missingShift"] != "2" || got["missingDate"] != "2026-10-07" {
			t.Fatalf("getInspectionProgress() = %#v, want missed Shift 2 dated 2026-10-07", got)
		}
		if got["activeShiftAvailable"] != false || got["nextShift"] != "" {
			t.Fatalf("getInspectionProgress() = %#v, want no normal fill on 2026-10-08", got)
		}
	})

	t.Run("normal fills stay open on the anchor date itself", func(t *testing.T) {
		inspections := []Inspection{
			inspek(jakarta, 2026, 10, 7, "1", 7, 0, false),
		}
		now := time.Date(2026, 10, 7, 16, 0, 0, 0, jakarta)
		got := getInspectionProgress(inspections, now)
		if got["requiresMissed"] == true || got["activeShiftAvailable"] != true || got["nextShift"] != "2" {
			t.Fatalf("getInspectionProgress() = %#v, want normal Shift 2 on the anchor date 2026-10-07", got)
		}
	})

	t.Run("shift three stays fillable normally until 0645 the next morning", func(t *testing.T) {
		inspections := []Inspection{
			inspek(jakarta, 2026, 10, 7, "1", 7, 0, false),
			inspek(jakarta, 2026, 10, 7, "2", 16, 0, false),
		}
		now := time.Date(2026, 10, 8, 6, 40, 0, 0, jakarta)
		got := getInspectionProgress(inspections, now)
		if got["requiresMissed"] == true || got["activeShiftAvailable"] != true || got["nextShift"] != "3" {
			t.Fatalf("getInspectionProgress() = %#v, want normal Shift 3 at 06:40 on 2026-10-08", got)
		}
		now = time.Date(2026, 10, 8, 6, 46, 0, 0, jakarta)
		got = getInspectionProgress(inspections, now)
		if got["requiresMissed"] != true || got["missingShift"] != "3" || got["missingDate"] != "2026-10-07" {
			t.Fatalf("getInspectionProgress() = %#v, want missed Shift 3 dated 2026-10-07 at 06:46", got)
		}
	})

	t.Run("exposes shift three as a missed debt while blocking already filled weekly shifts", func(t *testing.T) {
		inspections := []Inspection{
			inspek(jakarta, 2026, 10, 20, "1", 7, 0, false),
			inspek(jakarta, 2026, 10, 20, "2", 16, 0, false),
		}
		now := time.Date(2026, 10, 21, 7, 0, 0, 0, jakarta)
		got := getInspectionProgress(inspections, now)
		if got["requiresMissed"] != true || got["missingShift"] != "3" || got["missingDate"] != "2026-10-20" ||
			got["pendingShiftThree"] != true ||
			got["pendingShiftThreeDate"] != "2026-10-20" ||
			got["pendingShiftThreeAvailableFrom"] != "2026-10-21" ||
			got["pendingShiftThreeAvailableThrough"] != "2026-10-21" ||
			got["activeShiftAvailable"] != false {
			t.Fatalf("getInspectionProgress() = %#v, want Shift 3 missed debt and already-filled weekly Shift 1 blocked", got)
		}
	})

	t.Run("does not offer shift three catch-up before its source date has ended", func(t *testing.T) {
		inspections := []Inspection{
			{Date: time.Date(2026, 10, 20, 0, 0, 0, 0, jakarta), Shift: "1"},
			{Date: time.Date(2026, 10, 20, 0, 0, 0, 0, jakarta), Shift: "2"},
		}
		now := time.Date(2026, 10, 20, 16, 0, 0, 0, jakarta)
		got := getInspectionProgress(inspections, now)
		if got["pendingShiftThree"] == true {
			t.Fatalf("getInspectionProgress() = %#v, want Shift 3 to remain available normally on its source date", got)
		}
	})

	t.Run("carries an unresolved shift three into the following week", func(t *testing.T) {
		inspections := []Inspection{
			{Date: time.Date(2026, 10, 19, 0, 0, 0, 0, jakarta), Shift: "1"},
			{Date: time.Date(2026, 10, 19, 0, 0, 0, 0, jakarta), Shift: "2"},
		}
		now := time.Date(2026, 10, 26, 7, 0, 0, 0, jakarta)
		got := getInspectionProgress(inspections, now)
		if got["requiresMissed"] != true || got["shiftThreeCarryover"] != true ||
			got["missingShift"] != "3" || got["missingDate"] != "2026-10-19" {
			t.Fatalf("getInspectionProgress() = %#v, want previous week's Shift 3 as a carryover", got)
		}
	})

	t.Run("marks only earlier missing shifts on the active shift-start date", func(t *testing.T) {
		inspections := []Inspection{
			inspek(jakarta, 2026, 10, 27, "1", 7, 5, false),
			inspek(jakarta, 2026, 10, 27, "3", 23, 5, false),
		}
		now := time.Date(2026, 10, 27, 23, 30, 0, 0, jakarta)
		got := getInspectionProgress(inspections, now)
		if got["missedType"] != "shift" || got["missingShift"] != "2" || got["missingDate"] != "2026-10-27" {
			t.Fatalf("getInspectionProgress() = %#v, want only Shift 2 missed on 2026-10-27", got)
		}
	})
}

func TestInspectionDisplayDateTime(t *testing.T) {
	date := time.Date(2026, 10, 12, 0, 0, 0, 0, jakartaLocation())

	t.Run("normal inspection shows actual submit time", func(t *testing.T) {
		submittedAt := time.Date(2026, 10, 13, 1, 37, 0, 0, jakartaLocation())
		got := inspectionDisplayDateTime(Inspection{
			Date: date, Shift: "3", CreatedAt: submittedAt,
		})
		if got.Hour() != 1 || got.Minute() != 37 || got.Day() != 13 {
			t.Fatalf("inspectionDisplayDateTime() = %s, want actual submit time 2026-10-13 01:37 WIB", got.Format(time.RFC3339))
		}
	})

	t.Run("missed entry shows shift start time on selected inspection date", func(t *testing.T) {
		submittedAt := time.Date(2026, 10, 13, 1, 37, 0, 0, jakartaLocation())
		got := inspectionDisplayDateTime(Inspection{
			Date: date, Shift: "2", MissedEntry: true, CreatedAt: submittedAt,
		})
		if got.Hour() != 15 || got.Minute() != 15 || got.Day() != 12 {
			t.Fatalf("inspectionDisplayDateTime() = %s, want shift start 2026-10-12 15:15 WIB", got.Format(time.RFC3339))
		}
	})
}

func TestEarliestWeeklyMissedWeek(t *testing.T) {
	jakarta := jakartaLocation()
	createdAt := time.Date(2026, 10, 12, 9, 0, 0, 0, jakarta)
	currentWeekStart := time.Date(2026, 11, 2, 0, 0, 0, 0, jakarta)

	t.Run("finds the oldest completed empty week for the machine", func(t *testing.T) {
		inspections := []Inspection{
			{Date: time.Date(2026, 10, 12, 0, 0, 0, 0, jakarta), Shift: "1"},
			{Date: time.Date(2026, 10, 26, 0, 0, 0, 0, jakarta), Shift: "2"},
		}
		got, found := earliestWeeklyMissedWeek(inspections, createdAt, currentWeekStart)
		want := time.Date(2026, 10, 19, 0, 0, 0, 0, jakarta)
		if !found || !got.Equal(want) {
			t.Fatalf("earliestWeeklyMissedWeek() = %s, %t; want %s, true", got, found, want)
		}
	})

	t.Run("does not count the current incomplete week as missed", func(t *testing.T) {
		got, found := earliestWeeklyMissedWeek(nil, currentWeekStart, currentWeekStart)
		if found || !got.IsZero() {
			t.Fatalf("earliestWeeklyMissedWeek() = %s, %t; want zero, false", got, found)
		}
	})

	t.Run("requires a weekly entry before allowing current-week work", func(t *testing.T) {
		// Week Oct 12 is complete, week Oct 19 is fully empty, so the
		// weekly debt for Oct 19 comes before any current-week work.
		inspections := []Inspection{
			{Date: time.Date(2026, 10, 12, 0, 0, 0, 0, jakarta), Shift: "1"},
			{Date: time.Date(2026, 10, 12, 0, 0, 0, 0, jakarta), Shift: "2"},
			{Date: time.Date(2026, 10, 12, 0, 0, 0, 0, jakarta), Shift: "3"},
		}
		now := time.Date(2026, 10, 26, 7, 0, 0, 0, jakarta)
		progress := getInspectionProgress(inspections, now, createdAt)
		if progress["missedType"] != "weekly" || progress["missedWeekStart"] != "2026-10-19" ||
			progress["requiresMissed"] != true {
			t.Fatalf("getInspectionProgress() = %#v, want the empty week of 2026-10-19 required first", progress)
		}
	})

	t.Run("an older shift debt comes before a newer weekly debt", func(t *testing.T) {
		// User's example 2B: a Shift 3 debt from the Oct 5 week and an
		// empty Oct 12 week. The older Shift 3 debt must be cleared
		// first; only then is the weekly entry offered.
		inspections := []Inspection{
			inspek(jakarta, 2026, 10, 5, "1", 7, 0, false),
			inspek(jakarta, 2026, 10, 5, "2", 16, 0, false),
		}
		createdAt := time.Date(2026, 10, 5, 9, 0, 0, 0, jakarta)
		now := time.Date(2026, 10, 19, 7, 0, 0, 0, jakarta)
		progress := getInspectionProgress(inspections, now, createdAt)
		if progress["missedType"] != "shift" || progress["missingShift"] != "3" || progress["missingDate"] != "2026-10-05" {
			t.Fatalf("getInspectionProgress() = %#v, want Shift 3 debt dated 2026-10-05 before the weekly debt", progress)
		}
	})

	t.Run("detects a missed week even when this machine has no records yet", func(t *testing.T) {
		now := time.Date(2026, 10, 26, 7, 0, 0, 0, jakarta)
		progress := getInspectionProgress(nil, now, createdAt)
		if progress["missedType"] != "weekly" || progress["missedWeekStart"] != "2026-10-12" {
			t.Fatalf("getInspectionProgress() = %#v, want the empty week since machine creation", progress)
		}
	})
}

func TestHasInspectionForDateAndShift(t *testing.T) {
	targetDate := time.Date(2026, 10, 13, 0, 0, 0, 0, jakartaLocation())
	inspections := []Inspection{
		{Date: targetDate.AddDate(0, 0, -1), Shift: "1"},
		{Date: targetDate, Shift: "2"},
	}

	if hasInspectionForDateAndShift(inspections, targetDate, "1") {
		t.Fatal("shift 1 on a different date should not block this missed-shift entry")
	}
	if !hasInspectionForDateAndShift(inspections, targetDate, "2") {
		t.Fatal("existing shift 2 on the same date should block a duplicate")
	}
}

func TestSortInspectionReport(t *testing.T) {
	reports := []Inspection{
		{ID: "shift-3", Date: time.Date(2026, 10, 5, 12, 0, 0, 0, time.UTC), Shift: "3"},
		{ID: "shift-1-later-date", Date: time.Date(2026, 10, 12, 12, 0, 0, 0, time.UTC), Shift: "1"},
		{ID: "shift-1", Date: time.Date(2026, 10, 5, 12, 0, 0, 0, time.UTC), Shift: "1"},
		{ID: "shift-2", Date: time.Date(2026, 10, 5, 12, 0, 0, 0, time.UTC), Shift: "2"},
	}

	t.Run("oldest first keeps shifts in ascending order", func(t *testing.T) {
		sortInspectionReport(reports, "oldest")
		got := []string{reports[0].ID, reports[1].ID, reports[2].ID, reports[3].ID}
		want := []string{"shift-1", "shift-2", "shift-3", "shift-1-later-date"}
		if !reflect.DeepEqual(got, want) {
			t.Fatalf("oldest sort = %#v, want %#v", got, want)
		}
	})

	t.Run("newest date first still keeps shifts in ascending order", func(t *testing.T) {
		sortInspectionReport(reports, "newest")
		got := []string{reports[0].ID, reports[1].ID, reports[2].ID, reports[3].ID}
		want := []string{"shift-1-later-date", "shift-1", "shift-2", "shift-3"}
		if !reflect.DeepEqual(got, want) {
			t.Fatalf("newest sort = %#v, want %#v", got, want)
		}
	})
}

func TestSortInspectionReportPointers(t *testing.T) {
	reports := []*Inspection{
		{ID: "shift-3", Date: time.Date(2026, 10, 5, 12, 0, 0, 0, time.UTC), Shift: "3"},
		{ID: "shift-1-later-date", Date: time.Date(2026, 10, 12, 12, 0, 0, 0, time.UTC), Shift: "1"},
		{ID: "shift-1", Date: time.Date(2026, 10, 5, 12, 0, 0, 0, time.UTC), Shift: "1"},
		{ID: "shift-2", Date: time.Date(2026, 10, 5, 12, 0, 0, 0, time.UTC), Shift: "2"},
	}

	sorted := sortInspectionReportPointers(reports)
	got := make([]string, len(sorted))
	for i, report := range sorted {
		got[i] = report.ID
	}
	want := []string{"shift-1", "shift-2", "shift-3", "shift-1-later-date"}
	if !reflect.DeepEqual(got, want) {
		t.Fatalf("sorted PDF reports = %#v, want %#v", got, want)
	}
}

func TestCollectReportOperatorsIncludesInspectors(t *testing.T) {
	inspections := []*Inspection{
		{
			CreatedBy:          "USR-001",
			CreatedByUsername:  "admin",
			StaffName:          "System Administrator",
			SupervisorUsername: "yudha",
			SupervisorName:     "Yudha Nugraha",
		},
		{
			CreatedBy:          "USR-001",
			CreatedByUsername:  "admin",
			StaffName:          "System Administrator",
			SupervisorUsername: "yudha",
			SupervisorName:     "Yudha Nugraha",
		},
	}

	got := collectReportOperators(inspections)
	want := []reportOperator{
		{username: "admin", fullname: "System Administrator"},
		{username: "yudha", fullname: "Yudha Nugraha"},
	}
	if !reflect.DeepEqual(got, want) {
		t.Fatalf("collectReportOperators() = %#v, want %#v", got, want)
	}
}
