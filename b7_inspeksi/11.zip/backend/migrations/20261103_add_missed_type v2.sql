-- Penanda jenis Entry Terlewat (update 2026-11-03).
-- 'shift'  = Shift Terlewat (dicatat satu per satu).
-- 'weekly' = Entry Terlewat Mingguan (dibuat 3 record sekaligus).
--
-- JALANKAN FILE INI DI DATABASE PRODUKSI TERLEBIH DAHULU, SEBELUM menimpa
-- file backend dengan update ini, karena query backend terbaru membaca
-- kolom missed_type. (Contoh: psql -U <user> -d <db> -f 20261103_add_missed_type.sql)
ALTER TABLE inspections ADD COLUMN IF NOT EXISTS missed_type VARCHAR(20);

-- Backfill: triple mingguan dikenali dari 3 record terlewat (shift 1, 2, 3)
-- di lokasi dan tanggal yang sama, dengan alasan yang sama, dan waktu
-- submit yang sama persis (ketiganya dibuat dalam satu transaksi).
UPDATE inspections i
SET missed_type = 'weekly'
WHERE i.missed_entry = TRUE
  AND i.missed_type IS NULL
  AND EXISTS (
    SELECT 1
    FROM inspections x
    WHERE x.location_id = i.location_id
      AND x.date = i.date
      AND x.missed_entry = TRUE
      AND x.missed_reason IS NOT DISTINCT FROM i.missed_reason
      AND x.created_at = i.created_at
    GROUP BY x.location_id, x.date, x.missed_reason, x.created_at
    HAVING COUNT(DISTINCT x.shift) = 3
  );

-- Sisa entry terlewat: shift terlewat.
UPDATE inspections
SET missed_type = 'shift'
WHERE missed_entry = TRUE AND missed_type IS NULL;
