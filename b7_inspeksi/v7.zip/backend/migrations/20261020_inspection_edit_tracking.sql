BEGIN;

ALTER TABLE inspections
    ADD COLUMN IF NOT EXISTS last_edited_by VARCHAR(100)
        REFERENCES users(id)
        ON DELETE SET NULL,
    ADD COLUMN IF NOT EXISTS last_edited_at TIMESTAMPTZ,
    ADD COLUMN IF NOT EXISTS edit_count INTEGER NOT NULL DEFAULT 0;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM pg_constraint
        WHERE conname = 'inspections_edit_count_nonnegative'
    ) THEN
        ALTER TABLE inspections
            ADD CONSTRAINT inspections_edit_count_nonnegative
            CHECK (edit_count >= 0);
    END IF;
END $$;

WITH revision_history AS (
    SELECT
        i.id AS inspection_id,
        (ARRAY_AGG(u.id ORDER BY a.created_at DESC, a.id DESC))[1] AS editor_id,
        MAX(a.created_at) AS last_edited_at,
        COUNT(*)::INTEGER AS edit_count
    FROM inspections i
    JOIN audit_logs a
        ON a.action = 'REVISION'
        AND a.detail = 'Revision update executed on inspection ' || i.id
    JOIN users u
        ON u.username = a.user_id
    GROUP BY i.id
)
UPDATE inspections i
SET last_edited_by = h.editor_id,
    last_edited_at = h.last_edited_at,
    edit_count = h.edit_count
FROM revision_history h
WHERE i.id = h.inspection_id;

COMMIT;
