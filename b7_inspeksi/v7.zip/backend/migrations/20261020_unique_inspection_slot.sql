-- 20261020_unique_inspection_slot.sql
--
-- Cegah record ganda untuk slot inspeksi yang sama (mesin + tanggal + shift).
--
-- Tanpa index ini, dua submit yang bersamaan (klik ganda, dua petugas, retry
-- jaringan) bisa sama-sama lolos pemeriksaan "slot sudah terisi" di aplikasi
-- lalu sama-sama INSERT, menghasilkan dua record untuk satu slot. Index unik
-- ini membuat database menolak record kedua (error 23505), dan aplikasi
-- menampilkannya sebagai HTTP 409 "sudah ada" — bukan error 500.
--
-- Berlaku hanya untuk shift reguler 1/2/3. Jalankan file ini SATU KALI di
-- database production sebelum/sesudah deploy kode baru.
--
-- PENTING: bila index gagal dibuat karena sudah ada data ganda, cari dulu
-- duplikatnya dengan query ini, bersihkan (hapus salah satu record per slot),
-- lalu jalankan ulang file ini:
--
--   SELECT location_id, date, shift, COUNT(*)
--   FROM inspections
--   WHERE shift IN ('1', '2', '3')
--   GROUP BY location_id, date, shift
--   HAVING COUNT(*) > 1;

CREATE UNIQUE INDEX IF NOT EXISTS uq_inspections_location_date_shift
    ON inspections (location_id, date, shift)
    WHERE shift IN ('1', '2', '3');
