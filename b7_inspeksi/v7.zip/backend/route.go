package main

import (
	"net/http"
	"strings"
)

// SetupRoutes mendaftarkan seluruh HTTP handler dan middleware ke HTTP Mux/Router.
func SetupRoutes(handler *Handler, authMiddleware *AuthMiddleware) http.Handler {
	mux := http.NewServeMux()

	// ================================================================
	// PUBLIC / AUTH ROUTES
	// ================================================================
	mux.HandleFunc("/api/auth/login", handler.Login)
	mux.HandleFunc("/api/auth/logout", handler.Logout)
	mux.HandleFunc("/api/auth/session", handler.GetSession)
	mux.HandleFunc("/api/auth/continue", handler.ContinueSession)

	// Re-login untuk verifikasi tindakan sensitif.
	// Tetap membutuhkan session aktif.
	mux.Handle("/api/auth/relogin",
		authMiddleware.Authenticate(
			http.HandlerFunc(handler.Relogin),
		),
	)
	// ============================================================================
	// AUTHENTICATED ROUTES
	// ============================================================================

	// Master Data (Staff, Supervisor, Manager, Administrator)
	mux.Handle("/api/locations", authMiddleware.Authenticate(http.HandlerFunc(handler.GetLocations)))
	mux.Handle("/api/departments", authMiddleware.Authenticate(http.HandlerFunc(handler.GetDepartments)))
	mux.Handle("/api/sites", authMiddleware.Authenticate(http.HandlerFunc(handler.GetSites)))

	// Inspections
	mux.Handle("/api/inspections/progress", authMiddleware.Authenticate(http.HandlerFunc(handler.GetInspectionProgress)))
	mux.Handle("/api/inspections", authMiddleware.Authenticate(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.Method {
		case http.MethodGet:
			handler.GetReports(w, r)
		case http.MethodPost:
			handler.CreateInspection(w, r)
		default:
			writeError(w, http.StatusMethodNotAllowed, "Method not allowed")
		}
	})))

	mux.Handle("/api/inspections/missed-entry", authMiddleware.Authenticate(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			writeError(w, http.StatusMethodNotAllowed, "Method not allowed")
			return
		}
		handler.CreateMissedEntry(w, r)
	})))

	// Inspections with Path Parameters (/api/inspections/:id, approval, revision)
	mux.Handle("/api/inspections/", authMiddleware.Authenticate(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		path := strings.TrimPrefix(r.URL.Path, "/api/inspections/")
		parts := strings.Split(path, "/")

		if len(parts) == 0 || parts[0] == "" {
			writeError(w, http.StatusNotFound, "Endpoint tidak ditemukan")
			return
		}

		id := parts[0]

		// Route: POST /api/inspections/:id/approve/supervisor
		if len(parts) == 3 && parts[1] == "approve" && parts[2] == "supervisor" {
			if r.Method != http.MethodPost {
				writeError(w, http.StatusMethodNotAllowed, "Method not allowed")
				return
			}
			authMiddleware.RequireRoles(RoleSupervisor, RoleAdministrator)(
				http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
					handler.ApproveSupervisor(w, r, id)
				}),
			).ServeHTTP(w, r)
			return
		}

		// Route: POST /api/inspections/:id/revision
		if len(parts) == 2 && parts[1] == "revision" {
			if r.Method != http.MethodPost {
				writeError(w, http.StatusMethodNotAllowed, "Method not allowed")
				return
			}
			authMiddleware.RequireRoles(RoleSupervisor, RoleAdministrator)(
				http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
					handler.RequestRevision(w, r, id)
				}),
			).ServeHTTP(w, r)
			return
		}

		// Route: GET /api/inspections/:id & PUT /api/inspections/:id
		if len(parts) == 1 {
			switch r.Method {
			case http.MethodGet:
				handler.GetInspection(w, r, id)
			case http.MethodPut:
				handler.UpdateInspection(w, r, id)
			default:
				writeError(w, http.StatusMethodNotAllowed, "Method not allowed")
			}
			return
		}

		writeError(w, http.StatusNotFound, "Endpoint tidak ditemukan")
	})))

	// ============================================================================
	// USER MANAGEMENT (ADMINISTRATOR ONLY)
	// ============================================================================
	mux.Handle("/api/users", authMiddleware.Authenticate(
		authMiddleware.RequireRoles(RoleAdministrator)(
			http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				switch r.Method {
				case http.MethodGet:
					handler.GetUsers(w, r)

				case http.MethodPost:
					handler.CreateUser(w, r)

				default:
					writeError(w, http.StatusMethodNotAllowed, "Method not allowed")
				}
			}),
		),
	))

	mux.Handle("/api/users/", authMiddleware.Authenticate(
		authMiddleware.RequireRoles(RoleAdministrator)(
			http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				id := strings.TrimPrefix(r.URL.Path, "/api/users/")

				if strings.HasSuffix(id, "/reset-password") {
					userID := strings.TrimSuffix(id, "/reset-password")
					if userID == "" || r.Method != http.MethodPost {
						writeError(w, http.StatusMethodNotAllowed, "Method not allowed")
						return
					}
					handler.ResetUserPassword(w, r, userID)
					return
				}

				if id == "" {
					writeError(w, http.StatusBadRequest, "User ID wajib diisi")
					return
				}

				switch r.Method {
				case http.MethodPut:
					handler.UpdateUser(w, r, id)

				case http.MethodDelete:
					handler.DeactivateUser(w, r, id)

				default:
					writeError(w, http.StatusMethodNotAllowed, "Method not allowed")
				}
			}),
		),
	))

	// ============================================================================
	// REPORTS & AUDIT TRAIL
	// ============================================================================
	mux.Handle("/api/reports/inspections", authMiddleware.Authenticate(http.HandlerFunc(handler.GetReports)))
	mux.Handle("/api/reports/inspections/pdf", authMiddleware.Authenticate(http.HandlerFunc(handler.ExportInspectionPDF)))

	mux.Handle("/api/audit-trail", authMiddleware.Authenticate(
		authMiddleware.RequireRoles(RoleSupervisor, RoleManager, RoleAdministrator)(
			http.HandlerFunc(handler.GetAuditLogs),
		),
	))

	return mux
}
