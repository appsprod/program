package main

import (
	"context"
	"database/sql"
	"fmt"
	"log"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/joho/godotenv"
	_ "github.com/lib/pq"
)

// Config menampung konfigurasi aplikasi dari environment variable
type Config struct {
	Port        string
	DatabaseURL string
}

func loadConfig() (*Config, error) {
	port := os.Getenv("PORT")
	if port == "" {
		port = "2020"
	}

	dbURL := os.Getenv("DATABASE_URL")
	if dbURL == "" {
		return nil, fmt.Errorf("DATABASE_URL environment variable is required")
	}

	return &Config{
		Port:        port,
		DatabaseURL: dbURL,
	}, nil
}

func initDatabase(dbURL string) (*sql.DB, error) {
	db, err := sql.Open("postgres", dbURL)
	if err != nil {
		return nil, fmt.Errorf("gagal membuka koneksi postgres: %w", err)
	}

	// Konfigurasi connection pool
	db.SetMaxOpenConns(25)
	db.SetMaxIdleConns(5)
	db.SetConnMaxLifetime(15 * time.Minute)

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	if err := db.PingContext(ctx); err != nil {
		return nil, fmt.Errorf("gagal terhubung ke database postgres: %w", err)
	}

	return db, nil
}

func corsMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		// Mengizinkan Next.js Frontend (Port 2025)
		w.Header().Set("Access-Control-Allow-Origin", "http://localhost:2025")
		w.Header().Set("Access-Control-Allow-Credentials", "true")
		w.Header().Set("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
		w.Header().Set("Access-Control-Allow-Headers", "Content-Type, Authorization")

		if r.Method == http.MethodOptions {
			w.WriteHeader(http.StatusOK)
			return
		}

		next.ServeHTTP(w, r)
	})
}

func main() {
	log.Println("Memulai startup backend server...")

	// Load .env
	if err := godotenv.Load(); err != nil {
		log.Printf("Warning: .env tidak ditemukan: %v", err)
	}

	// 1. Load & Validate Configuration
	cfg, err := loadConfig()
	if err != nil {
		log.Fatalf("Configuration error: %v", err)
	}

	// 2. Connect PostgreSQL & Verify Connectivity
	db, err := initDatabase(cfg.DatabaseURL)
	if err != nil {
		log.Fatalf("Database initialization error: %v", err)
	}
	defer db.Close()
	log.Println("Koneksi PostgreSQL berhasil diverifikasi.")

	// 3. Initialize Repository & Core Dependencies
	repo := NewPostgresRepository(db)
	sessionStore := NewAuthSessionStore()
	authService := NewAuthService(repo, sessionStore)
	_ = NewAuditService(repo) // Audit service
	authMiddleware := NewAuthMiddleware(authService, sessionStore, repo)

	// 4. Initialize Handlers (Single Session Store / Shared Architecture)
	handler := NewHandler(repo, sessionStore)

	// 5. Setup Router & Register Routes
	router := SetupRoutes(handler, authMiddleware)

	// 6. Wrap HTTP Middleware (CORS & Logging)
	handlerWithMiddleware := corsMiddleware(router)

	// 7. Initialize HTTP Server
	serverAddr := ":" + cfg.Port
	server := &http.Server{
		Addr:         serverAddr,
		Handler:      handlerWithMiddleware,
		ReadTimeout:  15 * time.Second,
		WriteTimeout: 15 * time.Second,
		IdleTimeout:  60 * time.Second,
	}

	// 8. Start HTTP Server in Goroutine
	go func() {
		log.Printf("Server siap dan mendengarkan pada port %s", cfg.Port)
		if err := server.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			log.Fatalf("HTTP server error: %v", err)
		}
	}()

	// 9. Graceful Shutdown Listener
	stop := make(chan os.Signal, 1)
	signal.Notify(stop, os.Interrupt, syscall.SIGTERM)
	<-stop

	log.Println("Sinyal penghentian diterima. Melakukan graceful shutdown...")

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	if err := server.Shutdown(ctx); err != nil {
		log.Printf("Gagal menutup HTTP server secara aman: %v", err)
	} else {
		log.Println("HTTP server berhasil dihentikan.")
	}

	log.Println("Shutdown selesai.")
}
