package main

import (
	"bytes"
	"fmt"
	"io"
	"strings"
	"time"

	"github.com/jung-kurt/gofpdf"
)

// PDFReportRequest menampung parameter pencetakan yang telah divalidasi oleh handler
type PDFReportRequest struct {
	Month     int
	Year      int
	Location  string
	PrintedBy string // Berasal dari authenticated session, bukan client parameter
}

// GenerateInspectionPDFReport menghasilkan byte buffer PDF laporan inspeksi.
// Fungsi ini murni read-only dan tidak mengubah status database maupun data inspeksi.
func generateInspectionPDFReportPrevious(inspections []*Inspection, req PDFReportRequest) ([]byte, error) {
	pdf := gofpdf.New("L", "mm", "A4", "") // Landscape A4 untuk laporan operasional
	pdf.SetMargins(10, 10, 10)
	pdf.SetAutoPageBreak(false, 15)
	pdf.AliasNbPages("{nb}")

	// ============================================================
	// HEADER HALAMAN
	// ============================================================
	pdf.SetHeaderFunc(func() {
		pdf.SetFont("Arial", "B", 14)
		pdf.CellFormat(
			0, 8,
			"LAPORAN INSPEKSI OPERASIONAL",
			"",
			1,
			"C",
			false,
			0,
			"",
		)

		pdf.SetFont("Arial", "", 10)

		periodStr := fmt.Sprintf(
			"Periode: %02d/%d | Lokasi: %s",
			req.Month,
			req.Year,
			req.Location,
		)

		if strings.TrimSpace(req.Location) == "" {
			periodStr = fmt.Sprintf(
				"Periode: %02d/%d | Lokasi: Semua Lokasi",
				req.Month,
				req.Year,
			)
		}

		pdf.CellFormat(
			0, 6,
			periodStr,
			"",
			1,
			"C",
			false,
			0,
			"",
		)

		pdf.Ln(4)
	})

	// ============================================================
	// FOOTER HALAMAN
	// ============================================================
	pdf.SetFooterFunc(func() {
		pdf.SetY(-12)
		pdf.SetFont("Arial", "I", 8)

		printTime := time.Now().
			In(time.FixedZone("WIB", 7*60*60)).
			Format("02-01-2006 15:04:05 WIB")

		footerText := fmt.Sprintf(
			"Dicetak oleh: %s | Tanggal Cetak: %s",
			req.PrintedBy,
			printTime,
		)

		pdf.CellFormat(
			190,
			8,
			footerText,
			"",
			0,
			"L",
			false,
			0,
			"",
		)

		pageStr := fmt.Sprintf("Halaman %d/{nb}", pdf.PageNo())

		pdf.CellFormat(
			0,
			8,
			pageStr,
			"",
			0,
			"R",
			false,
			0,
			"",
		)
	})

	pdf.AddPage()

	// ============================================================
	// DATA KOSONG
	// ============================================================
	if len(inspections) == 0 {
		pdf.SetFont("Arial", "B", 12)
		pdf.Ln(20)

		pdf.CellFormat(
			0,
			10,
			"Tidak ada data inspeksi untuk periode/lokasi yang dipilih.",
			"1",
			1,
			"C",
			false,
			0,
			"",
		)

		var buf bytes.Buffer
		if err := pdf.Output(&buf); err != nil {
			return nil, fmt.Errorf(
				"gagal merender PDF data kosong: %w",
				err,
			)
		}

		return buf.Bytes(), nil
	}

	// ============================================================
	// KONFIGURASI TABEL
	//
	// Total Lebar = 277 mm
	// Lebar efektif Landscape A4: 297mm - Margin Kiri 10mm - Margin Kanan 10mm = 277 mm
	// ============================================================
	widths := []float64{
		25, // Tanggal
		11, // Shift
		20, // Personel
		20, // Ruangan
		20, // Peralatan
		45, // Keterangan
		34, // Staff
		34, // Supervisor
		34, // Manager
		34, // Status
	}

	headers := []string{
		"Tanggal",
		"Shift",
		"Personel",
		"Ruangan",
		"Peralatan",
		"Keterangan / Catatan",
		"Staff",
		"Supervisor",
		"Manager",
		"Status Final",
	}

	// ============================================================
	// DRAW TABLE HEADER
	// ============================================================
	drawTableHeader := func() {
		pdf.SetFont("Arial", "B", 7)
		pdf.SetFillColor(230, 230, 230)

		startX := pdf.GetX()
		startY := pdf.GetY()
		headerHeight := 9.0
		x := startX

		for i, header := range headers {
			pdf.SetXY(x, startY)

			pdf.CellFormat(
				widths[i],
				headerHeight,
				header,
				"1",
				0,
				"C",
				true,
				0,
				"",
			)

			x += widths[i]
		}

		pdf.SetXY(
			startX,
			startY+headerHeight,
		)
	}

	drawTableHeader()

	// ============================================================
	// HELPER: NAMA USER
	// ============================================================
	userName := func(name string, fallback string) string {
		name = strings.TrimSpace(name)
		if name != "" {
			return name
		}

		fallback = strings.TrimSpace(fallback)
		if fallback != "" {
			return fallback
		}

		return "-"
	}

	// ============================================================
	// RENDER DATA
	// ============================================================
	pdf.SetFont("Arial", "", 7)

	lineHeight := 4.0
	cellPadding := 1.5
	_, pageHeight := pdf.GetPageSize()
	bottomLimit := pageHeight - 15.0

	for _, item := range inspections {

		// --------------------------------------------------------
		// TANGGAL + JAM INPUT
		// --------------------------------------------------------
		dateStr := item.Date.Format("02-01-2006")

		displayDateTime := inspectionDisplayDateTime(*item)
		if !displayDateTime.IsZero() {
			inputTime := displayDateTime.Format("15:04:05")

			dateStr = fmt.Sprintf(
				"%s\n%s",
				dateStr,
				inputTime,
			)
		}

		// --------------------------------------------------------
		// CHECKLIST
		// --------------------------------------------------------
		personel := strings.TrimSpace(string(item.CheckPersonel))
		ruangan := strings.TrimSpace(string(item.CheckRuangan))
		peralatan := strings.TrimSpace(string(item.CheckPeralatan))

		if personel == "" {
			personel = "-"
		}
		if ruangan == "" {
			ruangan = "-"
		}
		if peralatan == "" {
			peralatan = "-"
		}

		// --------------------------------------------------------
		// KETERANGAN
		// --------------------------------------------------------
		var kets []string

		if item.KetPersonel != nil && strings.TrimSpace(*item.KetPersonel) != "" {
			kets = append(
				kets,
				"Pers: "+strings.TrimSpace(*item.KetPersonel),
			)
		}

		if item.KetRuangan != nil && strings.TrimSpace(*item.KetRuangan) != "" {
			kets = append(
				kets,
				"Rng: "+strings.TrimSpace(*item.KetRuangan),
			)
		}

		if item.KetPeralatan != nil && strings.TrimSpace(*item.KetPeralatan) != "" {
			kets = append(
				kets,
				"Alat: "+strings.TrimSpace(*item.KetPeralatan),
			)
		}

		if item.MissedEntry {
			missed := "Entry Terlewat"
			if item.MissedReason != nil && strings.TrimSpace(*item.MissedReason) != "" {
				missed += ": " + strings.TrimSpace(*item.MissedReason)
			}
			kets = append(kets, missed)
		}

		ketStr := "-"
		if len(kets) > 0 {
			ketStr = strings.Join(kets, "\n")
		}

		// --------------------------------------------------------
		// USER (STAFF, SUPERVISOR, MANAGER)
		// --------------------------------------------------------
		creatorStr := userName(
			item.StaffName,
			item.CreatedBy,
		)

		supervisorStr := userName(
			item.SupervisorName,
			"",
		)

		managerStr := userName(
			item.ManagerName,
			"",
		)

		// --------------------------------------------------------
		// STATUS
		// --------------------------------------------------------
		statusStr := strings.TrimSpace(string(item.Status))

		switch statusStr {
		case string(StatusApproved):
			statusStr = "FINAL"
		case string(InspectionStatusSupervisorApproved):
			statusStr = "SPV APPROVED"
		case string(InspectionStatusSubmitted):
			statusStr = "SUBMITTED"
		case "":
			statusStr = "-"
		}

		// --------------------------------------------------------
		// DATA ROW
		// --------------------------------------------------------
		values := []string{
			dateStr,
			strings.TrimSpace(item.Shift),
			personel,
			ruangan,
			peralatan,
			ketStr,
			creatorStr,
			supervisorStr,
			managerStr,
			statusStr,
		}

		// --------------------------------------------------------
		// HITUNG TINGGI ROW DENGAN AKURAT
		// --------------------------------------------------------
		rowHeight := 7.0

		for i, value := range values {
			lines := pdf.SplitLines(
				[]byte(value),
				widths[i]-cellPadding*2,
			)

			height := float64(len(lines))*lineHeight + cellPadding*2

			if height > rowHeight {
				rowHeight = height
			}
		}

		// --------------------------------------------------------
		// PAGE BREAK MANUAL
		// --------------------------------------------------------
		if pdf.GetY()+rowHeight > bottomLimit {
			pdf.AddPage()
			drawTableHeader()
		}

		// --------------------------------------------------------
		// POSISI AWAL ROW
		// --------------------------------------------------------
		startX := pdf.GetX()
		startY := pdf.GetY()
		x := startX

		// --------------------------------------------------------
		// DRAW CELL DENGAN BORDER TERPISAH (GANTI MULTICELL BORDER)
		// --------------------------------------------------------
		for i, value := range values {

			// 1. Gambar BORDER luar cell sesuai tinggi row maksimum
			pdf.Rect(
				x,
				startY,
				widths[i],
				rowHeight,
				"D",
			)

			// 2. Tentukan Align
			align := "L"
			if i <= 4 || i == 9 {
				align = "C"
			}

			// 3. Posisikan teks dengan Padding
			pdf.SetXY(
				x+cellPadding,
				startY+cellPadding,
			)

			// 4. Render MultiCell TANPA Border ("")
			pdf.MultiCell(
				widths[i]-cellPadding*2,
				lineHeight,
				value,
				"",
				align,
				false,
			)

			// 5. Geser ke kolom selanjutnya
			x += widths[i]
		}

		// --------------------------------------------------------
		// Pindah ke Baris/Row Selanjutnya
		// --------------------------------------------------------
		pdf.SetXY(
			startX,
			startY+rowHeight,
		)
	}

	// ============================================================
	// OUTPUT BUFFER
	// ============================================================
	var buf bytes.Buffer

	if err := pdf.Output(&buf); err != nil {
		return nil, fmt.Errorf(
			"gagal merender buffer PDF: %w",
			err,
		)
	}

	return buf.Bytes(), nil
}

// WritePDFResponse menuliskan byte PDF ke http.ResponseWriter dengan header yang sesuai
func WritePDFResponse(w io.Writer, pdfBytes []byte) error {
	_, err := w.Write(pdfBytes)
	return err
}

func truncateText(str string, maxLen int) string {
	if len(str) <= maxLen {
		return str
	}
	if maxLen < 3 {
		return str[:maxLen]
	}
	return str[:maxLen-3] + "..."
}
