package main

import (
	"time"
)

// ============================================================================
// CONSTANTS & TYPE ALIASES
// ============================================================================

// UserRole mendefinisikan peran pengguna dalam sistem
type UserRole string

const (
	RoleAdministrator UserRole = "administrator"
	RoleManager       UserRole = "manager"
	RoleSupervisor    UserRole = "supervisor"
	RoleStaff         UserRole = "staff"
)

// UserStatus mendefinisikan status keberadaan dan akses akun pengguna
type UserStatus string

const (
	UserStatusActive   UserStatus = "ACTIVE"
	UserStatusBlocked  UserStatus = "BLOCKED"
	UserStatusInactive UserStatus = "INACTIVE"
)

// InspectionStatus mendefinisikan status alur verifikasi approval dokumen inspeksi
type InspectionStatus string

const (
	InspectionStatusSubmitted          InspectionStatus = "SUBMITTED"
	InspectionStatusSupervisorApproved InspectionStatus = "SUPERVISOR_APPROVED"
	InspectionStatusApproved           InspectionStatus = "APPROVED"

	// Alias konstanta untuk kompatibilitas pengecekan status di pdf.go
	StatusApproved InspectionStatus = "APPROVED"
)

// DepartmentName mendefinisikan nama departemen yang valid
type DepartmentName string

const (
	DepartmentProduction        DepartmentName = "production"
	DepartmentEngineering       DepartmentName = "engineering"
	DepartmentWarehouse         DepartmentName = "warehouse"
	DepartmentTechnicalServices DepartmentName = "technical_services"
	DepartmentGeneralAffair     DepartmentName = "general_affair"
)

// AuditAction mendefinisikan jenis tindakan audit trail
type AuditAction string

const (
	AuditActionCreate       AuditAction = "CREATE"
	AuditActionUpdate       AuditAction = "UPDATE"
	AuditActionDeactivate   AuditAction = "DEACTIVATE"
	AuditActionApproval     AuditAction = "APPROVAL"
	AuditActionRevision     AuditAction = "REVISION"
	AuditActionAuthSecurity AuditAction = "AUTH_SECURITY"
)

// ============================================================================
// DOMAIN MODELS (PERSISTENCE LAYER)
// ============================================================================

// User merepresentasikan entitas akun pengguna di database PostgreSQL
type User struct {
	ID             string     `json:"id" db:"id"`
	FullName       string     `json:"fullName" db:"full_name"`
	Username       string     `json:"username" db:"username"`
	PasswordHash   string     `json:"-" db:"password_hash"` // Never exposed to JSON
	Role           UserRole   `json:"role" db:"role"`
	Department     string     `json:"department" db:"department"`
	Site           string     `json:"site" db:"site"`
	Status         UserStatus `json:"status" db:"status"`
	FailedAttempts int        `json:"failedAttempts" db:"failed_attempts"`
	CreatedAt      time.Time  `json:"createdAt" db:"created_at"`
	UpdatedAt      time.Time  `json:"updatedAt" db:"updated_at"`
}

// Inspection merepresentasikan entitas laporan inspeksi kebersihan
type Inspection struct {
	ID                   string           `json:"id" db:"id"`
	LocationID           string           `json:"locationId" db:"location_id"`
	Shift                string           `json:"shift" db:"shift"`
	CheckPersonel        string           `json:"checkPersonel" db:"check_personel"`    // OK / NOK
	CheckRuangan         string           `json:"checkRuangan" db:"check_ruangan font"` // OK / NOK
	CheckPeralatan       string           `json:"checkPeralatan" db:"check_peralatan"`  // OK / NOK
	KetPersonel          *string          `json:"ketPersonel,omitempty" db:"ket_personel"`
	KetRuangan           *string          `json:"ketRuangan,omitempty" db:"ket_ruangan"`
	KetPeralatan         *string          `json:"ketPeralatan,omitempty" db:"ket_peralatan"`
	Date                 time.Time        `json:"date" db:"date"`
	CreatedBy            string           `json:"createdBy" db:"created_by"`
	SupervisorApprovedBy *string          `json:"supervisorApprovedBy,omitempty" db:"supervisor_approved_by"`
	SupervisorApprovedAt *time.Time       `json:"supervisorApprovedAt,omitempty" db:"supervisor_approved_at"`
	ManagerApprovedBy    *string          `json:"managerApprovedBy,omitempty" db:"manager_approved_by"`
	ManagerApprovedAt    *time.Time       `json:"managerApprovedAt,omitempty" db:"manager_approved_at"`
	ApprovedBySupervisor *string          `json:"approvedBySupervisor,omitempty" db:"-"` // Alias kompatibilitas pdf.go
	ApprovedByManager    *string          `json:"approvedByManager,omitempty" db:"-"`    // Alias kompatibilitas pdf.go
	Status               InspectionStatus `json:"status" db:"status"`
	MissedEntry          bool             `json:"missedEntry" db:"missed_entry"`
	MissedReason         *string          `json:"missedReason,omitempty" db:"missed_reason"`
	CreatedAt            time.Time        `json:"createdAt" db:"created_at"`
	UpdatedAt            time.Time        `json:"updatedAt" db:"updated_at"`
	LastEditedByID       string           `json:"-" db:"-"`
	LastEditedAt         *time.Time       `json:"lastEditedAt,omitempty" db:"-"`
	EditCount            int              `json:"editCount" db:"-"`

	StaffName            string `json:"staffName,omitempty" db:"-"`
	SupervisorUsername   string `json:"supervisorUsername,omitempty" db:"-"`
	SupervisorName       string `json:"supervisorName,omitempty" db:"-"`
	LastEditedByUsername string `json:"lastEditedByUsername,omitempty" db:"-"`
	ManagerName          string `json:"managerName,omitempty" db:"-"`
	LocationName         string `json:"locationName,omitempty" db:"-"`
	// CreatedByUsername adalah username akun pembuat (hasil JOIN users),
	// karena CreatedBy menyimpan ID user (mis. USR-001), bukan username.
	CreatedByUsername string `json:"createdByUsername,omitempty" db:"-"`
}

// AuditLog merepresentasikan log aktivitas sistem yang bersifat imutabel
type AuditLog struct {
	ID         string      `json:"id" db:"id"`
	Timestamp  time.Time   `json:"timestamp" db:"timestamp"`
	CreatedAt  time.Time   `json:"createdAt" db:"created_at"` // Lapangan waktu paralel kompatibilitas audit.go
	User       string      `json:"user" db:"user"`
	Action     AuditAction `json:"action" db:"action"`
	EntityName *string     `json:"entityName,omitempty" db:"entity_name"`
	EntityID   *string     `json:"entityId,omitempty" db:"entity_id"`
	Area       *string     `json:"area,omitempty" db:"area"`
	Detail     string      `json:"detail" db:"detail"`
	OldValue   *string     `json:"oldValue,omitempty" db:"old_value"`
	NewValue   *string     `json:"newValue,omitempty" db:"new_value"`
	IPAddress  string      `json:"ipAddress" db:"ip_address"`
}

// Location merepresentasikan master data lokasi inspeksi
type Location struct {
	ID        string    `json:"id" db:"id"`
	Name      string    `json:"name" db:"name"`
	Status    string    `json:"status" db:"status"` // ACTIVE / INACTIVE
	CreatedAt time.Time `json:"createdAt" db:"created_at"`
	UpdatedAt time.Time `json:"updatedAt" db:"updated_at"`
}

// Department merepresentasikan master data departemen
type Department struct {
	ID        string    `json:"id" db:"id"`
	Name      string    `json:"name" db:"name"`
	Status    string    `json:"status" db:"status"` // ACTIVE / INACTIVE
	CreatedAt time.Time `json:"createdAt" db:"created_at"`
	UpdatedAt time.Time `json:"updatedAt" db:"updated_at"`
}

// Site merepresentasikan master data situs/lokasi operasional
type Site struct {
	ID        string    `json:"id" db:"id"`
	Name      string    `json:"name" db:"name"`
	Status    string    `json:"status" db:"status"` // ACTIVE / INACTIVE
	CreatedAt time.Time `json:"createdAt" db:"created_at"`
	UpdatedAt time.Time `json:"updatedAt" db:"updated_at"`
}

// ============================================================================
// DATA TRANSFER OBJECTS (DTOs) FOR API RESPONSE / SECURITY BOUNDARY
// ============================================================================

// UserResponse DTO untuk mengirimkan data user ke client tanpa mengekspos field sensitif
type UserResponse struct {
	ID         string     `json:"id"`
	FullName   string     `json:"fullName"`
	Username   string     `json:"username"`
	Role       UserRole   `json:"role"`
	Department string     `json:"department"`
	Site       string     `json:"site"`
	Status     UserStatus `json:"status"`
}

// ToResponse mengubah struct User domain menjadi UserResponse DTO yang aman
func (u *User) ToResponse() UserResponse {
	return UserResponse{
		ID:         u.ID,
		FullName:   u.FullName,
		Username:   u.Username,
		Role:       u.Role,
		Department: u.Department,
		Site:       u.Site,
		Status:     u.Status,
	}
}
