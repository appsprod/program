﻿package main

import (
    "encoding/json"
    "fmt"
    "net/http"
    "strings"
    "time"
)

type ReloginRequest struct {
    Username string `json:"username"`
    Password string `json:"password"`
}

func (h *Handler) Relogin(w http.ResponseWriter, r *http.Request) {
    if r.Method != http.MethodPost {
        writeError(w, http.StatusMethodNotAllowed, "Method not allowed")
        return
    }

    currentUser, err := h.getAuthenticatedUser(r)
    if err != nil {
        writeError(w, http.StatusUnauthorized, "Session tidak valid atau sudah berakhir")
        return
    }

    var req ReloginRequest
    if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
        writeError(w, http.StatusBadRequest, "Invalid request body")
        return
    }

    if !strings.EqualFold(strings.TrimSpace(req.Username), currentUser.Username) {
        writeError(w, http.StatusUnauthorized, "Username re-login tidak sesuai dengan session aktif")
        return
    }

    if !CheckPasswordHash(req.Password, currentUser.PasswordHash) {
        _ = h.repo.CreateAuditLog(r.Context(), &AuditLog{
            ID:        fmt.Sprintf("AUD-%d", time.Now().UnixNano()),
            User:      currentUser.Username,
            Action:    AuditActionAuthSecurity,
            Detail:    "Failed re-login verification for approval",
            IPAddress: getIPAddress(r),
        })

        writeError(w, http.StatusUnauthorized, "Verifikasi re-login gagal. Kredensial tidak sesuai.")
        return
    }

    _ = h.repo.CreateAuditLog(r.Context(), &AuditLog{
        ID:        fmt.Sprintf("AUD-%d", time.Now().UnixNano()),
        User:      currentUser.Username,
        Action:    AuditActionAuthSecurity,
        Detail:    "Successful re-login verification for approval",
        IPAddress: getIPAddress(r),
    })

    writeJSON(w, http.StatusOK, JSONResponse{
        Success: true,
        Message: "Verifikasi re-login berhasil",
    })
}
