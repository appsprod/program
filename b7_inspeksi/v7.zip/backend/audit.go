package main

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"strings"
	"time"
)

// ============================================================================
// AUDIT CONSTANTS & TYPES
// ============================================================================

type AuditActionType string

const (
	// Auth & Security Actions
	AuditActionLogin           AuditActionType = "LOGIN"
	AuditActionLoginFailed     AuditActionType = "LOGIN_FAILED"
	AuditActionLogout          AuditActionType = "LOGOUT"
	AuditActionAccountBlocked  AuditActionType = "ACCOUNT_BLOCKED"
	AuditActionAccountUnlocked AuditActionType = "ACCOUNT_UNLOCKED"

	// Inspection Actions
	AuditActionCreateInspection  AuditActionType = "CREATE_INSPECTION"
	AuditActionUpdateInspection  AuditActionType = "UPDATE_INSPECTION"
	AuditActionCreateMissedEntry AuditActionType = "CREATE_MISSED_ENTRY"

	// Approval Actions
	AuditActionSupervisorApproval AuditActionType = "SUPERVISOR_APPROVAL"
	AuditActionManagerApproval    AuditActionType = "MANAGER_APPROVAL"

	// Revision Actions
	AuditActionRevisionAuthorization AuditActionType = "REVISION_AUTHORIZATION"

	// User Management Actions
	AuditActionCreateUser     AuditActionType = "CREATE_USER"
	AuditActionUpdateUser     AuditActionType = "UPDATE_USER"
	AuditActionDeactivateUser AuditActionType = "DEACTIVATE_USER"
)

type AuditEntityType string

const (
	EntityAuth       AuditEntityType = "AUTHENTICATION"
	EntityInspection AuditEntityType = "INSPECTION"
	EntityUser       AuditEntityType = "USER"
	EntityAudit      AuditEntityType = "AUDIT"
)

// AuditPayload berisi data terstruktur untuk pembuatan audit log terpusat.
type AuditPayload struct {
	UserID    string
	Username  string
	Action    AuditActionType
	Entity    AuditEntityType
	EntityID  string
	OldValue  interface{}
	NewValue  interface{}
	IPAddress string
}

// ============================================================================
// CENTRALIZED AUDIT SERVICE
// ============================================================================

type AuditService struct {
	repo Repository
}

func NewAuditService(repo Repository) *AuditService {
	return &AuditService{
		repo: repo,
	}
}

// Log mencatat audit log baru ke database/repository secara terpusat.
// Audit log bersifat INSERT ONLY (Immutable).
func (s *AuditService) Log(ctx context.Context, payload AuditPayload) error {
	if payload.Action == "" {
		return errors.New("audit action type is required")
	}

	// Format Old Value ke JSON string (sanitize password/sensitive details)
	oldValJSON := ""
	if payload.OldValue != nil {
		sanitizedOld := sanitizeAuditData(payload.OldValue)
		b, err := json.Marshal(sanitizedOld)
		if err == nil {
			oldValJSON = string(b)
		}
	}

	// Format New Value ke JSON string (sanitize password/sensitive details)
	newValJSON := ""
	if payload.NewValue != nil {
		sanitizedNew := sanitizeAuditData(payload.NewValue)
		b, err := json.Marshal(sanitizedNew)
		if err == nil {
			newValJSON = string(b)
		}
	}

	actor := payload.Username
	if actor == "" {
		actor = payload.UserID
	}
	if actor == "" {
		actor = "SYSTEM"
	}

	detail := fmt.Sprintf("[%s] Entity: %s | EntityID: %s", payload.Action, payload.Entity, payload.EntityID)

	auditLog := &AuditLog{
		ID:        fmt.Sprintf("AUD-%d", time.Now().UTC().UnixNano()),
		User:      actor,
		Action:    AuditAction(payload.Action),
		Detail:    detail,
		OldValue:  &oldValJSON,
		NewValue:  &newValJSON,
		IPAddress: payload.IPAddress,
		CreatedAt: time.Now().UTC(), // Timestamp dikontrol penuh oleh server
	}

	err := s.repo.CreateAuditLog(ctx, auditLog)
	if err != nil {
		return fmt.Errorf("failed to persist audit log: %w", err)
	}

	return nil
}

// Helper khusus untuk mencatat audit event langsung dari HTTP Request & User Context
func (s *AuditService) LogFromContext(r *http.Request, action AuditActionType, entity AuditEntityType, entityID string, oldValue, newValue interface{}) error {
	user, _ := r.Context().Value(UserContextKey).(*User)

	userID := ""
	username := ""
	if user != nil {
		userID = user.ID
		username = user.Username
	}

	return s.Log(r.Context(), AuditPayload{
		UserID:    userID,
		Username:  username,
		Action:    action,
		Entity:    entity,
		EntityID:  entityID,
		OldValue:  oldValue,
		NewValue:  newValue,
		IPAddress: getIPAddress(r),
	})
}

// ============================================================================
// HELPER: SANITIZATION (PREVENT LEAKING PASSWORDS/SECRETS IN AUDIT)
// ============================================================================

func sanitizeAuditData(data interface{}) interface{} {
	if data == nil {
		return nil
	}

	// Konversi interface ke map melalui JSON marshal/unmarshal untuk pembersihan
	b, err := json.Marshal(data)
	if err != nil {
		return data
	}

	var m map[string]interface{}
	if err := json.Unmarshal(b, &m); err != nil {
		return data // Return data asli jika bukan representasi JSON Object
	}

	cleanMap(m)
	return m
}

func cleanMap(m map[string]interface{}) {
	sensitiveKeys := []string{"password", "password_hash", "passwordHash", "token", "session_token", "secret"}

	for k, v := range m {
		lowerK := strings.ToLower(k)
		for _, secretKey := range sensitiveKeys {
			if strings.Contains(lowerK, strings.ToLower(secretKey)) {
				m[k] = "[REDACTED]"
			}
		}

		if childMap, ok := v.(map[string]interface{}); ok {
			cleanMap(childMap)
		}
	}
}
