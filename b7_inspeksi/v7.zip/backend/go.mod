module b7_inspeksi

go 1.26.3

require (
	github.com/joho/godotenv v1.5.1
	github.com/jung-kurt/gofpdf v1.16.2
	github.com/lib/pq v1.12.3
	golang.org/x/crypto v0.57.0
)
