package main

import (
	"testing"
	"time"
)

func TestExpiredSessionCanBeResumedWithinWindow(t *testing.T) {
	store := NewAuthSessionStore()
	session, token := store.CreateSession("user-1", RoleStaff, "production")
	session.LastActivity = time.Now().Add(-InactivityTimeout)

	if _, active := store.GetSession(token); active {
		t.Fatal("expired session unexpectedly remains active")
	}
	if got, resumable := store.GetSessionForResume(token); !resumable || got.UserID != "user-1" {
		t.Fatal("expired session should remain available for password re-authentication")
	}
}

func TestSessionCannotBeResumedAfterResumeWindow(t *testing.T) {
	store := NewAuthSessionStore()
	session, token := store.CreateSession("user-1", RoleStaff, "production")
	session.CreatedAt = time.Now().Add(-SessionResumeWindow)

	if _, active := store.GetSession(token); active {
		t.Fatal("session outside its maximum lifetime unexpectedly remains active")
	}
	if _, resumable := store.GetSessionForResume(token); resumable {
		t.Fatal("session outside its maximum lifetime should not be resumable")
	}
}
