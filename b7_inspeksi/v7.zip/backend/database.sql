-- ============================================================================
-- MASTER DATA MIGRATION: LEGACY PHP/MYSQL TO GO/POSTGRESQL
-- DATABASE SCHEMA: database.sql
-- TARGET: PostgreSQL 12+
-- DESCRIPTION: PostgreSQL target schema with legacy master data.
--              Legacy inspection transactions are not migrated in this script.
-- ============================================================================

BEGIN;

-- ============================================================================
-- 1. DROP EXISTING TABLES
-- ============================================================================

DROP TABLE IF EXISTS audit_logs CASCADE;
DROP TABLE IF EXISTS inspections CASCADE;
DROP TABLE IF EXISTS inspection_daily_counters CASCADE;
DROP TABLE IF EXISTS users CASCADE;
DROP TABLE IF EXISTS locations CASCADE;
DROP TABLE IF EXISTS production_sections CASCADE;
DROP TABLE IF EXISTS sites CASCADE;
DROP TABLE IF EXISTS departments CASCADE;

-- ============================================================================
-- 2. MASTER DATA TABLES
-- ============================================================================

-- DEPARTMENTS TABLE
CREATE TABLE departments (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- SITES TABLE
CREATE TABLE sites (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- LOCATIONS TABLE
CREATE TABLE locations (
    id VARCHAR(50) PRIMARY KEY,
    site_id VARCHAR(50) NOT NULL
        REFERENCES sites(id)
        ON DELETE CASCADE,
    name VARCHAR(100) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT idx_site_location_unique
        UNIQUE (site_id, name)
);

-- LEGACY BAGIAN
CREATE TABLE production_sections (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================================
-- 3. USER MANAGEMENT & AUTHENTICATION
-- ============================================================================

CREATE TABLE users (
    id VARCHAR(50) PRIMARY KEY,
    full_name VARCHAR(150) NOT NULL,
    username VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,

    role VARCHAR(30) NOT NULL
        CHECK (
            role IN (
                'administrator',
                'manager',
                'supervisor',
                'staff'
            )
        ),

    department_id VARCHAR(50)
        REFERENCES departments(id)
        ON DELETE SET NULL,

    site_id VARCHAR(50)
        REFERENCES sites(id)
        ON DELETE SET NULL,

    status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE'
        CHECK (
            status IN (
                'ACTIVE',
                'BLOCKED',
                'INACTIVE'
            )
        ),

    failed_attempts INT NOT NULL DEFAULT 0
        CHECK (failed_attempts >= 0),

    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================================
-- 4. INSPECTIONS TABLE & COUNTER
-- ============================================================================

CREATE TABLE inspection_daily_counters (
    inspection_date DATE PRIMARY KEY,
    last_number INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE inspections (
    id VARCHAR(50) PRIMARY KEY,

    location_id VARCHAR(50) NOT NULL
        REFERENCES locations(id)
        ON DELETE RESTRICT,

    shift VARCHAR(10) NOT NULL
        CHECK (shift IN ('1', '2', '3', 'NS')),

    check_personel VARCHAR(20)
        CHECK (
            check_personel IN ('OK', 'NOK')
            OR check_personel IS NULL
        ),

    check_ruangan VARCHAR(20)
        CHECK (
            check_ruangan IN ('OK', 'NOK')
            OR check_ruangan IS NULL
        ),

    check_peralatan VARCHAR(20)
        CHECK (
            check_peralatan IN ('OK', 'NOK')
            OR check_peralatan IS NULL
        ),

    ket_personel TEXT,
    ket_ruangan TEXT,
    ket_peralatan TEXT,

    date DATE NOT NULL,

    created_by VARCHAR(100) NOT NULL,

    supervisor_approved_by VARCHAR(100),
    supervisor_approved_at TIMESTAMPTZ,

    manager_approved_by VARCHAR(100),
    manager_approved_at TIMESTAMPTZ,

    status VARCHAR(30) NOT NULL DEFAULT 'SUBMITTED'
        CHECK (
            status IN (
                'SUBMITTED',
                'SUPERVISOR_APPROVED',
                'APPROVED'
            )
        ),

    missed_entry BOOLEAN NOT NULL DEFAULT FALSE,
    missed_reason TEXT
        CHECK (missed_reason IN ('Lupa', 'Hari Libur', 'Tidak dilakukan') OR missed_reason IS NULL),

    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_edited_by VARCHAR(100)
        REFERENCES users(id)
        ON DELETE SET NULL,
    last_edited_at TIMESTAMPTZ,
    edit_count INTEGER NOT NULL DEFAULT 0
        CHECK (edit_count >= 0),

    -- Supervisor approval state
    CONSTRAINT chk_supervisor_approval_state CHECK (
        (
            supervisor_approved_by IS NULL
            AND supervisor_approved_at IS NULL
            AND status = 'SUBMITTED'
        )
        OR
        (
            supervisor_approved_by IS NOT NULL
            AND supervisor_approved_at IS NOT NULL
        )
    ),

    -- Manager is a monitoring role; Supervisor approval is final.
    CONSTRAINT chk_manager_approval_state CHECK (
        (
            manager_approved_by IS NULL
            AND manager_approved_at IS NULL
            AND status IN ('SUBMITTED', 'SUPERVISOR_APPROVED', 'APPROVED')
        )
        OR
        (
            manager_approved_by IS NOT NULL
            AND manager_approved_at IS NOT NULL
            AND status = 'APPROVED'
        )
    )
);

-- ============================================================================
-- 5. CENTRALIZED IMMUTABLE AUDIT TRAIL
-- ============================================================================

CREATE TABLE audit_logs (
    id VARCHAR(50) PRIMARY KEY,

    user_id VARCHAR(100) NOT NULL,

    action VARCHAR(50) NOT NULL
        CHECK (
            action IN (
                'AUTH_SECURITY',
                'CREATE',
                'UPDATE',
                'DEACTIVATE',
                'APPROVAL',
                'REVISION'
            )
        ),

    detail TEXT NOT NULL,

    old_value JSONB,
    new_value JSONB,

    ip_address VARCHAR(45) NOT NULL,

    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================================
-- AUDIT LOG IMMUTABILITY
-- ============================================================================

CREATE OR REPLACE FUNCTION block_audit_log_modification()
RETURNS TRIGGER AS $$
BEGIN
    RAISE EXCEPTION
        'Audit Trail is immutable! UPDATE or DELETE operations are strictly forbidden.';
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_protect_audit_logs_update
BEFORE UPDATE ON audit_logs
FOR EACH ROW
EXECUTE FUNCTION block_audit_log_modification();

CREATE TRIGGER trg_protect_audit_logs_delete
BEFORE DELETE ON audit_logs
FOR EACH ROW
EXECUTE FUNCTION block_audit_log_modification();

-- ============================================================================
-- 6. INDEXES
-- ============================================================================

-- Users
CREATE INDEX idx_users_username
    ON users(username);

CREATE INDEX idx_users_role_status
    ON users(role, status);

-- Inspections
CREATE INDEX idx_inspections_date_location
    ON inspections(date, location_id);

CREATE INDEX idx_inspections_location_date_created
    ON inspections(location_id, date DESC, created_at DESC);

CREATE INDEX idx_inspections_status
    ON inspections(status);

CREATE INDEX idx_inspections_created_by
    ON inspections(created_by);

CREATE INDEX idx_inspections_report_composite
    ON inspections(date, location_id, status);

-- Audit Logs
CREATE INDEX idx_audit_logs_created_at
    ON audit_logs(created_at DESC);

CREATE INDEX idx_audit_logs_user_id
    ON audit_logs(user_id);

CREATE INDEX idx_audit_logs_action
    ON audit_logs(action);

-- ============================================================================
-- 7. INITIAL SEED DATA (MIGRATED FROM LEGACY DATA MASTER)
-- ============================================================================

-- ============================================================================
-- DEPARTMENTS (LEGACY DATA)
-- ============================================================================

INSERT INTO departments (id, name) VALUES
('DEP-001', 'Produksi PG'),
('DEP-002', 'Warehouse PG')
ON CONFLICT (id) DO UPDATE SET name = EXCLUDED.name;

-- ============================================================================
-- LEGACY BAGIAN
-- ============================================================================

INSERT INTO production_sections (id, name) VALUES
('SEC-001', 'Produksi Liquid'),
('SEC-002', 'Produksi Powder')
ON CONFLICT (id) DO UPDATE SET
    name = EXCLUDED.name;

-- ============================================================================
-- SITES (LEGACY DATA)
-- ============================================================================

INSERT INTO sites (id, name) VALUES
('SITE-001', 'Pulogadung')
ON CONFLICT (id) DO UPDATE SET name = EXCLUDED.name;

-- ============================================================================
-- LOCATIONS (LEGACY DATA - ALL 28 LOCATIONS)
-- ============================================================================

INSERT INTO locations (id, site_id, name) VALUES
('LOC-001', 'SITE-001', 'Compounding Liquid 1'),
('LOC-002', 'SITE-001', 'Compounding Liquid 2'),
('LOC-003', 'SITE-001', 'Compounding Liquid 3'),
('LOC-004', 'SITE-001', 'Compounding Liquid 4'),
('LOC-005', 'SITE-001', 'Compounding Solid 2'),
('LOC-006', 'SITE-001', 'Compounding Solid 4'),
('LOC-007', 'SITE-001', 'Compounding Solid 7'),
('LOC-008', 'SITE-001', 'Compounding Solid 8'),
('LOC-009', 'SITE-001', 'Filling Liquid 1'),
('LOC-010', 'SITE-001', 'Filling Liquid 2'),
('LOC-011', 'SITE-001', 'Filling Liquid 3'),
('LOC-012', 'SITE-001', 'Filling Liquid 4'),
('LOC-013', 'SITE-001', 'Filling Liquid 5'),
('LOC-014', 'SITE-001', 'Filling Liquid 6'),
('LOC-015', 'SITE-001', 'Filling Liquid 7'),
('LOC-016', 'SITE-001', 'Filling Liquid 8'),
('LOC-017', 'SITE-001', 'Filling Liquid 9'),
('LOC-018', 'SITE-001', 'Filling Liquid 10'),
('LOC-019', 'SITE-001', 'Filling Liquid 11'),
('LOC-020', 'SITE-001', 'Filling Solid 1'),
('LOC-021', 'SITE-001', 'Filling Solid 2'),
('LOC-022', 'SITE-001', 'Packaging 1'),
('LOC-023', 'SITE-001', 'Packaging 2'),
('LOC-024', 'SITE-001', 'Packaging 3'),
('LOC-025', 'SITE-001', 'Staging Foil 1'),
('LOC-026', 'SITE-001', 'Staging RM 2'),
('LOC-027', 'SITE-001', 'Staging Solid 1'),
('LOC-028', 'SITE-001', 'Staging Solid 5')
ON CONFLICT (id) DO UPDATE SET
    site_id = EXCLUDED.site_id,
    name = EXCLUDED.name;

-- ============================================================================
-- DEFAULT ADMINISTRATOR
-- ============================================================================

INSERT INTO users (
    id,
    full_name,
    username,
    password_hash,
    role,
    department_id,
    site_id,
    status,
    failed_attempts
) VALUES (
    'USR-001',
    'System Administrator',
    'admin',
    '$2a$10$9qFVtKM306gL3UmTkbkZb.Fy.k8d4UYqFX051zpHbkL3iRg48ffa.',
    'administrator',
    'DEP-001',
    'SITE-001',
    'ACTIVE',
    0
)
ON CONFLICT (id) DO NOTHING;

COMMIT;

GRANT USAGE ON SCHEMA public TO b7_app;

GRANT SELECT, INSERT, UPDATE, DELETE
ON ALL TABLES IN SCHEMA public
TO b7_app;

GRANT USAGE, SELECT, UPDATE
ON ALL SEQUENCES IN SCHEMA public
TO b7_app;

ALTER DEFAULT PRIVILEGES IN SCHEMA public
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO b7_app;

ALTER DEFAULT PRIVILEGES IN SCHEMA public
GRANT USAGE, SELECT, UPDATE ON SEQUENCES TO b7_app;

DO $$
DECLARE
    constraint_name TEXT;
BEGIN
    FOR constraint_name IN
        SELECT conname
        FROM pg_constraint
        WHERE conrelid = 'public.inspections'::regclass
          AND contype = 'c'
          AND (
              pg_get_constraintdef(oid) ILIKE '%check_personel%'
              OR pg_get_constraintdef(oid) ILIKE '%check_ruangan%'
              OR pg_get_constraintdef(oid) ILIKE '%check_peralatan%'
              OR pg_get_constraintdef(oid) ILIKE '%missed_reason%'
          )
    LOOP
        EXECUTE format('ALTER TABLE public.inspections DROP CONSTRAINT %I', constraint_name);
    END LOOP;
END $$;

UPDATE public.inspections
SET check_personel = CASE WHEN check_personel = 'SESUAI' THEN 'OK' ELSE 'NOK' END
WHERE check_personel IS NOT NULL;

UPDATE public.inspections
SET check_ruangan = CASE WHEN check_ruangan = 'CLEAN' THEN 'OK' ELSE 'NOK' END
WHERE check_ruangan IS NOT NULL;

UPDATE public.inspections
SET check_peralatan = CASE WHEN check_peralatan = 'READY' THEN 'OK' ELSE 'NOK' END
WHERE check_peralatan IS NOT NULL;

ALTER TABLE public.inspections
    ADD CONSTRAINT inspections_check_personel_ok_nok_check
        CHECK (check_personel IN ('OK', 'NOK') OR check_personel IS NULL),
    ADD CONSTRAINT inspections_check_ruangan_ok_nok_check
        CHECK (check_ruangan IN ('OK', 'NOK') OR check_ruangan IS NULL),
    ADD CONSTRAINT inspections_check_peralatan_ok_nok_check
        CHECK (check_peralatan IN ('OK', 'NOK') OR check_peralatan IS NULL),
    ADD CONSTRAINT inspections_missed_reason_check
        CHECK (missed_reason IN ('Lupa', 'Hari Libur', 'Tidak dilakukan') OR missed_reason IS NULL);

GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO b7_app;
GRANT USAGE, SELECT, UPDATE ON ALL SEQUENCES IN SCHEMA public TO b7_app;