package main

import (
	"context"
	"crypto/rand"
	"encoding/hex"
	"errors"
	"fmt"
	"net/http"
	"strings"
	"sync"
	"time"

	"golang.org/x/crypto/bcrypt"
)

// ============================================================================
// CONTEXT KEYS & CONSTANTS
// ============================================================================

type contextKey string

const (
	UserContextKey    contextKey = "authenticatedUser"
	SessionContextKey contextKey = "authenticatedSession"

	StatusSessionExpired = 440
	InactivityTimeout    = 30 * time.Minute
	SessionResumeWindow  = 24 * time.Hour
	MaxFailedAttempts    = 3
)

// ============================================================================
// SESSION MODEL & STORE
// ============================================================================

type UserSession struct {
	ID           string
	UserID       string
	Role         UserRole
	Department   string
	CreatedAt    time.Time
	LastActivity time.Time
}

type AuthSessionStore struct {
	sync.RWMutex
	sessions map[string]*UserSession
}

func NewAuthSessionStore() *AuthSessionStore {
	return &AuthSessionStore{
		sessions: make(map[string]*UserSession),
	}
}

func (s *AuthSessionStore) CreateSession(userID string, role UserRole, department string) (*UserSession, string) {
	s.Lock()
	defer s.Unlock()

	b := make([]byte, 32)
	_, _ = rand.Read(b)
	token := hex.EncodeToString(b)

	now := time.Now().UTC()
	sess := &UserSession{
		ID:           token,
		UserID:       userID,
		Role:         role,
		Department:   department,
		CreatedAt:    now,
		LastActivity: now,
	}

	s.sessions[token] = sess
	return sess, token
}

func (s *AuthSessionStore) GetSession(token string) (*UserSession, bool) {
	s.RLock()
	defer s.RUnlock()

	sess, found := s.sessions[token]
	if !found || time.Since(sess.CreatedAt) >= SessionResumeWindow {
		return nil, false
	}

	// Inactivity Timeout Check (30 Minutes)
	if time.Since(sess.LastActivity) >= InactivityTimeout {
		return nil, false
	}

	return sess, true
}

func (s *AuthSessionStore) GetSessionForResume(token string) (*UserSession, bool) {
	s.RLock()
	defer s.RUnlock()

	sess, found := s.sessions[token]
	if !found || time.Since(sess.CreatedAt) >= SessionResumeWindow {
		return nil, false
	}

	return sess, true
}

func (s *AuthSessionStore) TouchSession(token string) {
	s.Lock()
	defer s.Unlock()

	if sess, found := s.sessions[token]; found {
		sess.LastActivity = time.Now().UTC()
	}
}

func (s *AuthSessionStore) DeleteSession(token string) {
	s.Lock()
	defer s.Unlock()
	delete(s.sessions, token)
}

// ============================================================================
// AUTH SERVICE / AUTHENTICATOR
// ============================================================================

type AuthService struct {
	repo         Repository
	sessionStore *AuthSessionStore
}

func NewAuthService(repo Repository, sessionStore *AuthSessionStore) *AuthService {
	return &AuthService{
		repo:         repo,
		sessionStore: sessionStore,
	}
}

// HashPassword hashes a raw password using bcrypt.
func HashPassword(password string) (string, error) {
	bytes, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
	return string(bytes), err
}

// CheckPasswordHash compares a raw password with a bcrypt hash.
func CheckPasswordHash(password, hash string) bool {
	err := bcrypt.CompareHashAndPassword([]byte(hash), []byte(password))
	return err == nil
}

// Login performs authentication, account status check, failed attempt tracking, and session creation.
func (a *AuthService) Login(ctx context.Context, username, password, ipAddress string) (*User, string, error) {
	user, err := a.repo.FindUserByUsername(ctx, username)
	if err != nil {
		return nil, "", errors.New("invalid credentials")
	}

	// Status Check: INACTIVE
	if user.Status == UserStatusInactive {
		return nil, "", errors.New("account is inactive")
	}

	// Status Check: BLOCKED
	if user.Status == UserStatusBlocked {
		return nil, "", errors.New("account is blocked due to failed login attempts")
	}

	// Verify Password Hash
	if !CheckPasswordHash(password, user.PasswordHash) {
		user.FailedAttempts++
		newStatus := user.Status
		if user.FailedAttempts >= MaxFailedAttempts {
			newStatus = UserStatusBlocked
		}

		_ = a.repo.UpdateFailedAttempts(ctx, user.ID, user.FailedAttempts, newStatus)

		_ = a.repo.CreateAuditLog(ctx, &AuditLog{
			ID:        fmt.Sprintf("AUD-%d", time.Now().UnixNano()),
			User:      user.Username,
			Action:    AuditActionAuthSecurity,
			Detail:    fmt.Sprintf("Failed login attempt (%d/%d)", user.FailedAttempts, MaxFailedAttempts),
			IPAddress: ipAddress,
		})

		if newStatus == UserStatusBlocked {
			_ = a.repo.CreateAuditLog(ctx, &AuditLog{
				ID:        fmt.Sprintf("AUD-%d", time.Now().UnixNano()),
				User:      user.Username,
				Action:    AuditActionAuthSecurity,
				Detail:    "Account automatically BLOCKED after reaching max failed attempts",
				IPAddress: ipAddress,
			})
			return nil, "", errors.New("account is blocked due to failed login attempts")
		}

		return nil, "", errors.New("invalid credentials")
	}

	// Reset Failed Attempts upon successful password verification
	if user.FailedAttempts > 0 {
		_ = a.repo.UpdateFailedAttempts(ctx, user.ID, 0, UserStatusActive)
	}

	// Create Authenticated Session
	_, token := a.sessionStore.CreateSession(user.ID, user.Role, user.Department)

	_ = a.repo.CreateAuditLog(ctx, &AuditLog{
		ID:        fmt.Sprintf("AUD-%d", time.Now().UnixNano()),
		User:      user.Username,
		Action:    AuditActionAuthSecurity,
		Detail:    "Login successful",
		IPAddress: ipAddress,
	})

	return user, token, nil
}

// AdminUnlockAccount unlocks a blocked user (Admin only operation).
func (a *AuthService) AdminUnlockAccount(ctx context.Context, adminUser *User, targetUserID, ipAddress string) error {
	if adminUser.Role != RoleAdministrator {
		return errors.New("unauthorized: admin only operation")
	}

	targetUser, err := a.repo.FindUserByID(ctx, targetUserID)
	if err != nil {
		return errors.New("target user not found")
	}

	if targetUser.ID == adminUser.ID {
		return errors.New("invalid operation: admin cannot unlock self")
	}

	err = a.repo.UpdateFailedAttempts(ctx, targetUser.ID, 0, UserStatusActive)
	if err != nil {
		return err
	}

	_ = a.repo.CreateAuditLog(ctx, &AuditLog{
		ID:        fmt.Sprintf("AUD-%d", time.Now().UnixNano()),
		User:      adminUser.Username,
		Action:    AuditActionAuthSecurity,
		Detail:    fmt.Sprintf("Admin unlocked account for user %s (%s)", targetUser.Username, targetUser.ID),
		IPAddress: ipAddress,
	})

	return nil
}

// SensitiveReLogin verifies the password of the currently authenticated user before performing sensitive actions.
func (a *AuthService) SensitiveReLogin(ctx context.Context, currentUser *User, password, ipAddress, operationName string) error {
	if !CheckPasswordHash(password, currentUser.PasswordHash) {
		_ = a.repo.CreateAuditLog(ctx, &AuditLog{
			ID:        fmt.Sprintf("AUD-%d", time.Now().UnixNano()),
			User:      currentUser.Username,
			Action:    AuditActionAuthSecurity,
			Detail:    fmt.Sprintf("Failed re-login verification for sensitive operation: %s", operationName),
			IPAddress: ipAddress,
		})
		return errors.New("re-login password verification failed")
	}

	_ = a.repo.CreateAuditLog(ctx, &AuditLog{
		ID:        fmt.Sprintf("AUD-%d", time.Now().UnixNano()),
		User:      currentUser.Username,
		Action:    AuditActionAuthSecurity,
		Detail:    fmt.Sprintf("Successful re-login verification for sensitive operation: %s", operationName),
		IPAddress: ipAddress,
	})

	return nil
}

// Logout invalidates the active session token.
func (a *AuthService) Logout(ctx context.Context, currentUser *User, token, ipAddress string) {
	a.sessionStore.DeleteSession(token)

	if currentUser != nil {
		_ = a.repo.CreateAuditLog(ctx, &AuditLog{
			ID:        fmt.Sprintf("AUD-%d", time.Now().UnixNano()),
			User:      currentUser.Username,
			Action:    AuditActionAuthSecurity,
			Detail:    "User logged out",
			IPAddress: ipAddress,
		})
	}
}

// ============================================================================
// AUTHENTICATION & AUTHORIZATION MIDDLEWARE
// ============================================================================

type AuthMiddleware struct {
	authService  *AuthService
	sessionStore *AuthSessionStore
	repo         Repository
}

func NewAuthMiddleware(authService *AuthService, sessionStore *AuthSessionStore, repo Repository) *AuthMiddleware {
	return &AuthMiddleware{
		authService:  authService,
		sessionStore: sessionStore,
		repo:         repo,
	}
}

// Authenticate verifies the session token and populates user context while enforcing inactivity timeout.
func (m *AuthMiddleware) Authenticate(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		cookie, err := r.Cookie("session_token")
		if err != nil || cookie.Value == "" {
			writeError(w, http.StatusUnauthorized, "Authentication required")
			return
		}

		token := cookie.Value
		sess, valid := m.sessionStore.GetSession(token)
		if !valid {
			expiredSession, resumable := m.sessionStore.GetSessionForResume(token)
			if resumable {
				user, err := m.repo.FindUserByID(r.Context(), expiredSession.UserID)
				if err == nil && user.Status == UserStatusActive {
					writeJSON(w, StatusSessionExpired, map[string]interface{}{
						"authenticated":  false,
						"sessionExpired": true,
						"user":           user.ToResponse(),
					})
					return
				}
				m.sessionStore.DeleteSession(token)
			}

			http.SetCookie(w, &http.Cookie{
				Name:     "session_token",
				Value:    "",
				Expires:  time.Unix(0, 0),
				HttpOnly: true,
				Path:     "/",
			})
			writeError(w, http.StatusUnauthorized, "Session expired or invalid")
			return
		}

		user, err := m.repo.FindUserByID(r.Context(), sess.UserID)
		if err != nil || user.Status != UserStatusActive {
			m.sessionStore.DeleteSession(token)
			writeError(w, http.StatusUnauthorized, "User account is no longer active")
			return
		}

		// Update activity timestamp on valid request
		m.sessionStore.TouchSession(token)

		ctx := context.WithValue(r.Context(), UserContextKey, user)
		ctx = context.WithValue(ctx, SessionContextKey, sess)

		next.ServeHTTP(w, r.WithContext(ctx))
	})
}

// RequireRoles restricts access to specific roles.
func (m *AuthMiddleware) RequireRoles(allowedRoles ...UserRole) func(http.Handler) http.Handler {
	return func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			user, ok := r.Context().Value(UserContextKey).(*User)
			if !ok || user == nil {
				writeError(w, http.StatusUnauthorized, "Unauthenticated request")
				return
			}

			roleAllowed := false
			for _, role := range allowedRoles {
				if user.Role == role {
					roleAllowed = true
					break
				}
			}

			if !roleAllowed {
				writeError(w, http.StatusForbidden, "Access denied: insufficient privileges")
				return
			}

			next.ServeHTTP(w, r)
		})
	}
}

// RequireDepartmentScope checks if the authenticated staff member belongs to the requested department scope.
func (m *AuthMiddleware) RequireDepartmentScope(departmentParam string) func(http.Handler) http.Handler {
	return func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			user, ok := r.Context().Value(UserContextKey).(*User)
			if !ok || user == nil {
				writeError(w, http.StatusUnauthorized, "Unauthenticated request")
				return
			}

			// Administrators, Managers, Supervisors have system-wide access based on RBAC rules.
			if user.Role == RoleAdministrator || user.Role == RoleManager || user.Role == RoleSupervisor {
				next.ServeHTTP(w, r)
				return
			}

			// Staff must strictly match their assigned department
			if user.Role == RoleStaff {
				if !strings.EqualFold(user.Department, departmentParam) {
					writeError(w, http.StatusForbidden, "Access denied: unauthorized department scope")
					return
				}
			}

			next.ServeHTTP(w, r)
		})
	}
}
