package main

import (
	"reflect"
	"testing"
	"time"
)

func TestGetAvailableShiftsForDate(t *testing.T) {
	refDate := time.Date(2026, 10, 15, 10, 0, 0, 0, time.UTC)

	t.Run("all shift slots are open when the date is empty", func(t *testing.T) {
		got := getAvailableShiftsForDate(nil, refDate)
		want := []string{"1", "2", "3"}
		if !reflect.DeepEqual(got, want) {
			t.Fatalf("getAvailableShiftsForDate(nil) = %#v, want %#v", got, want)
		}

	})

	t.Run("does not let entries from another date block today's shifts", func(t *testing.T) {
		inspections := []Inspection{
			{Date: time.Date(2026, 10, 12, 6, 45, 0, 0, time.UTC), Shift: "1"},
			{Date: time.Date(2026, 10, 13, 15, 15, 0, 0, time.UTC), Shift: "2"},
		}
		got := getAvailableShiftsForDate(inspections, refDate)
		want := []string{"1", "2", "3"}
		if !reflect.DeepEqual(got, want) {
			t.Fatalf("getAvailableShiftsForDate(...) = %#v, want %#v", got, want)
		}
	})

	t.Run("counts missed entries as filled shift slots for the same date", func(t *testing.T) {
		inspections := []Inspection{
			{Date: time.Date(2026, 10, 15, 0, 0, 0, 0, time.UTC), Shift: "1", MissedEntry: true},
		}
		got := getAvailableShiftsForDate(inspections, refDate)
		want := []string{"2", "3"}
		if !reflect.DeepEqual(got, want) {
			t.Fatalf("getAvailableShiftsForDate(...) = %#v, want %#v", got, want)
		}
	})

	t.Run("uses Jakarta calendar weeks", func(t *testing.T) {
		refDate := time.Date(2026, 10, 15, 22, 30, 0, 0, time.UTC)
		got := getWeekStart(refDate)
		want := time.Date(2026, 10, 12, 0, 0, 0, 0, jakartaLocation())
		if !got.Equal(want) {
			t.Fatalf("getWeekStart(...) = %s, want %s", got.Format(time.RFC3339), want.Format(time.RFC3339))
		}

		parsedDate := normalizeInspectionDate("2026-10-15", refDate)
		if parsedDate.Location().String() != jakartaLocation().String() || parsedDate.Day() != 15 || parsedDate.Month() != time.October {
			t.Fatalf("normalizeInspectionDate(...) = %s, want 2026-10-15 in Asia/Jakarta", parsedDate.Format(time.RFC3339))
		}
	})

	t.Run("maps clock boundaries to shifts and start dates", func(t *testing.T) {
		tests := []struct {
			name      string
			localTime time.Time
			wantShift string
			wantDate  string
		}{
			{"before shift 1 starts", time.Date(2026, 10, 13, 6, 44, 59, 0, jakartaLocation()), "3", "2026-10-12"},
			{"shift 1 starts", time.Date(2026, 10, 13, 6, 45, 0, 0, jakartaLocation()), "1", "2026-10-13"},
			{"shift 1 ends", time.Date(2026, 10, 13, 15, 14, 59, 0, jakartaLocation()), "1", "2026-10-13"},
			{"shift 2 starts", time.Date(2026, 10, 13, 15, 15, 0, 0, jakartaLocation()), "2", "2026-10-13"},
			{"shift 2 ends", time.Date(2026, 10, 13, 22, 29, 59, 0, jakartaLocation()), "2", "2026-10-13"},
			{"shift 3 starts", time.Date(2026, 10, 13, 22, 30, 0, 0, jakartaLocation()), "3", "2026-10-13"},
			{"early shift 3", time.Date(2026, 10, 13, 1, 37, 0, 0, jakartaLocation()), "3", "2026-10-12"},
		}
		for _, test := range tests {
			t.Run(test.name, func(t *testing.T) {
				gotShift, gotDate := getCurrentShift(test.localTime)
				if gotShift != test.wantShift {
					t.Errorf("shift = %s, want %s", gotShift, test.wantShift)
				}
				if got := gotDate.Format("2006-01-02"); got != test.wantDate {
					t.Errorf("date = %s, want %s", got, test.wantDate)
				}
			})
		}
	})
}

func TestGetInspectionProgressMissedEntryOrdering(t *testing.T) {
	jakarta := jakartaLocation()
	currentTime := time.Date(2026, 10, 26, 16, 0, 0, 0, jakarta)

	t.Run("requires first missed shift before active shift", func(t *testing.T) {
		inspections := []Inspection{
			{Date: time.Date(2026, 10, 26, 0, 0, 0, 0, jakarta), Shift: "2"},
		}
		got := getInspectionProgress(inspections, currentTime)
		if got["missedType"] != "shift" || got["missingShift"] != "1" {
			t.Fatalf("getInspectionProgress() = %#v, want missed Shift 1 before active Shift 2", got)
		}
	})

	t.Run("assigns pre-0645 shift 3 to its start date", func(t *testing.T) {
		inspections := []Inspection{
			{Date: time.Date(2026, 10, 12, 0, 0, 0, 0, jakarta), Shift: "1"},
		}
		now := time.Date(2026, 10, 13, 1, 37, 0, 0, jakarta)
		got := getInspectionProgress(inspections, now)
		if got["missedType"] != "shift" || got["missingShift"] != "2" || got["inspectionDate"] != "2026-10-12" {
			t.Fatalf("getInspectionProgress() = %#v, want Shift 2 missed in shift-start date 2026-10-12", got)
		}
	})

	t.Run("does not carry previous-day missed shifts into the active day", func(t *testing.T) {
		inspections := []Inspection{
			{Date: time.Date(2026, 10, 26, 0, 0, 0, 0, jakarta), Shift: "2"},
		}
		now := time.Date(2026, 10, 27, 7, 0, 0, 0, jakarta)
		got := getInspectionProgress(inspections, now)
		if got["requiresMissed"] == true {
			t.Fatalf("getInspectionProgress() = %#v, want no missed shift debt from the prior day", got)
		}
		if got["activeShift"] != "1" || got["activeShiftAvailable"] != true {
			t.Fatalf("getInspectionProgress() = %#v, want active Shift 1 available", got)
		}
	})

	t.Run("allows shift one on the next day even when all shifts were filled yesterday", func(t *testing.T) {
		inspections := []Inspection{
			{Date: time.Date(2026, 10, 20, 0, 0, 0, 0, jakarta), Shift: "1", MissedEntry: true},
			{Date: time.Date(2026, 10, 20, 0, 0, 0, 0, jakarta), Shift: "2"},
			{Date: time.Date(2026, 10, 20, 0, 0, 0, 0, jakarta), Shift: "3", MissedEntry: true},
		}
		now := time.Date(2026, 10, 21, 7, 0, 0, 0, jakarta)
		got := getInspectionProgress(inspections, now)
		if got["requiresMissed"] == true || got["activeShiftAvailable"] != true || got["nextShift"] != "1" {
			t.Fatalf("getInspectionProgress() = %#v, want Shift 1 available on 2026-10-21 without missed-entry prompt", got)
		}
	})

	t.Run("exposes an optional shift three catch-up without blocking today's regular shift", func(t *testing.T) {
		inspections := []Inspection{
			{Date: time.Date(2026, 10, 20, 0, 0, 0, 0, jakarta), Shift: "1"},
			{Date: time.Date(2026, 10, 20, 0, 0, 0, 0, jakarta), Shift: "2"},
		}
		now := time.Date(2026, 10, 21, 7, 0, 0, 0, jakarta)
		got := getInspectionProgress(inspections, now)
		if got["requiresMissed"] == true || got["pendingShiftThree"] != true ||
			got["pendingShiftThreeDate"] != "2026-10-20" || got["activeShiftAvailable"] != true {
			t.Fatalf("getInspectionProgress() = %#v, want optional Shift 3 catch-up and regular Shift 1 available", got)
		}
	})

	t.Run("carries an unresolved shift three into the following week", func(t *testing.T) {
		inspections := []Inspection{
			{Date: time.Date(2026, 10, 19, 0, 0, 0, 0, jakarta), Shift: "1"},
			{Date: time.Date(2026, 10, 19, 0, 0, 0, 0, jakarta), Shift: "2"},
		}
		now := time.Date(2026, 10, 26, 7, 0, 0, 0, jakarta)
		got := getInspectionProgress(inspections, now)
		if got["requiresMissed"] != true || got["shiftThreeCarryover"] != true ||
			got["missingShift"] != "3" || got["missingDate"] != "2026-10-19" {
			t.Fatalf("getInspectionProgress() = %#v, want previous week's Shift 3 as a carryover", got)
		}
	})

	t.Run("marks only earlier missing shifts on the active shift-start date", func(t *testing.T) {
		inspections := []Inspection{
			{Date: time.Date(2026, 10, 26, 0, 0, 0, 0, jakarta), Shift: "3"},
			{Date: time.Date(2026, 10, 27, 0, 0, 0, 0, jakarta), Shift: "1"},
		}
		now := time.Date(2026, 10, 27, 23, 0, 0, 0, jakarta)
		got := getInspectionProgress(inspections, now)
		if got["missedType"] != "shift" || got["missingShift"] != "2" || got["missingDate"] != "2026-10-27" {
			t.Fatalf("getInspectionProgress() = %#v, want only Shift 2 missed on 2026-10-27", got)
		}
	})
}

func TestInspectionDisplayDateTime(t *testing.T) {
	date := time.Date(2026, 10, 12, 0, 0, 0, 0, jakartaLocation())

	t.Run("normal inspection shows actual submit time", func(t *testing.T) {
		submittedAt := time.Date(2026, 10, 13, 1, 37, 0, 0, jakartaLocation())
		got := inspectionDisplayDateTime(Inspection{
			Date: date, Shift: "3", CreatedAt: submittedAt,
		})
		if got.Hour() != 1 || got.Minute() != 37 || got.Day() != 13 {
			t.Fatalf("inspectionDisplayDateTime() = %s, want actual submit time 2026-10-13 01:37 WIB", got.Format(time.RFC3339))
		}
	})

	t.Run("missed entry shows shift start time on selected inspection date", func(t *testing.T) {
		submittedAt := time.Date(2026, 10, 13, 1, 37, 0, 0, jakartaLocation())
		got := inspectionDisplayDateTime(Inspection{
			Date: date, Shift: "2", MissedEntry: true, CreatedAt: submittedAt,
		})
		if got.Hour() != 15 || got.Minute() != 15 || got.Day() != 12 {
			t.Fatalf("inspectionDisplayDateTime() = %s, want shift start 2026-10-12 15:15 WIB", got.Format(time.RFC3339))
		}
	})
}

func TestUnresolvedShiftThreeDates(t *testing.T) {
	date := time.Date(2026, 10, 19, 0, 0, 0, 0, jakartaLocation())
	weekEnd := date.AddDate(0, 0, 6)
	tests := []struct {
		name        string
		inspections []Inspection
		want        []string
	}{
		{
			name: "shift one and two without shift three create a pending entry",
			inspections: []Inspection{
				{Date: date, Shift: "1"},
				{Date: date, Shift: "2"},
			},
			want: []string{"2026-10-19"},
		},
		{
			name: "a missed shift three recorded on its original date resolves the entry",
			inspections: []Inspection{
				{Date: date, Shift: "1"},
				{Date: date, Shift: "2"},
				{Date: date, Shift: "3", MissedEntry: true},
			},
			want: []string{},
		},
		{
			name: "missed shift three on another date does not resolve the source date",
			inspections: []Inspection{
				{Date: date, Shift: "1"},
				{Date: date, Shift: "2"},
				{Date: date.AddDate(0, 0, 2), Shift: "3", MissedEntry: true},
			},
			want: []string{"2026-10-19"},
		},
		{
			name: "a missing earlier shift does not create a shift three debt",
			inspections: []Inspection{
				{Date: date, Shift: "1"},
			},
			want: []string{},
		},
		{
			name: "missed shift one and two entries do not create a shift three debt",
			inspections: []Inspection{
				{Date: date, Shift: "1", MissedEntry: true},
				{Date: date, Shift: "2", MissedEntry: true},
			},
			want: []string{},
		},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			gotDates := unresolvedShiftThreeDates(test.inspections, date, weekEnd)
			got := make([]string, len(gotDates))
			for i, pendingDate := range gotDates {
				got[i] = pendingDate.Format("2006-01-02")
			}
			if !reflect.DeepEqual(got, test.want) {
				t.Fatalf("unresolvedShiftThreeDates() = %#v, want %#v", got, test.want)
			}
		})
	}
}

func TestHasInspectionForDateAndShift(t *testing.T) {
	targetDate := time.Date(2026, 10, 13, 0, 0, 0, 0, jakartaLocation())
	inspections := []Inspection{
		{Date: targetDate.AddDate(0, 0, -1), Shift: "1"},
		{Date: targetDate, Shift: "2"},
	}

	if hasInspectionForDateAndShift(inspections, targetDate, "1") {
		t.Fatal("shift 1 on a different date should not block this missed-shift entry")
	}
	if !hasInspectionForDateAndShift(inspections, targetDate, "2") {
		t.Fatal("existing shift 2 on the same date should block a duplicate")
	}
}

func TestSortInspectionReport(t *testing.T) {
	reports := []Inspection{
		{ID: "shift-3", Date: time.Date(2026, 10, 5, 12, 0, 0, 0, time.UTC), Shift: "3"},
		{ID: "shift-1-later-date", Date: time.Date(2026, 10, 12, 12, 0, 0, 0, time.UTC), Shift: "1"},
		{ID: "shift-1", Date: time.Date(2026, 10, 5, 12, 0, 0, 0, time.UTC), Shift: "1"},
		{ID: "shift-2", Date: time.Date(2026, 10, 5, 12, 0, 0, 0, time.UTC), Shift: "2"},
	}

	t.Run("oldest first keeps shifts in ascending order", func(t *testing.T) {
		sortInspectionReport(reports, "oldest")
		got := []string{reports[0].ID, reports[1].ID, reports[2].ID, reports[3].ID}
		want := []string{"shift-1", "shift-2", "shift-3", "shift-1-later-date"}
		if !reflect.DeepEqual(got, want) {
			t.Fatalf("oldest sort = %#v, want %#v", got, want)
		}
	})

	t.Run("newest date first still keeps shifts in ascending order", func(t *testing.T) {
		sortInspectionReport(reports, "newest")
		got := []string{reports[0].ID, reports[1].ID, reports[2].ID, reports[3].ID}
		want := []string{"shift-1-later-date", "shift-1", "shift-2", "shift-3"}
		if !reflect.DeepEqual(got, want) {
			t.Fatalf("newest sort = %#v, want %#v", got, want)
		}
	})
}

func TestSortInspectionReportPointers(t *testing.T) {
	reports := []*Inspection{
		{ID: "shift-3", Date: time.Date(2026, 10, 5, 12, 0, 0, 0, time.UTC), Shift: "3"},
		{ID: "shift-1-later-date", Date: time.Date(2026, 10, 12, 12, 0, 0, 0, time.UTC), Shift: "1"},
		{ID: "shift-1", Date: time.Date(2026, 10, 5, 12, 0, 0, 0, time.UTC), Shift: "1"},
		{ID: "shift-2", Date: time.Date(2026, 10, 5, 12, 0, 0, 0, time.UTC), Shift: "2"},
	}

	sorted := sortInspectionReportPointers(reports)
	got := make([]string, len(sorted))
	for i, report := range sorted {
		got[i] = report.ID
	}
	want := []string{"shift-1", "shift-2", "shift-3", "shift-1-later-date"}
	if !reflect.DeepEqual(got, want) {
		t.Fatalf("sorted PDF reports = %#v, want %#v", got, want)
	}
}

func TestCollectReportOperatorsIncludesInspectors(t *testing.T) {
	inspections := []*Inspection{
		{
			CreatedBy:          "USR-001",
			CreatedByUsername:  "admin",
			StaffName:          "System Administrator",
			SupervisorUsername: "yudha",
			SupervisorName:     "Yudha Nugraha",
		},
		{
			CreatedBy:          "USR-001",
			CreatedByUsername:  "admin",
			StaffName:          "System Administrator",
			SupervisorUsername: "yudha",
			SupervisorName:     "Yudha Nugraha",
		},
	}

	got := collectReportOperators(inspections)
	want := []reportOperator{
		{username: "admin", fullname: "System Administrator"},
		{username: "yudha", fullname: "Yudha Nugraha"},
	}
	if !reflect.DeepEqual(got, want) {
		t.Fatalf("collectReportOperators() = %#v, want %#v", got, want)
	}
}
