package main

import (
	"bytes"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"time"

	"github.com/jung-kurt/gofpdf"
)

// GenerateInspectionPDFReport mengikuti format PDF acuan versi PHP:
// judul "Formulir Inspeksi Kebersihan Personil, Ruangan, dan Peralatan",
// tabel utama dengan kolom No + Check Item (keterangan lengkap),
// dan tabel Operator di bawah tabel utama pada halaman yang sama.
func GenerateInspectionPDFReport(inspections []*Inspection, req PDFReportRequest) ([]byte, error) {
	inspections = sortInspectionReportPointers(inspections)

	pdf := gofpdf.New("L", "mm", "A4", "")
	pdf.SetMargins(8, 8, 8)
	pdf.SetAutoPageBreak(true, 34)
	pdf.AliasNbPages("{nb}")
	logoPath := findReportLogo()

	// currentReq dibaca oleh fungsi header; nilai Lokasi-nya diganti mengikuti
	// grup lokasi yang sedang dirender (report batch = gabungan report satuan).
	currentReq := req
	hasData := len(inspections) > 0
	pdf.SetHeaderFunc(func() { drawLegacyHeader(pdf, currentReq, logoPath, hasData) })
	pdf.SetFooterFunc(func() { drawLegacyFooter(pdf, req.PrintedBy) })

	if !hasData {
		pdf.AddPage()
		pdf.SetFont("Arial", "", 10)
		pdf.CellFormat(0, 7, "Tidak ada data inspeksi untuk periode/lokasi yang dipilih.", "1", 1, "C", false, 0, "")
	} else {
		// Kelompokkan per lokasi: report "semua lokasi" dirender sebagai
		// gabungan report per mesin — masing-masing mulai di halaman baru
		// dengan header info, tabel, penomoran, dan tabel operator sendiri,
		// persis seperti mencetak report satuan satu per satu.
		for _, group := range groupInspectionsByLocation(inspections, req.Location) {
			currentReq.Location = group.name
			pdf.AddPage()
			for i, item := range group.items {
				if item != nil {
					drawInspectionRow(pdf, item, i+1)
				}
			}
			drawOperatorSection(pdf, group.items)
		}
	}

	var buf bytes.Buffer
	if err := pdf.Output(&buf); err != nil {
		return nil, fmt.Errorf("gagal merender buffer PDF: %w", err)
	}
	return buf.Bytes(), nil
}

func sortInspectionReportPointers(inspections []*Inspection) []*Inspection {
	sorted := append([]*Inspection(nil), inspections...)
	sort.SliceStable(sorted, func(i, j int) bool {
		if sorted[i] == nil {
			return false
		}
		if sorted[j] == nil {
			return true
		}
		return inspectionReportLess(*sorted[i], *sorted[j], "oldest")
	})
	return sorted
}

type inspectionLocationGroup struct {
	name  string
	items []*Inspection
}

// groupInspectionsByLocation mengelompokkan inspeksi per lokasi, terurut
// alfabet berdasarkan nama lokasi. Urutan baris di dalam grup mengikuti
// urutan inspections yang masuk (sudah terurut tanggal + shift).
func groupInspectionsByLocation(inspections []*Inspection, fallbackLocation string) []inspectionLocationGroup {
	byName := map[string]*inspectionLocationGroup{}
	for _, item := range inspections {
		if item == nil {
			continue
		}
		name := strings.TrimSpace(item.LocationName)
		if name == "" {
			name = strings.TrimSpace(item.LocationID)
		}
		if name == "" {
			name = fallbackLocation
		}
		group, ok := byName[name]
		if !ok {
			group = &inspectionLocationGroup{name: name}
			byName[name] = group
		}
		group.items = append(group.items, item)
	}

	names := make([]string, 0, len(byName))
	for name := range byName {
		names = append(names, name)
	}
	sort.Strings(names)

	groups := make([]inspectionLocationGroup, 0, len(names))
	for _, name := range names {
		groups = append(groups, *byName[name])
	}
	return groups
}

func drawLegacyHeader(pdf *gofpdf.Fpdf, req PDFReportRequest, logoPath string, hasData bool) {
	// Kotak judul: logo di kiri, judul formulir di kanan (sesuai acuan PHP).
	pdf.SetFont("Arial", "B", 14)
	pdf.CellFormat(50, 22, "", "1", 0, "C", false, 0, "")
	if logoPath != "" {
		pdf.ImageOptions(logoPath, 14, 11, 38, 0, false, gofpdf.ImageOptions{ImageType: "PNG", ReadDpi: true}, 0, "")
	}
	pdf.CellFormat(231, 22, "Formulir Inspeksi Kebersihan Personil, Ruangan, dan Peralatan", "1", 1, "C", false, 0, "")

	// Baris info: Lokasi | Bagian | Departemen | Site | Bulan dan Tahun.
	pdf.SetFont("Arial", "B", 9)
	pdf.CellFormat(15, 10, "Lokasi :", "", 0, "L", false, 0, "")
	pdf.CellFormat(52, 10, req.Location, "", 0, "L", false, 0, "")
	pdf.CellFormat(15, 10, "Bagian :", "", 0, "L", false, 0, "")
	pdf.CellFormat(33, 10, "Produksi Liquid", "", 0, "L", false, 0, "")
	pdf.CellFormat(24, 10, "Departemen :", "", 0, "L", false, 0, "")
	pdf.CellFormat(27, 10, "Produksi PG", "", 0, "L", false, 0, "")
	pdf.CellFormat(10, 10, "Site :", "", 0, "L", false, 0, "")
	pdf.CellFormat(23, 10, "Pulogadung", "", 0, "L", false, 0, "")
	pdf.CellFormat(31, 10, "Bulan dan Tahun :", "", 0, "L", false, 0, "")
	pdf.CellFormat(51, 10, reportMonth(req.Month, req.Year, hasData), "", 1, "L", false, 0, "")

	// Header tabel utama dua baris:
	// No | Tanggal | Shift | Check Item (6 kolom) | Lokasi | Pelaksana | Pemeriksa
	pdf.SetFont("Arial", "", 9)
	widths := reportColumnWidths()
	hdrY := pdf.GetY()
	checkItemW := widths[3] + widths[4] + widths[5] + widths[6] + widths[7] + widths[8]

	pdf.MultiCell(widths[0], 14, "No", "1", "C", false)
	pdf.SetXY(8+widths[0], hdrY)
	pdf.MultiCell(widths[1], 14, "Tanggal", "1", "C", false)
	pdf.SetXY(8+widths[0]+widths[1], hdrY)
	pdf.MultiCell(widths[2], 14, "Shift", "1", "C", false)
	pdf.SetXY(8+widths[0]+widths[1]+widths[2], hdrY)
	pdf.CellFormat(checkItemW, 7, "Check Item", "1", 0, "C", false, 0, "")
	pdf.SetXY(8+widths[0]+widths[1]+widths[2]+checkItemW, hdrY)
	pdf.MultiCell(widths[9], 14, "Lokasi", "1", "C", false)
	pdf.SetXY(8+widths[0]+widths[1]+widths[2]+checkItemW+widths[9], hdrY)
	pdf.MultiCell(widths[10], 14, "Pelaksana", "1", "C", false)
	pdf.SetXY(8+widths[0]+widths[1]+widths[2]+checkItemW+widths[9]+widths[10], hdrY)
	pdf.MultiCell(widths[11], 14, "Pemeriksa", "1", "C", false)

	pdf.SetXY(8+widths[0]+widths[1]+widths[2], hdrY+7)
	subHeaders := []string{"Personel", "Keterangan Personel", "Ruangan", "Keterangan Ruangan", "Peralatan", "Keterangan Peralatan"}
	for i, label := range subHeaders {
		pdf.CellFormat(widths[3+i], 7, label, "1", 0, "C", false, 0, "")
	}
	pdf.SetXY(8, hdrY+14)
}

func drawLegacyFooter(pdf *gofpdf.Fpdf, printedBy string) {
	pdf.SetFont("Arial", "", 8)
	pdf.SetY(-32)
	pdf.CellFormat(140, 10, "*Lakukan Pencatatan setiap hari pertama tiap minggu", "", 0, "L", false, 0, "")
	pdf.CellFormat(141, 10, "Lampiran 1 -WI-PR-PR-8001.03", "", 0, "R", false, 0, "")
	pdf.SetY(-26)
	pdf.CellFormat(281, 10, fmt.Sprintf("Halaman %d/{nb}", pdf.PageNo()), "", 0, "R", false, 0, "")
	pdf.SetXY(8, -26)
	pdf.CellFormat(281, 10, "Dokumen ini telah ditandatangani secara elektronik menggunakan aplikasi FUPD Online dengan melampirkan lembar", "", 0, "C", false, 0, "")
	pdf.SetY(-21)
	pdf.CellFormat(281, 10, "persetujuan elektronik milik PT. Bintang Toedjoe (A Kalbe Company)", "", 0, "C", false, 0, "")
	pdf.SetY(-14)
	pdf.CellFormat(132, 10, "", "", 0, "C", false, 0, "")
	pdf.SetTextColor(255, 0, 0)
	pdf.SetDrawColor(255, 0, 0)
	pdf.CellFormat(16, 7, "Approved", "1", 0, "C", false, 0, "")
	pdf.SetTextColor(0, 0, 0)
	pdf.SetDrawColor(0, 0, 0)
	printedAt := time.Now().In(time.FixedZone("WIB", 7*60*60)).Format("02-01-2006 15:04:05")
	pdf.CellFormat(133, 10, "Printed by : "+reportValue(printedBy, "-")+" on "+printedAt, "", 0, "R", false, 0, "")
}

// reportRowValues menyusun nilai satu baris tabel utama mengikuti format PHP:
//   - Entry terlewat (missed): kolom cek = "-", kolom keterangan = alasan
//     ("Lupa" / "Hari Libur" / "Tidak Dilakukan").
//   - Entry normal: kolom cek = OK/NOK apa adanya; kolom keterangan = catatan,
//     dan bila kosong atau berisi Ok/Nok ditampilkan "-".
func reportRowValues(item *Inspection, no int) []string {
	location := item.LocationName
	if location == "" {
		location = item.LocationID
	}
	var c1, k1, c2, k2, c3, k3 string
	if item.MissedEntry {
		reason := displayMissedReason(item.MissedReason)
		c1, k1, c2, k2, c3, k3 = "-", reason, "-", reason, "-", reason
	} else {
		c1, k1 = item.CheckPersonel, reportKetValue(item.KetPersonel)
		c2, k2 = item.CheckRuangan, reportKetValue(item.KetRuangan)
		c3, k3 = item.CheckPeralatan, reportKetValue(item.KetPeralatan)
		if strings.TrimSpace(c1) == "" {
			c1 = "-"
		}
		if strings.TrimSpace(c2) == "" {
			c2 = "-"
		}
		if strings.TrimSpace(c3) == "" {
			c3 = "-"
		}
	}
	return []string{
		strconv.Itoa(no),
		item.Date.Format("02-01-2006"),
		item.Shift,
		c1, k1, c2, k2, c3, k3,
		location,
		reportUsername(item),
		approvalUser(item),
	}
}

// reportUsername menampilkan username akun sesuai pendaftaran (mis. "admin"),
// bukan ID user dari database (mis. "USR-001") yang tersimpan di CreatedBy.
// Fallback ke CreatedBy bila username hasil JOIN tidak tersedia.
func reportUsername(item *Inspection) string {
	if strings.TrimSpace(item.CreatedByUsername) != "" {
		return item.CreatedByUsername
	}
	return item.CreatedBy
}

// displayMissedReason menormalkan alasan entry terlewat untuk tampilan report.
// "Tidak dilakukan" adalah keterangan baru versi migrasi yang tidak ada di PHP,
// dan tetap ditampilkan (dengan huruf kapital sesuai format keterangan lain).
func displayMissedReason(reason *string) string {
	if reason == nil {
		return "-"
	}
	r := strings.TrimSpace(*reason)
	switch strings.ToLower(r) {
	case "":
		return "-"
	case "lupa":
		return "Lupa"
	case "hari libur":
		return "Hari Libur"
	case "tidak dilakukan":
		return "Tidak Dilakukan"
	default:
		return r
	}
}

// reportKetValue menampilkan isi kolom keterangan entry normal:
// catatan asli apa adanya; kosong atau Ok/Nok menjadi "-".
func reportKetValue(ket *string) string {
	if ket == nil {
		return "-"
	}
	v := strings.TrimSpace(*ket)
	if v == "" {
		return "-"
	}
	if strings.EqualFold(v, "ok") || strings.EqualFold(v, "nok") {
		return "-"
	}
	return v
}

func drawInspectionRow(pdf *gofpdf.Fpdf, item *Inspection, no int) {
	pdf.SetFont("Arial", "", 9)
	drawWrappedTableRow(pdf, reportRowValues(item, no), reportColumnWidths(), nil)
}

type reportOperator struct {
	username string
	fullname string
}

func collectReportOperators(inspections []*Inspection) []reportOperator {
	seen := map[string]bool{}
	var operators []reportOperator
	addOperator := func(username, fullname string) {
		username = strings.TrimSpace(username)
		if username == "" || seen[strings.ToLower(username)] {
			return
		}
		seen[strings.ToLower(username)] = true
		fullname = reportValue(fullname, username)
		operators = append(operators, reportOperator{username: username, fullname: fullname})
	}

	for _, item := range inspections {
		if item == nil {
			continue
		}
		addOperator(reportUsername(item), item.StaffName)
		addOperator(item.SupervisorUsername, item.SupervisorName)
	}
	return operators
}

// drawOperatorSection menggambar tabel "Operator:" (No | Username | Nama Lengkap)
// di bawah tabel utama pada halaman yang sama, mengikuti acuan PHP.
// Menggantikan halaman terpisah "Identitas paraf user" pada versi sebelumnya.
func drawOperatorSection(pdf *gofpdf.Fpdf, inspections []*Inspection) {
	ops := collectReportOperators(inspections)
	if len(ops) == 0 {
		return
	}

	// Jaga section Operator tidak yatim/terpotong di dasar halaman: butuh ruang
	// untuk Ln + label + header tabel + minimal satu baris (±24mm sebelum
	// batas page break di 176mm). Bila tidak cukup, pindah halaman dulu.
	if pdf.GetY() > 150 {
		pdf.AddPage()
	}

	pdf.Ln(6)
	pdf.SetFont("Arial", "B", 9)
	pdf.CellFormat(0, 6, "Operator:", "", 1, "L", false, 0, "")

	pdf.SetFont("Arial", "B", 9)
	operatorWidths := []float64{12, 22, 62}
	drawWrappedTableRow(pdf, []string{"No", "Username", "Nama Lengkap"}, operatorWidths, []string{"C", "L", "C"})

	pdf.SetFont("Arial", "", 9)
	for i, op := range ops {
		drawWrappedTableRow(
			pdf,
			[]string{fmt.Sprintf("%d)", i+1), op.username, op.fullname},
			operatorWidths,
			[]string{"C", "L", "L"},
		)
	}
}

func drawWrappedTableRow(pdf *gofpdf.Fpdf, values []string, widths []float64, aligns []string) {
	const lineHeight = 5.0
	lineCounts := make([]int, len(values))
	maxLines := 1
	for i, value := range values {
		lines := pdf.SplitText(value, widths[i]-1)
		if len(lines) > maxLines {
			maxLines = len(lines)
		}
		lineCounts[i] = len(lines)
	}

	rowHeight := float64(maxLines)*lineHeight + 1

	// Page-break safety: bila baris tidak muat di sisa halaman, pindah halaman
	// SEBELUM menggambar. Tanpa ini MultiCell memicu page break di tengah baris:
	// rect tertinggal di halaman lama, teks pindah ke halaman baru menimpa
	// header, dan posisi baris berikutnya kacau (report jadi amburadul).
	if auto, margin := pdf.GetAutoPageBreak(); auto {
		_, pageHeight := pdf.GetPageSize()
		if pdf.GetY()+rowHeight > pageHeight-margin {
			pdf.AddPage()
		}
	}

	startX, startY := pdf.GetXY()
	x := startX
	for i, value := range values {
		pdf.Rect(x, startY, widths[i], rowHeight, "D")
		align := "C"
		if i < len(aligns) && aligns[i] != "" {
			align = aligns[i]
		}
		textHeight := float64(lineCounts[i]) * lineHeight
		textY := startY + (rowHeight-textHeight)/2
		pdf.SetXY(x+0.5, textY)
		pdf.MultiCell(widths[i]-1, lineHeight, value, "", align, false)
		x += widths[i]
	}
	pdf.SetXY(startX, startY+rowHeight)
}

// reportColumnWidths: No, Tanggal, Shift, Personel, Ket Personel, Ruangan,
// Ket Ruangan, Peralatan, Ket Peralatan, Lokasi, Pelaksana, Pemeriksa.
// Total 281mm (A4 landscape, margin 8mm kiri + 8mm kanan) — format acuan PHP.
// Lebar kolom TETAP; teks panjang dibungkus (wrap) ke dalam sel oleh
// drawWrappedTableRow, bukan dengan mengubah lebar kolom.
func reportColumnWidths() []float64 {
	return []float64{7, 20, 10, 19, 38, 19, 38, 19, 38, 35, 19, 19}
}

func findReportLogo() string {
	paths := []string{filepath.Join("..", "frontend", "public", "img", "logo.png"), filepath.Join("frontend", "public", "img", "logo.png")}
	for _, path := range paths {
		if _, err := os.Stat(path); err == nil {
			return path
		}
	}
	return ""
}

func reportMonth(month, year int, hasData bool) string {
	if !hasData || month < 1 || month > 12 {
		return ""
	}
	return time.Date(year, time.Month(month), 1, 0, 0, 0, 0, time.UTC).Format("January 2006")
}

func reportValue(value, fallback string) string {
	if strings.TrimSpace(value) != "" {
		return strings.TrimSpace(value)
	}
	return fallback
}

func textPointer(value *string) string {
	if value == nil {
		return ""
	}
	return *value
}

func approvalUser(item *Inspection) string {
	if item.SupervisorName != "" {
		return item.SupervisorName
	}
	if item.SupervisorApprovedBy != nil {
		return *item.SupervisorApprovedBy
	}
	return ""
}
