'use client';

import React, { Suspense, useState, useEffect, FormEvent, ChangeEvent } from 'react';
import { useRouter } from 'next/navigation';
import Sidebar from '../sidebar';

interface UserSession {
  id: string;
  name: string;
  username: string;
  role: string;
  department: string;
  site: string;
}

interface Location {
  id: string;
  name: string;
}

interface InspectionData {
  id: string;
  date: string;
  shift: string;
  locationId: string;
  locationName?: string;
  checkPersonel: 'OK' | 'NOK';
  checkRuangan: 'OK' | 'NOK';
  checkPeralatan: 'OK' | 'NOK';
  ketPersonel: string;
  ketRuangan: string;
  ketPeralatan: string;
  status: 'SUBMITTED' | 'SUPERVISOR_APPROVED' | 'APPROVED';
  staffName?: string;
  supervisorName?: string;
  managerName?: string;
}

export default function EditInspectionPage() {
  const router = useRouter();

  const [inspectionId, setInspectionId] = useState<string | null>(null);

  // Session & Master Data
  const [currentUser, setCurrentUser] = useState<UserSession | null>(null);
  const [locations, setLocations] = useState<Location[]>([]);

  // State Monitoring Otorisasi Revisi
  const [isAuthorizedForEdit, setIsAuthorizedForEdit] =
    useState<boolean>(false);

  // Form State Data Inspeksi
  const [date, setDate] = useState<string>('');
  const [shift, setShift] = useState<string>('1');
  const [locationId, setLocationId] = useState<string>('');
  const [checkPersonel, setCheckPersonel] = useState<'OK' | 'NOK'>('OK');
  const [checkRuangan, setCheckRuangan] = useState<'OK' | 'NOK'>('OK');
  const [checkPeralatan, setCheckPeralatan] = useState<'OK' | 'NOK'>('OK');
  const [ketPersonel, setKetPersonel] = useState<string>('');
  const [ketRuangan, setKetRuangan] = useState<string>('');
  const [ketPeralatan, setKetPeralatan] = useState<string>('');
  const [currentStatus, setCurrentStatus] = useState<string>('');

  // UI & Loading States
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [validationErrors, setValidationErrors] = useState<Record<string, string>>({});

  // Modal Re-login / Authorization States
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);
  const [reloginUsername, setReloginUsername] = useState<string>('');
  const [reloginPassword, setReloginPassword] = useState<string>('');
  const [reloginError, setReloginError] = useState<string | null>(null);
  const [isVerifyingAuth, setIsVerifyingAuth] = useState<boolean>(false);

  // Load Initial Session, Locations, & Inspection Data
  useEffect(() => {
    const initData = async () => {
      const id = new URLSearchParams(window.location.search).get('id');
      setInspectionId(id);

      if (!id) {
        setError('ID Inspeksi tidak ditemukan dalam parameter URL.');
        setIsLoading(false);
        return;
      }
      try {
        // Fetch User Session
        const sessionRes = await fetch('/api/auth/session');
        if (sessionRes.status === 401) {
          router.push('/login');
          return;
        }
        if (sessionRes.ok) {
          const sessionData = await sessionRes.json();
          setCurrentUser(sessionData.user || null);
        }

        // Fetch Locations Master Data
        const locRes = await fetch('/api/locations');
        if (locRes.ok) {
          const locData: { success: boolean; data: Location[] } = await locRes.json();
          setLocations(locData.data || []);
        }

        // Fetch Inspection Detail
        const inspectionRes = await fetch(`/api/inspections/${id}`);
        if (inspectionRes.status === 401) {
          router.push('/login');
          return;
        }
        if (inspectionRes.status === 404) {
          setError('Data inspeksi tidak ditemukan.');
          setIsLoading(false);
          return;
        }
        if (!inspectionRes.ok) {
          const errorData = await inspectionRes.json().catch(() => ({}));
          setError(errorData.error || errorData.message || 'Gagal memuat detail data inspeksi.');
          setIsLoading(false);
          return;
        }
        const result: { success: boolean; data: InspectionData } =
          await inspectionRes.json();
        const data = result.data;
        if (!data) {
          setError('Respons detail inspeksi tidak berisi data.');
          setIsLoading(false);
          return;
        }
        setDate(
          typeof data.date === 'string' ? data.date.split('T')[0] : ''
        );
        setShift(data.shift);
        setLocationId(data.locationId);
        setCheckPersonel(data.checkPersonel);
        setCheckRuangan(data.checkRuangan);
        setCheckPeralatan(data.checkPeralatan);
        setKetPersonel(data.ketPersonel || '');
        setKetRuangan(data.ketRuangan || '');
        setKetPeralatan(data.ketPeralatan || '');
        setCurrentStatus(data.status);

      } catch (err) {
        setError('Terjadi kesalahan sistem saat memuat data.');
      } finally {
        setIsLoading(false);
      }
    };
    initData();
  }, [router]);

  // Handler Buka Modal Re-login
  const handleOpenAuthModal = () => {
    setReloginUsername('');
    setReloginPassword('');
    setReloginError(null);
    setIsAuthModalOpen(true);
  };

  // Handler Verifikasi Re-login & Minta Otorisasi Revisi ke Backend
  const handleAuthSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!reloginUsername.trim() || !reloginPassword) {
      setReloginError('Username dan password wajib diisi untuk otorisasi.');
      return;
    }
    setIsVerifyingAuth(true);
    setReloginError(null);
    try {
      // Step 1: Re-login Credential Verification
      const reloginRes = await fetch('/api/auth/relogin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username: reloginUsername.trim(),
          password: reloginPassword,
        }),
      });
      if (!reloginRes.ok) {
        const errData = await reloginRes.json().catch(() => ({}));
        setReloginError(
          errData.message || 'Kredensial re-login tidak valid.'
        );
        setIsVerifyingAuth(false);
        return;
      }

      // Step 2: Request Revision Authorization to Backend
      const revisionRes = await fetch(
        `/api/inspections/${inspectionId}/revision`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            password: reloginPassword,
          }),
        }
      );
      if (!revisionRes.ok) {
        const errData = await revisionRes.json().catch(() => ({}));
        setReloginError(
          errData.message || 'Anda tidak memiliki hak otorisasi untuk melakukan revisi.'
        );
        setIsVerifyingAuth(false);
        return;
      }

      // Authorization granted
      setIsAuthorizedForEdit(true);
      setIsAuthModalOpen(false);
      setReloginPassword('');
    } catch (err) {
      setReloginError(
        'Terjadi kesalahan koneksi saat memverifikasi otorisasi.'
      );
    } finally {
      setIsVerifyingAuth(false);
    }
  };

  // Client Validation Logic
  const validateForm = (): boolean => {
    const errors: Record<string, string> = {};
    if (!locationId) errors.locationId = 'Lokasi wajib dipilih.';
    if (!shift) errors.shift = 'Shift wajib dipilih.';
    if (!checkPersonel) errors.checkPersonel = 'Status kebersihan personel wajib dipilih.';
    if (!checkRuangan) errors.checkRuangan = 'Status kebersihan ruangan wajib dipilih.';
    if (!checkPeralatan) errors.checkPeralatan = 'Status kebersihan peralatan wajib dipilih.';

    if (checkPersonel === 'NOK' && !ketPersonel.trim()) {
      errors.ketPersonel = 'Keterangan wajib diisi jika status NOK.';
    }
    if (checkRuangan === 'NOK' && !ketRuangan.trim()) {
      errors.ketRuangan = 'Keterangan wajib diisi jika status NOK.';
    }
    if (checkPeralatan === 'NOK' && !ketPeralatan.trim()) {
      errors.ketPeralatan = 'Keterangan wajib diisi jika status NOK.';
    }

    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };

  // Handler Submit Form Edit Inspeksi (PUT Request)
  const handleSubmitForm = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!isAuthorizedForEdit) return;
    if (!validateForm()) return;

    setIsSubmitting(true);
    setError(null);

    const payload = {
      locationId,
      shift,
      checkPersonel,
      checkRuangan,
      checkPeralatan,
      ketPersonel: ketPersonel.trim() || undefined,
      ketRuangan: ketRuangan.trim() || undefined,
      ketPeralatan: ketPeralatan.trim() || undefined,
    };

    try {
      const res = await fetch(`/api/inspections/${inspectionId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      if (res.status === 401) {
        router.push('/login');
        return;
      }

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        setError(errData.message || 'Gagal menyimpan perubahan revisi inspeksi.');
        setIsSubmitting(false);
        return;
      }

      // Success -> Redirect to Inspection Report Page
      router.push('/report_inspeksi');
    } catch (err) {
      setError('Terjadi kesalahan sistem saat mengirimkan data perubahan.');
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <Suspense fallback={null}>
        <Sidebar />
      </Suspense>
      <div className="lg:ml-72 min-h-screen transition-all duration-300">
        <main className="p-4 sm:p-6 lg:p-8">
          {isLoading ? (
            <div className="flex items-center justify-center p-12">
              <p className="text-sm text-gray-500 font-medium">Memuat data inspeksi...</p>
            </div>
          ) : (
            <div className="w-full bg-white p-6 sm:p-8 rounded-2xl border border-slate-200/80 shadow-sm">
              {/* Header Bar */}
              <div className="pb-6 border-b border-slate-100">
                <div>
                  <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">Edit Form Inspeksi Kebersihan</h1>
                  <p className="text-sm text-slate-500 mt-1">
                    Perbarui rekaman inspeksi (Status akan kembali menjadi Menunggu Supervisor).
                  </p>
                </div>
              </div>

              {/* Banner Alert Failure/Error */}
              {error && (
                <div className="mt-6 bg-rose-50 border border-rose-200 text-rose-700 p-4 rounded-xl text-sm">
                  <p className="font-semibold">Validasi Gagal</p>
                  <p className="mt-1">{error}</p>
                </div>
              )}

              {/* Lock State Banner - Need Authorization */}
              {!isAuthorizedForEdit && (
                <div className="mt-6 bg-amber-50 border border-amber-200 p-4 rounded-xl text-amber-900 space-y-3">
                  <h2 className="font-bold text-sm">Otorisasi Edit Diperlukan</h2>
                  <p className="text-sm">
                    Data inspeksi ini berstatus <strong className="uppercase">{currentStatus}</strong>. Untuk dapat melakukan pengubahan data, diperlukan re-login akun Supervisor atau Administrator.
                  </p>
                  {currentUser?.role === 'staff' || currentUser?.role === 'manager' ? (
                    <p className="text-xs text-red-600 font-semibold italic">
                      Akses terbatas: akun ini hanya dapat memonitor data dan tidak dapat mengotorisasi perubahan.
                    </p>
                  ) : (
                    <button
                      type="button"
                      onClick={handleOpenAuthModal}
                      className="px-5 py-2.5 rounded-xl text-sm font-semibold text-white bg-amber-600 hover:bg-amber-700 focus:outline-none focus:ring-2 focus:ring-amber-500/20 transition-all shadow-sm"
                    >
                      Minta Otorisasi Revisi (Re-login)
                    </button>
                  )}
                </div>
              )}

              {/* Main Editable Form */}
              <div className="mt-6">
                <form onSubmit={handleSubmitForm} className="space-y-6">
                  {/* Field Read-only Info */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pb-2">
                    <div>
                      <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1.5">Tanggal Inspeksi</label>
                      <input
                        type="text"
                        value={date}
                        disabled
                        className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-slate-700 text-sm font-medium"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1.5">Status Dokumen Saat Ini</label>
                      <input
                        type="text"
                        value={
                          currentStatus === 'SUBMITTED'
                            ? 'Menunggu Supervisor'
                            : currentStatus === 'SUPERVISOR_APPROVED'
                            ? 'Approved oleh Supervisor'
                            : 'Approved / Final'
                        }
                        disabled
                        className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-slate-700 text-sm font-medium"
                      />
                    </div>
                  </div>

                  {/* Field Location & Shift */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1.5">Lokasi Area <span className="text-rose-500">*</span></label>
                      <select
                        value={locationId}
                        onChange={(e: ChangeEvent<HTMLSelectElement>) => setLocationId(e.target.value)}
                        disabled={!isAuthorizedForEdit || isSubmitting}
                        className="w-full rounded-xl border border-slate-300 bg-white px-3.5 py-2.5 text-slate-800 text-sm focus:border-sky-500 focus:ring-2 focus:ring-sky-500/20 focus:outline-none disabled:bg-slate-100 transition-all"
                      >
                        <option value="">-- Pilih Lokasi --</option>
                        {locations.map((loc) => (
                          <option key={loc.id} value={loc.id}>
                            {loc.name}
                          </option>
                        ))}
                      </select>
                      {validationErrors.locationId && (
                        <p className="mt-1 text-xs text-red-600">{validationErrors.locationId}</p>
                      )}
                    </div>
                    <div>
                      <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1.5">Shift <span className="text-rose-500">*</span></label>
                      <select
                        value={shift}
                        onChange={(e: ChangeEvent<HTMLSelectElement>) => setShift(e.target.value)}
                        disabled={!isAuthorizedForEdit || isSubmitting}
                        className="w-full rounded-xl border border-slate-300 bg-white px-3.5 py-2.5 text-slate-800 text-sm focus:border-sky-500 focus:ring-2 focus:ring-sky-500/20 focus:outline-none disabled:bg-slate-100 transition-all"
                      >
                        <option value="1">Shift 1</option>
                        <option value="2">Shift 2</option>
                        <option value="3">Shift 3</option>
                      </select>
                      {validationErrors.shift && (
                        <p className="mt-1 text-xs text-red-600">{validationErrors.shift}</p>
                      )}
                    </div>
                  </div>

                  {/* Checklist Section */}
                  <div className="space-y-4 pt-2">
                    <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider border-b border-slate-100 pb-3">
                      Pemeriksaan Kebersihan
                    </h3>

                    {/* 1. Personel */}
                    <div className="p-4 sm:p-5 rounded-2xl border border-slate-200/80 bg-slate-50/50 space-y-3">
                      <div className="space-y-3">
                        <label className="text-sm font-semibold text-slate-800">1. Kebersihan Personel <span className="text-rose-500">*</span></label>
                        <div className="grid grid-cols-2 gap-3 w-full sm:max-w-md">
                          {(['OK', 'NOK'] as const).map((value) => (
                            <label key={value} className={`flex items-center justify-center gap-2 p-2.5 rounded-xl border text-sm font-semibold cursor-pointer transition-all ${checkPersonel === value ? (value === 'OK' ? 'bg-emerald-50 border-emerald-500 text-emerald-700 shadow-sm' : 'bg-rose-50 border-rose-500 text-rose-700 shadow-sm') : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'}`}>
                              <input type="radio" name="checkPersonel" value={value} checked={checkPersonel === value} onChange={() => { setCheckPersonel(value); if (value === 'OK') setKetPersonel(''); }} disabled={!isAuthorizedForEdit || isSubmitting} className="sr-only" />
                              <span>{value === 'OK' ? '✓ OK' : '✕ NOK (Not OK)'}</span>
                            </label>
                          ))}
                        </div>
                      </div>
                      {checkPersonel === 'NOK' && (
                        <div className="pt-2">
                          <label className="block text-xs font-semibold text-rose-700 mb-1">
                            Keterangan Personel (Wajib diisi bila NOK) *
                          </label>
                          <textarea
                            rows={2}
                            value={ketPersonel}
                            onChange={(e: ChangeEvent<HTMLTextAreaElement>) => setKetPersonel(e.target.value)}
                            disabled={!isAuthorizedForEdit || isSubmitting}
                            placeholder="Jelaskan alasan/penemuan NOK personel..."
                            className="w-full rounded-xl border border-rose-300 p-3 text-sm text-slate-800 focus:border-rose-500 focus:ring-2 focus:ring-rose-500/20 focus:outline-none disabled:bg-slate-100"
                          />
                          {validationErrors.ketPersonel && (
                            <p className="mt-1 text-xs text-red-600">{validationErrors.ketPersonel}</p>
                          )}
                        </div>
                      )}
                    </div>

                    {/* 2. Ruangan */}
                    <div className="p-4 sm:p-5 rounded-2xl border border-slate-200/80 bg-slate-50/50 space-y-3">
                      <div className="space-y-3">
                        <label className="text-sm font-semibold text-slate-800">2. Kebersihan Ruangan <span className="text-rose-500">*</span></label>
                        <div className="grid grid-cols-2 gap-3 w-full sm:max-w-md">
                          {(['OK', 'NOK'] as const).map((value) => (
                            <label key={value} className={`flex items-center justify-center gap-2 p-2.5 rounded-xl border text-sm font-semibold cursor-pointer transition-all ${checkRuangan === value ? (value === 'OK' ? 'bg-emerald-50 border-emerald-500 text-emerald-700 shadow-sm' : 'bg-rose-50 border-rose-500 text-rose-700 shadow-sm') : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'}`}>
                              <input type="radio" name="checkRuangan" value={value} checked={checkRuangan === value} onChange={() => { setCheckRuangan(value); if (value === 'OK') setKetRuangan(''); }} disabled={!isAuthorizedForEdit || isSubmitting} className="sr-only" />
                              <span>{value === 'OK' ? '✓ OK' : '✕ NOK (Not OK)'}</span>
                            </label>
                          ))}
                        </div>
                      </div>
                      {checkRuangan === 'NOK' && (
                        <div className="pt-2">
                          <label className="block text-xs font-semibold text-rose-700 mb-1">
                            Keterangan Ruangan (Wajib diisi bila NOK) *
                          </label>
                          <textarea
                            rows={2}
                            value={ketRuangan}
                            onChange={(e: ChangeEvent<HTMLTextAreaElement>) => setKetRuangan(e.target.value)}
                            disabled={!isAuthorizedForEdit || isSubmitting}
                            placeholder="Jelaskan alasan/penemuan NOK ruangan..."
                            className="w-full rounded-xl border border-rose-300 p-3 text-sm text-slate-800 focus:border-rose-500 focus:ring-2 focus:ring-rose-500/20 focus:outline-none disabled:bg-slate-100"
                          />
                          {validationErrors.ketRuangan && (
                            <p className="mt-1 text-xs text-red-600">{validationErrors.ketRuangan}</p>
                          )}
                        </div>
                      )}
                    </div>

                    {/* 3. Peralatan */}
                    <div className="p-4 sm:p-5 rounded-2xl border border-slate-200/80 bg-slate-50/50 space-y-3">
                      <div className="space-y-3">
                        <label className="text-sm font-semibold text-slate-800">3. Kebersihan Peralatan <span className="text-rose-500">*</span></label>
                        <div className="grid grid-cols-2 gap-3 w-full sm:max-w-md">
                          {(['OK', 'NOK'] as const).map((value) => (
                            <label key={value} className={`flex items-center justify-center gap-2 p-2.5 rounded-xl border text-sm font-semibold cursor-pointer transition-all ${checkPeralatan === value ? (value === 'OK' ? 'bg-emerald-50 border-emerald-500 text-emerald-700 shadow-sm' : 'bg-rose-50 border-rose-500 text-rose-700 shadow-sm') : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'}`}>
                              <input type="radio" name="checkPeralatan" value={value} checked={checkPeralatan === value} onChange={() => { setCheckPeralatan(value); if (value === 'OK') setKetPeralatan(''); }} disabled={!isAuthorizedForEdit || isSubmitting} className="sr-only" />
                              <span>{value === 'OK' ? '✓ OK' : '✕ NOK (Not OK)'}</span>
                            </label>
                          ))}
                        </div>
                      </div>
                      {checkPeralatan === 'NOK' && (
                        <div className="pt-2">
                          <label className="block text-xs font-semibold text-rose-700 mb-1">
                            Keterangan Peralatan (Wajib diisi bila NOK) *
                          </label>
                          <textarea
                            rows={2}
                            value={ketPeralatan}
                            onChange={(e: ChangeEvent<HTMLTextAreaElement>) => setKetPeralatan(e.target.value)}
                            disabled={!isAuthorizedForEdit || isSubmitting}
                            placeholder="Jelaskan alasan/penemuan NOK peralatan..."
                            className="w-full rounded-xl border border-rose-300 p-3 text-sm text-slate-800 focus:border-rose-500 focus:ring-2 focus:ring-rose-500/20 focus:outline-none disabled:bg-slate-100"
                          />
                          {validationErrors.ketPeralatan && (
                            <p className="mt-1 text-xs text-red-600">{validationErrors.ketPeralatan}</p>
                          )}
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="pt-4 border-t border-gray-200 flex justify-end space-x-3">
                    <button
                      type="button"
                      onClick={() => router.push('/report_inspeksi')}
                      disabled={isSubmitting}
                      className="px-5 py-2.5 border border-slate-300 rounded-xl text-sm font-semibold text-slate-700 bg-white hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-sky-500/20 disabled:opacity-50 transition-all"
                    >
                      Batal
                    </button>
                    <button
                      type="submit"
                      disabled={!isAuthorizedForEdit || isSubmitting}
                      className="px-6 py-2.5 rounded-xl text-sm font-semibold text-white bg-sky-600 hover:bg-sky-700 focus:outline-none focus:ring-2 focus:ring-sky-500/20 disabled:bg-slate-300 transition-all shadow-sm"
                    >
                      {isSubmitting ? 'Menyimpan Revisi...' : 'Simpan Revisi Inspection'}
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}
        </main>
      </div>

      {/* Modal Re-login Otorisasi Revisi */}
      {isAuthModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg border border-gray-200 shadow-md max-w-md w-full p-6 space-y-4">
            <h3 className="text-lg font-bold text-slate-900 border-b border-slate-100 pb-3">
              Konfirmasi Otorisasi Revisi
            </h3>
            <p className="text-sm text-slate-500">
              Masukkan username dan password akun Supervisor atau Administrator untuk membuka akses edit.
            </p>
            {reloginError && (
              <div className="bg-red-50 border border-red-200 text-red-700 p-3 rounded text-xs">
                {reloginError}
              </div>
            )}
            <form onSubmit={handleAuthSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-gray-700">Username Otorisator</label>
                <input
                  type="text"
                  value={reloginUsername}
                  onChange={(e: ChangeEvent<HTMLInputElement>) => setReloginUsername(e.target.value)}
                  disabled={isVerifyingAuth}
                  className="w-full rounded-xl border border-slate-300 px-3.5 py-2.5 text-sm text-slate-800 focus:border-sky-500 focus:ring-2 focus:ring-sky-500/20 focus:outline-none disabled:bg-slate-100"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700">Password</label>
                <input
                  type="password"
                  value={reloginPassword}
                  onChange={(e: ChangeEvent<HTMLInputElement>) => setReloginPassword(e.target.value)}
                  disabled={isVerifyingAuth}
                  placeholder="Masukkan password Anda"
                  className="w-full rounded-xl border border-slate-300 px-3.5 py-2.5 text-sm text-slate-800 focus:border-sky-500 focus:ring-2 focus:ring-sky-500/20 focus:outline-none disabled:bg-slate-100"
                />
              </div>
              <div className="flex justify-end space-x-2 pt-2 border-t border-gray-200">
                <button
                  type="button"
                  onClick={() => setIsAuthModalOpen(false)}
                  disabled={isVerifyingAuth}
                  className="px-4 py-2.5 border border-slate-300 rounded-xl text-sm font-semibold text-slate-700 bg-white hover:bg-slate-50 transition-all disabled:opacity-50"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={isVerifyingAuth}
                  className="px-5 py-2.5 rounded-xl text-sm font-semibold text-white bg-sky-600 hover:bg-sky-700 transition-all disabled:bg-slate-300"
                >
                  {isVerifyingAuth ? 'Memverifikasi...' : 'Verifikasi & Edit'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}