'use client';

import React, { useState, useEffect, Suspense } from 'react';
import { useRouter } from 'next/navigation';
import Sidebar from '../sidebar';

interface UserSession {
  id: string;
  name: string;
  username: string;
  role: 'Administrator' | 'Manager' | 'Supervisor' | 'Staff' | string;
  department: string;
  site: string;
}

export default function DashboardPage() {
  const router = useRouter();

  // Session & UI States
  const [user, setUser] = useState<UserSession | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [isLoggingOut, setIsLoggingOut] = useState<boolean>(false);

  // Fetch Session from Backend API (Next.js Rewrite Proxy)
  useEffect(() => {
    const fetchSession = async () => {
      try {
        const response = await fetch('/api/auth/session', {
          method: 'GET',
          headers: { 'Content-Type': 'application/json' },
        });

        if (response.status === 401) {
          router.push('/login');
          return;
        }

        if (!response.ok) {
          setError('Gagal memverifikasi sesi pengguna. Silakan login kembali.');
          setIsLoading(false);
          return;
        }

        const data = await response.json();

        if (data && data.authenticated && data.user) {
          setUser(data.user);
        } else {
          router.push('/login');
          return;
        }
      } catch (err) {
        setError('Terjadi kesalahan koneksi saat memverifikasi sesi.');
      } finally {
        setIsLoading(false);
      }
    };

    fetchSession();
  }, [router]);

  // Logout Handler
  const handleLogout = async () => {
    setIsLoggingOut(true);
    try {
      const res = await fetch('/api/auth/logout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });

      if (res.ok || res.status === 401) {
        router.push('/login');
      } else {
        setError('Gagal melakukan logout dari server.');
        setIsLoggingOut(false);
      }
    } catch (err) {
      setError('Terjadi kesalahan koneksi saat melakukan logout.');
      setIsLoggingOut(false);
    }
  };

  // Error State Handling
  if (error) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm max-w-md w-full text-center space-y-4">
          <p className="text-base text-rose-600 font-medium">{error}</p>
          <button
            onClick={() => router.push('/login')}
            className="px-5 py-2.5 bg-sky-600 hover:bg-sky-700 text-white text-sm font-medium rounded-lg transition-colors"
          >
            Kembali ke Halaman Login
          </button>
        </div>
      </div>
    );
  }

  // Loading or Unauthenticated User State (Keeps Sidebar visible)
  if (isLoading || !user) {
    return (
      <div className="min-h-screen bg-slate-50/50">
        <Suspense fallback={null}>
          <Sidebar />
        </Suspense>

        <div className="lg:ml-72 min-h-screen transition-all duration-300">
          <main className="p-4 sm:p-6 lg:p-8">
            <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm">
              <p className="text-base text-slate-500 font-medium">
                Memuat dashboard...
              </p>
            </div>
          </main>
        </div>
      </div>
    );
  }

  const roleUpper = user.role.toUpperCase();

  return (
    <div className="min-h-screen bg-slate-50/50">
      {/* Sidebar Navigation */}
      <Suspense fallback={null}>
        <Sidebar />
      </Suspense>

      {/* Main Content Area */}
      <div className="lg:ml-72 min-h-screen transition-all duration-300">
        <main className="p-4 sm:p-6 lg:p-8 space-y-6">
          {/* Header Page */}
          <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200/80 shadow-sm">
            <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">Dashboard Utama</h1>
            <p className="text-base text-slate-600 mt-2">
              Selamat datang kembali, <span className="font-semibold text-slate-800">{user.name}</span>
            </p>
          </div>

          {/* Role-Aware Menu Grid Section */}
          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {/* STAFF MENUS */}
              {(roleUpper === 'STAFF' || roleUpper === 'ADMINISTRATOR') && (
                <>
                  <div
                    onClick={() => router.push('/selectlokasi')}
                    className="group relative bg-white p-6 sm:p-7 rounded-2xl border border-slate-200/80 shadow-sm hover:shadow-md hover:border-sky-500 hover:-translate-y-1 cursor-pointer transition-all duration-200 flex flex-col justify-between"
                  >
                    <div>
                      <div className="w-12 h-12 rounded-xl bg-sky-50 text-sky-600 flex items-center justify-center mb-5 group-hover:bg-sky-600 group-hover:text-white transition-colors duration-200">
                        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" />
                        </svg>
                      </div>
                      <h3 className="font-bold text-slate-900 text-lg group-hover:text-sky-600 transition-colors">
                        Input Inspection
                      </h3>
                      <p className="text-sm text-slate-600 mt-2 leading-relaxed">
                        Pilih lokasi dan isi entri formulir inspeksi kebersihan baru.
                      </p>
                    </div>
                    <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between text-sm font-semibold text-sky-600">
                      <span>Buka Form</span>
                      <span className="transform group-hover:translate-x-1 transition-transform text-base">→</span>
                    </div>
                  </div>

                  <div
                    onClick={() => router.push('/selectlokasi?next=keterangan')}
                    className="hidden"
                  >
                    <div>
                      <div className="w-12 h-12 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center mb-5 group-hover:bg-amber-500 group-hover:text-white transition-colors duration-200">
                        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                      </div>
                      <h3 className="font-bold text-slate-900 text-lg group-hover:text-amber-600 transition-colors">
                        Entry Terlewat
                      </h3>
                      <p className="text-sm text-slate-600 mt-2 leading-relaxed">
                        Pengajuan keterangan atau alasan untuk jadwal pengisian yang terlewat.
                      </p>
                    </div>
                    <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between text-sm font-semibold text-amber-600">
                      <span>Ajukan Alasan</span>
                      <span className="transform group-hover:translate-x-1 transition-transform text-base">→</span>
                    </div>
                  </div>
                </>
              )}

              {/* COMMON REPORT MENU (Available for all roles) */}
              <div
                onClick={() => router.push('/report_inspeksi')}
                className="group relative bg-white p-6 sm:p-7 rounded-2xl border border-slate-200/80 shadow-sm hover:shadow-md hover:border-indigo-500 hover:-translate-y-1 cursor-pointer transition-all duration-200 flex flex-col justify-between"
              >
                <div>
                  <div className="w-12 h-12 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center mb-5 group-hover:bg-indigo-600 group-hover:text-white transition-colors duration-200">
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                    </svg>
                  </div>
                  <h3 className="font-bold text-slate-900 text-lg group-hover:text-indigo-600 transition-colors">
                    {roleUpper === 'STAFF' ? 'Own Inspection Report' : 'Inspection Reports'}
                  </h3>
                  <p className="text-sm text-slate-600 mt-2 leading-relaxed">
                    Lihat daftar rekaman laporan inspeksi dan status persetujuan.
                  </p>
                </div>
                <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between text-sm font-semibold text-indigo-600">
                  <span>Lihat Laporan</span>
                  <span className="transform group-hover:translate-x-1 transition-transform text-base">→</span>
                </div>
              </div>

              {/* SUPERVISOR & MANAGER APPROVAL MENUS */}
              {(roleUpper === 'SUPERVISOR' || roleUpper === 'MANAGER' || roleUpper === 'ADMINISTRATOR') && (
                <div
                  onClick={() => router.push('/validasi_inspeksi')}
                  className="group relative bg-white p-6 sm:p-7 rounded-2xl border border-slate-200/80 shadow-sm hover:shadow-md hover:border-emerald-500 hover:-translate-y-1 cursor-pointer transition-all duration-200 flex flex-col justify-between"
                >
                  <div>
                    <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center mb-5 group-hover:bg-emerald-600 group-hover:text-white transition-colors duration-200">
                      <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                    </div>
                    <h3 className="font-bold text-slate-900 text-lg group-hover:text-emerald-600 transition-colors">
                      {roleUpper === 'MANAGER' ? 'Monitoring Validasi' : 'Validasi & Approval'}
                    </h3>
                    <p className="text-sm text-slate-600 mt-2 leading-relaxed">
                      {roleUpper === 'SUPERVISOR' && 'Proses verifikasi dokumen berstatus SUBMITTED.'}
                      {roleUpper === 'MANAGER' && 'Monitoring status inspeksi yang telah diverifikasi Supervisor.'}
                      {roleUpper === 'ADMINISTRATOR' && 'Kelola alur verifikasi approval dokumen inspeksi.'}
                    </p>
                  </div>
                  <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between text-sm font-semibold text-emerald-600">
                    <span>{roleUpper === 'MANAGER' ? 'Lihat Monitoring' : 'Proses Approval'}</span>
                    <span className="transform group-hover:translate-x-1 transition-transform text-base">→</span>
                  </div>
                </div>
              )}

              {/* AUDIT TRAIL MENU (Supervisor, Manager, Administrator) */}
              {(roleUpper === 'SUPERVISOR' || roleUpper === 'MANAGER' || roleUpper === 'ADMINISTRATOR') && (
                <div
                  onClick={() => router.push('/audit_trail')}
                  className="group relative bg-white p-6 sm:p-7 rounded-2xl border border-slate-200/80 shadow-sm hover:shadow-md hover:border-slate-700 hover:-translate-y-1 cursor-pointer transition-all duration-200 flex flex-col justify-between"
                >
                  <div>
                    <div className="w-12 h-12 rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center mb-5 group-hover:bg-slate-800 group-hover:text-white transition-colors duration-200">
                      <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                      </svg>
                    </div>
                    <h3 className="font-bold text-slate-900 text-lg group-hover:text-slate-800 transition-colors">
                      Audit Trail System
                    </h3>
                    <p className="text-sm text-slate-600 mt-2 leading-relaxed">
                      Melihat log imutabel perubahan data, waktu, dan riwayat user.
                    </p>
                  </div>
                  <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between text-sm font-semibold text-slate-700">
                    <span>Cek Log System</span>
                    <span className="transform group-hover:translate-x-1 transition-transform text-base">→</span>
                  </div>
                </div>
              )}

              {/* ADMINISTRATOR EXCLUSIVE MENUS */}
              {roleUpper === 'ADMINISTRATOR' && (
                <div
                  onClick={() => router.push('/users')}
                  className="group relative bg-white p-6 sm:p-7 rounded-2xl border border-slate-200/80 shadow-sm hover:shadow-md hover:border-rose-500 hover:-translate-y-1 cursor-pointer transition-all duration-200 flex flex-col justify-between"
                >
                  <div>
                    <div className="w-12 h-12 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center mb-5 group-hover:bg-rose-600 group-hover:text-white transition-colors duration-200">
                      <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
                      </svg>
                    </div>
                    <h3 className="font-bold text-slate-900 text-lg group-hover:text-rose-600 transition-colors">
                      User Management
                    </h3>
                    <p className="text-sm text-slate-600 mt-2 leading-relaxed">
                      Kelola akun pengguna, penugasan role, department, dan status akun.
                    </p>
                  </div>
                  <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between text-sm font-semibold text-rose-600">
                    <span>Kelola Pengguna</span>
                    <span className="transform group-hover:translate-x-1 transition-transform text-base">→</span>
                  </div>
                </div>
              )}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}