'use client';
import React, { Suspense, useState, useEffect, useMemo, ChangeEvent } from 'react';
import { useRouter } from 'next/navigation';
import Sidebar from '../sidebar';

interface Location {
  id: string;
  name: string;
  code?: string;
}

interface InspectionRecord {
  id: string;
  date: string;
  createdAt?: string;
  lastEditedAt?: string;
  lastEditedByUsername?: string;
  createdByUsername?: string;
  editCount?: number;
  shift: string;
  locationId: string;
  locationName: string;
  checkPersonel: string;
  checkRuangan: string;
  checkPeralatan: string;
  ketPersonel?: string;
  ketRuangan?: string;
  ketPeralatan?: string;
  missedEntry?: boolean;
  missedReason?: string;
  status: 'SUBMITTED' | 'SUPERVISOR_APPROVED' | 'APPROVED';
  staffName?: string;
  supervisorName?: string;
}

type SortOrder = 'newest' | 'oldest';

const SHIFT_START_TIMES: Record<string, string> = {
  '1': '06:45:00',
  '2': '15:15:00',
  '3': '22:30:00',
};

function getReportTimestamp(record: InspectionRecord): number {
  if (!record.missedEntry && record.createdAt) {
    const createdAt = new Date(record.createdAt).getTime();
    if (!Number.isNaN(createdAt)) {
      return createdAt;
    }
  }

  const date = record.date.slice(0, 10);
  const shiftStart = SHIFT_START_TIMES[record.shift] || '00:00:00';
  const timestamp = Date.parse(`${date}T${shiftStart}+07:00`);
  return Number.isNaN(timestamp) ? 0 : timestamp;
}

function sortReportRecords(records: InspectionRecord[], sortOrder: SortOrder): InspectionRecord[] {
  return [...records].sort((a, b) => {
    const timeDifference = getReportTimestamp(a) - getReportTimestamp(b);
    if (timeDifference !== 0) {
      return sortOrder === 'newest' ? -timeDifference : timeDifference;
    }
    return sortOrder === 'newest'
      ? b.id.localeCompare(a.id)
      : a.id.localeCompare(b.id);
  });
}

export default function ReportInspeksiPage() {
  const router = useRouter();

  // Session & Master Data
  const [locations, setLocations] = useState<Location[]>([]);

  // Filter States
  const [selectedMonth, setSelectedMonth] = useState<string>(
    (new Date().getMonth() + 1).toString()
  );
  const [selectedYear, setSelectedYear] = useState<string>(
    new Date().getFullYear().toString()
  );
  const [selectedLocation, setSelectedLocation] = useState<string>('');
  const [sortOrder, setSortOrder] = useState<SortOrder>('newest');

  // Data States
  const [records, setRecords] = useState<InspectionRecord[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // Pagination States
  const [currentPage, setCurrentPage] = useState<number>(1);
  const itemsPerPage = 50;
  const sortedRecords = useMemo(
    () => sortReportRecords(records, sortOrder),
    [records, sortOrder],
  );

  // Load Initial Data (Session & Master Locations)
  useEffect(() => {
    const initializePage = async () => {
      try {
        // Get Session User Info
        const sessionRes = await fetch('/api/auth/session');
        if (sessionRes.status === 401) {
          router.push('/login');
          return;
        }
        if (sessionRes.ok) {
          await sessionRes.json();
        }

        // Get Locations
        const locRes = await fetch('/api/locations');
        if (locRes.ok) {
          const locData: { success: boolean; data: Location[] } = await locRes.json();
          setLocations(locData.data || []);
        }
      } catch (err) {
        // Session or master data fetch error
      }
    };
    initializePage();
  }, [router]);

  // Fetch Inspections List based on Filters
  const fetchReportData = async (
    month = selectedMonth,
    year = selectedYear,
    location = selectedLocation,
  ) => {
    setIsLoading(true);
    setError(null);
    const queryParams = new URLSearchParams({
      month,
      year,
      ...(location && { locationId: location }),
    });

    try {
      const response = await fetch(`/api/reports/inspections?${queryParams.toString()}`, {
        method: 'GET',
        cache: 'no-store',
        headers: { 'Content-Type': 'application/json' },
      });

      if (response.status === 401) {
        router.push('/login');
        return;
      }

      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        setError(errData.message || 'Gagal mengambil data laporan inspeksi.');
        setIsLoading(false);
        return;
      }

      const responseData = await response.json();
      const data: InspectionRecord[] = Array.isArray(responseData)
        ? responseData
        : Array.isArray(responseData.data)
        ? responseData.data
        : [];

      setRecords(data);
      setCurrentPage(1); // Reset ke halaman 1 tiap kali data baru dimuat
    } catch (err) {
      setError('Terjadi kesalahan koneksi saat memuat laporan.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const requestedMonth = params.get('month') || '';
    const requestedYear = params.get('year') || '';
    const requestedLocation = params.get('locationId') || '';
    const requestedSortOrder = params.get('sortOrder') === 'oldest' ? 'oldest' : 'newest';
    const month = /^\d{1,2}$/.test(requestedMonth) && Number(requestedMonth) >= 1 && Number(requestedMonth) <= 12
      ? String(Number(requestedMonth))
      : selectedMonth;
    const year = /^\d{4}$/.test(requestedYear) ? requestedYear : selectedYear;

    setSelectedMonth(month);
    setSelectedYear(year);
    setSelectedLocation(requestedLocation);
    setSortOrder(requestedSortOrder);
    fetchReportData(month, year, requestedLocation);
  }, []);

  // Logic Pagination Calculation
  const totalPages = Math.ceil(sortedRecords.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const paginatedRecords = sortedRecords.slice(startIndex, endIndex);

  const handlePageChange = (newPage: number) => {
    if (newPage >= 1 && newPage <= totalPages) {
      setCurrentPage(newPage);
    }
  };

  // PDF Export Trigger
  const handlePrintPDF = () => {
    const queryParams = new URLSearchParams({
      month: selectedMonth,
      year: selectedYear,
      _: Date.now().toString(),
      ...(selectedLocation && { locationId: selectedLocation }),
    });
    // Redirect / Direct browser open PDF endpoint
    window.open(`/api/reports/inspections/pdf?${queryParams.toString()}`, '_blank');
  };

  const formatReportDate = (date: string, shift: string, missedEntry: boolean, createdAt?: string) => {
    const dateValue = new Date(`${date.slice(0, 10)}T12:00:00Z`);
    const datePart = new Intl.DateTimeFormat('id-ID', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      timeZone: 'Asia/Jakarta',
    }).format(dateValue);
    const shiftStart = missedEntry
      ? ({ '1': '06:45:00', '2': '15:15:00', '3': '22:30:00' }[shift] || '')
      : '';
    const submittedTime = createdAt
      ? new Intl.DateTimeFormat('en-GB', {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
          hourCycle: 'h23',
          timeZone: 'Asia/Jakarta',
        }).format(new Date(createdAt))
      : '';
    const timePart = shiftStart || submittedTime;

    return timePart ? `${datePart} ${timePart}` : datePart;
  };

  const formatSubmitDate = (record: InspectionRecord) => {
    const editCount = record.editCount || 0;
    const timestamp = editCount > 0 && record.lastEditedAt
      ? record.lastEditedAt
      : record.createdAt;
    if (!timestamp) return '-';

    const submittedAt = new Date(timestamp);
    const datePart = new Intl.DateTimeFormat('id-ID', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      timeZone: 'Asia/Jakarta',
    }).format(submittedAt);
    const timePart = new Intl.DateTimeFormat('en-GB', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hourCycle: 'h23',
      timeZone: 'Asia/Jakarta',
    }).format(submittedAt);
    const by = editCount > 0
      ? record.lastEditedByUsername
      : record.staffName || record.createdByUsername;

    return `${datePart} ${timePart} by ${by || '-'}${editCount > 0 ? ` (edited ${editCount}x)` : ''}`;
  };

  // Helper Badge Render Status
  const renderStatusBadge = (status: InspectionRecord['status']) => {
    switch (status) {
      case 'SUBMITTED':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-sm font-medium bg-amber-50 text-amber-800 border border-amber-200">
            Menunggu Supervisor
          </span>
        );
      case 'SUPERVISOR_APPROVED':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-sm font-medium bg-sky-50 text-sky-800 border border-sky-200">
            Approved oleh Supervisor
          </span>
        );
      case 'APPROVED':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-sm font-medium bg-emerald-50 text-emerald-800 border border-emerald-200">
            Approved / Final
          </span>
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col">
      {/* Sidebar Navigation Global */}
      <Suspense fallback={null}>
        <Sidebar />
      </Suspense>

      {/* Main Content Area */}
      <div className="lg:ml-72 flex-1 flex flex-col min-w-0">
        <main className="w-full p-4 sm:p-6 lg:p-8 space-y-6">
          {/* Header Halaman */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-5">
            <div>
              <h1 className="text-2xl font-bold tracking-tight text-slate-900">
                Laporan Inspeksi Kebersihan
              </h1>
              <p className="text-sm text-slate-500 mt-1">
                Monitoring rekapan inspeksi kebersihan area operasional.
              </p>
            </div>
          </div>

          {/* Panel Filter Data */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-5 transition-all">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 items-end">
              <div>
                <label className="block text-sm font-semibold uppercase tracking-wider text-slate-500 mb-1.5">
                  Bulan
                </label>
                <select
                  value={selectedMonth}
                  onChange={(e: ChangeEvent<HTMLSelectElement>) => {
                    const month = e.target.value;
                    setSelectedMonth(month);
                    fetchReportData(month, selectedYear, selectedLocation);
                  }}
                  className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-800 shadow-xs focus:border-sky-500 focus:ring-2 focus:ring-sky-500/20 focus:outline-none transition"
                >
                  {Array.from({ length: 12 }, (_, i) => i + 1).map((m) => (
                    <option key={m} value={m}>
                      {new Date(2026, m - 1, 1).toLocaleString('id-ID', { month: 'long' })}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold uppercase tracking-wider text-slate-500 mb-1.5">
                  Tahun
                </label>
                <select
                  value={selectedYear}
                  onChange={(e: ChangeEvent<HTMLSelectElement>) => {
                    const year = e.target.value;
                    setSelectedYear(year);
                    fetchReportData(selectedMonth, year, selectedLocation);
                  }}
                  className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-800 shadow-xs focus:border-sky-500 focus:ring-2 focus:ring-sky-500/20 focus:outline-none transition"
                >
                  {['2024', '2025', '2026', '2027'].map((y) => (
                    <option key={y} value={y}>
                      {y}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold uppercase tracking-wider text-slate-500 mb-1.5">
                  Lokasi
                </label>
                <select
                  value={selectedLocation}
                  onChange={(e: ChangeEvent<HTMLSelectElement>) => {
                    const location = e.target.value;
                    setSelectedLocation(location);
                    fetchReportData(selectedMonth, selectedYear, location);
                  }}
                  className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-800 shadow-xs focus:border-sky-500 focus:ring-2 focus:ring-sky-500/20 focus:outline-none transition"
                >
                  <option value="">-- Semua Lokasi --</option>
                  {locations.map((loc) => (
                    <option key={loc.id} value={loc.id}>
                      {loc.name}
                    </option>
                  ))}
                </select>
              </div>

            </div>
            <div className="mt-4 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
              <div className="w-full sm:max-w-[calc((100%-2rem)/3)]">
                <label className="block text-sm font-semibold uppercase tracking-wider text-slate-500 mb-1.5">
                  Urutan Data
                </label>
                <select
                  value={sortOrder}
                  onChange={(e: ChangeEvent<HTMLSelectElement>) => {
                    setSortOrder(e.target.value as SortOrder);
                    setCurrentPage(1);
                  }}
                  className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-800 shadow-xs focus:border-sky-500 focus:ring-2 focus:ring-sky-500/20 focus:outline-none transition"
                >
                  <option value="newest">Data Terbaru</option>
                  <option value="oldest">Data Terlama</option>
                </select>
              </div>
              <button
                type="button"
                onClick={handlePrintPDF}
                disabled={isLoading || records.length === 0}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-900 active:bg-slate-950 text-white font-medium text-sm rounded-lg shadow-xs transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Cetak PDF
              </button>
            </div>
          </div>

          {/* Notifikasi Error */}
          {error && (
            <div className="bg-rose-50 border border-rose-200 text-rose-700 p-4 rounded-xl text-sm space-y-1">
              <p className="font-semibold">Terjadi Kesalahan</p>
              <p>{error}</p>
            </div>
          )}

          {/* Tabel Konten Laporan */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden flex flex-col">
            {isLoading ? (
              <div className="text-center py-16 space-y-2">
                <div className="inline-block h-6 w-6 animate-spin rounded-full border-2 border-slate-300 border-t-sky-600"></div>
                <p className="text-sm text-slate-500 font-medium">Memuat data laporan inspeksi...</p>
              </div>
            ) : records.length === 0 ? (
              <div className="text-center py-16 px-4">
                <p className="text-base font-medium text-slate-700">Data Tidak Ditemukan</p>
                <p className="text-sm text-slate-500 mt-1">Tidak ada data inspeksi yang sesuai dengan kriteria periode ini.</p>
              </div>
            ) : (
              <>
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse text-sm">
                    <thead>
                      <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold text-xs uppercase tracking-wider">
                        <th className="px-4 py-3">Tanggal / Shift</th>
                        <th className="px-4 py-3">Lokasi</th>
                        <th className="px-4 py-3">Hasil Checklist</th>
                        <th className="px-4 py-3">Submit Date</th>
                        <th className="px-4 py-3">Status</th>
                        <th className="px-4 py-3">Petugas & Verifikator</th>
                        <th className="px-4 py-3 text-right">Aksi</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 bg-white">
                      {paginatedRecords.map((rec) => (
                        <tr key={rec.id} className="hover:bg-slate-50/80 transition-colors">
                          <td className="px-4 py-3 whitespace-nowrap">
                            <div className="font-semibold text-slate-900">
                              {formatReportDate(rec.date, rec.shift, Boolean(rec.missedEntry), rec.createdAt)}
                            </div>
                            <div className="text-sm text-slate-500 mt-0.5">Shift {rec.shift}</div>
                          </td>
                          <td className="px-4 py-3 whitespace-nowrap font-medium text-slate-800">
                            {rec.locationName || locations.find((loc) => loc.id === rec.locationId)?.name || '-'}
                          </td>
                          <td className="px-4 py-3">
                            <div className="space-y-1 text-sm">
                              <div className="flex items-center gap-1">
                                <span className="text-slate-500 w-16">Personel:</span>
                                <span className={rec.checkPersonel === 'NOK' ? 'text-rose-600 font-bold' : 'text-emerald-600 font-medium'}>
                                  {rec.missedEntry ? `- (${rec.missedReason || 'Entry Terlewat'})` : rec.checkPersonel || '-'}
                                </span>
                                {rec.ketPersonel && <span className="font-medium text-slate-700">({rec.ketPersonel})</span>}
                              </div>
                              <div className="flex items-center gap-1">
                                <span className="text-slate-500 w-16">Ruangan:</span>
                                <span className={rec.checkRuangan === 'NOK' ? 'text-rose-600 font-bold' : 'text-emerald-600 font-medium'}>
                                  {rec.missedEntry ? `- (${rec.missedReason || 'Entry Terlewat'})` : rec.checkRuangan || '-'}
                                </span>
                                {rec.ketRuangan && <span className="font-medium text-slate-700">({rec.ketRuangan})</span>}
                              </div>
                              <div className="flex items-center gap-1">
                                <span className="text-slate-500 w-16">Peralatan:</span>
                                <span className={rec.checkPeralatan === 'NOK' ? 'text-rose-600 font-bold' : 'text-emerald-600 font-medium'}>
                                  {rec.missedEntry ? `- (${rec.missedReason || 'Entry Terlewat'})` : rec.checkPeralatan || '-'}
                                </span>
                                {rec.ketPeralatan && <span className="font-medium text-slate-700">({rec.ketPeralatan})</span>}
                              </div>
                            </div>
                          </td>
                          <td className="px-4 py-3 text-sm text-slate-700 [overflow-wrap:anywhere]">
                            {formatSubmitDate(rec)}
                          </td>
                          <td className="px-4 py-3 whitespace-nowrap">
                            {renderStatusBadge(rec.status)}
                          </td>
                          <td className="px-4 py-3 text-sm text-slate-600 [overflow-wrap:anywhere]">
                            <div className="space-y-0.5">
                              <div><span className="text-slate-400">Staff:</span> {rec.staffName || '-'}</div>
                              <div><span className="text-slate-400">SPV:</span> {rec.supervisorName || '-'}</div>
                            </div>
                          </td>
                          <td className="px-4 py-3 whitespace-nowrap text-right">
                            <div className="flex items-center justify-end gap-2">
                              <button
                                onClick={() => router.push(`/edit?id=${rec.id}`)}
                                className="px-3 py-1.5 text-sm font-medium bg-amber-600 hover:bg-amber-700 text-white rounded-md shadow-xs transition-colors"
                              >
                                Edit
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Pagination Controls Component */}
                {records.length > 0 && (
                  <div className="px-5 py-4 border-t border-slate-200 bg-slate-50 flex flex-col sm:flex-row items-center justify-between gap-4">
                    <div className="text-sm text-slate-600">
                      Menampilkan <span className="font-semibold text-slate-900">{startIndex + 1}</span> -{' '}
                      <span className="font-semibold text-slate-900">{Math.min(endIndex, records.length)}</span> dari{' '}
                      <span className="font-semibold text-slate-900">{records.length}</span> total data
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handlePageChange(currentPage - 1)}
                        disabled={currentPage === 1}
                        className="px-3 py-1.5 text-sm font-medium rounded-lg border border-slate-300 bg-white text-slate-700 hover:bg-slate-50 disabled:opacity-50 disabled:cursor-not-allowed shadow-xs transition-colors"
                      >
                        Previous
                      </button>
                      <div className="flex items-center gap-1">
                        {Array.from({ length: totalPages }, (_, i) => i + 1)
                          .filter((page) => page === 1 || page === totalPages || Math.abs(page - currentPage) <= 1)
                          .map((page, idx, array) => {
                            const showEllipsis = idx > 0 && page - array[idx - 1] > 1;
                            return (
                              <React.Fragment key={page}>
                                {showEllipsis && <span className="px-1 text-slate-400 text-sm">...</span>}
                                <button
                                  onClick={() => handlePageChange(page)}
                                  className={`px-3 py-1.5 text-sm font-medium rounded-lg transition-colors ${
                                    currentPage === page
                                      ? 'bg-sky-600 text-white shadow-xs'
                                      : 'border border-slate-300 bg-white text-slate-700 hover:bg-slate-50'
                                  }`}
                                >
                                  {page}
                                </button>
                              </React.Fragment>
                            );
                          })}
                      </div>
                      <button
                        onClick={() => handlePageChange(currentPage + 1)}
                        disabled={currentPage === totalPages || totalPages === 0}
                        className="px-3 py-1.5 text-sm font-medium rounded-lg border border-slate-300 bg-white text-slate-700 hover:bg-slate-50 disabled:opacity-50 disabled:cursor-not-allowed shadow-xs transition-colors"
                      >
                        Next
                      </button>
                    </div>
                  </div>
                )}
              </>
            )}
          </div>
        </main>
      </div>

    </div>
  );
}