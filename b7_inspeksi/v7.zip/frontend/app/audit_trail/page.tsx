'use client';

import React, { useState, useEffect, ChangeEvent, Suspense } from 'react';
import { useRouter } from 'next/navigation';
import Sidebar from '../sidebar';

interface UserSession {
  id: string;
  name: string;
  username: string;
  role: string;
  department?: string;
  site?: string;
}

interface AuditLog {
  id: string;
  timestamp: string;
  username: string;
  fullName?: string;
  action: string;
  entityName?: string;
  entityId?: string;
  area?: string;
  description?: string;
  detail?: string;
  oldValue?: string;
  newValue?: string;
  ipAddress?: string;
}

type Location = {
  id: string;
  name: string;
};

export default function AuditTrailPage() {
  const router = useRouter();

  // Session State
  const [currentUser, setCurrentUser] = useState<UserSession | null>(null);

  // Filter States
  const [filterDate, setFilterDate] = useState<string>('');
  const [filterUser, setFilterUser] = useState<string>('');
  const [filterAction, setFilterAction] = useState<string>('');

  // Data & UI States
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [locations, setLocations] = useState<Location[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [unauthorized, setUnauthorized] = useState<boolean>(false);

  // Pagination States
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [totalPages, setTotalPages] = useState<number>(1);
  const [totalRows, setTotalRows] = useState<number>(0);
  const paginationItems = (() => {
    const pages = new Set<number>([1, totalPages]);
    for (let page = Math.max(1, currentPage - 1); page <= Math.min(totalPages, currentPage + 1); page += 1) {
      pages.add(page);
    }

    const sortedPages = [...pages].sort((a, b) => a - b);
    const items: Array<number | 'ellipsis'> = [];
    sortedPages.forEach((page, index) => {
      if (index > 0 && page - sortedPages[index - 1] > 1) {
        items.push('ellipsis');
      }
      items.push(page);
    });
    return items;
  })();

  // Initialize Session
  useEffect(() => {
    const initPage = async () => {
      try {
        const sessionRes = await fetch('/api/auth/session');
        if (sessionRes.status === 401) {
          router.push('/login');
          return;
        }

        if (sessionRes.ok) {
          const sessionData = await sessionRes.json();
          setCurrentUser(sessionData.user || null);
        }
      } catch (err) {
        // Fallthrough to fetch audit trail which will handle backend auth check
      }
    };

    initPage();
  }, [router]);

  // Fetch Locations Master Data
  const fetchLocations = async () => {
    try {
      const response = await fetch('/api/locations', {
        method: 'GET',
        headers: { 'Content-Type': 'application/json' },
      });

      if (!response.ok) return;

      const data = await response.json();

      setLocations(data.data || data || []);
    } catch {
      // Jika master lokasi gagal dimuat, audit tetap ditampilkan dengan ID lokasi
    }
  };

  useEffect(() => {
    fetchLocations();
  }, []);

  // Fetch Audit Logs from Backend
  const fetchAuditLogs = async (
    page = currentPage,
    filters = { date: filterDate, user: filterUser, action: filterAction }
  ) => {
    setIsLoading(true);
    setError(null);
    setUnauthorized(false);

    const queryParams = new URLSearchParams();
    queryParams.append('page', String(page));
    if (filters.date) queryParams.append('date', filters.date);
    if (filters.user.trim()) queryParams.append('user', filters.user.trim());
    if (filters.action) queryParams.append('action', filters.action);

    try {
      const response = await fetch(`/api/audit-trail?${queryParams.toString()}`, {
        method: 'GET',
        headers: { 'Content-Type': 'application/json' },
      });

      if (response.status === 401) {
        router.push('/login');
        return;
      }

      if (response.status === 403) {
        setUnauthorized(true);
        setIsLoading(false);
        return;
      }

      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        setError(errData.message || 'Gagal mengambil data audit log.');
        setIsLoading(false);
        return;
      }

      const data: {
        success: boolean;
        data: AuditLog[];
        pagination?: {
          page: number;
          limit: number;
          total: number;
          totalPages: number;
        };
      } = await response.json();

      const mappedLogs: AuditLog[] = (data.data || []).map((log: any) => ({
        ...log,
        username: log.username || log.user || '',
        fullName: log.fullName || '',
        description: log.description || log.detail || '',
        detail: log.detail || log.description || '',
      }));

      setLogs(mappedLogs);
      setTotalRows(data.pagination?.total || 0);
      setTotalPages(data.pagination?.totalPages || 1);
    } catch (err) {
      setError('Terjadi kesalahan koneksi saat memuat audit trail.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    const timeout = window.setTimeout(() => {
      fetchAuditLogs(currentPage);
    }, filterUser ? 300 : 0);

    return () => window.clearTimeout(timeout);
  }, [currentPage, filterDate, filterUser, filterAction]);

  const handleResetFilter = () => {
    setFilterDate('');
    setFilterUser('');
    setFilterAction('');
    setCurrentPage(1);
  };

  // Format timestamp agar mudah dibaca
  const formatTimestamp = (value?: string) => {
    if (!value) return '-';

    const date = new Date(value);

    if (Number.isNaN(date.getTime())) {
      return value;
    }

    const datePart = new Intl.DateTimeFormat('id-ID', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
    }).format(date);
    const timePart = new Intl.DateTimeFormat('en-GB', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hourCycle: 'h23',
    }).format(date);

    return `${datePart}, ${timePart}`;
  };

  // Safe renderer to mask any sensitive data if present
  const formatDetailValue = (val?: string) => {
    if (!val) return '-';

    if (
      val.toLowerCase().includes('password') ||
      val.toLowerCase().includes('token')
    ) {
      return '[REDACTED_SENSITIVE_DATA]';
    }

    return val;
  };

  // Bridge LOC-xxx -> Nama Lokasi
  const formatAuditDetail = (value?: string) => {
    const detail = formatDetailValue(value);

    if (detail === '-') return detail;

    const translatedDetail = detail
      .replace(/^Failed login attempt \((\d+)\/(\d+)\)$/, 'Percobaan login gagal ($1 dari $2)')
      .replace(/^Account automatically BLOCKED after reaching max failed attempts$/, 'Akun diblokir otomatis setelah mencapai batas maksimal percobaan login')
      .replace(/^Login successful$/, 'Login berhasil')
      .replace(/^Admin unlocked account for user (.+) \(([^)]+)\)$/, 'Administrator membuka blokir akun pengguna $1 (ID: $2)')
      .replace(/^User logged out$/, 'Pengguna keluar dari sistem')
      .replace(/^Created Inspection (.+) for location (.+)$/, 'Membuat laporan inspeksi $1 untuk mesin $2')
      .replace(/^Submitted Weekly Missed Entry for location (.+), week (.+) to (.+)\. Reason: (.+)$/, 'Mengirim Entry Terlewat Mingguan untuk mesin $1, minggu $2 sampai $3. Alasan: $4')
      .replace(/^Submitted Missed Shift (.+) for location (.+)\. Reason: (.+)$/, 'Mengirim Shift Terlewat $1 untuk mesin $2. Alasan: $3')
      .replace(/^Supervisor approval executed for Inspection ID: (.+)$/, 'Supervisor menyetujui laporan inspeksi dengan ID: $1')
      .replace(/^Authorized revision granted for Inspection ID: (.+)$/, 'Izin revisi diberikan untuk laporan inspeksi dengan ID: $1')
      .replace(/^Revision update executed on inspection (.+)$/, 'Revisi diterapkan pada laporan inspeksi $1')
      .replace(/^Created new user (.+) with role (.+)$/, 'Membuat pengguna baru $1 dengan peran $2')
      .replace(/^Updated user ID: (.+)$/, 'Memperbarui data pengguna dengan ID: $1')
      .replace(/^Deactivated user ID: (.+) \(Status set to INACTIVE\)$/, 'Menonaktifkan pengguna dengan ID: $1 (status: tidak aktif)')
      .replace(/^Failed re-login verification for approval$/, 'Verifikasi login ulang untuk persetujuan gagal')
      .replace(/^Successful re-login verification for approval$/, 'Verifikasi login ulang untuk persetujuan berhasil')
      .replace(/^Failed re-login verification for sensitive operation: (.+)$/, 'Verifikasi login ulang untuk tindakan sensitif gagal: $1')
      .replace(/^Successful re-login verification for sensitive operation: (.+)$/, 'Verifikasi login ulang untuk tindakan sensitif berhasil: $1')
      .replace(/^\[(.+)] Entity: (.+) \| EntityID: (.+)$/, (_, action: string, entity: string, entityId: string) => {
        const actionLabels: Record<string, string> = {
          LOGIN: 'Login',
          LOGIN_FAILED: 'Login gagal',
          LOGOUT: 'Keluar',
          ACCOUNT_BLOCKED: 'Akun diblokir',
          ACCOUNT_UNLOCKED: 'Blokir akun dibuka',
          CREATE_INSPECTION: 'Membuat laporan inspeksi',
          UPDATE_INSPECTION: 'Memperbarui laporan inspeksi',
          CREATE_MISSED_ENTRY: 'Mencatat entri terlewat',
          SUPERVISOR_APPROVAL: 'Persetujuan supervisor',
          MANAGER_APPROVAL: 'Persetujuan manajer',
          REVISION_AUTHORIZATION: 'Otorisasi revisi',
          CREATE_USER: 'Membuat pengguna',
          UPDATE_USER: 'Memperbarui pengguna',
          DEACTIVATE_USER: 'Menonaktifkan pengguna',
        };
        const entityLabels: Record<string, string> = {
          AUTHENTICATION: 'Autentikasi',
          INSPECTION: 'Inspeksi',
          USER: 'Pengguna',
          AUDIT: 'Audit',
        };
        return `${actionLabels[action] || action} | Jenis data: ${entityLabels[entity] || entity} | ID: ${entityId}`;
      })
      .replace(/\bBLOCKED\b/g, 'DIBLOKIR')
      .replace(/\bINACTIVE\b/g, 'TIDAK AKTIF');

    return translatedDetail.replace(/\bLOC-[A-Za-z0-9_-]+\b/g, (locationId) => {
      const location = locations.find(
        (item) => item.id.toLowerCase() === locationId.toLowerCase()
      );

      return location?.name || locationId;
    });
  };

  // Nama action yang tampil di UI
  const formatActionLabel = (action?: string) => {
    if (!action) return '-';

    const normalized = action.toUpperCase();

    if (normalized === 'AUTH_SECURITY') {
      return 'LOGIN / KEAMANAN';
    }

    const labels: Record<string, string> = {
      CREATE: 'BUAT',
      UPDATE: 'UBAH',
      DEACTIVATE: 'NONAKTIFKAN',
      APPROVAL: 'PERSETUJUAN',
      REVISION: 'REVISI',
    }

    return labels[normalized] || normalized;
  };

  // Helper Badge Render Action
  const renderActionBadge = (action: string) => {
    const actUpper = action.toUpperCase();
    const label = formatActionLabel(action);

    if (actUpper === 'AUTH_SECURITY') {
      return (
        <span className="inline-flex items-center rounded-md bg-purple-50 px-2 py-1 text-sm font-medium text-purple-700 ring-1 ring-inset ring-purple-600/20">
          {label}
        </span>
      );
    }

    if (actUpper === 'CREATE') {
      return (
        <span className="inline-flex items-center rounded-md bg-emerald-50 px-2 py-1 text-sm font-medium text-emerald-700 ring-1 ring-inset ring-emerald-600/20">
          {label}
        </span>
      );
    }

    if (actUpper === 'UPDATE') {
      return (
        <span className="inline-flex items-center rounded-md bg-sky-50 px-2 py-1 text-sm font-medium text-sky-700 ring-1 ring-inset ring-sky-600/20">
          {label}
        </span>
      );
    }

    if (actUpper === 'DEACTIVATE') {
      return (
        <span className="inline-flex items-center rounded-md bg-rose-50 px-2 py-1 text-sm font-medium text-rose-700 ring-1 ring-inset ring-rose-600/20">
          {label}
        </span>
      );
    }

    if (actUpper === 'APPROVAL') {
      return (
        <span className="inline-flex items-center rounded-md bg-amber-50 px-2 py-1 text-sm font-medium text-amber-700 ring-1 ring-inset ring-amber-600/20">
          {label}
        </span>
      );
    }

    if (actUpper === 'REVISION') {
      return (
        <span className="inline-flex items-center rounded-md bg-orange-50 px-2 py-1 text-sm font-medium text-orange-700 ring-1 ring-inset ring-orange-600/20">
          {label}
        </span>
      );
    }

    return (
      <span className="inline-flex items-center rounded-md bg-slate-100 px-2 py-1 text-sm font-medium text-slate-600 ring-1 ring-inset ring-slate-500/10">
        {label}
      </span>
    );
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <Suspense fallback={null}>
        <Sidebar />
      </Suspense>

      <main className="lg:ml-72 min-h-screen">
        <div className="w-full px-4 py-8 sm:px-6 lg:px-8 space-y-6">
          {/* Clean Page Header */}
          <div>
            <h1 className="text-2xl font-bold tracking-tight text-slate-900">Audit Trail</h1>
            <p className="text-sm text-slate-500 mt-1">
              Riwayat aktivitas dan transaksi pengguna.
            </p>
          </div>

          {/* Unauthorized View */}
          {unauthorized ? (
            <div className="rounded-xl bg-white p-12 border border-slate-200 shadow-sm text-center">
              <h2 className="text-base font-semibold text-rose-600">Akses Ditolak</h2>
              <p className="text-sm text-slate-500 mt-1">
                Anda tidak memiliki izin otorisasi untuk melihat catatan audit log sistem.
              </p>
            </div>
          ) : (
            <>
              {/* Compact Filter Card */}
              <div className="rounded-xl bg-white p-5 border border-slate-200 shadow-sm">
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4 items-end">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Tanggal</label>
                    <input
                      type="date"
                      value={filterDate}
                      onChange={(e: ChangeEvent<HTMLInputElement>) => {
                        setFilterDate(e.target.value);
                        setCurrentPage(1);
                      }}
                      className="block w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 shadow-sm focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">User / Username</label>
                    <input
                      type="text"
                      placeholder="Nama / Username..."
                      value={filterUser}
                      onChange={(e: ChangeEvent<HTMLInputElement>) => {
                        setFilterUser(e.target.value);
                        setCurrentPage(1);
                      }}
                      className="block w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 shadow-sm focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Jenis Action</label>
                    <select
                      value={filterAction}
                      onChange={(e: ChangeEvent<HTMLSelectElement>) => {
                        setFilterAction(e.target.value);
                        setCurrentPage(1);
                      }}
                      className="block w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 shadow-sm focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
                    >
                      <option value="">-- Semua Action --</option>
                      <option value="AUTH_SECURITY">Login / Keamanan</option>
                      <option value="CREATE">Buat</option>
                      <option value="UPDATE">Ubah</option>
                      <option value="DEACTIVATE">Nonaktifkan</option>
                      <option value="APPROVAL">Persetujuan</option>
                      <option value="REVISION">Revisi</option>
                    </select>
                  </div>

                  <div className="flex justify-end">
                    <button
                      type="button"
                      onClick={handleResetFilter}
                      disabled={isLoading}
                      className="rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-sm font-semibold text-slate-700 shadow-sm hover:bg-slate-50 disabled:opacity-50 transition-colors"
                    >
                      Reset
                    </button>
                  </div>
                </div>
              </div>

              {/* Error Notification */}
              {error && (
                <div className="rounded-xl bg-rose-50 border border-rose-200 p-4 text-sm text-rose-700">
                  <p className="font-semibold">Kesalahan</p>
                  <p className="mt-0.5">{error}</p>
                </div>
              )}

              {/* Table Data View */}
              <div className="rounded-xl border border-slate-200 bg-white shadow-sm overflow-hidden">
                {isLoading ? (
                  <div className="py-16 text-center">
                    <p className="text-sm text-slate-500">Memuat log audit trail...</p>
                  </div>
                ) : logs.length === 0 ? (
                  <div className="py-16 text-center">
                    <p className="text-sm text-slate-500">Tidak ada catatan audit ditemukan.</p>
                  </div>
                ) : (
                  <>
                    <div className="overflow-x-auto">
                      <table className="w-full min-w-[1000px] text-left text-[13px] border-collapse">
                        <thead>
                          <tr className="border-b border-slate-200 bg-slate-50 text-xs uppercase tracking-wider text-slate-600 font-semibold">
                            <th className="px-4 py-3.5 whitespace-nowrap">Waktu</th>
                            <th className="px-4 py-3.5 whitespace-nowrap">Pengguna</th>
                            <th className="px-4 py-3.5 whitespace-nowrap">Tindakan</th>
                            <th className="px-4 py-3.5 whitespace-nowrap">Alamat IP</th>
                            <th className="px-4 py-3.5 min-w-[420px]">Detail Aktivitas</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-200 text-slate-700">
                          {logs.map((log) => (
                            <tr key={log.id} className="hover:bg-slate-50/80 transition-colors">
                              <td className="px-4 py-3.5 whitespace-nowrap text-slate-600">
                                {formatTimestamp(log.timestamp)}
                              </td>

                              <td className="px-4 py-3.5 font-medium text-slate-900 [overflow-wrap:anywhere]">
                                {log.username || '-'}
                              </td>

                              <td className="px-4 py-3.5 whitespace-nowrap">
                                {renderActionBadge(log.action)}
                              </td>

                              <td className="px-4 py-3.5 whitespace-nowrap font-mono text-slate-600">
                                {log.ipAddress || '-'}
                              </td>

                              <td className="px-4 py-3.5 text-slate-800 leading-relaxed min-w-[420px]">
                                {formatAuditDetail(log.description || log.detail)}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>

                    {/* Clean Pagination Footer */}
                    <div className="flex flex-col sm:flex-row items-center justify-between border-t border-slate-200 bg-white px-4 py-3 gap-3">
                      <div className="text-sm text-slate-500">
                        Menampilkan maksimal 50 data per halaman
                        {totalRows > 0 && (
                          <> · Total <span className="font-medium text-slate-700">{totalRows}</span> aktivitas</>
                        )}
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          disabled={currentPage <= 1 || isLoading}
                          onClick={() => setCurrentPage((prev) => Math.max(1, prev - 1))}
                          className="rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-sm font-semibold text-slate-700 shadow-sm hover:bg-slate-50 disabled:opacity-40 transition-colors"
                        >
                          Sebelumnya
                        </button>

                        {paginationItems.map((item, index) =>
                          item === 'ellipsis' ? (
                            <span key={`ellipsis-${index}`} className="px-1 text-sm text-slate-400" aria-hidden="true">
                              ...
                            </span>
                          ) : (
                            <button
                              key={item}
                              type="button"
                              aria-current={item === currentPage ? 'page' : undefined}
                              disabled={isLoading}
                              onClick={() => setCurrentPage(item)}
                              className={`min-w-8 rounded-lg border px-2.5 py-1.5 text-sm font-semibold transition-colors disabled:cursor-wait ${
                                item === currentPage
                                  ? 'border-sky-600 bg-sky-600 text-white'
                                  : 'border-slate-300 bg-white text-slate-700 hover:bg-slate-50'
                              }`}
                            >
                              {item}
                            </button>
                          )
                        )}

                        <button
                          type="button"
                          disabled={currentPage >= totalPages || isLoading}
                          onClick={() =>
                            setCurrentPage((prev) =>
                              Math.min(totalPages, prev + 1)
                            )
                          }
                          className="rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-sm font-semibold text-slate-700 shadow-sm hover:bg-slate-50 disabled:opacity-40 transition-colors"
                        >
                          Berikutnya
                        </button>
                      </div>
                    </div>
                  </>
                )}
              </div>
            </>
          )}
        </div>
      </main>
    </div>
  );
}