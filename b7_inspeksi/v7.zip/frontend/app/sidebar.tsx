'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { usePathname, useRouter, useSearchParams } from 'next/navigation';
import {
  LayoutDashboard,
  ClipboardList,
  FileText,
  BarChart3,
  History,
  CheckSquare,
  Users,
  LogOut,
  Menu,
  X,
  User as UserIcon,
  ShieldCheck,
  Building2,
} from 'lucide-react';

// ==========================================
// TYPES & INTERFACES
// ==========================================
export type UserRole = 'administrator' | 'manager' | 'supervisor' | 'staff';

export interface UserSession {
  id?: string;
  name: string;
  username: string;
  role: UserRole;
}

interface SidebarProps {
  /** Optional user prop if session is managed at layout/page level */
  user?: UserSession | null;
  /** Custom logout handler if required by existing auth architecture */
  onLogout?: () => void | Promise<void>;
}

interface MenuItem {
  label: string;
  href: string;
  icon: React.ElementType;
}

interface MenuSection {
  title?: string;
  items: MenuItem[];
}

// Map human-readable role labels
const ROLE_LABELS: Record<UserRole, string> = {
  administrator: 'Administrator',
  manager: 'Manager',
  supervisor: 'Supervisor',
  staff: 'Staff',
};

function normalizeSessionUser(value: unknown): UserSession | null {
  if (!value || typeof value !== 'object') return null;
  const session = value as Record<string, unknown>;
  const role = typeof session.role === 'string' ? session.role.toLowerCase() : '';
  if (!['administrator', 'manager', 'supervisor', 'staff'].includes(role)) return null;

  const username = typeof session.username === 'string' ? session.username : '';
  const name =
    (typeof session.fullName === 'string' && session.fullName) ||
    (typeof session.name === 'string' && session.name) ||
    username;
  if (!username || !name) return null;

  return {
    id: typeof session.id === 'string' ? session.id : undefined,
    name,
    username,
    role: role as UserRole,
  };
}

let cachedSidebarUser: UserSession | null = null;
let sidebarSessionPromise: Promise<UserSession | null> | null = null;

// ==========================================
// COMPONENT
// ==========================================
export default function Sidebar({ user: propUser, onLogout }: SidebarProps) {
  const pathname = usePathname();
  const router = useRouter();
  const searchParams = useSearchParams();
  const nextPage = searchParams.get('next');

  const [isOpen, setIsOpen] = useState<boolean>(false);
  const [user, setUser] = useState<UserSession | null>(
    () => normalizeSessionUser(propUser) || cachedSidebarUser
  );
  const [loading, setLoading] = useState<boolean>(!propUser && !cachedSidebarUser);
  const [sessionError, setSessionError] = useState<boolean>(false);
  const [sessionRetry, setSessionRetry] = useState<number>(0);

  useEffect(() => {
    if (propUser) {
      const sessionUser = normalizeSessionUser(propUser);
      if (sessionUser) cachedSidebarUser = sessionUser;
      setUser(sessionUser);
      setLoading(false);
      return;
    }

    if (cachedSidebarUser) {
      setUser(cachedSidebarUser);
      setLoading(false);
      setSessionError(false);
      return;
    }

    let isMounted = true;
    setLoading(true);
    setSessionError(false);

    async function fetchSession() {
      try {
        if (!sidebarSessionPromise) {
          sidebarSessionPromise = fetch('/api/auth/session', {
            credentials: 'include',
            cache: 'no-store',
          }).then(async (response) => {
            if (response.status === 401) return null;
            if (!response.ok) {
              throw new Error(`Session verification failed with status ${response.status}`);
            }

            const data = await response.json();
            const sessionUser = normalizeSessionUser(data?.user);
            if (!data?.authenticated || !sessionUser) return null;

            cachedSidebarUser = sessionUser;
            return sessionUser;
          });
        }

        const pendingSession = sidebarSessionPromise;
        const sessionUser = await pendingSession;
        if (!sessionUser) {
          router.replace('/login');
          return;
        }
        if (isMounted) setUser(sessionUser);
      } catch (error) {
        if (!isMounted) return;
        console.error('Failed to retrieve user session for Sidebar:', error);
        setSessionError(true);
      } finally {
        sidebarSessionPromise = null;
        if (isMounted) setLoading(false);
      }
    }

    fetchSession();

    return () => {
      isMounted = false;
    };
  }, [propUser, router, sessionRetry]);

  // Handle Logout using existing logout endpoints or handlers
  const handleLogout = async () => {
    cachedSidebarUser = null;
    sidebarSessionPromise = null;

    if (onLogout) {
      await onLogout();
      return;
    }

    try {
      // Call existing logout API endpoint
      const res = await fetch('/api/auth/logout', { method: 'POST' });
      if (res.ok) {
        router.push('/login');
        router.refresh();
      } else {
        // Fallback redirection
        router.push('/login');
      }
    } catch (error) {
      console.error('Logout failed:', error);
      router.push('/login');
    }
  };

  // Close mobile drawer on route change
  useEffect(() => {
    setIsOpen(false);
  }, [pathname]);

  const activeRole = user?.role;

  // ==========================================
  // NAVIGATION STRUCTURE PER ROLE
  // ==========================================
  const menuSections: MenuSection[] = [
    {
      items: [
        {
          label: 'Dashboard',
          href: '/dashboard',
          icon: LayoutDashboard,
        },
      ],
    },
    {
      title: 'INSPEKSI',
      items: [
        {
          label: 'Form Inspeksi',
          href: '/form_inspeksi',
          icon: ClipboardList,
        },
        {
          label: 'Laporan Inspeksi',
          href: '/report_inspeksi',
          icon: BarChart3,
        },
        {
          label: 'Audit Trail',
          href: '/audit_trail',
          icon: History,
        },
      ],
    },
  ];

  // APPROVAL SECTION: Administrator, Manager, & Supervisor only (Staff EXCLUDED)
  if (
    activeRole === 'administrator' ||
    activeRole === 'manager' ||
    activeRole === 'supervisor'
  ) {
    menuSections.push({
      title: 'APPROVAL',
      items: [
        {
          label: 'Validasi & Approval',
          href: '/validasi_inspeksi',
          icon: CheckSquare,
        },
      ],
    });
  }

  // ADMINISTRASI SECTION: Administrator only
  if (activeRole === 'administrator') {
    menuSections.push({
      title: 'ADMINISTRASI',
      items: [
        {
          label: 'User Management',
          href: '/users',
          icon: Users,
        },
      ],
    });
  }

  // Filter empty sections if any
  const visibleSections = menuSections.filter(
    (section) => section.items && section.items.length > 0
  );

  // Helper check for Active State
  const isRouteActive = (href: string) => {
    if (href === '/dashboard') {
      return pathname === '/dashboard';
    }

    // Select Lokasi adalah bagian dari flow Missed Entry
    if (pathname === '/selectlokasi' && nextPage === 'keterangan') {
      return href === '/keterangan';
    }

    // Select Lokasi tanpa next=keterangan adalah bagian dari flow Form Inspeksi
    if (pathname === '/selectlokasi') {
      return href === '/form_inspeksi';
    }

    return pathname.startsWith(href);
  };

  return (
    <>
      {/* MOBILE TOP BAR (Visible only on small screens) */}
      <div className="lg:hidden fixed top-0 left-0 right-0 h-16 bg-sky-50/90 backdrop-blur-md border-b border-sky-100 px-4 flex items-center justify-between z-40">
        <div className="flex items-center space-x-3">
          <div className="bg-sky-600 text-white p-2 rounded-lg shadow-sm">
            <Building2 className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-sm font-bold text-sky-950 leading-tight">
              Logbook
            </h1>
            <p className="text-[10px] text-sky-700 font-medium">PT Bintang Toedjoe</p>
          </div>
        </div>
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="p-2 rounded-lg text-sky-800 hover:bg-sky-100 transition-colors focus:outline-none focus:ring-2 focus:ring-sky-400"
          aria-label="Toggle Navigation Menu"
        >
          {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* MOBILE BACKDROP OVERLAY */}
      {isOpen && (
        <div
          className="lg:hidden fixed inset-0 bg-slate-900/40 backdrop-blur-xs z-40 transition-opacity"
          onClick={() => setIsOpen(false)}
        />
      )}

      {/* SIDEBAR CONTAINER (Desktop Fixed / Mobile Drawer) */}
      <aside
        className={`
          fixed top-0 bottom-0 left-0 z-50
          w-72 bg-sky-50/80 border-r border-sky-200/70
          flex flex-col justify-between
          transition-transform duration-300 ease-in-out
          lg:translate-x-0
          ${isOpen ? 'translate-x-0' : '-translate-x-full'}
        `}
      >
        {/* TOP SECTION: HEADER & NAV */}
        <div className="flex flex-col flex-1 overflow-y-auto">
          {/* HEADER BRANDING */}
          <div className="p-6 border-b border-sky-100 bg-sky-100/40">
            <div className="flex items-start space-x-3">
              <div className="bg-sky-600 text-white p-2.5 rounded-xl shadow-md shadow-sky-600/20 mt-0.5">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <div>
                <h1 className="text-base font-bold text-sky-950 leading-snug">
                  Logbook
                </h1>
                <p className="text-xs font-semibold text-sky-800">
                  Inspeksi Kebersihan
                </p>
                <div className="mt-2 pt-2 border-t border-sky-200/50">
                  <p className="text-[11px] font-semibold text-sky-900 tracking-wide uppercase">
                    PT Bintang Toedjoe
                  </p>
                  <p className="text-[10px] text-sky-600 font-medium">
                    Production Area Pulogadung
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* NAVIGATION LINKS */}
          <nav className="flex-1 px-4 py-5 space-y-6">
            {visibleSections.map((section, idx) => (
              <div key={idx} className="space-y-1.5">
                {section.title && (
                  <h2 className="px-3 text-[11px] font-bold text-sky-700 tracking-wider uppercase mb-2">
                    {section.title}
                  </h2>
                )}
                <ul className="space-y-1">
                  {section.items.map((item) => {
                    const isActive = isRouteActive(item.href);
                    const Icon = item.icon;

                    return (
                      <li key={item.href}>
                        <Link
                          href={item.href}
                          className={`
                            flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-medium
                            transition-all duration-200 ease-in-out group
                            ${
                              isActive
                                ? 'bg-sky-600 text-white shadow-sm shadow-sky-600/25 font-semibold'
                                : 'text-slate-700 hover:bg-sky-100/80 hover:text-sky-900'
                            }
                          `}
                        >
                          <Icon
                            className={`w-5 h-5 shrink-0 transition-transform duration-200 group-hover:scale-105 ${
                              isActive
                                ? 'text-white'
                                : 'text-sky-600 group-hover:text-sky-800'
                            }`}
                          />
                          <span>{item.label}</span>
                        </Link>
                      </li>
                    );
                  })}
                </ul>
              </div>
            ))}
          </nav>
        </div>

        {/* BOTTOM SECTION: USER PROFILE & LOGOUT */}
        <div className="p-4 border-t border-sky-200/80 bg-sky-100/50 space-y-3">
          {/* USER PROFILE CARD */}
          <div className="flex items-center space-x-3 px-2 py-1.5">
            <div className="w-10 h-10 rounded-full bg-sky-200 border border-sky-300 flex items-center justify-center shrink-0 shadow-xs">
              <UserIcon className="w-5 h-5 text-sky-800" />
            </div>
            <div className="flex-1 min-w-0">
              {loading ? (
                <div className="space-y-1.5 animate-pulse">
                  <div className="h-3.5 bg-sky-200 rounded w-24"></div>
                  <div className="h-2.5 bg-sky-200 rounded w-16"></div>
                </div>
              ) : user ? (
                <>
                  <p className="text-sm font-bold text-slate-900 truncate leading-tight">
                    {user.name}
                  </p>
                  <p className="text-xs text-sky-700 truncate">
                    @{user.username}
                  </p>
                  <span className="inline-block mt-1 px-2 py-0.5 text-[10px] font-semibold bg-sky-200/80 text-sky-900 rounded-md border border-sky-300/60">
                    {ROLE_LABELS[user.role] || user.role}
                  </span>
                </>
              ) : sessionError ? (
                <button
                  type="button"
                  onClick={() => setSessionRetry((retry) => retry + 1)}
                  className="text-xs font-medium text-rose-700 hover:underline"
                >
                  Gagal memuat sesi. Coba lagi
                </button>
              ) : (
                <p className="text-xs text-slate-500 italic">Memverifikasi sesi...</p>
              )}
            </div>
          </div>

          <div className="h-px bg-sky-200/80 my-1" />

          {/* LOGOUT BUTTON */}
          <button
            onClick={handleLogout}
            disabled={loading || !user}
            className="
              w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl
              text-xs font-semibold text-rose-700 bg-rose-50/80 hover:bg-rose-100/80 hover:text-rose-800
              border border-rose-200/70 transition-all duration-200 ease-in-out
              focus:outline-none focus:ring-2 focus:ring-rose-400 disabled:cursor-not-allowed disabled:opacity-50
            "
          >
            <LogOut className="w-4 h-4" />
            <span>Logout</span>
          </button>
        </div>
      </aside>
    </>
  );
}