'use client';

import React, { Suspense, useState, useEffect, FormEvent, ChangeEvent, useMemo } from 'react';
import { useRouter } from 'next/navigation';
import Sidebar from '../sidebar';

interface User {
  id: string;
  fullName: string;
  username: string;
  role: 'administrator' | 'manager' | 'supervisor' | 'staff' | string;
  department: 'Produksi PG' | 'Warehouse PG' | string;
  site: string;
  status: 'ACTIVE' | 'BLOCKED' | 'INACTIVE' | string;
}

function getPaginationItems(totalPages: number, currentPage: number): Array<number | 'ellipsis'> {
  const pages = new Set<number>([1, totalPages]);
  for (
    let page = Math.max(1, currentPage - 1);
    page <= Math.min(totalPages, currentPage + 1);
    page += 1
  ) {
    pages.add(page);
  }

  const sortedPages = [...pages].sort((a, b) => a - b);
  const items: Array<number | 'ellipsis'> = [];
  sortedPages.forEach((page, index) => {
    if (index > 0 && page - sortedPages[index - 1] > 1) {
      items.push('ellipsis');
    }
    items.push(page);
  });
  return items;
}

export default function UserManagementPage() {
  const router = useRouter();

  // User List & System States
  const [users, setUsers] = useState<User[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [resetPasswordError, setResetPasswordError] = useState<string | null>(null);
  const [unauthorized, setUnauthorized] = useState<boolean>(false);

  // Search, Filter & Pagination States
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [roleFilter, setRoleFilter] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<string>('');
  const [currentPage, setCurrentPage] = useState<number>(1);
  const ITEMS_PER_PAGE = 50;

  // Modal Form States
  const [isFormModalOpen, setIsFormModalOpen] = useState<boolean>(false);
  const [editingUserId, setEditingUserId] = useState<string | null>(null);
  const [isResetPasswordConfirmOpen, setIsResetPasswordConfirmOpen] = useState<boolean>(false);

  // Form Fields (Updated site initial state to 'Pulogadung')
  const [fullName, setFullName] = useState<string>('');
  const [username, setUsername] = useState<string>('');
  const [password, setPassword] = useState<string>('');
  const [oldPassword, setOldPassword] = useState<string>('');
  const [role, setRole] = useState<string>('staff');
  const [department, setDepartment] = useState<string>('Produksi PG');
  const [site, setSite] = useState<string>('Pulogadung');
  const [status, setStatus] = useState<string>('ACTIVE');
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});
  const passwordCriteria = [
    { label: 'Minimal 8 karakter', met: password.length >= 8 },
    { label: 'Huruf besar', met: /[A-Z]/.test(password) },
    { label: 'Huruf kecil', met: /[a-z]/.test(password) },
    { label: 'Angka', met: /[0-9]/.test(password) },
    { label: 'Karakter spesial', met: /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password) },
  ];
  const passwordStrength = passwordCriteria.filter((criterion) => criterion.met).length;

  // Confirmation Modal State (Deactivation)
  const [deactivatingUser, setDeactivatingUser] = useState<User | null>(null);

  // Fetch All Users
  const fetchUsers = async () => {
    setIsLoading(true);
    setError(null);
    setUnauthorized(false);

    try {
      const res = await fetch('/api/users', {
        method: 'GET',
        headers: { 'Content-Type': 'application/json' },
      });

      if (res.status === 401) {
        router.push('/login');
        return;
      }

      if (res.status === 403) {
        setUnauthorized(true);
        return;
      }

      const data: {
        success: boolean;
        data?: User[];
        message?: string;
      } = await res.json();

      if (!res.ok || !data.success) {
        setError(data.message || 'Gagal memuat daftar pengguna.');
        setUsers([]);
        return;
      }

      setUsers(Array.isArray(data.data) ? data.data : []);
    } catch (err) {
      setError('Terjadi kesalahan koneksi saat memuat data pengguna.');
      setUsers([]);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  // Filter & Search Logic
  const filteredUsers = useMemo(() => {
    return users.filter((u) => {
      const matchSearch =
        u.fullName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        u.username.toLowerCase().includes(searchQuery.toLowerCase());
      const matchRole = roleFilter ? u.role === roleFilter : true;
      const matchStatus = statusFilter ? u.status === statusFilter : true;

      return matchSearch && matchRole && matchStatus;
    });
  }, [users, searchQuery, roleFilter, statusFilter]);

  // Reset pagination on filter change
  useEffect(() => {
    setCurrentPage(1);
  }, [searchQuery, roleFilter, statusFilter]);

  // Pagination Calculation
  const totalPages = Math.ceil(filteredUsers.length / ITEMS_PER_PAGE) || 1;
  const paginationItems = getPaginationItems(totalPages, currentPage);
  const paginatedUsers = useMemo(() => {
    const start = (currentPage - 1) * ITEMS_PER_PAGE;
    return filteredUsers.slice(start, start + ITEMS_PER_PAGE);
  }, [filteredUsers, currentPage]);

  // Password Policy Validation: Min 8 chars, 1 uppercase, 1 lowercase, 1 number, 1 special char
  const validatePasswordPolicy = (pwd: string): boolean => {
    const minLength = pwd.length >= 8;
    const hasUpper = /[A-Z]/.test(pwd);
    const hasLower = /[a-z]/.test(pwd);
    const hasNumber = /[0-9]/.test(pwd);
    const hasSpecial = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(pwd);

    return minLength && hasUpper && hasLower && hasNumber && hasSpecial;
  };

  // Client Validation Logic
  const validateForm = (): boolean => {
    const errors: Record<string, string> = {};

    if (!fullName.trim()) errors.fullName = 'Nama lengkap wajib diisi.';
    if (!username.trim()) errors.username = 'Username wajib diisi.';
    if (!site.trim()) errors.site = 'Site wajib diisi.';
    if (!role) errors.role = 'Role wajib dipilih.';
    if (!department) errors.department = 'Department wajib dipilih.';

    // Password validation: required for CREATE, optional for UPDATE
    if (!editingUserId) {
      if (!password) {
        errors.password = 'Password wajib diisi untuk pengguna baru.';
      } else if (!validatePasswordPolicy(password)) {
        errors.password =
          'Password minimal 8 karakter dan harus mengandung huruf besar, huruf kecil, angka, dan karakter spesial.';
      }
    } else if (password) {
      if (!oldPassword) {
        errors.oldPassword = 'Password lama akun wajib diisi untuk mengubah password.';
      }
      if (!validatePasswordPolicy(password)) {
        errors.password =
          'Password minimal 8 karakter dan harus mengandung huruf besar, huruf kecil, angka, dan karakter spesial.';
      }
    }

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  // Open Modal Create User
  const handleOpenCreateModal = () => {
    setEditingUserId(null);
    setFullName('');
    setUsername('');
    setPassword('');
    setOldPassword('');
    setRole('staff');
    setDepartment('Produksi PG');
    setSite('Pulogadung');
    setStatus('ACTIVE');
    setFormErrors({});
    setIsFormModalOpen(true);
  };

  // Open Modal Edit User
  const handleOpenEditModal = (user: User) => {
    setEditingUserId(user.id);
    setFullName(user.fullName);
    setUsername(user.username);
    setPassword(''); // Never prefill existing password
    setOldPassword('');
    setRole(user.role);
    setDepartment(user.department);
    setSite(user.site);
    setStatus(user.status);
    setFormErrors({});
    setIsFormModalOpen(true);
  };

  // Handle Submit Form (Create / Update)
  const handleSubmitForm = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!validateForm()) return;

    setIsSubmitting(true);
    setError(null);
    setResetPasswordError(null);
    setSuccessMessage(null);

    const isEditing = Boolean(editingUserId);

    // Build payload without password if empty on edit
    const payload: Record<string, any> = {
      fullName: fullName.trim(),
      username: username.trim(),
      role,
      department,
      site: site.trim(),
      status,
    };

    if (password) {
      payload.password = password;
    }
    if (isEditing && oldPassword) {
      payload.oldPassword = oldPassword;
    }

    const url = isEditing ? `/api/users/${editingUserId}` : '/api/users';
    const method = isEditing ? 'PUT' : 'POST';

    try {
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      if (res.status === 401) {
        router.push('/login');
        return;
      }

      if (res.status === 403) {
        setError('Akses ditolak: Hanya Administrator yang dapat mengelola akun pengguna.');
        setIsSubmitting(false);
        return;
      }

      if (!res.ok) {
        const responseText = await res.text();

        let errData: { message?: string; error?: string } = {};

        try {
          errData = responseText ? JSON.parse(responseText) : {};
        } catch {
          // Response bukan JSON, gunakan raw text
        }

        console.error('[USER CREATE/UPDATE ERROR]', {
          status: res.status,
          statusText: res.statusText,
          rawResponse: responseText,
          parsedResponse: errData,
        });

        setError(
          errData.message ||
            errData.error ||
            responseText ||
            `Gagal menyimpan data pengguna. HTTP ${res.status}`
        );

        setIsSubmitting(false);
        return;
      }

      // Clear sensitive state from memory immediately
      setPassword('');
      setOldPassword('');
      setIsFormModalOpen(false);
      setSuccessMessage(
        isEditing
          ? 'Data pengguna berhasil diperbarui.'
          : 'Pengguna baru berhasil dibuat.'
      );

      fetchUsers();
    } catch (err) {
      setError('Terjadi kesalahan koneksi saat mengirim data.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleResetPasswordToDefault = async () => {
    if (!editingUserId) return;

    setIsSubmitting(true);
    setError(null);
    setSuccessMessage(null);
    try {
      const res = await fetch(`/api/users/${editingUserId}/reset-password`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });

      if (res.status === 401) {
        router.push('/login');
        return;
      }
      if (res.status === 403) {
        setResetPasswordError('Akses ditolak: Hanya Administrator yang dapat mereset password pengguna.');
        return;
      }
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        setResetPasswordError(data.message || data.error || 'Gagal mereset password pengguna.');
        return;
      }

      setPassword('');
      setOldPassword('');
      setIsResetPasswordConfirmOpen(false);
      setSuccessMessage(`Password akun ${username} berhasil direset ke password default.`);
      fetchUsers();
    } catch {
      setResetPasswordError('Terjadi kesalahan koneksi saat mereset password pengguna.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Handle Logical Deactivation (DELETE -> Status INACTIVE)
  const handleConfirmDeactivate = async () => {
    if (!deactivatingUser) return;

    setIsSubmitting(true);
    setError(null);

    try {
      const res = await fetch(`/api/users/${deactivatingUser.id}`, {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
      });

      if (res.status === 401) {
        router.push('/login');
        return;
      }

      if (res.status === 403) {
        setError('Akses ditolak: Hanya Administrator yang dapat menonaktifkan pengguna.');
        setIsSubmitting(false);
        return;
      }

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        setError(errData.message || 'Gagal menonaktifkan pengguna.');
        setIsSubmitting(false);
        return;
      }

      setSuccessMessage(`Akun ${deactivatingUser.username} berhasil dinonaktifkan.`);
      setDeactivatingUser(null);
      fetchUsers();
    } catch (err) {
      setError('Terjadi kesalahan koneksi saat menonaktifkan pengguna.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const renderStatusBadge = (userStatus: string) => {
    switch (userStatus) {
      case 'ACTIVE':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-sm font-semibold bg-emerald-100 text-emerald-800">
            ACTIVE
          </span>
        );
      case 'BLOCKED':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-sm font-semibold bg-amber-100 text-amber-800">
            BLOCKED
          </span>
        );
      case 'INACTIVE':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-sm font-semibold bg-rose-100 text-rose-800">
            INACTIVE
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-sm font-semibold bg-slate-100 text-slate-800">
            {userStatus}
          </span>
        );
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      <Suspense fallback={null}>
        <Sidebar />
      </Suspense>

      <main className="lg:ml-72 p-4 sm:p-6 lg:p-8">
        <div className="w-full space-y-6">
          {/* Header Page */}
          <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
              <h1 className="text-2xl font-bold text-slate-900">User Management</h1>
              <p className="text-sm text-slate-500 mt-1">
                Pengelolaan akun pengguna, otorisasi role, department, dan status akun.
              </p>
            </div>
            {!unauthorized && (
              <button
                onClick={handleOpenCreateModal}
                className="px-4 py-2 text-sm font-semibold text-white bg-sky-600 hover:bg-sky-700 rounded-lg shadow-sm transition-colors cursor-pointer shrink-0"
              >
                + Tambah Akun Baru
              </button>
            )}
          </div>

          {/* Alert Success */}
          {successMessage && (
            <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 p-4 rounded-xl text-sm flex justify-between items-center shadow-sm">
              <span>{successMessage}</span>
              <button
                onClick={() => setSuccessMessage(null)}
                className="text-emerald-700 font-bold ml-4 hover:text-emerald-900 cursor-pointer"
              >
                ✕
              </button>
            </div>
          )}

          {/* Alert Error */}
          {error && (
            <div className="bg-rose-50 border border-rose-200 text-rose-700 p-4 rounded-xl text-sm shadow-sm">
              <p className="font-semibold">Kesalahan</p>
              <p className="mt-1">{error}</p>
            </div>
          )}

          {/* Unauthorized View */}
          {unauthorized ? (
            <div className="bg-white p-12 rounded-xl border border-slate-200 shadow-sm text-center">
              <h2 className="text-lg font-bold text-rose-600">Akses Ditolak</h2>
              <p className="text-sm text-slate-500 mt-2">
                Anda tidak memiliki wewenang (Administrator) untuk mengakses halaman User Management.
              </p>
            </div>
          ) : (
            /* Main Content: Filter, Search & Table */
            <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden space-y-4 p-4 sm:p-6">
              {/* Search & Filter Bar */}
              <div className="flex flex-col md:flex-row gap-3 justify-between items-center pb-2">
                <div className="w-full md:w-72">
                  <input
                    type="text"
                    placeholder="Cari nama atau username..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 px-3.5 py-2 text-sm text-slate-900 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
                  />
                </div>

                <div className="flex flex-wrap sm:flex-nowrap gap-3 w-full md:w-auto">
                  <select
                    value={roleFilter}
                    onChange={(e) => setRoleFilter(e.target.value)}
                    className="w-full sm:w-40 rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500 bg-white"
                  >
                    <option value="">Semua Role</option>
                    <option value="administrator">Administrator</option>
                    <option value="manager">Manager</option>
                    <option value="supervisor">Supervisor</option>
                    <option value="staff">Staff</option>
                  </select>

                  <select
                    value={statusFilter}
                    onChange={(e) => setStatusFilter(e.target.value)}
                    className="w-full sm:w-40 rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500 bg-white"
                  >
                    <option value="">Semua Status</option>
                    <option value="ACTIVE">ACTIVE</option>
                    <option value="BLOCKED">BLOCKED</option>
                    <option value="INACTIVE">INACTIVE</option>
                  </select>
                </div>
              </div>

              {/* User List Table */}
              {isLoading ? (
                <div className="text-center py-12">
                  <p className="text-sm text-slate-500">Memuat data pengguna...</p>
                </div>
              ) : paginatedUsers.length === 0 ? (
                <div className="text-center py-12 border-t border-slate-100">
                  <p className="text-sm text-slate-500">
                    {searchQuery || roleFilter || statusFilter
                      ? 'Tidak ada akun yang sesuai dengan filter pencarian.'
                      : 'Belum ada akun pengguna terdaftar.'}
                  </p>
                </div>
              ) : (
                <>
                  <div className="overflow-x-auto border border-slate-200 rounded-lg">
                    <table className="min-w-full divide-y divide-slate-200 text-left text-[15px]">
                      <thead className="bg-slate-50 text-slate-700 font-semibold">
                        <tr>
                          <th className="px-4 py-3.5 text-sm">Nama Lengkap</th>
                          <th className="px-4 py-3.5 text-sm">Username</th>
                          <th className="px-4 py-3.5 text-sm">Role</th>
                          <th className="px-4 py-3.5 text-sm">Department</th>
                          <th className="px-4 py-3.5 text-sm">Site</th>
                          <th className="px-4 py-3.5 text-sm">Status</th>
                          <th className="px-4 py-3.5 text-right text-sm">Aksi</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-200 bg-white">
                        {paginatedUsers.map((u) => (
                          <tr key={u.id} className="hover:bg-slate-50/80 transition-colors">
                            <td className="px-4 py-3.5 font-medium text-slate-900 [overflow-wrap:anywhere]">
                              {u.fullName}
                            </td>
                            <td className="px-4 py-3.5 text-slate-700 font-mono [overflow-wrap:anywhere]">
                              {u.username}
                            </td>
                            <td className="px-4 py-3.5 text-slate-800 whitespace-nowrap capitalize">
                              {u.role}
                            </td>
                            <td className="px-4 py-3.5 text-slate-700 whitespace-nowrap">
                              {u.department}
                            </td>
                            <td className="px-4 py-3.5 text-slate-700 whitespace-nowrap">
                              {u.site}
                            </td>
                            <td className="px-4 py-3.5 whitespace-nowrap">
                              {renderStatusBadge(u.status)}
                            </td>
                            <td className="px-4 py-3.5 whitespace-nowrap text-right space-x-2">
                              <button
                                onClick={() => handleOpenEditModal(u)}
                                className="px-3 py-1.5 text-sm font-semibold text-sky-700 bg-sky-50 hover:bg-sky-100 rounded-md transition-colors cursor-pointer"
                              >
                                Edit
                              </button>
                              {u.status !== 'INACTIVE' && (
                                <button
                                  onClick={() => setDeactivatingUser(u)}
                                  className="px-3 py-1.5 text-sm font-semibold text-rose-700 bg-rose-50 hover:bg-rose-100 rounded-md transition-colors cursor-pointer"
                                >
                                  Nonaktifkan
                                </button>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                  {/* Pagination Footer */}
                  <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-3 border-t border-slate-100 text-sm text-slate-600">
                    <div>
                      Menampilkan <span className="font-semibold">{paginatedUsers.length}</span> dari{' '}
                      <span className="font-semibold">{filteredUsers.length}</span> total pengguna
                    </div>
                    <div className="flex flex-wrap items-center justify-center gap-2">
                      <button
                        onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
                        disabled={currentPage === 1}
                        className="px-3 py-1.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 disabled:opacity-50 disabled:cursor-not-allowed text-sm font-medium cursor-pointer"
                      >
                        Sebelumnya
                      </button>
                      {paginationItems.map((item, index) =>
                        item === 'ellipsis' ? (
                          <span key={`ellipsis-${index}`} className="px-1 text-sm text-slate-400" aria-hidden="true">
                            ...
                          </span>
                        ) : (
                          <button
                            key={item}
                            type="button"
                            aria-current={item === currentPage ? 'page' : undefined}
                            onClick={() => setCurrentPage(item)}
                            className={`min-w-9 rounded-lg border px-3 py-1.5 text-sm font-semibold transition-colors ${
                              item === currentPage
                                ? 'border-sky-600 bg-sky-600 text-white'
                                : 'border-slate-300 bg-white text-slate-700 hover:bg-slate-50'
                            }`}
                          >
                            {item}
                          </button>
                        )
                      )}
                      <button
                        onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
                        disabled={currentPage === totalPages}
                        className="px-3 py-1.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 disabled:opacity-50 disabled:cursor-not-allowed text-sm font-medium cursor-pointer"
                      >
                        Selanjutnya
                      </button>
                    </div>
                  </div>
                </>
              )}
            </div>
          )}
        </div>
      </main>

      {/* Modal Form Create / Edit User */}
      {isFormModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl border border-slate-200 shadow-xl max-w-lg w-full p-6 space-y-4">
            <div className="flex justify-between items-center border-b border-slate-200 pb-3">
              <h3 className="text-lg font-bold text-slate-900">
                {editingUserId ? 'Edit Akun Pengguna' : 'Tambah Akun Pengguna Baru'}
              </h3>
              <button
                onClick={() => setIsFormModalOpen(false)}
                disabled={isSubmitting}
                className="text-slate-400 hover:text-slate-600 text-sm font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmitForm} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700">Nama Lengkap *</label>
                <input
                  type="text"
                  value={fullName}
                  onChange={(e: ChangeEvent<HTMLInputElement>) => setFullName(e.target.value)}
                  disabled={isSubmitting}
                  placeholder="Masukkan nama lengkap"
                  className="mt-1 block w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500 disabled:bg-slate-100"
                />
                {formErrors.fullName && (
                  <p className="mt-1 text-xs text-rose-600">{formErrors.fullName}</p>
                )}
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700">Username *</label>
                <input
                  type="text"
                  value={username}
                  onChange={(e: ChangeEvent<HTMLInputElement>) => setUsername(e.target.value)}
                  disabled={isSubmitting}
                  placeholder="Masukkan username"
                  className="mt-1 block w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500 disabled:bg-slate-100"
                />
                {formErrors.username && (
                  <p className="mt-1 text-xs text-rose-600">{formErrors.username}</p>
                )}
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700">
                  {editingUserId ? 'Password Lama (wajib jika password diubah)' : 'Password *'}
                </label>
                {editingUserId && (
                  <>
                    <input
                      type="password"
                      value={oldPassword}
                      onChange={(e: ChangeEvent<HTMLInputElement>) => setOldPassword(e.target.value)}
                      disabled={isSubmitting}
                      placeholder="Masukkan password lama akun..."
                      autoComplete="current-password"
                      className="mt-1 block w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500 disabled:bg-slate-100"
                    />
                    {formErrors.oldPassword && (
                      <p className="mt-1 text-xs text-rose-600">{formErrors.oldPassword}</p>
                    )}
                    <label className="mt-2 block text-xs font-semibold text-slate-700">
                      Password baru (kosongkan bila tidak diubah)
                    </label>
                  </>
                )}
                <input
                  type="password"
                  value={password}
                  onChange={(e: ChangeEvent<HTMLInputElement>) => setPassword(e.target.value)}
                  disabled={isSubmitting}
                  placeholder={editingUserId ? 'Ubah password (opsional)...' : 'Password baru...'}
                  autoComplete="new-password"
                  className="mt-1 block w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500 disabled:bg-slate-100"
                />
                <div
                  className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-slate-200"
                  role="progressbar"
                  aria-label="Kekuatan password"
                  aria-valuemin={0}
                  aria-valuemax={passwordCriteria.length}
                  aria-valuenow={passwordStrength}
                >
                  <div
                    className={`h-full rounded-full transition-all duration-200 ${
                      passwordStrength === passwordCriteria.length
                        ? 'bg-emerald-500'
                        : password
                        ? 'bg-rose-500'
                        : 'bg-slate-300'
                    }`}
                    style={{ width: `${(passwordStrength / passwordCriteria.length) * 100}%` }}
                  />
                </div>
                <div className="mt-1.5 flex flex-wrap gap-x-3 gap-y-1">
                  {passwordCriteria.map((criterion) => (
                    <span
                      key={criterion.label}
                      className={`text-[11px] ${criterion.met ? 'text-emerald-700' : 'text-slate-500'}`}
                    >
                      {criterion.met ? '✓' : '○'} {criterion.label}
                    </span>
                  ))}
                </div>
                <p className="mt-1 text-[11px] text-slate-500">
                  Min. 8 karakter, wajib kombinasi huruf besar, huruf kecil, angka, dan karakter spesial.
                </p>
                {formErrors.password && (
                  <p className="mt-1 text-xs text-rose-600">{formErrors.password}</p>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700">Role *</label>
                  <select
                    value={role}
                    onChange={(e: ChangeEvent<HTMLSelectElement>) => setRole(e.target.value)}
                    disabled={isSubmitting}
                    className="mt-1 block w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500 disabled:bg-slate-100 bg-white"
                  >
                    <option value="administrator">Administrator</option>
                    <option value="manager">Manager</option>
                    <option value="supervisor">Supervisor</option>
                    <option value="staff">Staff</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700">Department *</label>
                  <select
                    value={department}
                    onChange={(e: ChangeEvent<HTMLSelectElement>) => setDepartment(e.target.value)}
                    disabled={isSubmitting}
                    className="mt-1 block w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500 disabled:bg-slate-100 bg-white"
                  >
                    <option value="Produksi PG">Produksi PG</option>
                    <option value="Warehouse PG">Warehouse PG</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700">Site *</label>
                  <select
                    value={site}
                    onChange={(e: ChangeEvent<HTMLSelectElement>) => setSite(e.target.value)}
                    disabled={isSubmitting}
                    className="mt-1 block w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500 disabled:bg-slate-100 bg-white"
                  >
                    <option value="">Pilih site...</option>
                    <option value="Pulogadung">Pulogadung</option>
                  </select>
                  {formErrors.site && (
                    <p className="mt-1 text-xs text-rose-600">{formErrors.site}</p>
                  )}
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700">Status Akun</label>
                  <select
                    value={status}
                    onChange={(e: ChangeEvent<HTMLSelectElement>) => setStatus(e.target.value)}
                    disabled={isSubmitting}
                    className="mt-1 block w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500 disabled:bg-slate-100 bg-white"
                  >
                    <option value="ACTIVE">ACTIVE</option>
                    <option value="BLOCKED">BLOCKED</option>
                    <option value="INACTIVE">INACTIVE</option>
                  </select>
                </div>
              </div>

              <div className="flex flex-col-reverse gap-3 border-t border-slate-200 pt-3 sm:flex-row sm:items-center sm:justify-between">
                {editingUserId ? (
                  <button
                    type="button"
                    onClick={() => {
                      setResetPasswordError(null);
                      setIsResetPasswordConfirmOpen(true);
                    }}
                    disabled={isSubmitting}
                    className="px-4 py-2 text-xs font-semibold text-rose-700 bg-rose-50 border border-rose-200 hover:bg-rose-100 rounded-lg transition-colors disabled:opacity-50 cursor-pointer"
                  >
                    Reset Password ke Default
                  </button>
                ) : <span />}
                <div className="flex justify-end space-x-2">
                  <button
                    type="button"
                    onClick={() => setIsFormModalOpen(false)}
                    disabled={isSubmitting}
                    className="px-4 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors disabled:opacity-50 cursor-pointer"
                  >
                    Batal
                  </button>
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="px-4 py-2 text-xs font-semibold text-white bg-sky-600 hover:bg-sky-700 rounded-lg transition-colors disabled:bg-sky-300 cursor-pointer"
                  >
                    {isSubmitting ? 'Memproses...' : editingUserId ? 'Simpan Perubahan' : 'Buat Akun'}
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {isResetPasswordConfirmOpen && editingUserId && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-slate-900/50 p-4">
          <div
            role="alertdialog"
            aria-modal="true"
            aria-labelledby="reset-password-title"
            className="w-full max-w-md space-y-4 rounded-xl border border-slate-200 bg-white p-6 shadow-2xl"
          >
            <h3 id="reset-password-title" className="text-lg font-bold text-slate-900">
              Konfirmasi Reset Password
            </h3>
            <p className="text-sm leading-relaxed text-slate-600">
              Password akun <strong className="text-slate-900">{username}</strong> akan direset menjadi password default. Lanjutkan?
            </p>
            {resetPasswordError && (
              <p className="rounded-lg border border-rose-200 bg-rose-50 p-3 text-xs text-rose-700">
                {resetPasswordError}
              </p>
            )}
            <div className="flex justify-end gap-2 border-t border-slate-100 pt-3">
              <button
                type="button"
                onClick={() => setIsResetPasswordConfirmOpen(false)}
                disabled={isSubmitting}
                className="rounded-lg border border-slate-300 bg-white px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 disabled:opacity-50"
              >
                Tidak
              </button>
              <button
                type="button"
                onClick={handleResetPasswordToDefault}
                disabled={isSubmitting}
                className="rounded-lg bg-rose-600 px-4 py-2 text-xs font-semibold text-white hover:bg-rose-700 disabled:bg-rose-300"
              >
                {isSubmitting ? 'Mereset...' : 'Ya, Reset Password'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal Deactivation Confirmation */}
      {deactivatingUser && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl border border-slate-200 shadow-xl max-w-sm w-full p-6 space-y-4">
            <h3 className="text-lg font-bold text-slate-900 border-b border-slate-200 pb-2">
              Konfirmasi Deaktivasi Akun
            </h3>

            <p className="text-xs text-slate-600 leading-relaxed">
              Apakah Anda yakin ingin menonaktifkan pengguna{' '}
              <strong className="text-slate-900">{deactivatingUser.fullName}</strong> (
              <span className="font-mono">{deactivatingUser.username}</span>)? Status pengguna akan diubah menjadi <strong className="text-rose-600">INACTIVE</strong>.
            </p>

            <div className="flex justify-end space-x-2 pt-2 border-t border-slate-200">
              <button
                type="button"
                onClick={() => setDeactivatingUser(null)}
                disabled={isSubmitting}
                className="px-3.5 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors disabled:opacity-50 cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleConfirmDeactivate}
                disabled={isSubmitting}
                className="px-3.5 py-2 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-700 rounded-lg transition-colors disabled:bg-rose-300 cursor-pointer"
              >
                {isSubmitting ? 'Menonaktifkan...' : 'Ya, Menonaktifkan'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}