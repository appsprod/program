'use client';

import React, { useState, useEffect, FormEvent, ChangeEvent, Suspense } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Sidebar from '../sidebar';

interface Location {
  id: string;
  name: string;
  code?: string;
  site?: string;
  department?: string;
}

interface InspectionFormContentProps {
  locations: Location[];
  isLocationLoading: boolean;
}

function InspectionFormContent({ locations, isLocationLoading }: InspectionFormContentProps) {
  const router = useRouter();
  const searchParams = useSearchParams();
  const locationQueryParam = searchParams.get('lokasi') || '';

  // Form States
  const [selectedLocationId, setSelectedLocationId] = useState<string>(locationQueryParam);
  const [shift, setShift] = useState<string>(searchParams.get('shift') || '');
  const [checkPersonel, setCheckPersonel] = useState<string>('OK');
  const [checkRuangan, setCheckRuangan] = useState<string>('OK');
  const [checkPeralatan, setCheckPeralatan] = useState<string>('OK');
  const [ketPersonel, setKetPersonel] = useState<string>('');
  const [ketRuangan, setKetRuangan] = useState<string>('');
  const [ketPeralatan, setKetPeralatan] = useState<string>('');

  // UI States
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [serverDateFormatted, setServerDateFormatted] = useState<string>('');
  const [currentUserName, setCurrentUserName] = useState<string>('');
  const [availableShifts, setAvailableShifts] = useState<string[]>([]);

  // Sinkronisasi query param lokasi jika berubah
  useEffect(() => {
    if (!locationQueryParam) {
      router.replace('/selectlokasi');
      return;
    }

    if (locationQueryParam) {
      setSelectedLocationId(locationQueryParam);
    }
  }, [locationQueryParam, router]);

  // Ambil nama user yang sedang login untuk ditampilkan sebagai Paraf User
  useEffect(() => {
    let isMounted = true;

    const fetchCurrentUser = async () => {
      try {
        const response = await fetch('/api/auth/session', {
          credentials: 'include',
        });

        if (!response.ok) {
          return;
        }

        const data = await response.json();

        // FIX: Menggunakan fullName sesuai dengan payload backend
        if (isMounted && data?.user?.fullName) {
          setCurrentUserName(data.user.fullName);
        }
      } catch (error) {
        console.error('Gagal mengambil session user:', error);
      }
    };

    fetchCurrentUser();

    return () => {
      isMounted = false;
    };
  }, []);

  if (!locationQueryParam) {
    return (
      <div className="w-full bg-white p-8 rounded-2xl border border-slate-200/80 shadow-sm text-center">
        <p className="text-sm text-slate-500 font-medium">Mengarahkan ke pengecekan lokasi...</p>
      </div>
    );
  }

  useEffect(() => {
    if (!selectedLocationId) {
      setAvailableShifts([]);
      setShift('');
      return;
    }

    let isActive = true;

    const loadAvailableShift = async () => {
      try {
        const response = await fetch(`/api/inspections/progress?locationId=${encodeURIComponent(selectedLocationId)}`);
        if (!response.ok) {
          throw new Error('Gagal memeriksa shift aktif untuk lokasi ini.');
        }

        const payload = await response.json();
        const progress = payload?.data;
        if (progress?.requiresMissed) {
          const params = new URLSearchParams({
            locationId: selectedLocationId,
            entryType: progress.missedType || 'shift',
            date: progress.missingDate || '',
            shift: progress.missingShift || '',
            weekStart: progress.missedWeekStart || '',
            weekEnd: progress.missedWeekEnd || '',
          });
          router.replace(`/keterangan?${params.toString()}`);
          return;
        }
        const activeShift = progress?.nextShift ? String(progress.nextShift) : '';
        const effectiveDate = typeof progress?.inspectionDate === 'string' ? progress.inspectionDate : '';

        if (isActive) {
          const available = activeShift ? [activeShift] : [];
          setAvailableShifts(available);
          setShift(activeShift);
          if (effectiveDate) {
            const [year, month, day] = effectiveDate.split('-').map(Number);
            const date = new Date(Date.UTC(year, month - 1, day, 12));
            setServerDateFormatted(new Intl.DateTimeFormat('id-ID', {
              timeZone: 'Asia/Jakarta',
              year: 'numeric',
              month: 'long',
              day: 'numeric',
              weekday: 'long',
            }).format(date));
          }
          setError(activeShift ? null : (progress?.message || 'Shift aktif tidak tersedia untuk lokasi ini pada minggu ini.'));
        }
      } catch (error) {
        console.error('Gagal memuat shift yang tersedia:', error);
        if (isActive) {
          setAvailableShifts([]);
          setShift('');
          setError(error instanceof Error ? error.message : 'Gagal memeriksa shift aktif.');
        }
      }
    };

    loadAvailableShift();
    const intervalId = window.setInterval(loadAvailableShift, 60_000);
    return () => {
      isActive = false;
      window.clearInterval(intervalId);
    };
  }, [selectedLocationId]);

  // Client-side Validation
  const validateForm = (): boolean => {
    if (!selectedLocationId) {
      setError('Lokasi wajib dipilih.');
      return false;
    }

    if (!shift) {
      setError('Shift wajib dipilih.');
      return false;
    }

    if (!availableShifts.includes(shift)) {
      setError('Shift ini sudah terisi untuk lokasi dan minggu yang sama. Silakan pilih shift lain yang masih tersedia.');
      return false;
    }

    if (!checkPersonel) {
      setError('Status personel wajib dipilih.');
      return false;
    }

    if (!checkRuangan) {
      setError('Status ruangan wajib dipilih.');
      return false;
    }

    if (!checkPeralatan) {
      setError('Status peralatan wajib dipilih.');
      return false;
    }

    if (checkPersonel === 'NOK' && !ketPersonel.trim()) {
      setError('Keterangan personel wajib diisi jika status NOK.');
      return false;
    }

    if (checkRuangan === 'NOK' && !ketRuangan.trim()) {
      setError('Keterangan ruangan wajib diisi jika status NOK.');
      return false;
    }

    if (checkPeralatan === 'NOK' && !ketPeralatan.trim()) {
      setError('Keterangan peralatan wajib diisi jika status NOK.');
      return false;
    }

    return true;
  };

  const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setError(null);

    if (!validateForm()) {
      return;
    }

    setIsSubmitting(true);

    const payload = {
      locationId: selectedLocationId,
      shift: shift,

      checkPersonel,
      checkRuangan,
      checkPeralatan,

      ketPersonel: checkPersonel === 'NOK' ? ketPersonel.trim() : '',
      ketRuangan: checkRuangan === 'NOK' ? ketRuangan.trim() : '',
      ketPeralatan: checkPeralatan === 'NOK' ? ketPeralatan.trim() : '',
    };

    try {
      const response = await fetch('/api/inspections', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      });

      if (response.status === 401) {
        router.push('/login');
        return;
      }

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        setError(errorData.message || 'Gagal menyimpan data inspeksi.');
        setIsSubmitting(false);
        return;
      }

      router.push('/report_inspeksi');
    } catch (err) {
      setError('Terjadi kesalahan koneksi ke server. Silakan coba lagi.');
      setIsSubmitting(false);
    }
  };

  return (
    <div className="w-full bg-white p-6 sm:p-8 rounded-2xl border border-slate-200/80 shadow-sm">
      {/* Header Form */}
      <div className="pb-6 border-b border-slate-100">
        <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">Form Inspeksi Kebersihan</h1>
        <p className="text-sm text-slate-500 mt-1">
          Isi formulir inspeksi kebersihan personel, ruangan, dan peralatan.
        </p>
      </div>

      {/* Error Alert */}
      {error && (
        <div className="mt-6 bg-rose-50 border border-rose-200 text-rose-700 p-4 rounded-xl text-sm">
          <p className="font-semibold">Validasi Gagal</p>
          <p className="mt-0.5">{error}</p>
        </div>
      )}

      <form onSubmit={handleSubmit} className="mt-6 space-y-6">
        {/* Info Lokasi & Tanggal */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1.5">
              Tanggal Inspeksi
            </label>
            <input
              type="text"
              readOnly
              value={serverDateFormatted || 'Memuat tanggal...'}
              className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-slate-700 text-sm font-medium cursor-not-allowed focus:outline-none"
            />
          </div>

          <div>
            <label htmlFor="locationId" className="block text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1.5">
              Lokasi Area <span className="text-rose-500">*</span>
            </label>
            <select
              id="locationId"
              name="locationId"
              value={selectedLocationId}
              onChange={(e: ChangeEvent<HTMLSelectElement>) => setSelectedLocationId(e.target.value)}
              disabled={isLocationLoading || isSubmitting || Boolean(locationQueryParam)}
              className="w-full rounded-xl border border-slate-300 bg-white px-3.5 py-2.5 text-slate-800 text-sm focus:border-sky-500 focus:ring-2 focus:ring-sky-500/20 focus:outline-none disabled:bg-slate-100 transition-all"
            >
              <option value="">-- Pilih Lokasi --</option>
              {locations.map((loc) => (
                <option key={loc.id} value={loc.id}>
                  {loc.name} {loc.code ? `(${loc.code})` : ''}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Shift & Paraf User */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label
              htmlFor="shift"
              className="block text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1.5"
            >
              Shift <span className="text-rose-500">*</span>
            </label>

            <select
              id="shift"
              name="shift"
              value={shift}
              onChange={(e: ChangeEvent<HTMLSelectElement>) => setShift(e.target.value)}
              disabled={isSubmitting || availableShifts.length === 0}
              className="w-full rounded-xl border border-slate-300 bg-white px-3.5 py-2.5 text-slate-800 text-sm focus:border-sky-500 focus:ring-2 focus:ring-sky-500/20 focus:outline-none disabled:bg-slate-100 transition-all"
            >
              <option value="">-- Pilih Shift --</option>
              {availableShifts.map((option) => (
                <option key={option} value={option}>
                  Shift {option}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label
              htmlFor="parafUser"
              className="block text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1.5"
            >
              Paraf User
            </label>

            <input
              id="parafUser"
              name="parafUser"
              type="text"
              value={currentUserName || 'Memuat user...'}
              disabled
              readOnly
              className="w-full rounded-xl border border-slate-200 bg-slate-100 px-3.5 py-2.5 text-slate-600 text-sm font-medium cursor-not-allowed focus:outline-none"
            />
          </div>
        </div>

        <div className="pt-2">
          <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-3">Item Pemeriksaan</h2>

          <div className="space-y-4">
            {/* Item 1: Kebersihan Personel */}
            <div className="p-4 sm:p-5 rounded-2xl border border-slate-200/80 bg-slate-50/50 space-y-3">
              <span className="block text-sm font-semibold text-slate-800">
                1. Kebersihan Personel <span className="text-rose-500">*</span>
              </span>

              <div className="grid grid-cols-2 gap-3 w-full sm:max-w-md">
                <label
                  className={`flex items-center justify-center gap-2 p-2.5 rounded-xl border text-sm font-semibold cursor-pointer transition-all ${
                    checkPersonel === 'OK'
                      ? 'bg-emerald-50 border-emerald-500 text-emerald-700 shadow-sm'
                      : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  <input
                    type="radio"
                    name="checkPersonel"
                    value="OK"
                    checked={checkPersonel === 'OK'}
                    onChange={(e: ChangeEvent<HTMLInputElement>) => {
                      setCheckPersonel(e.target.value);
                      if (e.target.value === 'OK') setKetPersonel('');
                    }}
                    disabled={isSubmitting}
                    className="sr-only"
                  />
                  <span>✓ OK</span>
                </label>

                <label
                  className={`flex items-center justify-center gap-2 p-2.5 rounded-xl border text-sm font-semibold cursor-pointer transition-all ${
                    checkPersonel === 'NOK'
                      ? 'bg-rose-50 border-rose-500 text-rose-700 shadow-sm'
                      : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  <input
                    type="radio"
                    name="checkPersonel"
                    value="NOK"
                    checked={checkPersonel === 'NOK'}
                    onChange={(e: ChangeEvent<HTMLInputElement>) => setCheckPersonel(e.target.value)}
                    disabled={isSubmitting}
                    className="sr-only"
                  />
                  <span>✕ NOK (Not OK)</span>
                </label>
              </div>

              {checkPersonel === 'NOK' && (
                <div className="pt-2">
                  <label htmlFor="ketPersonel" className="block text-xs font-semibold text-rose-700 mb-1">
                    Keterangan Personel (Wajib diisi bila NOK) <span className="text-rose-500">*</span>
                  </label>
                  <textarea
                    id="ketPersonel"
                    name="ketPersonel"
                    rows={2}
                    value={ketPersonel}
                    onChange={(e: ChangeEvent<HTMLTextAreaElement>) => setKetPersonel(e.target.value)}
                    disabled={isSubmitting}
                    placeholder="Jelaskan ketidaksesuaian kebersihan personel..."
                    className="w-full rounded-xl border border-rose-300 p-3 text-sm text-slate-800 focus:border-rose-500 focus:ring-2 focus:ring-rose-500/20 focus:outline-none disabled:bg-slate-100"
                  />
                </div>
              )}
            </div>

            {/* Item 2: Kebersihan Ruangan */}
            <div className="p-4 sm:p-5 rounded-2xl border border-slate-200/80 bg-slate-50/50 space-y-3">
              <span className="block text-sm font-semibold text-slate-800">
                2. Kebersihan Ruangan <span className="text-rose-500">*</span>
              </span>

              <div className="grid grid-cols-2 gap-3 w-full sm:max-w-md">
                <label
                  className={`flex items-center justify-center gap-2 p-2.5 rounded-xl border text-sm font-semibold cursor-pointer transition-all ${
                    checkRuangan === 'OK'
                      ? 'bg-emerald-50 border-emerald-500 text-emerald-700 shadow-sm'
                      : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  <input
                    type="radio"
                    name="checkRuangan"
                    value="OK"
                    checked={checkRuangan === 'OK'}
                    onChange={(e: ChangeEvent<HTMLInputElement>) => {
                      setCheckRuangan(e.target.value);
                      if (e.target.value === 'OK') setKetRuangan('');
                    }}
                    disabled={isSubmitting}
                    className="sr-only"
                  />
                  <span>✓ OK</span>
                </label>

                <label
                  className={`flex items-center justify-center gap-2 p-2.5 rounded-xl border text-sm font-semibold cursor-pointer transition-all ${
                    checkRuangan === 'NOK'
                      ? 'bg-rose-50 border-rose-500 text-rose-700 shadow-sm'
                      : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  <input
                    type="radio"
                    name="checkRuangan"
                    value="NOK"
                    checked={checkRuangan === 'NOK'}
                    onChange={(e: ChangeEvent<HTMLInputElement>) => setCheckRuangan(e.target.value)}
                    disabled={isSubmitting}
                    className="sr-only"
                  />
                  <span>✕ NOK (Not OK)</span>
                </label>
              </div>

              {checkRuangan === 'NOK' && (
                <div className="pt-2">
                  <label htmlFor="ketRuangan" className="block text-xs font-semibold text-rose-700 mb-1">
                    Keterangan Ruangan (Wajib diisi bila NOK) <span className="text-rose-500">*</span>
                  </label>
                  <textarea
                    id="ketRuangan"
                    name="ketRuangan"
                    rows={2}
                    value={ketRuangan}
                    onChange={(e: ChangeEvent<HTMLTextAreaElement>) => setKetRuangan(e.target.value)}
                    disabled={isSubmitting}
                    placeholder="Jelaskan ketidaksesuaian kebersihan ruangan..."
                    className="w-full rounded-xl border border-rose-300 p-3 text-sm text-slate-800 focus:border-rose-500 focus:ring-2 focus:ring-rose-500/20 focus:outline-none disabled:bg-slate-100"
                  />
                </div>
              )}
            </div>

            {/* Item 3: Kebersihan Peralatan */}
            <div className="p-4 sm:p-5 rounded-2xl border border-slate-200/80 bg-slate-50/50 space-y-3">
              <span className="block text-sm font-semibold text-slate-800">
                3. Kebersihan Peralatan <span className="text-rose-500">*</span>
              </span>

              <div className="grid grid-cols-2 gap-3 w-full sm:max-w-md">
                <label
                  className={`flex items-center justify-center gap-2 p-2.5 rounded-xl border text-sm font-semibold cursor-pointer transition-all ${
                    checkPeralatan === 'OK'
                      ? 'bg-emerald-50 border-emerald-500 text-emerald-700 shadow-sm'
                      : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  <input
                    type="radio"
                    name="checkPeralatan"
                    value="OK"
                    checked={checkPeralatan === 'OK'}
                    onChange={(e: ChangeEvent<HTMLInputElement>) => {
                      setCheckPeralatan(e.target.value);
                      if (e.target.value === 'OK') setKetPeralatan('');
                    }}
                    disabled={isSubmitting}
                    className="sr-only"
                  />
                  <span>✓ OK</span>
                </label>

                <label
                  className={`flex items-center justify-center gap-2 p-2.5 rounded-xl border text-sm font-semibold cursor-pointer transition-all ${
                    checkPeralatan === 'NOK'
                      ? 'bg-rose-50 border-rose-500 text-rose-700 shadow-sm'
                      : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  <input
                    type="radio"
                    name="checkPeralatan"
                    value="NOK"
                    checked={checkPeralatan === 'NOK'}
                    onChange={(e: ChangeEvent<HTMLInputElement>) => setCheckPeralatan(e.target.value)}
                    disabled={isSubmitting}
                    className="sr-only"
                  />
                  <span>✕ NOK (Not OK)</span>
                </label>
              </div>

              {checkPeralatan === 'NOK' && (
                <div className="pt-2">
                  <label htmlFor="ketPeralatan" className="block text-xs font-semibold text-rose-700 mb-1">
                    Keterangan Peralatan (Wajib diisi bila NOK) <span className="text-rose-500">*</span>
                  </label>
                  <textarea
                    id="ketPeralatan"
                    name="ketPeralatan"
                    rows={2}
                    value={ketPeralatan}
                    onChange={(e: ChangeEvent<HTMLTextAreaElement>) => setKetPeralatan(e.target.value)}
                    disabled={isSubmitting}
                    placeholder="Jelaskan ketidaksesuaian kebersihan peralatan..."
                    className="w-full rounded-xl border border-rose-300 p-3 text-sm text-slate-800 focus:border-rose-500 focus:ring-2 focus:ring-rose-500/20 focus:outline-none disabled:bg-slate-100"
                  />
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="pt-4 flex items-center justify-end gap-3 border-t border-slate-100">
          <button
            type="button"
            onClick={() => router.push('/dashboard')}
            disabled={isSubmitting}
            className="px-5 py-2.5 border border-slate-300 rounded-xl text-sm font-semibold text-slate-700 bg-white hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-sky-500/20 disabled:opacity-50 transition-all"
          >
            Batal
          </button>
          <button
            type="submit"
            disabled={isSubmitting || isLocationLoading}
            className="px-6 py-2.5 rounded-xl text-sm font-semibold text-white bg-sky-600 hover:bg-sky-700 focus:outline-none focus:ring-2 focus:ring-sky-500/20 disabled:bg-slate-300 transition-all shadow-sm"
          >
            {isSubmitting ? 'Menyimpan...' : 'Simpan Inspeksi'}
          </button>
        </div>
      </form>
    </div>
  );
}

export default function FormInspeksiPage() {
  const router = useRouter();
  const [locations, setLocations] = useState<Location[]>([]);
  const [isLocationLoading, setIsLocationLoading] = useState<boolean>(true);
  const [fetchError, setFetchError] = useState<string | null>(null);

  useEffect(() => {
    fetchLocations();
  }, []);

  const fetchLocations = async () => {
    setIsLocationLoading(true);
    setFetchError(null);

    try {
      const response = await fetch('/api/locations', {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (response.status === 401) {
        router.push('/login');
        return;
      }

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        setFetchError(errorData.message || 'Gagal memuat daftar lokasi.');
        setIsLocationLoading(false);
        return;
      }

      const result: { success: boolean; data: Location[] } = await response.json();
      setLocations(result.data || []);
    } catch (err) {
      setFetchError('Terjadi kesalahan koneksi saat mengambil data lokasi.');
    } finally {
      setIsLocationLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Sidebar Navigation */}
      <Suspense fallback={null}>
        <Sidebar />
      </Suspense>

      {/* Main Area */}
      <div className="lg:ml-72 min-h-screen transition-all duration-300">
        <main className="p-4 sm:p-6 lg:p-8">
          {fetchError ? (
            <div className="w-full bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm">
              <div className="bg-rose-50 border border-rose-200 text-rose-700 p-4 rounded-xl text-sm mb-4">
                <p className="font-semibold">Terjadi Kesalahan</p>
                <p className="mt-0.5">{fetchError}</p>
              </div>
              <button
                onClick={fetchLocations}
                className="px-4 py-2 bg-sky-600 hover:bg-sky-700 text-white text-xs font-semibold rounded-xl transition-colors"
              >
                Coba Lagi
              </button>
            </div>
          ) : (
            <Suspense
              fallback={
                <div className="w-full bg-white p-8 rounded-2xl border border-slate-200/80 shadow-sm text-center py-12">
                  <p className="text-sm text-slate-500 font-medium">Memuat formulir inspeksi...</p>
                </div>
              }
            >
              <InspectionFormContent
                locations={locations}
                isLocationLoading={isLocationLoading}
              />
            </Suspense>
          )}
        </main>
      </div>
    </div>
  );
}