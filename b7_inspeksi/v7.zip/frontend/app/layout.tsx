import type { Metadata } from "next";
import "./globals.css";
import SessionGuard from "./session-guard";

export const metadata: Metadata = {
  title: "Mini Apps Logbook Inspeksi Kebersihan Personel, Ruangan dan Peralatan Berbasis Web - PT Bintang Toedjoe",
  description: "Sistem logbook inspeksi kebersihan personel, ruangan, dan peralatan berbasis web untuk Production Area Pulogadung PT Bintang Toedjoe.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="id">
      <body>
        {children}
        <SessionGuard />
      </body>
    </html>
  );
}
