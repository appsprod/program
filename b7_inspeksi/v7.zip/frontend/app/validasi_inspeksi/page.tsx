'use client';

import React, { Suspense, useState, useEffect, useMemo, FormEvent, ChangeEvent } from 'react';
import { useRouter } from 'next/navigation';
import Sidebar from '../sidebar';

interface UserSession {
  id: string;
  name: string;
  username: string;
  role: string;
  department: string;
  site: string;
}

interface Location {
  id: string;
  name: string;
}

interface InspectionRecord {
  id: string;
  date: string;
  createdAt?: string;
  lastEditedAt?: string;
  lastEditedByUsername?: string;
  createdByUsername?: string;
  editCount?: number;
  shift: string;
  locationId: string;
  locationName?: string;
  checkPersonel: string;
  checkRuangan: string;
  checkPeralatan: string;
  ketPersonel?: string;
  ketRuangan?: string;
  ketPeralatan?: string;
  missedEntry?: boolean;
  missedReason?: string;
  status: 'SUBMITTED' | 'SUPERVISOR_APPROVED' | 'APPROVED';
  staffName?: string;
  supervisorName?: string;
}

type ApprovalType = 'SUPERVISOR';
type SortOrder = 'newest' | 'oldest';

const INSPECTIONS_PER_PAGE = 20;
const SHIFT_START_TIMES: Record<string, string> = {
  '1': '06:45:00',
  '2': '15:15:00',
  '3': '22:30:00',
};

function getInspectionTimestamp(inspection: InspectionRecord): number {
  if (!inspection.missedEntry && inspection.createdAt) {
    const createdAt = new Date(inspection.createdAt).getTime();
    if (!Number.isNaN(createdAt)) {
      return createdAt;
    }
  }

  const date = inspection.date.slice(0, 10);
  const shiftStart = SHIFT_START_TIMES[inspection.shift] || '00:00:00';
  const timestamp = Date.parse(`${date}T${shiftStart}+07:00`);
  return Number.isNaN(timestamp) ? 0 : timestamp;
}

function sortInspectionRecords(
  records: InspectionRecord[],
  sortOrder: SortOrder
): InspectionRecord[] {
  return [...records].sort((a, b) => {
    const timeDifference = getInspectionTimestamp(a) - getInspectionTimestamp(b);
    if (timeDifference !== 0) {
      return sortOrder === 'newest' ? -timeDifference : timeDifference;
    }
    return sortOrder === 'newest'
      ? b.id.localeCompare(a.id)
      : a.id.localeCompare(b.id);
  });
}

function getPaginationItems(totalPages: number, currentPage: number): Array<number | 'ellipsis'> {
  const pages = new Set<number>([1, totalPages]);
  for (
    let page = Math.max(1, currentPage - 1);
    page <= Math.min(totalPages, currentPage + 1);
    page += 1
  ) {
    pages.add(page);
  }

  const sortedPages = [...pages].sort((a, b) => a - b);
  const items: Array<number | 'ellipsis'> = [];
  sortedPages.forEach((page, index) => {
    if (index > 0 && page - sortedPages[index - 1] > 1) {
      items.push('ellipsis');
    }
    items.push(page);
  });
  return items;
}

export default function ValidasiInspeksiPage() {
  const router = useRouter();

  // Session & Master Data
  const [currentUser, setCurrentUser] = useState<UserSession | null>(null);
  const [locations, setLocations] = useState<Location[]>([]);

  // Filter States
  const [statusFilter, setStatusFilter] = useState<string>('');
  const [locationFilter, setLocationFilter] = useState<string>('');
  const [dateFilter, setDateFilter] = useState<string>('');
  const [sortOrder, setSortOrder] = useState<SortOrder>('newest');
  const [currentPage, setCurrentPage] = useState<number>(1);

  // Data & UI States
  const [inspections, setInspections] = useState<InspectionRecord[]>([]);
  const [selectedInspection, setSelectedInspection] = useState<InspectionRecord | null>(null);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // Re-login Modal States
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [pendingApprovalType, setPendingApprovalType] = useState<ApprovalType | null>(null);
  const [reloginUsername, setReloginUsername] = useState<string>('');
  const [reloginPassword, setReloginPassword] = useState<string>('');
  const [showReloginPassword, setShowReloginPassword] = useState<boolean>(false);
  const [reloginError, setReloginError] = useState<string | null>(null);
  const [isApproving, setIsApproving] = useState<boolean>(false);
  const sortedInspections = useMemo(() => {
    return sortInspectionRecords(inspections, sortOrder);
  }, [inspections, sortOrder]);
  const totalPages = Math.ceil(sortedInspections.length / INSPECTIONS_PER_PAGE);
  const paginationItems = getPaginationItems(totalPages, currentPage);
  const paginatedInspections = sortedInspections.slice(
    (currentPage - 1) * INSPECTIONS_PER_PAGE,
    currentPage * INSPECTIONS_PER_PAGE
  );

  // Format tanggal inspeksi + waktu dibuat
  const formatInspectionDateTime = (inspection: InspectionRecord) => {
    const parsedDate = new Date(`${inspection.date.slice(0, 10)}T12:00:00Z`);
    const datePart = new Intl.DateTimeFormat('id-ID', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      timeZone: 'Asia/Jakarta',
    }).format(parsedDate);
    const shiftStart = inspection.missedEntry
    ? (SHIFT_START_TIMES[inspection.shift] || '')
      : '';
    const submittedTime = inspection.createdAt
      ? new Intl.DateTimeFormat('en-GB', {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
          hourCycle: 'h23',
          timeZone: 'Asia/Jakarta',
        }).format(new Date(inspection.createdAt))
      : '';
    const timePart = shiftStart || submittedTime;

    return timePart ? `${datePart} ${timePart}` : datePart;
  };

  const formatSubmitDate = (inspection: InspectionRecord) => {
    const editCount = inspection.editCount || 0;
    const timestamp = editCount > 0 && inspection.lastEditedAt
      ? inspection.lastEditedAt
      : inspection.createdAt;
    if (!timestamp) return '-';

    const submittedAt = new Date(timestamp);
    const datePart = new Intl.DateTimeFormat('id-ID', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      timeZone: 'Asia/Jakarta',
    }).format(submittedAt);
    const timePart = new Intl.DateTimeFormat('en-GB', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hourCycle: 'h23',
      timeZone: 'Asia/Jakarta',
    }).format(submittedAt);
    const by = editCount > 0
      ? inspection.lastEditedByUsername
      : inspection.staffName || inspection.createdByUsername;

    return `${datePart} ${timePart} by ${by || '-'}${editCount > 0 ? ` (edited ${editCount}x)` : ''}`;
  };

  // Resolve nama lokasi dari locationId karena API inspections
  // hanya mengembalikan locationId
  const getLocationName = (inspection: InspectionRecord) => {
    if (inspection.locationName?.trim()) {
      return inspection.locationName;
    }

    const location = locations.find((loc) => loc.id === inspection.locationId);

    return location?.name || inspection.locationId || '-';
  };

  const getStatusLabel = (status: InspectionRecord['status']) => {
    if (status === 'SUBMITTED') {
      return 'Menunggu SPV';
    }

    if (status === 'SUPERVISOR_APPROVED') {
      return 'Approved oleh Supervisor';
    }

    return 'Approved';
  };

  const getStatusClass = (status: InspectionRecord['status']) => {
    if (status === 'SUBMITTED') {
      return 'bg-amber-100 text-amber-800';
    }

    if (status === 'SUPERVISOR_APPROVED') {
      return 'bg-sky-100 text-sky-800';
    }

    return 'bg-emerald-100 text-emerald-800';
  };

  const getDetailStatusLabel = (status: InspectionRecord['status']) => {
    if (status === 'SUBMITTED') {
      return 'Status: Menunggu Supervisor';
    }

    if (status === 'SUPERVISOR_APPROVED') {
      return 'Status: Approved oleh Supervisor';
    }

    return 'Status: Final Approved';
  };

  // Initialize Session and Set Default Filter by Role
  useEffect(() => {
    const initPage = async () => {
      try {
        const sessionRes = await fetch('/api/auth/session');

        if (sessionRes.status === 401) {
          router.push('/login');
          return;
        }

        if (sessionRes.ok) {
          const sessionData = await sessionRes.json();
          const user: UserSession = sessionData.user;

          setCurrentUser(user);

          // Restriksi role: Staff tidak diperbolehkan mengakses halaman validasi
          if (user.role === 'staff') {
            setError('Akses ditolak. Staff tidak memiliki kewenangan untuk verifikasi/approval.');
            setIsLoading(false);
            return;
          }

          // Default status filter berdasarkan role
          if (user.role === 'supervisor') {
            setStatusFilter('SUBMITTED');
          } else {
            setStatusFilter('SUBMITTED');
          }
        }

        // Fetch Locations for Filter
        const locRes = await fetch('/api/locations');

        if (locRes.ok) {
          const locData: {
            success: boolean;
            data: Location[];
          } = await locRes.json();

          setLocations(locData.data || []);
        }
      } catch (err) {
        setError('Terjadi kesalahan koneksi saat menginisialisasi halaman.');
      }
    };

    initPage();
  }, [router]);

  // Fetch Inspections List based on Filters
  const fetchInspections = async (
    filters = { status: statusFilter, location: locationFilter, date: dateFilter }
  ) => {
    if (currentUser?.role === 'staff') {
      return;
    }

    setIsLoading(true);
    setError(null);

    const queryParams = new URLSearchParams();

    if (filters.status) {
      queryParams.append('status', filters.status);
    }

    if (filters.location) {
      queryParams.append('location', filters.location);
    }

    if (filters.date) {
      queryParams.append('date', filters.date);
    }

    try {
      const response = await fetch(`/api/inspections?${queryParams.toString()}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (response.status === 401) {
        router.push('/login');
        return;
      }

      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));

        setError(
          errData.message || 'Gagal memuat daftar verifikasi inspeksi.'
        );

        setIsLoading(false);
        return;
      }

      const responseData = await response.json();

      const data: InspectionRecord[] = Array.isArray(responseData)
        ? responseData
        : Array.isArray(responseData.data)
        ? responseData.data
        : [];

      setInspections(data);
      setCurrentPage(1);
      const sortedData = sortInspectionRecords(data, sortOrder);

      // Reset or auto-select first item
      if (data.length > 0) {
        if (
          !selectedInspection ||
          !data.some((item) => item.id === selectedInspection.id)
        ) {
          setSelectedInspection(sortedData[0]);
        } else {
          // Refresh selected detail
          const updatedSelected = data.find(
            (item) => item.id === selectedInspection.id
          );

          if (updatedSelected) {
            setSelectedInspection(updatedSelected);
          }
        }
      } else {
        setSelectedInspection(null);
      }
    } catch (err) {
      setError('Terjadi kesalahan koneksi saat mengambil data inspeksi.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (currentUser && currentUser.role !== 'staff') {
      fetchInspections();
    }
  }, [statusFilter, locationFilter, dateFilter, currentUser]);

  // Open Re-login Modal for Approval Action
  const openApprovalModal = (
    type: ApprovalType,
    inspection = selectedInspection
  ) => {
    if (!inspection) {
      return;
    }

    setSelectedInspection(inspection);
    setPendingApprovalType(type);
    setReloginUsername(currentUser?.username || '');
    setReloginPassword('');
    setShowReloginPassword(false);
    setReloginError(null);
    setIsModalOpen(true);
  };

  const closeApprovalModal = () => {
    setIsModalOpen(false);
    setPendingApprovalType(null);
    setReloginUsername('');
    setReloginPassword('');
    setShowReloginPassword(false);
    setReloginError(null);
    setIsApproving(false);
  };

  // Handle Approval Submission via Re-login Validation
  const handleApprovalSubmit = async (
    e: FormEvent<HTMLFormElement>
  ) => {
    e.preventDefault();

    if (!selectedInspection || !pendingApprovalType) {
      return;
    }

    if (!reloginUsername.trim() || !reloginPassword) {
      setReloginError('Username dan password wajib diisi.');
      return;
    }

    setIsApproving(true);
    setReloginError(null);

    try {
      // Step 1: Re-login Credential Verification
      const reloginRes = await fetch('/api/auth/relogin', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          username: reloginUsername.trim(),
          password: reloginPassword,
        }),
      });

      if (!reloginRes.ok) {
        const errData = await reloginRes.json().catch(() => ({}));

        setReloginError(
          errData.message ||
            'Verifikasi re-login gagal. Kredensial tidak sesuai.'
        );

        setIsApproving(false);
        return;
      }

      // Step 2: Call Specific Approval Endpoint
      const endpoint = `/api/inspections/${selectedInspection.id}/approve/supervisor`;

      const approveRes = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          password: reloginPassword,
        }),
      });

      if (approveRes.status === 401) {
        router.push('/login');
        return;
      }

      if (!approveRes.ok) {
        const errData = await approveRes.json().catch(() => ({}));

        setReloginError(
          errData.message || 'Gagal memproses approval.'
        );

        setIsApproving(false);
        return;
      }

      closeApprovalModal();
      setIsDetailModalOpen(false);
      fetchInspections();
    } catch (err) {
      setReloginError(
        'Terjadi kesalahan sistem saat memproses verifikasi.'
      );

      setIsApproving(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800">
      <Suspense fallback={null}>
        <Sidebar />
      </Suspense>

      <main className="lg:ml-72 min-h-screen p-4 sm:p-6 lg:p-8 space-y-6">
        {/* Page Header */}
        <header className="border-b border-slate-200 pb-4">
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            Validasi & Approval Inspeksi Kebersihan
          </h1>

          <p className="text-sm text-slate-500 mt-1">
            Verifikasi berjenjang logbook inspeksi kebersihan.
            Supervisor approval menjadi status final.
          </p>
        </header>

        {/* Access Denied View for Staff */}
        {currentUser?.role === 'staff' && (
          <div className="bg-white rounded-xl border border-rose-100 p-8 text-center shadow-sm max-w-xl mx-auto my-12 space-y-3">
            <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-rose-50 text-rose-600 font-bold text-xl mb-1">
              !
            </div>

            <h2 className="text-lg font-bold text-slate-900">
              Akses Dibatasi
            </h2>

            <p className="text-sm text-slate-600">
              Anda tidak memiliki wewenang untuk mengakses halaman validasi
              inspeksi ini. Silakan hubungi administrator jika ini adalah
              kesalahan.
            </p>
          </div>
        )}

        {currentUser?.role !== 'staff' && (
          <>
            {/* Filter Controls Card */}
            <section className="bg-white rounded-xl border border-slate-200/80 p-5 shadow-sm space-y-3">
              <div className="text-xs font-semibold tracking-wider text-slate-400 uppercase">
                Filter Data
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Status Validasi
                  </label>

                  <select
                    value={statusFilter}
                    onChange={(e: ChangeEvent<HTMLSelectElement>) => {
                      setStatusFilter(e.target.value);
                      setCurrentPage(1);
                    }}
                    className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-800 shadow-sm transition focus:border-sky-500 focus:outline-none focus:ring-2 focus:ring-sky-500/20"
                  >
                    <option value="">
                      -- Semua Status Validasi --
                    </option>

                    <option value="SUBMITTED">
                      Menunggu Approval Supervisor (SUBMITTED)
                    </option>

                    <option value="APPROVED">
                      Selesai / Final (APPROVED)
                    </option>
                  </select>

                  <label className="mt-3 block text-xs font-medium text-slate-700 mb-1">
                    Urutan Data
                  </label>
                  <select
                    value={sortOrder}
                    onChange={(e: ChangeEvent<HTMLSelectElement>) => {
                      setSortOrder(e.target.value as SortOrder);
                      setCurrentPage(1);
                    }}
                    className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-800 shadow-sm transition focus:border-sky-500 focus:outline-none focus:ring-2 focus:ring-sky-500/20"
                  >
                    <option value="newest">Data Terbaru</option>
                    <option value="oldest">Data Terlama</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Lokasi
                  </label>

                  <select
                    value={locationFilter}
                    onChange={(e: ChangeEvent<HTMLSelectElement>) => {
                      setLocationFilter(e.target.value);
                      setCurrentPage(1);
                    }}
                    className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-800 shadow-sm transition focus:border-sky-500 focus:outline-none focus:ring-2 focus:ring-sky-500/20"
                  >
                    <option value="">-- Semua Lokasi --</option>

                    {locations.map((loc) => (
                      <option key={loc.id} value={loc.id}>
                        {loc.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Tanggal
                  </label>

                  <input
                    type="date"
                    value={dateFilter}
                    onChange={(e: ChangeEvent<HTMLInputElement>) => {
                      setDateFilter(e.target.value);
                      setCurrentPage(1);
                    }}
                    className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-800 shadow-sm transition focus:border-sky-500 focus:outline-none focus:ring-2 focus:ring-sky-500/20"
                  />
                </div>
              </div>
              <div className="flex justify-end border-t border-slate-100 pt-3">
                <button
                  type="button"
                  onClick={() => {
                    setStatusFilter('');
                    setLocationFilter('');
                    setDateFilter('');
                    setSortOrder('newest');
                    setCurrentPage(1);
                  }}
                  disabled={isLoading}
                  className="rounded-lg border border-slate-300 bg-white px-4 py-2 text-xs font-semibold text-slate-700 shadow-sm transition-colors hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-50"
                >
                  Reset
                </button>
              </div>
            </section>

            {/* Error Notification */}
            {error && (
              <div className="bg-rose-50 border border-rose-200 text-rose-800 p-4 rounded-xl text-sm shadow-sm space-y-1">
                <p className="font-semibold">Terjadi Kesalahan</p>
                <p className="text-xs text-rose-700">{error}</p>
              </div>
            )}

            {/* Main Content Grid */}
            <div className="grid grid-cols-1 gap-6 items-start">
              {/* Left Column: Inspection List */}
              <div className="col-span-full bg-white rounded-xl border border-slate-200/80 shadow-sm overflow-hidden flex flex-col">
                <div className="p-4 border-b border-slate-100 bg-slate-50/50 flex items-center justify-between">
                  <div>
                    <h2 className="font-semibold text-slate-900 text-sm">
                      Daftar Antrean Inspeksi
                    </h2>

                    <p className="text-[11px] text-slate-400 mt-0.5">
                      Data berdasarkan filter aktif
                    </p>
                  </div>

                  <span className="bg-rose-100 text-rose-800 text-lg font-bold px-3.5 py-1.5 rounded-full ring-1 ring-inset ring-rose-200">
                    {inspections.length}
                  </span>
                </div>

                <div>
                  {isLoading ? (
                    <div className="text-center py-12 text-xs text-slate-400">
                      Memuat antrean...
                    </div>
                  ) : inspections.length === 0 ? (
                    <div className="text-center py-12 text-xs text-slate-400 px-4">
                      Tidak ada data inspeksi yang memerlukan validasi pada
                      filter ini.
                    </div>
                  ) : (
                    <div>
                    <div className="overflow-x-auto">
                      <table className="w-full text-left border-collapse text-[13px]">
                        <thead>
                          <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold text-xs uppercase tracking-wider">
                            <th className="px-4 py-3">Tanggal / Shift</th>
                            <th className="px-4 py-3">Lokasi</th>
                            <th className="px-4 py-3">Hasil Checklist</th>
                            <th className="px-4 py-3">Submit Date</th>
                            <th className="px-4 py-3">Status</th>
                            <th className="px-4 py-3">Petugas & Verifikator</th>
                            <th className="px-4 py-3 text-right">Aksi</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100 bg-white">
                          {paginatedInspections.map((item) => (
                            <tr key={item.id} className="hover:bg-slate-50/80 transition-colors">
                              <td className="px-4 py-3 whitespace-nowrap">
                                <div className="font-medium text-slate-900">
                                  {formatInspectionDateTime(item)}
                                </div>
                                <div className="text-xs text-slate-500 mt-0.5">
                                  Shift {item.shift}
                                </div>
                              </td>
                              <td className="px-4 py-3 whitespace-nowrap font-medium text-slate-800">
                                {getLocationName(item)}
                                <div className="text-xs text-slate-400 font-mono mt-0.5">
                                  {item.id}
                                </div>
                              </td>
                              <td className="px-4 py-3">
                                <div className="space-y-1 text-[13px]">
                                  <div>
                                    <span className="text-slate-500">Personel: </span>
                                    <span className={item.checkPersonel === 'NOK' ? 'text-rose-600 font-bold' : 'text-emerald-600 font-medium'}>
                                      {item.missedEntry ? `- (${item.missedReason || 'Entry Terlewat'})` : item.checkPersonel || '-'}
                                    </span>
                                    {!item.missedEntry && item.ketPersonel && (
                                      <span className="ml-1 font-medium text-slate-700">
                                        ({item.ketPersonel})
                                      </span>
                                    )}
                                  </div>
                                  <div>
                                    <span className="text-slate-500">Ruangan: </span>
                                    <span className={item.checkRuangan === 'NOK' ? 'text-rose-600 font-bold' : 'text-emerald-600 font-medium'}>
                                      {item.missedEntry ? `- (${item.missedReason || 'Entry Terlewat'})` : item.checkRuangan || '-'}
                                    </span>
                                    {!item.missedEntry && item.ketRuangan && (
                                      <span className="ml-1 font-medium text-slate-700">
                                        ({item.ketRuangan})
                                      </span>
                                    )}
                                  </div>
                                  <div>
                                    <span className="text-slate-500">Peralatan: </span>
                                    <span className={item.checkPeralatan === 'NOK' ? 'text-rose-600 font-bold' : 'text-emerald-600 font-medium'}>
                                      {item.missedEntry ? `- (${item.missedReason || 'Entry Terlewat'})` : item.checkPeralatan || '-'}
                                    </span>
                                    {!item.missedEntry && item.ketPeralatan && (
                                      <span className="ml-1 font-medium text-slate-700">
                                        ({item.ketPeralatan})
                                      </span>
                                    )}
                                  </div>
                                </div>
                              </td>
                              <td className="px-4 py-3 text-[13px] text-slate-700 [overflow-wrap:anywhere]">
                                {formatSubmitDate(item)}
                              </td>
                              <td className="px-4 py-3 whitespace-nowrap">
                                <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${getStatusClass(item.status)}`}>
                                  {getStatusLabel(item.status)}
                                </span>
                              </td>
                              <td className="px-4 py-3 text-[13px] text-slate-600 [overflow-wrap:anywhere]">
                                <div>Staff: {item.staffName || '-'}</div>
                                <div>SPV: {item.supervisorName || '-'}</div>
                              </td>
                              <td className="px-4 py-3 whitespace-nowrap">
                                <div className="flex items-center justify-end gap-2">
                                  <button
                                    type="button"
                                    onClick={() => {
                                      setSelectedInspection(item);
                                      setIsDetailModalOpen(true);
                                    }}
                                    className="rounded-md border border-slate-300 bg-white px-2.5 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 transition-colors"
                                  >
                                    View
                                  </button>
                                  {item.status === 'SUBMITTED' &&
                                    (currentUser?.role === 'supervisor' ||
                                      currentUser?.role === 'administrator') && (
                                      <button
                                        type="button"
                                        onClick={() => openApprovalModal('SUPERVISOR', item)}
                                        className="rounded-md bg-sky-600 px-2.5 py-1.5 text-xs font-medium text-white hover:bg-sky-700 transition-colors"
                                      >
                                        Approve sebagai Supervisor
                                      </button>
                                    )}
                                </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                    {totalPages > 1 && (
                      <div className="flex flex-col gap-3 border-t border-slate-200 bg-slate-50 px-4 py-3 sm:flex-row sm:items-center sm:justify-between">
                        <p className="text-sm text-slate-600">
                          Menampilkan{' '}
                          <span className="font-semibold text-slate-900">
                            {(currentPage - 1) * INSPECTIONS_PER_PAGE + 1}
                          </span>
                          {' '}–{' '}
                          <span className="font-semibold text-slate-900">
                            {Math.min(currentPage * INSPECTIONS_PER_PAGE, sortedInspections.length)}
                          </span>
                          {' '}dari{' '}
                          <span className="font-semibold text-slate-900">{sortedInspections.length}</span>
                          {' '}data
                        </p>
                        <div className="flex flex-wrap items-center justify-center gap-2">
                          <button
                            type="button"
                            onClick={() => setCurrentPage((page) => Math.max(page - 1, 1))}
                            disabled={currentPage === 1}
                            className="rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-sm font-medium text-slate-700 hover:bg-slate-100 disabled:cursor-not-allowed disabled:opacity-50"
                          >
                            Sebelumnya
                          </button>
                          {paginationItems.map((item, index) =>
                            item === 'ellipsis' ? (
                              <span key={`ellipsis-${index}`} className="px-1 text-sm text-slate-400" aria-hidden="true">
                                ...
                              </span>
                            ) : (
                              <button
                                key={item}
                                type="button"
                                aria-current={item === currentPage ? 'page' : undefined}
                                onClick={() => setCurrentPage(item)}
                                className={`min-w-9 rounded-lg border px-3 py-1.5 text-sm font-semibold transition-colors ${
                                  item === currentPage
                                    ? 'border-sky-600 bg-sky-600 text-white'
                                    : 'border-slate-300 bg-white text-slate-700 hover:bg-slate-100'
                                }`}
                              >
                                {item}
                              </button>
                            )
                          )}
                          <button
                            type="button"
                            onClick={() => setCurrentPage((page) => Math.min(page + 1, totalPages))}
                            disabled={currentPage === totalPages}
                            className="rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-sm font-medium text-slate-700 hover:bg-slate-100 disabled:cursor-not-allowed disabled:opacity-50"
                          >
                            Berikutnya
                          </button>
                        </div>
                      </div>
                    )}
                    </div>
                  )}
                </div>
              </div>

              {selectedInspection && isDetailModalOpen && (
                <div className="fixed inset-0 z-40 flex items-center justify-center bg-slate-900/40 p-4 backdrop-blur-sm">
                <div className="max-h-[90vh] w-full max-w-4xl overflow-y-auto rounded-xl border border-slate-200 bg-white p-5 shadow-xl sm:p-6">
                {!selectedInspection ? (
                  <div className="m-auto text-center py-20 text-slate-400 text-xs">
                    Pilih salah satu rekaman inspeksi di sebelah kiri untuk
                    melihat rincian.
                  </div>
                ) : (
                  <div className="space-y-6 w-full">
                    {/* Header Detail */}
                    <div className="border-b border-slate-100 pb-4 flex flex-wrap items-center justify-between gap-3">
                      <div className="min-w-0">
                        <h2 className="text-lg font-bold text-slate-900">
                          Rincian Inspeksi
                        </h2>

                        <p className="text-xs font-mono text-slate-400 mt-0.5 break-all">
                          ID: {selectedInspection.id}
                        </p>
                      </div>

                      <span
                        className={`text-xs font-semibold px-3 py-1 rounded-full ${getStatusClass(
                          selectedInspection.status
                        )}`}
                      >
                        {getDetailStatusLabel(selectedInspection.status)}
                      </span>

                      <button
                        type="button"
                        onClick={() => setIsDetailModalOpen(false)}
                        className="rounded-md border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50"
                      >
                        Tutup
                      </button>
                    </div>

                    {/* Metadata Grid */}
                    <div className="bg-slate-50 rounded-lg border border-slate-100 overflow-hidden">
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
                        <div className="p-4 border-b border-slate-100 sm:border-r">
                          <span className="text-[10px] uppercase tracking-wide text-slate-400 block mb-1">
                            Tanggal & Waktu
                          </span>

                          <span className="font-semibold text-sm text-slate-800">
                            {formatInspectionDateTime(selectedInspection)}
                          </span>
                        </div>

                        <div className="p-4 border-b border-slate-100 lg:border-r">
                          <span className="text-[10px] uppercase tracking-wide text-slate-400 block mb-1">
                            Shift
                          </span>

                          <span className="font-semibold text-sm text-slate-800">
                            Shift {selectedInspection.shift}
                          </span>
                        </div>

                        <div className="p-4 border-b border-slate-100 sm:border-r lg:border-r-0">
                          <span className="text-[10px] uppercase tracking-wide text-slate-400 block mb-1">
                            Lokasi
                          </span>

                          <span className="font-semibold text-sm text-slate-800">
                            {getLocationName(selectedInspection)}
                          </span>
                        </div>

                        <div className="p-4 border-b border-slate-100 sm:border-r lg:border-b-0">
                          <span className="text-[10px] uppercase tracking-wide text-slate-400 block mb-1">
                            Dibuat Oleh (Staff)
                          </span>

                          <span className="font-medium text-sm text-slate-800">
                            {selectedInspection.staffName || '-'}
                          </span>
                        </div>

                        <div className="p-4 border-b border-slate-100 lg:border-b-0 lg:border-r">
                          <span className="text-[10px] uppercase tracking-wide text-slate-400 block mb-1">
                            Verifikator Supervisor
                          </span>

                          <span className="font-medium text-sm text-slate-800">
                            {selectedInspection.supervisorName || '-'}
                          </span>
                        </div>

                      </div>
                    </div>

                    {/* Checklist Items */}
                    <div className="space-y-3">
                      <div>
                        <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
                          Hasil Pemeriksaan Kebersihan
                        </h3>

                        <p className="text-[11px] text-slate-400 mt-1">
                          Detail hasil pemeriksaan dari logbook inspeksi.
                        </p>
                      </div>

                      {/* Personel */}
                      <div className="p-3.5 border border-slate-200/80 rounded-lg bg-slate-50/30 space-y-2">
                        <div className="flex items-center justify-between gap-3 text-xs">
                          <span className="font-medium text-slate-700">
                            1. Kebersihan Personel
                          </span>

                          <span
                            className={`font-bold px-2 py-0.5 rounded text-[11px] ${
                              selectedInspection.checkPersonel === 'NOK'
                                ? 'bg-rose-100 text-rose-700'
                                : 'bg-emerald-100 text-emerald-700'
                            }`}
                          >
                            {selectedInspection.missedEntry
                              ? `- (${selectedInspection.missedReason || 'Entry Terlewat'})`
                              : selectedInspection.checkPersonel || '-'}
                          </span>
                        </div>

                        {selectedInspection.ketPersonel && (
                          <div className="text-xs text-rose-700 bg-rose-50 border border-rose-100 p-2 rounded-md mt-1">
                            <strong>Keterangan:</strong>{' '}
                            {selectedInspection.ketPersonel}
                          </div>
                        )}
                      </div>

                      {/* Ruangan */}
                      <div className="p-3.5 border border-slate-200/80 rounded-lg bg-slate-50/30 space-y-2">
                        <div className="flex items-center justify-between gap-3 text-xs">
                          <span className="font-medium text-slate-700">
                            2. Kebersihan Ruangan
                          </span>

                          <span
                            className={`font-bold px-2 py-0.5 rounded text-[11px] ${
                              selectedInspection.checkRuangan === 'NOK'
                                ? 'bg-rose-100 text-rose-700'
                                : 'bg-emerald-100 text-emerald-700'
                            }`}
                          >
                            {selectedInspection.missedEntry
                              ? `- (${selectedInspection.missedReason || 'Entry Terlewat'})`
                              : selectedInspection.checkRuangan || '-'}
                          </span>
                        </div>

                        {selectedInspection.ketRuangan && (
                          <div className="text-xs text-rose-700 bg-rose-50 border border-rose-100 p-2 rounded-md mt-1">
                            <strong>Keterangan:</strong>{' '}
                            {selectedInspection.ketRuangan}
                          </div>
                        )}
                      </div>

                      {/* Peralatan */}
                      <div className="p-3.5 border border-slate-200/80 rounded-lg bg-slate-50/30 space-y-2">
                        <div className="flex items-center justify-between gap-3 text-xs">
                          <span className="font-medium text-slate-700">
                            3. Kebersihan Peralatan
                          </span>

                          <span
                            className={`font-bold px-2 py-0.5 rounded text-[11px] ${
                              selectedInspection.checkPeralatan === 'NOK'
                                ? 'bg-rose-100 text-rose-700'
                                : 'bg-emerald-100 text-emerald-700'
                            }`}
                          >
                            {selectedInspection.missedEntry
                              ? `- (${selectedInspection.missedReason || 'Entry Terlewat'})`
                              : selectedInspection.checkPeralatan || '-'}
                          </span>
                        </div>

                        {selectedInspection.ketPeralatan && (
                          <div className="text-xs text-rose-700 bg-rose-50 border border-rose-100 p-2 rounded-md mt-1">
                            <strong>Keterangan:</strong>{' '}
                            {selectedInspection.ketPeralatan}
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Action Panel Footer */}
                    <div className="pt-4 border-t border-slate-100 flex flex-wrap items-center justify-end gap-3">
                      {/* Supervisor Action Button */}
                      {selectedInspection.status === 'SUBMITTED' &&
                        (currentUser?.role === 'supervisor' ||
                          currentUser?.role === 'administrator') && (
                          <button
                            type="button"
                            onClick={() =>
                              openApprovalModal('SUPERVISOR')
                            }
                            className="px-4 py-2 bg-sky-600 hover:bg-sky-700 text-white font-medium text-xs rounded-lg shadow-sm transition"
                          >
                            Approve sebagai Supervisor
                          </button>
                        )}

                      {selectedInspection.status ===
                        'SUPERVISOR_APPROVED' &&
                        (currentUser?.role === 'supervisor' ||
                          currentUser?.role === 'manager' ||
                          currentUser?.role === 'administrator') && (
                          <p className="text-xs text-sky-700 italic bg-sky-50 px-3 py-2 rounded-lg border border-sky-200/60 w-full text-right">
                            Telah disetujui Supervisor dan berstatus final.
                          </p>
                        )}

                      {selectedInspection.status === 'APPROVED' && (
                        <p className="text-xs text-emerald-700 font-medium bg-emerald-50 px-3 py-2 rounded-lg border border-emerald-200/60 w-full text-right">
                          Pemeriksaan telah selesai diverifikasi sepenuhnya
                          (APPROVED).
                        </p>
                      )}
                    </div>
                  </div>
                )}
                </div>
                </div>
              )}
            </div>
          </>
        )}
      </main>

      {/* Re-login Modal Dialog */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-xl border border-slate-200 shadow-xl max-w-md w-full p-6 space-y-4">
            <div className="border-b border-slate-100 pb-3">
              <h3 className="text-base font-bold text-slate-900">
                Konfirmasi Otorisasi (Re-login)
              </h3>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              Silakan masukkan kredensial Anda untuk memverifikasi tindakan
              approval{' '}
              <strong className="text-slate-900">
                Supervisor
              </strong>
              .
            </p>

            {reloginError && (
              <div className="bg-rose-50 border border-rose-200 text-rose-700 p-3 rounded-lg text-xs">
                {reloginError}
              </div>
            )}

            <form
              onSubmit={handleApprovalSubmit}
              className="space-y-4"
            >
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Username
                </label>

                <input
                  type="text"
                  value={reloginUsername}
                  onChange={(e: ChangeEvent<HTMLInputElement>) =>
                    setReloginUsername(e.target.value)
                  }
                  disabled={isApproving}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 shadow-sm transition focus:border-sky-500 focus:outline-none focus:ring-2 focus:ring-sky-500/20 disabled:bg-slate-100"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Password
                </label>

                <div className="relative">
                  <input
                    type={showReloginPassword ? 'text' : 'password'}
                    value={reloginPassword}
                    onChange={(e: ChangeEvent<HTMLInputElement>) =>
                      setReloginPassword(e.target.value)
                    }
                    disabled={isApproving}
                    placeholder="Masukkan password Anda"
                    className="w-full rounded-lg border border-slate-300 py-2 pl-3 pr-10 text-sm text-slate-900 shadow-sm transition focus:border-sky-500 focus:outline-none focus:ring-2 focus:ring-sky-500/20 disabled:bg-slate-100"
                  />
                  <button
                    type="button"
                    onClick={() => setShowReloginPassword((visible) => !visible)}
                    disabled={isApproving}
                    className="absolute inset-y-0 right-0 flex items-center px-3 text-slate-400 transition-colors hover:text-slate-600 focus:outline-none disabled:cursor-not-allowed"
                    aria-label={showReloginPassword ? 'Sembunyikan password' : 'Tampilkan password'}
                    aria-pressed={showReloginPassword}
                  >
                    {showReloginPassword ? (
                      <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={1.8}
                          d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858-5.908a10.016 10.016 0 013.682-.763c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m-1.565 1.565L3 3l18 18"
                        />
                      </svg>
                    ) : (
                      <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={1.8}
                          d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"
                        />
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={1.8}
                          d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"
                        />
                      </svg>
                    )}
                  </button>
                </div>
              </div>

              <div className="flex justify-end space-x-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={closeApprovalModal}
                  disabled={isApproving}
                  className="px-3.5 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition disabled:opacity-50"
                >
                  Batal
                </button>

                <button
                  type="submit"
                  disabled={isApproving}
                  className="px-3.5 py-2 text-xs font-medium text-white bg-sky-600 hover:bg-sky-700 rounded-lg transition disabled:bg-sky-300"
                >
                  {isApproving
                    ? 'Memproses...'
                    : 'Konfirmasi & Approve'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
