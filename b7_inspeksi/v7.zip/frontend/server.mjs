import { createServer } from 'node:http';
import { parse } from 'node:url';
import next from 'next';

const dev = process.argv.includes('--dev');
const hostname = '0.0.0.0';
const port = Number(process.env.PORT || 2025);

function normalizeAddress(address) {
  if (!address) {
    return '';
  }

  if (address.startsWith('::ffff:')) {
    return address.slice(7);
  }

  return address;
}

const app = next({ dev, hostname, port });
const handle = app.getRequestHandler();

await app.prepare();

createServer((request, response) => {
  const clientIp = normalizeAddress(request.socket.remoteAddress);

  if (clientIp) {
    request.headers['x-client-ip'] = clientIp;
  }

  handle(request, response, parse(request.url, true));
}).listen(port, hostname, () => {
  console.log(`Frontend siap di http://${hostname}:${port}`);
});
