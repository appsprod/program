import { NextRequest, NextResponse } from 'next/server';

export function proxy(request: NextRequest) {
  const forwardedHeaders = new Headers(request.headers);
  const clientIpHeader = request.headers.get('x-client-ip');
  const forwardedFor = request.headers.get('x-forwarded-for');
  const realIp = request.headers.get('x-real-ip');
  const requestWithIp = request as NextRequest & { ip?: string };
  const clientIp = clientIpHeader || forwardedFor?.split(',')[0]?.trim() || realIp || requestWithIp.ip;

  if (clientIp) {
    forwardedHeaders.set('x-client-ip', clientIp);
  }

  return NextResponse.next({
    request: {
      headers: forwardedHeaders,
    },
  });
}

export const config = {
  matcher: '/api/:path*',
};