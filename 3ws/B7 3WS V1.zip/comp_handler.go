package main

import (
	"context"
	"database/sql"
	"encoding/json"
	"net/http"
	"strconv"
	"strings"
)

type CompoundingHandler struct {
	service *CompoundingService
}

func NewCompoundingHandler(
	service *CompoundingService,
) *CompoundingHandler {
	return &CompoundingHandler{
		service: service,
	}
}

func (h *CompoundingHandler) GetBatches(
	w http.ResponseWriter,
	r *http.Request,
) {
	if r.Method != http.MethodGet {
		http.Error(
			w,
			"method not allowed",
			http.StatusMethodNotAllowed,
		)
		return
	}

	page := 1
	limit := 30

	if value := r.URL.Query().Get("page"); value != "" {
		if parsed, err := strconv.Atoi(value); err == nil &&
			parsed > 0 {
			page = parsed
		}
	}

	if value := r.URL.Query().Get("limit"); value != "" {
		if parsed, err := strconv.Atoi(value); err == nil &&
			parsed > 0 &&
			parsed <= 100 {
			limit = parsed
		}
	}

	data, total, totalPages, err :=
		h.service.GetBatches(
			r.Context(),
			page,
			limit,
		)

	if err != nil {
		writeCompoundingJSON(
			w,
			http.StatusInternalServerError,
			map[string]interface{}{
				"success": false,
				"error":   err.Error(),
			},
		)
		return
	}

	writeCompoundingJSON(
		w,
		http.StatusOK,
		CompoundingListResponse{
			Success:    true,
			Data:       data,
			Page:       page,
			Limit:      limit,
			Total:      total,
			TotalPages: totalPages,
		},
	)
}

func (h *CompoundingHandler) ReceiveEvent(
	w http.ResponseWriter,
	r *http.Request,
) {
	if r.Method != http.MethodPost {
		http.Error(
			w,
			"method not allowed",
			http.StatusMethodNotAllowed,
		)
		return
	}

	var event CompoundingEvent

	if err := json.NewDecoder(
		r.Body,
	).Decode(&event); err != nil {
		writeCompoundingJSON(
			w,
			http.StatusBadRequest,
			map[string]interface{}{
				"success": false,
				"error":   "invalid JSON",
			},
		)
		return
	}

	if event.Process != "" &&
		event.Process != "COMPOUNDING" {
		writeCompoundingJSON(
			w,
			http.StatusBadRequest,
			map[string]interface{}{
				"success": false,
				"error":   "invalid process",
			},
		)
		return
	}

	switch strings.ToUpper(
		event.EventType,
	) {
	case "START":
		if err := h.service.Start(
			r.Context(),
			&event,
		); err != nil {
			writeCompoundingJSON(
				w,
				http.StatusInternalServerError,
				map[string]interface{}{
					"success": false,
					"error":   err.Error(),
				},
			)
			return
		}

	case "END":
		if err := h.service.Complete(
			r.Context(),
			&event,
		); err != nil {
			writeCompoundingJSON(
				w,
				http.StatusInternalServerError,
				map[string]interface{}{
					"success": false,
					"error":   err.Error(),
				},
			)
			return
		}

	default:
		writeCompoundingJSON(
			w,
			http.StatusBadRequest,
			map[string]interface{}{
				"success": false,
				"error":   "unsupported event_type",
			},
		)
		return
	}

	writeCompoundingJSON(
		w,
		http.StatusOK,
		map[string]interface{}{
			"success": true,
		},
	)
}

func (h *CompoundingHandler) ReceiveProgress(
	w http.ResponseWriter,
	r *http.Request,
) {
	if r.Method != http.MethodPost {
		http.Error(
			w,
			"method not allowed",
			http.StatusMethodNotAllowed,
		)
		return
	}

	var event CompoundingEvent

	if err := json.NewDecoder(
		r.Body,
	).Decode(&event); err != nil {
		writeCompoundingJSON(
			w,
			http.StatusBadRequest,
			map[string]interface{}{
				"success": false,
				"error":   "invalid JSON",
			},
		)
		return
	}

	if event.EventType != "" &&
		strings.ToUpper(event.EventType) != "PROGRESS" {
		writeCompoundingJSON(
			w,
			http.StatusBadRequest,
			map[string]interface{}{
				"success": false,
				"error":   "invalid event_type",
			},
		)
		return
	}

	if err := h.service.Progress(
		r.Context(),
		&event,
	); err != nil {

		if strings.Contains(
			err.Error(),
			"belum START",
		) {
			writeCompoundingJSON(
				w,
				http.StatusConflict,
				map[string]interface{}{
					"success": false,
					"error":   err.Error(),
				},
			)
			return
		}

		writeCompoundingJSON(
			w,
			http.StatusInternalServerError,
			map[string]interface{}{
				"success": false,
				"error":   err.Error(),
			},
		)
		return
	}

	writeCompoundingJSON(
		w,
		http.StatusOK,
		map[string]interface{}{
			"success": true,
		},
	)
}

func writeCompoundingJSON(
	w http.ResponseWriter,
	status int,
	payload interface{},
) {
	w.Header().Set(
		"Content-Type",
		"application/json",
	)

	w.WriteHeader(status)

	_ = json.NewEncoder(w).Encode(payload)
}

func ensureCompoundingSchema(
	db *sql.DB,
) error {
	repo := NewCompoundingRepository(db)

	return repo.EnsureSchema(
		context.Background(),
	)
}
