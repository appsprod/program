import os
import time
import json
import uuid
import socket
import threading
import ctypes
from datetime import datetime, timezone
from pynput import mouse

from validator import validate_capture_data
from batch_pc import BatchPCRecorder
from capture_core import (
    CONFIG_PATH,
    DB_PATH,
    BATCH_HISTORY_PATH,
    DEFAULT_SERVER_URL,
    HEARTBEAT_INTERVAL,
    EXTRACTION_INTERVAL,
    QUEUE_FLUSH_INTERVAL,
    normalize_text,
    parse_pallet_suffix,
    parse_nomor_mb,
    get_element_value,
    SQLiteQueue,
    APIClient,
    UIAExtractor,
)

# ============================================================
# SINGLE INSTANCE GUARD (MUTEX)
# ============================================================
_SINGLE_INSTANCE_MUTEX_NAME = r"Global\B7_3WS_CaptureAgent"

def acquire_single_instance():
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

    CreateMutexW = kernel32.CreateMutexW
    CreateMutexW.argtypes = [
        ctypes.c_void_p,
        ctypes.c_bool,
        ctypes.c_wchar_p,
    ]
    CreateMutexW.restype = ctypes.c_void_p

    ERROR_ALREADY_EXISTS = 183

    mutex_handle = CreateMutexW(
        None,
        False,
        _SINGLE_INSTANCE_MUTEX_NAME,
    )

    if not mutex_handle:
        raise ctypes.WinError(ctypes.get_last_error())

    if ctypes.get_last_error() == ERROR_ALREADY_EXISTS:
        kernel32.CloseHandle(mutex_handle)
        return None

    return mutex_handle

# ============================================================
# BATCH HISTORY & CONFIG
# ============================================================
def update_batch_history(batch_identity_key, batch_data):
    try:
        history = []
        if os.path.exists(BATCH_HISTORY_PATH):
            try:
                with open(BATCH_HISTORY_PATH, "r", encoding="utf-8") as f:
                    history = json.load(f)
                if not isinstance(history, list):
                    history = []
            except Exception:
                history = []

        existing_index = -1
        for idx, item in enumerate(history):
            if item.get("identity") == batch_identity_key:
                existing_index = idx
                break

        now = datetime.now(timezone.utc).isoformat()
        if existing_index >= 0:
            history[existing_index]["updated_at"] = now
            history[existing_index]["data"] = batch_data
        else:
            history.append({
                "identity": batch_identity_key,
                "created_at": now,
                "updated_at": now,
                "data": batch_data
            })

        history.sort(key=lambda x: x.get("updated_at", ""))
        if len(history) > 5:
            history = history[-5:]

        with open(BATCH_HISTORY_PATH, "w", encoding="utf-8") as f:
            json.dump(history, f, indent=2, ensure_ascii=False)
    except Exception:
        pass

def load_or_create_config():
    current_hostname = socket.gethostname()
    generated_agent_id = str(uuid.uuid4())
    config = {
        "agent_id": generated_agent_id,
        "server_url": DEFAULT_SERVER_URL,
        "hostname": current_hostname
    }
    if os.path.exists(CONFIG_PATH):
        try:
            with open(CONFIG_PATH, "r", encoding="utf-8") as f:
                saved_config = json.load(f)
            if isinstance(saved_config, dict):
                saved_hostname = normalize_text(saved_config.get("hostname", ""))
                saved_agent_id = normalize_text(saved_config.get("agent_id", ""))
                saved_server_url = normalize_text(saved_config.get("server_url", ""))

                if saved_agent_id and saved_hostname and saved_hostname.lower() == current_hostname.lower():
                    config["agent_id"] = saved_agent_id
                else:
                    config["agent_id"] = generated_agent_id

                if saved_server_url:
                    config["server_url"] = saved_server_url
                config["hostname"] = current_hostname
        except Exception:
            config = {
                "agent_id": generated_agent_id,
                "server_url": DEFAULT_SERVER_URL,
                "hostname": current_hostname
            }
    try:
        with open(CONFIG_PATH, "w", encoding="utf-8") as f:
            json.dump(config, f, indent=2)
    except Exception:
        pass
    return config

# ============================================================
# SESSION ENGINE
# ============================================================
class SessionEngine:
    def __init__(self, queue, agent_id, api_client):
        self.queue = queue
        self.agent_id = agent_id
        self.api_client = api_client
        self.current_identity = None
        self.session_active = False
        self.has_start_event = False
        self.last_extracted_data = {}
        self.last_progress_pallet = None
        self.last_progress_nomor_mb = None
        self.last_progress_monotonic = None
        self.pending_end_trigger = False
        self.end_click_timestamp = None
        self.end_type_label = ""
        # State lifecycle per batch identity untuk menangani switch/resume
        self.batch_sessions = {}

    def _save_batch_session(self):
        if not self.current_identity:
            return

        self.batch_sessions[self.current_identity] = {
            "has_start_event": self.has_start_event,
            "last_extracted_data": dict(self.last_extracted_data),
            "last_progress_pallet": self.last_progress_pallet,
            "last_progress_nomor_mb": self.last_progress_nomor_mb,
            "last_progress_monotonic": self.last_progress_monotonic,
            "session_active": self.session_active,
        }

    def _restore_batch_session(self, identity):
        state = self.batch_sessions.get(identity)
        if not state:
            return False

        self.current_identity = identity
        self.session_active = state.get("session_active", False)
        self.has_start_event = state.get("has_start_event", False)
        self.last_extracted_data = dict(
            state.get("last_extracted_data", {})
        )
        self.last_progress_pallet = state.get("last_progress_pallet")
        self.last_progress_nomor_mb = state.get(
            "last_progress_nomor_mb"
        )
        self.last_progress_monotonic = state.get(
            "last_progress_monotonic",
            time.monotonic(),
        )

        return True

    def process_extraction(self, data):
        if not data:
            return

        work_order = data.get("work_order", "").strip()
        batch = data.get("batch", "").strip()
        formula = data.get("formula", "").strip()
        product_code = data.get("product_code", "").strip()
        work_station = normalize_text(data.get("work_station", ""))

        if not work_order or not (batch or formula or product_code):
            return

        identity = f"{work_order}|{batch}|{formula}|{work_station}"
        now_iso = datetime.now(timezone.utc).isoformat()

        if self.session_active and self._is_same_active_identity(data) and self._is_incomplete_mb_fallback_trigger(data):
            print("[SESSION] Incomplete MB fallback trigger fired")
            end_time = datetime.now(timezone.utc).isoformat()
            fallback_data = dict(self.last_extracted_data or data)
            success = self._emit_event(
                "END",
                "start process" if self.has_start_event else "mid process",
                "incomplete_mb_fallback_trigger",
                fallback_data,
                end_time,
            )
            if success:
                self._reset_session()
                return

        # ============================================================
        # CASE 1: TIDAK ADA SESSION AKTIF
        # ============================================================
        if not self.session_active:
            print(
                f"[SESSION] Starting identity: {identity}"
            )

            # --------------------------------------------------------
            # Jangan percaya local cache sebagai source of truth.
            # Backend tetap harus dicek karena batch mungkin:
            # - masih Running
            # - sudah Idle (runtime status)
            # - pernah kena ghost END lalu direopen
            # - sudah Completed
            # --------------------------------------------------------
            if self._recover_identity(data, identity):
                return

            # --------------------------------------------------------
            # Backend lookup gagal.
            # Hanya jika identity belum dapat direcover, mulai
            # session baru berdasarkan kondisi UI saat ini.
            # --------------------------------------------------------
            self.session_active = True
            self.current_identity = identity
            self.last_extracted_data = dict(data)
            self.last_progress_pallet = normalize_text(
                data.get("pallet", "")
            )
            self.last_progress_nomor_mb = normalize_text(
                data.get("nomor_mb", "")
            )
            self.last_progress_monotonic = time.monotonic()

            if self._check_start_condition(data):
                self.has_start_event = True

                self._emit_event(
                    "START",
                    "start process",
                    "",
                    data,
                    now_iso,
                )
            else:
                self.has_start_event = False

                self._emit_event(
                    "MID_PROCESS",
                    "mid process",
                    "",
                    data,
                    now_iso,
                )

            self._save_batch_session()
            update_batch_history(
                self.current_identity,
                data,
            )

            return

        # ============================================================
        # CASE 2: IDENTITY SAMA
        # ============================================================
        if (
            self.session_active
            and self.current_identity == identity
        ):
            previous_data = dict(
                self.last_extracted_data
            )

            self.last_extracted_data = dict(data)

            # --------------------------------------------------------
            # START hanya boleh terjadi satu kali dalam lifecycle session.
            # --------------------------------------------------------
            if (
                not self.has_start_event
                and self._check_start_condition(data)
            ):
                self.has_start_event = True

                self._emit_event(
                    "START",
                    "start process",
                    "",
                    data,
                    now_iso,
                )

            # --------------------------------------------------------
            # Progress normal: pallet berubah ATAU nomor MB berubah.
            # --------------------------------------------------------
            self._process_progress(
                previous_data,
                data,
            )

            self._save_batch_session()

            update_batch_history(
                self.current_identity,
                data,
            )

            return

        # ============================================================
        # CASE 3: IDENTITY BERUBAH
        # ============================================================
        if (
            self.session_active
            and self.current_identity != identity
        ):
            # Simpan state batch lama sebelum pindah.
            self._save_batch_session()

            previous_identity = self.current_identity

            previous_data = dict(self.last_extracted_data)
            if self._should_auto_end_on_identity_change(
                previous_data,
                data,
            ):
                end_time = datetime.now(timezone.utc).isoformat()
                success = self._emit_event(
                    "END",
                    "start process" if self.has_start_event else "mid process",
                    "idle auto-end after batch identity change",
                    previous_data,
                    end_time,
                )
                if success:
                    print(
                        f"[SESSION] Auto-ended idle batch after identity change: "
                        f"{previous_identity} -> {identity}"
                    )
                    self._reset_session()
                    return

            print(
                f"[SESSION] Switching batch: "
                f"{previous_identity} -> {identity}"
            )

            # --------------------------------------------------------
            # Backend menjadi source of truth untuk batch tujuan.
            # _recover_identity() juga akan membandingkan progress
            # server dengan UI terbaru.
            # --------------------------------------------------------
            if self._recover_identity(data, identity):
                return

            print(
                f"[SESSION] Identity recovery failed. "
                f"Keeping current identity: "
                f"{previous_identity}"
            )

            return

    def _recover_identity(self, data, identity):
        work_order = normalize_text(
            data.get("work_order", "")
        )
        batch = normalize_text(
            data.get("batch", "")
        )
        formula = normalize_text(
            data.get("formula", "")
        )
        work_station = normalize_text(
            data.get("work_station", "")
        )

        if (
            not work_order
            or not batch
            or not formula
            or not work_station
        ):
            return False

        try:
            batch_record, err_msg = (
                self.api_client.get_batch_by_identity(
                    work_order,
                    batch,
                    formula,
                    work_station,
                )
            )

            if err_msg:
                print(
                    f"[SESSION] Identity lookup failed "
                    f"WO={work_order} "
                    f"Batch={batch} "
                    f"Formula={formula} "
                    f"WorkStation={work_station}: "
                    f"{err_msg}"
                )
                return False

            # ========================================================
            # EXISTING BATCH
            # ========================================================
            if batch_record:
                server_status = normalize_text(
                    batch_record.get("status", "")
                ).lower()

                if server_status == "completed":
                    print(
                        f"[SESSION] Skip recover completed batch: {identity}"
                    )
                    return False

                print(
                    f"[SESSION] Re-attaching existing batch: "
                    f"{identity}"
                )

                server_start_type = normalize_text(
                    batch_record.get(
                        "start_type",
                        "",
                    )
                ).lower()

                server_pallet = normalize_text(
                    batch_record.get(
                        "pallet",
                        "",
                    )
                )

                server_nomor_mb = normalize_text(
                    batch_record.get(
                        "nomor_mb",
                        "",
                    )
                )

                current_pallet = normalize_text(
                    data.get(
                        "pallet",
                        "",
                    )
                )

                current_nomor_mb = normalize_text(
                    data.get(
                        "nomor_mb",
                        "",
                    )
                )

                # ----------------------------------------------------
                # Backend adalah source of truth lifecycle.
                # Jangan ubah START menjadi MID saat reattach.
                # ----------------------------------------------------
                self.current_identity = identity
                self.session_active = True

                # ============================================================
                # RESTORE START STATE
                # ============================================================
                # START yang sudah tersimpan di backend tetap authoritative.
                # Tetapi jika backend masih MID dan UI sekarang sudah mencapai
                # kondisi START (Pallet 01 + MB 0002), upgrade lifecycle ke START.
                # ============================================================
                server_has_start = (
                    server_start_type == "start process"
                )

                current_has_start = self._check_start_condition(data)

                self.has_start_event = (
                    server_has_start or current_has_start
                )

                if (
                    not server_has_start
                    and current_has_start
                ):
                    print(
                        f"[SESSION] Existing batch reached START condition: "
                        f"{identity} "
                        f"pallet={current_pallet} "
                        f"nomor_mb={current_nomor_mb}"
                    )

                    self._emit_event(
                        "START",
                        "start process",
                        "",
                        data,
                        datetime.now(
                            timezone.utc
                        ).isoformat(),
                    )

                # ----------------------------------------------------
                # Backend menjadi baseline progress.
                # ----------------------------------------------------
                self.last_progress_pallet = server_pallet
                self.last_progress_nomor_mb = (
                    server_nomor_mb
                )
                self.last_progress_monotonic = self._get_progress_time(
                    batch_record.get("updated_at")
                )

                # Data terbaru dari UI tetap disimpan.
                self.last_extracted_data = dict(data)

                # ----------------------------------------------------
                # Simpan cache lokal.
                # ----------------------------------------------------
                self.batch_sessions[identity] = {
                    "has_start_event":
                        self.has_start_event,

                    "last_extracted_data":
                        dict(data),

                    "last_progress_pallet":
                        server_pallet,

                    "last_progress_nomor_mb":
                        server_nomor_mb,

                    "last_progress_monotonic":
                        self.last_progress_monotonic,

                    "session_active": True,
                }

                update_batch_history(
                    identity,
                    data,
                )

                # ----------------------------------------------------
                # IMPORTANT:
                # Server: MB 0010
                # UI sekarang: MB 0011
                # Maka progress 0011 HARUS dikirim.
                # Kalau sama, jangan kirim duplicate.
                # ----------------------------------------------------
                progress_changed = (
                    current_pallet != server_pallet
                    or current_nomor_mb != server_nomor_mb
                )

                if progress_changed:
                    print(
                        f"[SESSION] Resumed batch has new progress: "
                        f"{server_pallet}/{server_nomor_mb} "
                        f"-> "
                        f"{current_pallet}/{current_nomor_mb}"
                    )

                    self.last_progress_pallet = (
                        current_pallet
                    )

                    self.last_progress_nomor_mb = (
                        current_nomor_mb
                    )
                    self.last_progress_monotonic = time.monotonic()

                    self._emit_event(
                        "PROGRESS",
                        "",
                        "",
                        data,
                        datetime.now(
                            timezone.utc
                        ).isoformat(),
                    )

                    # Update cache setelah progress dikirim.
                    self.batch_sessions[identity][
                        "last_progress_pallet"
                    ] = current_pallet

                    self.batch_sessions[identity][
                        "last_progress_nomor_mb"
                    ] = current_nomor_mb

                return True

            # ========================================================
            # BATCH BELUM ADA DI SERVER
            # ========================================================
            print(
                f"[SESSION] New unfinished identity: "
                f"{identity}"
            )

            self.current_identity = identity
            self.session_active = True
            self.last_extracted_data = dict(data)

            self.last_progress_pallet = normalize_text(
                data.get("pallet", "")
            )

            self.last_progress_nomor_mb = normalize_text(
                data.get("nomor_mb", "")
            )
            self.last_progress_monotonic = time.monotonic()

            # --------------------------------------------------------
            # Batch benar-benar baru.
            # Kalau sudah berada di START condition, kirim START.
            # Jangan selalu MID_PROCESS.
            # --------------------------------------------------------
            if self._check_start_condition(data):
                self.has_start_event = True

                self._emit_event(
                    "START",
                    "start process",
                    "",
                    data,
                    datetime.now(
                        timezone.utc
                    ).isoformat(),
                )
            else:
                self.has_start_event = False

                self._emit_event(
                    "MID_PROCESS",
                    "mid process",
                    "",
                    data,
                    datetime.now(
                        timezone.utc
                    ).isoformat(),
                )

            self._save_batch_session()

            update_batch_history(
                identity,
                data,
            )

            return True

        except Exception as exc:
            print(
                f"[SESSION] Failed to recover identity "
                f"{identity}: {exc}"
            )
            return False

    def _process_progress(self, previous_data, current_data):
        previous_pallet = normalize_text(previous_data.get("pallet", ""))
        current_pallet = normalize_text(current_data.get("pallet", ""))
        previous_nomor_mb = normalize_text(previous_data.get("nomor_mb", ""))
        current_nomor_mb = normalize_text(current_data.get("nomor_mb", ""))

        if current_pallet == previous_pallet and current_nomor_mb == previous_nomor_mb:
            return

        self.last_progress_pallet = current_pallet
        self.last_progress_nomor_mb = current_nomor_mb
        self.last_progress_monotonic = time.monotonic()
        self._emit_event("PROGRESS", "", "", current_data, datetime.now(timezone.utc).isoformat())

    def _is_incomplete_mb_fallback_trigger(self, data):
        if not isinstance(data, dict):
            return False

        if bool(data.get("incomplete_mb_fallback")):
            return True

        fallback_text = " ".join(
            normalize_text(value)
            for value in (
                data.get("work_order", ""),
                data.get("product_code", ""),
                data.get("formula", ""),
                data.get("batch", ""),
                data.get("work_station", ""),
                data.get("pallet", ""),
                data.get("nomor_mb", ""),
                data.get("master_box", ""),
            )
            if normalize_text(value)
        ).lower()

        patterns = (
            "master box is incomplete",
            "electronic signature",
            "sign here to continue",
            "masukkan jumlah uom primary",
            "enter quantity of box",
            "check weighing - select work order",
            "ketik nomor schedule",
        )

        return any(pattern in fallback_text for pattern in patterns)

    def _is_same_active_identity(self, data):
        if not self.current_identity or not isinstance(data, dict):
            return False

        current_fields = {
            "work_order": normalize_text(self.last_extracted_data.get("work_order", "")),
            "batch": normalize_text(self.last_extracted_data.get("batch", "")),
            "formula": normalize_text(self.last_extracted_data.get("formula", "")),
            "work_station": normalize_text(self.last_extracted_data.get("work_station", "")),
        }

        incoming_fields = {
            "work_order": normalize_text(data.get("work_order", "")),
            "batch": normalize_text(data.get("batch", "")),
            "formula": normalize_text(data.get("formula", "")),
            "work_station": normalize_text(data.get("work_station", "")),
        }

        if any(not value for value in current_fields.values()):
            return True

        return all(
            current_fields[key] == incoming_fields[key]
            for key in ("work_order", "batch", "formula", "work_station")
            if current_fields[key] or incoming_fields[key]
        )

    def _should_auto_end_on_identity_change(self, previous_data, current_data):
        if not previous_data or self.last_progress_monotonic is None:
            return False

        idle_seconds = time.monotonic() - self.last_progress_monotonic
        if idle_seconds < 20 * 60:
            return False

        identity_fields = (
            "work_order",
            "batch",
            "formula",
            "work_station",
        )
        if any(
            not normalize_text(previous_data.get(field, ""))
            or not normalize_text(current_data.get(field, ""))
            for field in identity_fields
        ):
            return False

        return any(
            normalize_text(previous_data.get(field, ""))
            != normalize_text(current_data.get(field, ""))
            for field in identity_fields
        )

    @staticmethod
    def _get_progress_time(updated_at):
        now_monotonic = time.monotonic()
        if not updated_at:
            return now_monotonic

        try:
            updated = datetime.fromisoformat(
                normalize_text(updated_at).replace("Z", "+00:00")
            )
            if updated.tzinfo is None:
                updated = updated.replace(tzinfo=timezone.utc)
            age_seconds = max(
                0.0,
                (datetime.now(timezone.utc) - updated.astimezone(timezone.utc)).total_seconds(),
            )
            return now_monotonic - age_seconds
        except (TypeError, ValueError):
            return now_monotonic

    def trigger_end_click(self, label, click_timestamp=None):
        if not self.session_active:
            return False

        end_time = click_timestamp or datetime.now(timezone.utc).isoformat()
        end_data = dict(self.last_extracted_data)

        if not end_data:
            return False

        success = self._emit_event(
            "END",
            "start process" if self.has_start_event else "mid process",
            label,
            end_data,
            end_time,
        )

        if success:
            self._reset_session()

        return success

    def _check_start_condition(self, data):
        pallet_suffix = parse_pallet_suffix(data.get("pallet", ""))
        nomor_mb = parse_nomor_mb(data.get("nomor_mb", ""))
        return pallet_suffix == 1 and nomor_mb == 2

    def _emit_event(self, event_type, start_type, end_type, data, timestamp):
        unique_event_id = str(uuid.uuid4())
        payload = {
            "event_id": unique_event_id,
            "agent_id": self.agent_id,
            "event_type": event_type,
            "timestamp": timestamp,
            "work_order": data.get("work_order", ""),
            "product_code": data.get("product_code", ""),
            "formula": data.get("formula", ""),
            "batch": data.get("batch", ""),
            "work_station": data.get("work_station", ""),
            "pallet": data.get("pallet", ""),
            "nomor_mb": data.get("nomor_mb", ""),
            "master_box": data.get("master_box", ""),
            "start_type": start_type,
            "end_type": end_type
        }
        return self.queue.enqueue(unique_event_id, event_type, payload)

    def _reset_session(self):
        if self.current_identity and self.current_identity in self.batch_sessions:
            del self.batch_sessions[self.current_identity]

        self.session_active = False
        self.current_identity = None
        self.has_start_event = False
        self.last_extracted_data = {}
        self.last_progress_pallet = None
        self.last_progress_nomor_mb = None
        self.last_progress_monotonic = None
        self.pending_end_trigger = False
        self.end_click_timestamp = None
        self.end_type_label = ""

# ============================================================
# MOUSE END DETECTOR
# ============================================================
class MouseEndDetector:
    """
    Mendeteksi END hanya dari klik LEFT yang benar-benar terjadi
    di tombol END pada window 3WS yang sedang aktif.

    Proteksi:
    - Mouse button harus LEFT + pressed=True
    - Target window harus masih valid
    - Target PID harus sama dengan PID 3WS
    - Target window harus foreground
    - Button harus visible
    - Button harus enabled
    - Button PID harus sama dengan target PID
    - Koordinat klik harus berada di rectangle button
    - Debounce untuk mencegah satu klik menghasilkan END ganda
    """

    END_BUTTON_TARGETS = (
        "INCOMPLETE MB",
        "MASTER BOX TERAKHIR",
        "LAST MB",
    )

    DEBOUNCE_SECONDS = 1.0

    def __init__(self, session_engine, uia_extractor, batch_recorder):
        self.session_engine = session_engine
        self.uia_extractor = uia_extractor
        self.batch_recorder = batch_recorder
        self.listener = None

        self._last_end_click_time = 0.0

    def start(self):
        self.listener = mouse.Listener(on_click=self.on_click)
        self.listener.daemon = True
        self.listener.start()

    def _get_foreground_hwnd(self):
        try:
            user32 = ctypes.windll.user32
            return user32.GetForegroundWindow()
        except Exception:
            return None

    def _is_foreground_target(self, win):
        """
        Pastikan window yang menerima klik adalah window foreground.
        """
        try:
            target_hwnd = getattr(
                getattr(win, "element_info", None),
                "handle",
                None,
            )

            if not target_hwnd:
                target_hwnd = self.uia_extractor.target_hwnd

            foreground_hwnd = self._get_foreground_hwnd()

            if not foreground_hwnd or not target_hwnd:
                return False

            return int(foreground_hwnd) == int(target_hwnd)

        except Exception:
            return False

    def _is_element_visible(self, elem):
        try:
            value = getattr(elem, "is_visible", None)

            if callable(value):
                return bool(value())

            if value is None:
                return True

            return bool(value)

        except Exception:
            return False

    def _is_element_enabled(self, elem):
        try:
            value = getattr(elem, "is_enabled", None)

            if callable(value):
                return bool(value())

            if value is None:
                return True

            return bool(value)

        except Exception:
            return False

    def _get_element_pid(self, elem):
        try:
            info = getattr(elem, "element_info", None)

            if info is not None:
                pid = getattr(info, "process_id", None)
                if pid:
                    return int(pid)

            pid = getattr(elem, "process_id", None)
            if pid:
                return int(pid)

        except Exception:
            pass

        return None

    def _get_element_rect(self, elem):
        try:
            rect = elem.rectangle()

            if rect is None:
                return None

            left = int(rect.left)
            top = int(rect.top)
            right = int(rect.right)
            bottom = int(rect.bottom)

            if right <= left or bottom <= top:
                return None

            return left, top, right, bottom

        except Exception:
            return None

    def _point_inside_rect(self, x, y, rect):
        if not rect:
            return False

        left, top, right, bottom = rect

        return (
            left <= x <= right
            and
            top <= y <= bottom
        )

    def _is_end_button_text(self, text):
        try:
            text_upper = normalize_text(text).upper()

            return any(
                target in text_upper
                for target in self.END_BUTTON_TARGETS
            )

        except Exception:
            return False

    def on_click(self, x, y, button, pressed):
        # --------------------------------------------------------
        # 1. Hanya LEFT BUTTON DOWN
        # --------------------------------------------------------
        if not pressed:
            return

        if button != mouse.Button.left:
            return

        # --------------------------------------------------------
        # 2. Lifecycle harus masih aktif
        # --------------------------------------------------------
        if not self.session_engine.session_active:
            return

        win = self.uia_extractor.target_window

        if not win:
            return

        try:
            # ----------------------------------------------------
            # 3. Validasi target window / PID
            # ----------------------------------------------------
            info = getattr(win, "element_info", None)

            if info is None:
                return

            window_pid = getattr(info, "process_id", None)
            target_pid = self.uia_extractor.target_pid

            if target_pid:
                if not window_pid:
                    return

                if int(window_pid) != int(target_pid):
                    return

            # ----------------------------------------------------
            # 4. Window harus foreground
            # ----------------------------------------------------
            if not self._is_foreground_target(win):
                return

            # ----------------------------------------------------
            # 5. Koordinat harus berada di window 3WS
            # ----------------------------------------------------
            window_rect = self._get_element_rect(win)

            if not self._point_inside_rect(
                x,
                y,
                window_rect,
            ):
                return

            # ----------------------------------------------------
            # 6. Debounce END
            # ----------------------------------------------------
            now_monotonic = time.monotonic()

            if (
                now_monotonic - self._last_end_click_time
                < self.DEBOUNCE_SECONDS
            ):
                return

            # ----------------------------------------------------
            # 7. Cari tombol END yang benar-benar diklik
            # ----------------------------------------------------
            for elem in win.descendants(control_type="Button"):
                try:
                    # --------------------------------------------
                    # Text button
                    # --------------------------------------------
                    raw_text = get_element_value(elem)
                    btn_text_upper = normalize_text(
                        raw_text
                    ).upper()

                    if not self._is_end_button_text(
                        btn_text_upper
                    ):
                        continue

                    # --------------------------------------------
                    # PID element harus sama
                    # --------------------------------------------
                    element_pid = self._get_element_pid(elem)

                    if target_pid and element_pid:
                        if int(element_pid) != int(target_pid):
                            continue

                    # Jika UIA memberikan PID berbeda,
                    # jangan percaya element tersebut.
                    if target_pid and element_pid is None:
                        continue

                    # --------------------------------------------
                    # Button harus visible
                    # --------------------------------------------
                    if not self._is_element_visible(elem):
                        continue

                    # --------------------------------------------
                    # Button harus enabled
                    # --------------------------------------------
                    if not self._is_element_enabled(elem):
                        continue

                    # --------------------------------------------
                    # Rectangle harus valid
                    # --------------------------------------------
                    btn_rect = self._get_element_rect(elem)

                    if not btn_rect:
                        continue

                    # --------------------------------------------
                    # Click harus benar-benar berada di button
                    # --------------------------------------------
                    if not self._point_inside_rect(
                        x,
                        y,
                        btn_rect,
                    ):
                        continue

                    # ====================================================
                    # VALID END CLICK
                    # ====================================================
                    click_timestamp = (
                        datetime.now(timezone.utc).isoformat()
                    )

                    self._last_end_click_time = now_monotonic

                    print(
                        "[END-DETECT] VALID CLICK "
                        f"x={x} y={y} "
                        f"label={btn_text_upper!r} "
                        f"rect={btn_rect} "
                        f"pid={element_pid}"
                    )

                    # ------------------------------------------------
                    # Recorder: hanya logging
                    # ------------------------------------------------
                    try:
                        self.batch_recorder.record_end_click(
                            label=btn_text_upper,
                            timestamp=click_timestamp,
                        )
                    except Exception:
                        pass

                    # ------------------------------------------------
                    # Lifecycle END
                    # ------------------------------------------------
                    success = self.session_engine.trigger_end_click(
                        label=btn_text_upper,
                        click_timestamp=click_timestamp,
                    )

                    if success:
                        print(
                            "[END-DETECT] END EVENT QUEUED "
                            f"label={btn_text_upper!r}"
                        )

                        try:
                            self.batch_recorder.record_end(
                                timestamp=click_timestamp,
                            )
                        except Exception:
                            pass
                    else:
                        print(
                            "[END-DETECT] END EVENT REJECTED "
                            f"label={btn_text_upper!r}"
                        )

                    break

                except Exception as exc:
                    # Jangan matikan global mouse listener
                    # karena satu element UIA bermasalah.
                    continue

        except Exception as exc:
            # Jangan biarkan exception mouse detector
            # menghentikan agent.
            return

# ============================================================
# THREAD WORKERS & MAIN
# ============================================================
def heartbeat_worker(api_client, stop_event):
    while not stop_event.is_set():
        api_client.send_heartbeat()
        stop_event.wait(HEARTBEAT_INTERVAL)

def queue_flush_worker(queue, api_client, stop_event):
    while not stop_event.is_set():
        pending_events = queue.get_pending_events()
        lifecycle_blocked = False

        for event in pending_events:
            event_id = event["event_id"]
            event_type = normalize_text(event.get("event_type", "")).upper()
            payload = event["payload"]

            if lifecycle_blocked and event_type != "PROGRESS":
                continue

            success, err_msg = api_client.send_event(payload)
            if success:
                queue.mark_sent(event_id)
            else:
                queue.increment_attempt(event_id, err_msg)

            if event_type == "PROGRESS":
                continue

            lifecycle_blocked = True

        stop_event.wait(QUEUE_FLUSH_INTERVAL)

def main():
    mutex_handle = acquire_single_instance()

    if mutex_handle is None:
        print("[AGENT] Another B7CaptureAgent instance is already running. Exiting.")
        return

    stop_event = threading.Event()
    batch_recorder = None

    try:
        config = load_or_create_config()
        agent_id = config["agent_id"]
        server_url = config["server_url"]

        api_client = APIClient(server_url, agent_id)
        queue = SQLiteQueue(DB_PATH)
        api_client.register()

        session_engine = SessionEngine(queue, agent_id, api_client)
        uia_extractor = UIAExtractor()

        batch_recorder = BatchPCRecorder(
            agent_id=agent_id,
        )

        try:
            batch_recorder.record_agent_started()
        except Exception:
            pass

        mouse_detector = MouseEndDetector(
            session_engine,
            uia_extractor,
            batch_recorder,
        )
        mouse_detector.start()

        threading.Thread(
            target=heartbeat_worker,
            args=(api_client, stop_event),
            daemon=True
        ).start()

        threading.Thread(
            target=queue_flush_worker,
            args=(queue, api_client, stop_event),
            daemon=True
        ).start()

        while True:
            try:
                found = uia_extractor.find_3ws_window()

                if not found:
                    try:
                        batch_recorder.record_3ws_lost()
                    except Exception:
                        pass

                    time.sleep(EXTRACTION_INTERVAL)
                    continue

                try:
                    batch_recorder.record_3ws_found(
                        process_id=uia_extractor.target_pid
                    )
                except Exception:
                    pass

                extracted_data = uia_extractor.extract_data()

                if extracted_data is not None:
                    validation = validate_capture_data(extracted_data)

                    if validation["valid"]:
                        try:
                            batch_recorder.observe(extracted_data)
                        except Exception:
                            pass

                        session_engine.process_extraction(extracted_data)
                elif (
                    session_engine.session_active
                    and session_engine._is_same_active_identity(session_engine.last_extracted_data)
                    and uia_extractor.detect_incomplete_mb_fallback_screen()
                ):
                    print("[SESSION] Fallback screen detected without batch payload")
                    end_time = datetime.now(timezone.utc).isoformat()
                    success = session_engine._emit_event(
                        "END",
                        "start process" if session_engine.has_start_event else "mid process",
                        "incomplete_mb_fallback_trigger",
                        dict(session_engine.last_extracted_data),
                        end_time,
                    )
                    if success:
                        session_engine._reset_session()

            except Exception:
                uia_extractor.target_window = None
                uia_extractor.target_pid = None
                uia_extractor.target_hwnd = None

            time.sleep(EXTRACTION_INTERVAL)

    except (KeyboardInterrupt, Exception):
        stop_event.set()

    finally:
        if batch_recorder is not None:
            try:
                batch_recorder.record_agent_stopped()
                batch_recorder.flush()
            except Exception:
                pass

        ctypes.WinDLL(
            "kernel32",
            use_last_error=True
        ).CloseHandle(mutex_handle)

if __name__ == "__main__":
    main()
