import os
import sys
import time
import subprocess
from pathlib import Path

import psutil
import win32com.client


# ============================================================
# CONFIG
# ============================================================

AGENT_EXE_NAME = "B7CaptureAgent.exe"
SHORTCUT_NAME = "B7CaptureAgent.lnk"

STARTUP_DIR = (
    Path(os.environ["APPDATA"])
    / "Microsoft"
    / "Windows"
    / "Start Menu"
    / "Programs"
    / "Startup"
)


# ============================================================
# PATH
# ============================================================

def get_base_dir():
    """
    Folder tempat installer.exe berada.

    Struktur yang diwajibkan:
        installer.exe
        B7CaptureAgent.exe
    """
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent

    return Path(__file__).resolve().parent


# ============================================================
# 1. STOP AGENT
# ============================================================

def stop_agent():
    print("[1/5] Stop B7CaptureAgent.exe")

    found = False

    for proc in psutil.process_iter(["pid", "name"]):
        try:
            name = proc.info["name"] or ""

            if name.casefold() != AGENT_EXE_NAME.casefold():
                continue

            found = True
            pid = proc.info["pid"]

            print(f"      Found PID: {pid}")

            proc.terminate()

            try:
                proc.wait(timeout=5)
            except psutil.TimeoutExpired:
                print(f"      PID {pid} belum berhenti, terminate paksa.")
                proc.kill()
                proc.wait(timeout=3)

        except (
            psutil.NoSuchProcess,
            psutil.AccessDenied,
            psutil.ZombieProcess,
        ):
            continue

    if not found:
        print("      B7CaptureAgent tidak sedang berjalan.")

    time.sleep(1)


# ============================================================
# 2. DELETE STARTUP SHORTCUT
# ============================================================

def delete_startup_shortcut():
    print("[2/5] Delete shortcut dari shell:startup")

    startup_shortcut = STARTUP_DIR / SHORTCUT_NAME

    if startup_shortcut.exists():
        startup_shortcut.unlink()
        print(f"      Deleted: {startup_shortcut}")
    else:
        print("      Shortcut lama tidak ditemukan.")


# ============================================================
# 3. CREATE SHORTCUT BESIDE AGENT
# ============================================================

def create_shortcut(agent_exe):
    print("[3/5] Create shortcut dari B7CaptureAgent.exe")

    temporary_shortcut = agent_exe.parent / SHORTCUT_NAME

    # Bersihkan shortcut sementara kalau masih ada.
    if temporary_shortcut.exists():
        temporary_shortcut.unlink()

    shell = win32com.client.Dispatch("WScript.Shell")

    shortcut = shell.CreateShortcut(
        str(temporary_shortcut)
    )

    shortcut.TargetPath = str(agent_exe)
    shortcut.WorkingDirectory = str(agent_exe.parent)
    shortcut.Description = "B7 3WS Capture Agent"
    shortcut.IconLocation = str(agent_exe)

    shortcut.Save()

    if not temporary_shortcut.exists():
        raise RuntimeError(
            "Gagal membuat shortcut B7CaptureAgent.lnk"
        )

    print(f"      Created: {temporary_shortcut}")

    return temporary_shortcut


# ============================================================
# 4. MOVE SHORTCUT TO STARTUP
# ============================================================

def move_to_startup(temporary_shortcut):
    print("[4/5] Cut shortcut ke shell:startup")

    STARTUP_DIR.mkdir(
        parents=True,
        exist_ok=True
    )

    destination = STARTUP_DIR / SHORTCUT_NAME

    if destination.exists():
        destination.unlink()

    # Move langsung menggunakan filesystem Windows.
    # Tidak menggunakan PowerShell / CMD.
    temporary_shortcut.replace(destination)

    if not destination.exists():
        raise RuntimeError(
            "Gagal memindahkan shortcut ke Startup."
        )

    print(f"      Startup: {destination}")


# ============================================================
# 5. RUN ORIGINAL EXE
# ============================================================

def run_agent(agent_exe):
    print("[5/5] Run B7CaptureAgent.exe asli")

    subprocess.Popen(
        [str(agent_exe)],
        cwd=str(agent_exe.parent)
    )

    print(f"      Started: {agent_exe}")


# ============================================================
# MAIN
# ============================================================

def main():

    base_dir = get_base_dir()

    agent_exe = base_dir / AGENT_EXE_NAME

    print("=" * 60)
    print(" B7 3WS - B7CaptureAgent Installer")
    print("=" * 60)

    print(f"Installer folder : {base_dir}")
    print(f"Agent EXE        : {agent_exe}")
    print(f"Startup folder   : {STARTUP_DIR}")
    print()

    # --------------------------------------------------------
    # Pastikan B7CaptureAgent.exe sejajar dengan installer.exe
    # --------------------------------------------------------

    if not agent_exe.is_file():

        print("ERROR:")
        print("B7CaptureAgent.exe tidak ditemukan.")
        print()
        print("Pastikan struktur folder:")
        print()
        print("    installer.exe")
        print("    B7CaptureAgent.exe")
        print()

        return 1

    try:

        # 1
        stop_agent()

        # 2
        delete_startup_shortcut()

        # 3
        temporary_shortcut = create_shortcut(
            agent_exe
        )

        # 4
        move_to_startup(
            temporary_shortcut
        )

        # 5
        run_agent(
            agent_exe
        )

        print()
        print("=" * 60)
        print(" INSTALL SELESAI")
        print("=" * 60)

        return 0

    except Exception as error:

        print()
        print("=" * 60)
        print(" INSTALL GAGAL")
        print("=" * 60)
        print()
        print(f"{type(error).__name__}: {error}")

        return 1


if __name__ == "__main__":
    sys.exit(main())