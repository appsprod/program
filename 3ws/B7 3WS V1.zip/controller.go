package main

import (
	"encoding/json"
	"html/template"
	"log"
	"net/http"
	"path/filepath"
	"strconv"
	"strings"
	"time"
)

// AppController menangani seluruh skenario HTTP endpoints B7_3WS
type AppController struct {
	service Service
}

// NewAppController instansiasi controller baru dengan Dependency Injection Service
func NewAppController(svc Service) *AppController {
	return &AppController{
		service: svc,
	}
}

// Helper internal untuk mengirim HTTP JSON Error Response yang konsisten
func sendJSONError(w http.ResponseWriter, statusCode int, message string) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.WriteHeader(statusCode)
	json.NewEncoder(w).Encode(ErrorResponse{
		Success: false,
		Error:   message,
	})
}

// Helper internal untuk mengirim HTTP JSON Success Response
func sendJSONSuccess(w http.ResponseWriter, statusCode int, data interface{}) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.WriteHeader(statusCode)
	json.NewEncoder(w).Encode(data)
}

// ============================================================
// 1. HTML PAGES HANDLERS
// ============================================================

// IndexHandler GET / -> Redirect atau render Dashboard Page
func (c *AppController) IndexHandler(w http.ResponseWriter, r *http.Request) {
	if r.URL.Path != "/" {
		http.NotFound(w, r)
		return
	}
	http.Redirect(w, r, "/dashboard", http.StatusSeeOther)
}

// DashboardHandler GET /dashboard -> Render templates/dashboard.html
func (c *AppController) DashboardHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		sendJSONError(w, http.StatusMethodNotAllowed, "Method not allowed")
		return
	}

	tmplPath := filepath.Join("templates", "dashboard.html")
	tmpl, err := template.ParseFiles(tmplPath)
	if err != nil {
		log.Printf("[CONTROLLER] Error loading template dashboard.html: %v", err)
		http.Error(w, "Template dashboard.html not found or failed to parse", http.StatusInternalServerError)
		return
	}

	// Ambil data batch awal untuk initial server-side render
	batchesRes, err := c.service.GetDashboardBatches(r.Context(), 1, 30)
	if err != nil {
		log.Printf("[CONTROLLER] Error fetching initial dashboard data: %v", err)
		batchesRes = &PaginatedBatchResponse{
			Success:    true,
			Data:       []BatchRecord{},
			Page:       1,
			Limit:      30,
			Total:      0,
			TotalPages: 0,
		}
	}

	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	if err := tmpl.Execute(w, batchesRes); err != nil {
		log.Printf("[CONTROLLER] Error executing dashboard template: %v", err)
	}
}

// MonitorHandler GET /monitor -> Render templates/monitor.html
func (c *AppController) MonitorHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		sendJSONError(w, http.StatusMethodNotAllowed, "Method not allowed")
		return
	}

	tmplPath := filepath.Join("templates", "monitor.html")
	tmpl, err := template.ParseFiles(tmplPath)
	if err != nil {
		log.Printf("[CONTROLLER] Error loading template monitor.html: %v", err)
		http.Error(w, "Template monitor.html not found or failed to parse", http.StatusInternalServerError)
		return
	}

	agents, err := c.service.GetAgents(r.Context())
	if err != nil {
		log.Printf("[CONTROLLER] Error fetching agents for monitor: %v", err)
		agents = []AgentRecord{}
	}

	data := struct {
		Success   bool          `json:"success"`
		Agents    []AgentRecord `json:"agents"`
		FetchTime time.Time     `json:"fetch_time"`
	}{
		Success:   true,
		Agents:    agents,
		FetchTime: time.Now().Local(),
	}

	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	if err := tmpl.Execute(w, data); err != nil {
		log.Printf("[CONTROLLER] Error executing monitor template: %v", err)
	}
}

// ============================================================
// 2. BATCH API HANDLERS
// ============================================================

// GetBatchesHandler GET /api/batches -> Mengambil data batch terpaginasi
func (c *AppController) GetBatchesHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		sendJSONError(w, http.StatusMethodNotAllowed, "Method not allowed")
		return
	}

	pageQuery := r.URL.Query().Get("page")
	limitQuery := r.URL.Query().Get("limit")

	page := 1
	limit := 30

	if p, err := strconv.Atoi(pageQuery); err == nil && p > 0 {
		page = p
	}
	if l, err := strconv.Atoi(limitQuery); err == nil && l > 0 {
		limit = l
	}

	res, err := c.service.GetDashboardBatches(r.Context(), page, limit)
	if err != nil {
		log.Printf("[CONTROLLER] GetBatches error: %v", err)
		sendJSONError(w, http.StatusInternalServerError, err.Error())
		return
	}

	sendJSONSuccess(w, http.StatusOK, res)
}

// SearchBatchesHandler GET /api/batches/search?q=query -> Search global case-insensitive
func (c *AppController) SearchBatchesHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		sendJSONError(w, http.StatusMethodNotAllowed, "Method not allowed")
		return
	}

	q := strings.TrimSpace(r.URL.Query().Get("q"))
	pageQuery := r.URL.Query().Get("page")
	limitQuery := r.URL.Query().Get("limit")

	page := 1
	limit := 30

	if p, err := strconv.Atoi(pageQuery); err == nil && p > 0 {
		page = p
	}
	if l, err := strconv.Atoi(limitQuery); err == nil && l > 0 {
		limit = l
	}

	res, err := c.service.SearchBatches(r.Context(), q, page, limit)
	if err != nil {
		log.Printf("[CONTROLLER] SearchBatches error (q='%s'): %v", q, err)
		sendJSONError(w, http.StatusInternalServerError, err.Error())
		return
	}

	sendJSONSuccess(w, http.StatusOK, res)
}

// ============================================================
// 3. AGENT API HANDLERS
// ============================================================

// RegisterAgentHandler POST /api/agent/register -> Pendaftaran identitas agen
func (c *AppController) RegisterAgentHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		sendJSONError(w, http.StatusMethodNotAllowed, "Method not allowed")
		return
	}

	var req AgentRegisterRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		sendJSONError(w, http.StatusBadRequest, "Invalid JSON payload: "+err.Error())
		return
	}

	res, err := c.service.RegisterAgent(r.Context(), &req)
	if err != nil {
		log.Printf("[CONTROLLER] RegisterAgent error: %v", err)
		sendJSONError(w, http.StatusBadRequest, err.Error())
		return
	}

	sendJSONSuccess(w, http.StatusOK, res)
}

// HeartbeatHandler POST /api/agent/heartbeat -> Menerima pings periodik agen
func (c *AppController) HeartbeatHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		sendJSONError(w, http.StatusMethodNotAllowed, "Method not allowed")
		return
	}

	var req AgentHeartbeatRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		sendJSONError(w, http.StatusBadRequest, "Invalid JSON payload: "+err.Error())
		return
	}

	res, err := c.service.UpdateHeartbeat(r.Context(), &req)
	if err != nil {
		log.Printf("[CONTROLLER] Heartbeat error: %v", err)
		sendJSONError(w, http.StatusBadRequest, err.Error())
		return
	}

	sendJSONSuccess(w, http.StatusOK, res)
}

// EventBatchHandler POST /api/agent/events -> Event pengolahan MID_PROCESS, START, END
func (c *AppController) EventBatchHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		sendJSONError(w, http.StatusMethodNotAllowed, "Method not allowed")
		return
	}

	var req AgentEventRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		sendJSONError(w, http.StatusBadRequest, "Invalid JSON payload: "+err.Error())
		return
	}

	// Validasi awal event_type
	if req.EventType != EventTypeMidProcess && req.EventType != EventTypeStart && req.EventType != EventTypeEnd {
		sendJSONError(w, http.StatusBadRequest, "Invalid event_type. Allowed: MID_PROCESS, START, END")
		return
	}

	res, err := c.service.ReceiveBatchEvent(r.Context(), &req)
	if err != nil {
		log.Printf("[CONTROLLER] ReceiveBatchEvent error [%s]: %v", req.EventType, err)
		sendJSONError(w, http.StatusBadRequest, err.Error())
		return
	}

	sendJSONSuccess(w, http.StatusOK, res)
}

// ProgressHandler POST /api/agent/progress
//
// PROGRESS hanya digunakan untuk realtime pallet dan nomor MB.
// Lifecycle timestamp tidak diproses di endpoint ini.
func (c *AppController) ProgressHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		sendJSONError(w, http.StatusMethodNotAllowed, "Method not allowed")
		return
	}

	var req ProgressRequest

	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		sendJSONError(
			w,
			http.StatusBadRequest,
			"Invalid JSON payload: "+err.Error(),
		)
		return
	}

	if err := req.Validate(); err != nil {
		sendJSONError(
			w,
			http.StatusBadRequest,
			"Invalid progress payload: "+err.Error(),
		)
		return
	}

	res, err := c.service.UpdateBatchProgress(r.Context(), &req)
	if err != nil {
		log.Printf(
			"[CONTROLLER] UpdateBatchProgress error [%s]: %v",
			req.EventID,
			err,
		)

		sendJSONError(w, http.StatusBadRequest, err.Error())
		return
	}

	sendJSONSuccess(w, http.StatusOK, res)
}

// GetBatchByIdentityHandler GET /api/agent/batch
//
// Digunakan agent untuk melakukan reconciliation ketika UI berpindah
// ke identity batch baru.
func (c *AppController) GetBatchByIdentityHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		sendJSONError(w, http.StatusMethodNotAllowed, "Method not allowed")
		return
	}

	query := r.URL.Query()

	workOrder := strings.TrimSpace(query.Get("work_order"))
	batch := strings.TrimSpace(query.Get("batch"))
	formula := strings.TrimSpace(query.Get("formula"))
	workStation := strings.TrimSpace(query.Get("work_station"))

	if workOrder == "" || batch == "" || formula == "" || workStation == "" {
		sendJSONError(
			w,
			http.StatusBadRequest,
			"work_order, batch, formula, and work_station are required",
		)
		return
	}

	batchRecord, err := c.service.GetBatchByIdentity(
		r.Context(),
		workOrder,
		batch,
		formula,
		workStation,
	)
	if err != nil {
		log.Printf(
			"[CONTROLLER] GetBatchByIdentity error WO=%s Batch=%s Formula=%s WorkStation=%s: %v",
			workOrder,
			batch,
			formula,
			workStation,
			err,
		)

		sendJSONError(w, http.StatusInternalServerError, err.Error())
		return
	}

	if batchRecord == nil {
		sendJSONSuccess(w, http.StatusOK, map[string]interface{}{
			"success": true,
			"found":   false,
			"batch":   nil,
		})
		return
	}

	sendJSONSuccess(w, http.StatusOK, map[string]interface{}{
		"success": true,
		"found":   true,
		"batch":   batchRecord,
	})
}

// GetAgentsHandler GET /api/agents -> Mengambil daftar seluruh PC Agent terdaftar
func (c *AppController) GetAgentsHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		sendJSONError(w, http.StatusMethodNotAllowed, "Method not allowed")
		return
	}

	agents, err := c.service.GetAgents(r.Context())
	if err != nil {
		log.Printf("[CONTROLLER] GetAgents error: %v", err)
		sendJSONError(w, http.StatusInternalServerError, err.Error())
		return
	}

	response := struct {
		Success bool          `json:"success"`
		Data    []AgentRecord `json:"data"`
	}{
		Success: true,
		Data:    agents,
	}

	sendJSONSuccess(w, http.StatusOK, response)
}

// DeleteAgentHandler DELETE /api/agents/:id -> Menghapus agent berdasarkan ID database
func (c *AppController) DeleteAgentHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodDelete {
		sendJSONError(w, http.StatusMethodNotAllowed, "Method not allowed")
		return
	}

	idStr := strings.TrimPrefix(r.URL.Path, "/api/agents/")
	idStr = strings.TrimSpace(idStr)

	if idStr == "" {
		sendJSONError(w, http.StatusBadRequest, "Agent ID is required")
		return
	}

	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil || id <= 0 {
		sendJSONError(w, http.StatusBadRequest, "Invalid agent ID")
		return
	}

	res, err := c.service.DeleteAgent(r.Context(), id)
	if err != nil {
		log.Printf(
			"[CONTROLLER] DeleteAgent error [ID=%d]: %v",
			id,
			idStr,
		)

		sendJSONError(w, http.StatusBadRequest, err.Error())
		return
	}

	sendJSONSuccess(w, http.StatusOK, res)
}
