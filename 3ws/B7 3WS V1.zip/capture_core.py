# capture_core.py
import os
import json
import socket
import getpass
import sqlite3
import re
from datetime import datetime, timezone
import requests
from pywinauto import Application, Desktop

# ============================================================
# CONSTANTS & CONFIG PATHS
# ============================================================
APP_NAME = "B7_3WS"
AGENT_VERSION = "1.0.0"
DEFAULT_SERVER_URL = "http://localhost:2005"
HEARTBEAT_INTERVAL = 30
EXTRACTION_INTERVAL = 1.0
QUEUE_FLUSH_INTERVAL = 5.0
TARGET_PROCESS_NAMES = {"3ws.exe", "3ws.net.exe"}
TARGET_WINDOW_TITLE_KEYWORDS = ["Penimbangan FG"]
MAX_TREE_DEPTH = 12
MAX_CONTROLS = 3000

# V1 automation IDs sebagai fallback
V1_AUTOMATION_IDS = {
    "1705480": "work_order",
    "395160": "formula",
    "1050396": "batch",
    "btnIncompleteMB": "incomplete_mb",
    "btnLastMB": "last_mb",
}

APPDATA_DIR = os.path.join(os.environ.get("APPDATA", os.path.expanduser("~")), APP_NAME)
os.makedirs(APPDATA_DIR, exist_ok=True)
CONFIG_PATH = os.path.join(APPDATA_DIR, "config.json")
DB_PATH = os.path.join(APPDATA_DIR, "agent_queue.db")
BATCH_HISTORY_PATH = os.path.join(APPDATA_DIR, "batch_history.json")


# ============================================================
# TEXT HELPERS
# ============================================================
def normalize_text(value):
    if value is None:
        return ""
    try:
        value = str(value)
    except Exception:
        return ""
    value = value.replace("\r", " ").replace("\n", " ")
    value = re.sub(r"\s+", " ", value)
    return value.strip()


def clean_value(value):
    return normalize_text(value)


def lower_text(value):
    return normalize_text(value).lower()


# ============================================================
# DATA NORMALIZATION & CLEANERS
# ============================================================
def parse_numeric_value(value):
    if value is None:
        return 0
    value = normalize_text(value)
    if not value:
        return 0
    match = re.search(r"\d+", value)
    if not match:
        return 0
    try:
        return int(match.group(0))
    except Exception:
        return 0


def parse_nomor_mb(mb_str):
    return parse_numeric_value(mb_str)


def parse_pallet_suffix(pallet_str):
    if not pallet_str:
        return 0
    value = normalize_text(pallet_str)
    match = re.search(r"(?:^|[-_/])(\d+)$", value)
    if match:
        try:
            return int(match.group(1))
        except Exception:
            pass
    parts = value.split("-")
    if parts:
        last_part = re.sub(r"[^\d]", "", parts[-1])
        if last_part.isdigit():
            try:
                return int(last_part)
            except Exception:
                pass
    return 0


def parse_master_box(mb_str):
    return parse_numeric_value(mb_str)


def strip_label(value, labels):
    value = normalize_text(value)
    if not value:
        return ""
    for label in labels:
        pattern = r"^\s*" + re.escape(label) + r"\s*:?\s*"
        cleaned = re.sub(pattern, "", value, flags=re.IGNORECASE).strip()
        if cleaned != value:
            return cleaned
    return value


def extract_work_order_value(value): return strip_label(value, ["Work Order"])
def extract_formula_value(value): return strip_label(value, ["Formula"])
def extract_batch_value(value): return strip_label(value, ["Nomor Batch", "Batch"])
def extract_pallet_value(value): return strip_label(value, ["Nomor Pallet", "Pallet"])


def extract_work_station_value(value):
    value = normalize_text(value)
    value = strip_label(value, ["Work Station", "Workstation", "Station"])
    return value


def extract_nomor_mb_value(value):
    value = normalize_text(value)
    value = strip_label(value, ["Nomor MB", "No MB"])
    match = re.search(r"\b(\d{1,8})\b", value)
    return match.group(1) if match else value


def extract_master_box_value(value):
    value = normalize_text(value)
    value = strip_label(value, ["Master Box"])
    match = re.search(r"\b(\d{1,8})\b", value)
    return match.group(1) if match else value


# ============================================================
# SQLITE OFFLINE QUEUE
# ============================================================
class SQLiteQueue:
    def __init__(self, db_path):
        self.db_path = db_path
        self._init_db()

    def _get_connection(self):
        return sqlite3.connect(self.db_path, timeout=10)

    def _init_db(self):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS queue_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                event_id TEXT UNIQUE NOT NULL,
                event_type TEXT NOT NULL,
                payload_json TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'PENDING',
                created_at TEXT NOT NULL,
                sent_at TEXT,
                attempt_count INTEGER DEFAULT 0,
                last_error TEXT
            )
            """)
            conn.commit()

    def enqueue(self, event_id, event_type, payload):
        payload_str = json.dumps(payload, ensure_ascii=False)
        now_iso = datetime.now(timezone.utc).isoformat()
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("""
                INSERT INTO queue_events (event_id, event_type, payload_json, status, created_at)
                VALUES (?, ?, ?, 'PENDING', ?)
                """, (event_id, event_type, payload_str, now_iso))
                conn.commit()
            return True
        except (sqlite3.IntegrityError, Exception):
            return False

    def get_pending_events(self):
        events = []
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("""
                SELECT id, event_id, event_type, payload_json, attempt_count
                FROM queue_events WHERE status = 'PENDING' ORDER BY id ASC
                """)
                for row in cursor.fetchall():
                    try:
                        payload = json.loads(row[3])
                    except Exception:
                        payload = {}
                    events.append({
                        "id": row[0],
                        "event_id": row[1],
                        "event_type": row[2],
                        "payload": payload,
                        "attempt_count": row[4]
                    })
        except Exception:
            pass
        return events

    def mark_sent(self, event_id):
        now_iso = datetime.now(timezone.utc).isoformat()
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("UPDATE queue_events SET status = 'SENT', sent_at = ? WHERE event_id = ?", (now_iso, event_id))
                conn.commit()
        except Exception:
            pass

    def increment_attempt(self, event_id, error_msg):
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("""
                UPDATE queue_events SET attempt_count = attempt_count + 1, last_error = ? WHERE event_id = ?
                """, (str(error_msg), event_id))
                conn.commit()
        except Exception:
            pass


# ============================================================
# HTTP API CLIENT
# ============================================================
class APIClient:
    def __init__(self, base_url, agent_id):
        self.base_url = base_url.rstrip("/")
        self.agent_id = agent_id
        self.hostname = socket.gethostname()
        self.username = getpass.getuser()

    def register(self):
        url = f"{self.base_url}/api/agent/register"
        payload = {
            "agent_id": self.agent_id,
            "hostname": self.hostname,
            "username": self.username,
            "agent_version": AGENT_VERSION
        }
        try:
            return requests.post(url, json=payload, timeout=5).status_code == 200
        except Exception:
            return False

    def send_heartbeat(self):
        url = f"{self.base_url}/api/agent/heartbeat"
        payload = {
            "agent_id": self.agent_id,
            "hostname": self.hostname,
            "agent_version": AGENT_VERSION
        }
        try:
            return requests.post(url, json=payload, timeout=5).status_code == 200
        except Exception:
            return False

    def send_event(self, payload):
        event_type = normalize_text(payload.get("event_type", "")).upper()
        url = f"{self.base_url}/api/agent/progress" if event_type == "PROGRESS" else f"{self.base_url}/api/agent/events"
        try:
            response = requests.post(url, json=payload, timeout=5)
            if response.status_code == 200:
                return True, ""
            return False, f"HTTP {response.status_code}: {response.text}"
        except Exception as e:
            return False, str(e)

    def get_batch_by_identity(self, work_order, batch, formula, work_station):
        try:
            params = {
                "work_order": work_order,
                "batch": batch,
                "formula": formula,
                "work_station": work_station,
            }

            url = f"{self.base_url}/api/agent/batch"

            response = requests.get(
                url,
                params=params,
                timeout=5,
            )

            if response.status_code != 200:
                return None, f"HTTP {response.status_code}"

            result = response.json()

            if not result.get("success"):
                return None, result.get("message", "batch lookup failed")

            if not result.get("found"):
                return None, None

            return result.get("batch"), None

        except requests.RequestException as exc:
            return None, str(exc)
        except Exception as exc:
            return None, str(exc)


# ============================================================
# UIA CONTROL READERS & SCORING
# ============================================================
def get_element_value(element):
    try:
        iface = getattr(element, "iface_value", None)
        if iface and iface.CurrentValue:
            return normalize_text(iface.CurrentValue)
    except Exception:
        pass
    try:
        texts = [normalize_text(t) for t in element.texts() if normalize_text(t)]
        if texts:
            return " | ".join(texts)
    except Exception:
        pass
    try:
        iface = getattr(element, "iface_legacy_iaccessible", None)
        if iface and iface.CurrentValue:
            return normalize_text(iface.CurrentValue)
    except Exception:
        pass
    try:
        val = normalize_text(element.window_text())
        if val:
            return val
    except Exception:
        pass
    return ""


def collect_controls(root, controls=None, depth=0):
    if controls is None:
        controls = []
    if depth > MAX_TREE_DEPTH or len(controls) >= MAX_CONTROLS:
        return controls
    try:
        info = root.element_info
        name = normalize_text(getattr(info, "name", ""))
        control_type = normalize_text(getattr(info, "control_type", "")).lower()
        class_name = normalize_text(getattr(info, "class_name", ""))
        automation_id = normalize_text(getattr(info, "automation_id", ""))
        framework_id = normalize_text(getattr(info, "framework_id", ""))
        value = ""
        readable_types = {"edit", "document", "text", "button", "combo box", "list item", "custom"}

        if control_type in readable_types:
            value = get_element_value(root)

        ancestor_text = []
        try:
            parent = root.parent()
            for _ in range(5):
                if not parent:
                    break
                try:
                    p_info = parent.element_info
                    p_name = normalize_text(getattr(p_info, "name", ""))
                    p_type = normalize_text(getattr(p_info, "control_type", "")).lower()
                    p_val = get_element_value(parent) if p_type in readable_types else ""
                    combined = " ".join(x for x in [p_name, p_val] if x)
                    if combined:
                        ancestor_text.append(combined)
                except Exception:
                    pass
                parent = parent.parent()
        except Exception:
            pass

        controls.append({
            "element": root, "name": name, "value": value,
            "control_type": control_type, "class_name": class_name,
            "automation_id": automation_id, "framework_id": framework_id,
            "depth": depth, "ancestor_text": " | ".join(ancestor_text)
        })
    except Exception:
        return controls

    if len(controls) >= MAX_CONTROLS:
        return controls

    try:
        for child in root.children():
            if len(controls) >= MAX_CONTROLS:
                break
            collect_controls(child, controls, depth + 1)
    except Exception:
        pass
    return controls


def control_context(control):
    return " ".join([
        lower_text(control.get("name", "")),
        lower_text(control.get("value", "")),
        lower_text(control.get("ancestor_text", ""))
    ])


# Target Scorers
def score_work_order(control):
    value = normalize_text(control.get("value", ""))
    if not value or control.get("control_type") not in {"edit", "text", "document", "combo box", "custom"}:
        return 0
    name, context, score = lower_text(control.get("name", "")), control_context(control), 0
    if name == "work order:": score += 300
    if "work order" in name: score += 240
    if "work order" in context: score += 130
    if "informasi work order" in context: score += 90
    if "material" in name and "informasi work order" in context: score += 50
    if re.search(r"\d", value): score += 20
    if re.search(r"[-/]", value): score += 15
    return score


def score_product(control):
    value = normalize_text(control.get("value", ""))
    if not value or control.get("control_type") not in {"edit", "text", "document", "combo box", "custom"}:
        return 0
    name, context, score = lower_text(control.get("name", "")), control_context(control), 0
    keywords = ["kode produk", "code produk", "product code", "product", "kode material", "material code", "material"]
    for kw in keywords:
        if kw in name: score += 200
        if kw in context: score += 100
    if "informasi work order" in context: score += 40
    return score


def score_formula(control):
    value = normalize_text(control.get("value", ""))
    if not value or control.get("control_type") not in {"edit", "text", "document", "combo box", "custom"}:
        return 0
    name, context, score = lower_text(control.get("name", "")), control_context(control), 0
    if "formula" in name: score += 240
    if "formula" in context: score += 160
    if "informasi work order" in context: score += 40
    if re.fullmatch(r"[A-Za-z0-9._/-]+", value): score += 20
    return score


def score_batch(control):
    value = normalize_text(control.get("value", ""))
    if not value or control.get("control_type") not in {"edit", "text", "document", "combo box", "custom"}:
        return 0
    name, context, score = lower_text(control.get("name", "")), control_context(control), 0
    if name == "nomor batch": score += 300
    if "nomor batch" in name: score += 260
    if "batch" in name: score += 210
    if "batch" in context: score += 130
    if "informasi work order" in context: score += 40
    if re.search(r"[A-Za-z]", value): score += 20
    if re.search(r"\d", value): score += 20
    return score


def score_work_station(control):
    value = normalize_text(control.get("value", ""))
    if not value or control.get("control_type") not in {
        "edit", "text", "document", "combo box", "custom"
    }:
        return 0

    name = lower_text(control.get("name", ""))
    context = control_context(control)
    score = 0

    if name == "work station":
        score += 600
    if "work station" in name:
        score += 500
    if "workstation" in name:
        score += 500
    if "work station" in context:
        score += 350
    if "workstation" in context:
        score += 300

    # Format Work Station 3WS:
    # B7-PGDPRDD13
    if re.fullmatch(r"B7-[A-Za-z0-9]+", value, re.IGNORECASE):
        score += 200

    return score


def score_machine(control):
    if not normalize_text(control.get("value", "")): return 0
    name, context, score = lower_text(control.get("name", "")), control_context(control), 0
    if "penimbang" in name: score += 200
    if "penimbang" in context: score += 130
    if "machine" in name or "mesin" in name: score += 180
    return score


def score_packer(control):
    if not normalize_text(control.get("value", "")): return 0
    name, context, score = lower_text(control.get("name", "")), control_context(control), 0
    if "pengepak" in name: score += 300
    if "pengepak" in context: score += 220
    if "packer" in name: score += 250
    if "packer" in context: score += 180
    return score


def score_scale(control):
    if not normalize_text(control.get("value", "")): return 0
    name, context, score = lower_text(control.get("name", "")), control_context(control), 0
    if "timbangan" in name: score += 300
    if "timbangan" in context: score += 220
    if "scale" in name: score += 250
    if "scale" in context: score += 180
    return score


def score_pallet(control):
    value = normalize_text(control.get("value", ""))
    if not value or control.get("control_type") not in {"edit", "text", "document", "combo box", "list item", "custom"}:
        return 0
    name, context, score = lower_text(control.get("name", "")), control_context(control), 0
    if name == "nomor pallet": score += 500
    if "nomor pallet" in name: score += 450
    if "nomor pallet" in context: score += 250
    if "pallet" in name: score += 200
    if "pallet" in context: score += 100
    if re.fullmatch(r"[A-Za-z]+(?:-[A-Za-z0-9]+)+", value): score += 40
    if re.search(r"\d", value): score += 20
    return score


def score_nomor_mb(control):
    value = normalize_text(control.get("value", ""))
    if not value or control.get("control_type") not in {"edit", "text", "document", "combo box", "list item", "custom"}:
        return 0
    name, context, score = lower_text(control.get("name", "")), control_context(control), 0
    if name == "nomor mb": score += 600
    if "nomor mb" in name: score += 550
    if "nomor mb" in context: score += 350
    if "no mb" in name: score += 500
    if "no mb" in context: score += 300
    if "master box" in name: score -= 500
    if "master box" in context and "nomor mb" not in context: score -= 300
    if re.search(r"\d", value): score += 50
    return max(score, 0)


def score_master_box(control):
    value = normalize_text(control.get("value", ""))
    if not value or control.get("control_type") not in {"edit", "text", "document", "combo box", "list item", "button", "custom"}:
        return 0
    name, context, score = lower_text(control.get("name", "")), control_context(control), 0
    if name == "master box": score += 600
    if "master box" in name: score += 500
    if "master box" in context: score += 350
    if re.fullmatch(r"\d+", value): score += 100
    elif re.search(r"\d", value): score += 40
    return max(score, 0)


def select_best(controls, scorer):
    candidates = []
    for control in controls:
        try:
            score = scorer(control)
            if score > 0:
                candidates.append({"score": score, "control": control})
        except Exception:
            continue
    candidates.sort(key=lambda x: x["score"], reverse=True)
    return candidates[0]["control"] if candidates else None


def score_button(control, keywords):
    if control.get("control_type") != "button":
        return 0
    name, value, context, score = lower_text(control.get("name", "")), lower_text(control.get("value", "")), control_context(control), 0
    for kw in keywords:
        kw = kw.lower()
        if kw == name: score += 500
        elif kw in name: score += 350
        elif kw in value: score += 300
        elif kw in context: score += 200
    return score


def find_best_button(controls, keywords):
    candidates = []
    for control in controls:
        try:
            score = score_button(control, keywords)
            if score > 0:
                candidates.append({"score": score, "control": control})
        except Exception:
            continue
    candidates.sort(key=lambda x: x["score"], reverse=True)
    return candidates[0]["control"] if candidates else None


def button_state(button):
    if not button:
        return {"exists": False, "enabled": False}
    try:
        return {"exists": True, "enabled": bool(button["element"].is_enabled())}
    except Exception:
        return {"exists": True, "enabled": False}


INCOMPLETE_MB_FALLBACK_PATTERNS = (
    "master box is incomplete",
    "electronic signature",
    "sign here to continue",
    "masukkan jumlah uom primary",
    "enter quantity of box",
    "check weighing - select work order",
    "ketik nomor schedule",
)


def detect_incomplete_mb_fallback(controls):
    if not controls:
        return False

    text_chunks = []
    for control in controls:
        if not isinstance(control, dict):
            continue
        for field in ("name", "value", "ancestor_text"):
            value = normalize_text(control.get(field, ""))
            if value:
                text_chunks.append(value)

    haystack = " ".join(text_chunks).lower()
    if "master box is incomplete" in haystack:
        return True
    if "electronic signature" in haystack and "sign here to continue" in haystack:
        return True
    if "masukkan jumlah uom primary" in haystack or "enter quantity of box" in haystack:
        return True
    if "check weighing - select work order" in haystack:
        return True
    if "ketik nomor schedule" in haystack:
        return True
    return False


# ============================================================
# V1 AUTOMATION FALLBACK
# ============================================================
def find_v1_control(controls, automation_id):
    for control in controls:
        if normalize_text(control.get("automation_id", "")) == automation_id:
            return control
    return None


def apply_v1_fallback(controls, data, selected_controls):
    for automation_id, field_name in V1_AUTOMATION_IDS.items():
        control = find_v1_control(controls, automation_id)
        if not control:
            continue
        value = normalize_text(control.get("value", ""))
        if field_name == "work_order" and not data["work_order"] and value:
            data["work_order"] = extract_work_order_value(value)
        elif field_name == "formula" and not data["formula"] and value:
            data["formula"] = extract_formula_value(value)
        elif field_name == "batch" and not data["batch"] and value:
            data["batch"] = extract_batch_value(value)
        elif field_name == "incomplete_mb":
            selected_controls["incomplete_button"] = control
        elif field_name == "last_mb":
            selected_controls["last_mb_button"] = control
    return data


# ============================================================
# UIA EXTRACTION ENGINE
# ============================================================
class UIAExtractor:
    def __init__(self):
        self.app = None
        self.target_window = None
        self.target_pid = None
        self.target_hwnd = None

    def find_3ws_window(self):
        # UI Automation mode
        try:
            desktop = Desktop(backend="uia")
            for win in desktop.windows(title_re=".*Penimbangan FG.*", visible_only=True):
                try:
                    pid = win.element_info.process_id
                    if self._is_target_process(pid):
                        self.target_window = win
                        self.target_pid = pid
                        self.target_hwnd = getattr(win, "handle", None)
                        return True
                except Exception:
                    continue
        except Exception:
            pass

        # Win32 Fallback
        try:
            desktop = Desktop(backend="win32")
            for win in desktop.windows(title_re=".*Penimbangan FG.*", visible_only=True):
                try:
                    pid = win.element_info.process_id
                    if not self._is_target_process(pid):
                        continue
                    hwnd = win.handle
                    app = Application(backend="uia").connect(handle=hwnd)
                    self.app = app
                    self.target_window = app.window(handle=hwnd)
                    self.target_pid = pid
                    self.target_hwnd = hwnd
                    return True
                except Exception:
                    continue
        except Exception:
            pass

        self.target_window = None
        self.target_pid = None
        self.target_hwnd = None
        return False

    def _is_target_process(self, pid):
        if not pid:
            return False
        try:
            import psutil
            return psutil.Process(pid).name().strip().lower() in TARGET_PROCESS_NAMES
        except Exception:
            return True

    def _validate_window(self):
        if self.target_window is None:
            return False
        try:
            info = self.target_window.element_info
            if info is None:
                return False
            pid = getattr(info, "process_id", None)
            if not pid:
                return False
            self.target_pid = pid
            try:
                if self.target_window.handle:
                    self.target_hwnd = self.target_window.handle
            except Exception:
                pass
            if not self._is_target_process(pid):
                self.target_window = None
                self.target_pid = None
                self.target_hwnd = None
                return False
            return True
        except Exception:
            self.target_window = None
            self.target_pid = None
            self.target_hwnd = None
            return False

    def detect_incomplete_mb_fallback_screen(self):
        if not self._validate_window():
            return False
        try:
            controls = collect_controls(self.target_window)
        except Exception:
            return False
        if not controls:
            return False
        return detect_incomplete_mb_fallback(controls)

    def extract_data(self):
        if not self._validate_window():
            return None
        try:
            controls = collect_controls(self.target_window)
        except Exception:
            return None
        if not controls:
            return None

        try:
            work_order_control = select_best(controls, score_work_order)
            product_control = select_best(controls, score_product)
            formula_control = select_best(controls, score_formula)
            batch_control = select_best(controls, score_batch)
            work_station_control = select_best(controls, score_work_station)
            machine_control = select_best(controls, score_machine)
            packer_control = select_best(controls, score_packer)
            scale_control = select_best(controls, score_scale)
            pallet_control = select_best(controls, score_pallet)
            nomor_mb_control = select_best(controls, score_nomor_mb)
            master_box_control = select_best(controls, score_master_box)
            incomplete_button = find_best_button(controls, ["INCOMPLETE MB"])
            last_mb_button = find_best_button(controls, ["MASTER BOX TERAKHIR", "LAST MB"])
        except Exception:
            return None

        data = {
            "work_order": "",
            "product_code": "",
            "formula": "",
            "batch": "",
            "work_station": "",
            "machine": "",
            "packer": "",
            "scale": "",
            "pallet": "",
            "nomor_mb": "",
            "master_box": "",
            "incomplete_mb": "",
            "last_mb": "",
            "incomplete_mb_fallback": False,
        }
        selected_controls = {"incomplete_button": incomplete_button, "last_mb_button": last_mb_button}

        if work_order_control: data["work_order"] = extract_work_order_value(work_order_control.get("value", ""))
        if product_control: data["product_code"] = clean_value(product_control.get("value", ""))
        if formula_control: data["formula"] = extract_formula_value(formula_control.get("value", ""))
        if batch_control:
            data["batch"] = extract_batch_value(batch_control.get("value", ""))
        if work_station_control:
            data["work_station"] = extract_work_station_value(
                work_station_control.get("value", "")
            )
        if machine_control: data["machine"] = clean_value(machine_control.get("value", ""))
        if packer_control: data["packer"] = clean_value(packer_control.get("value", ""))
        if scale_control: data["scale"] = clean_value(scale_control.get("value", ""))
        if pallet_control: data["pallet"] = extract_pallet_value(pallet_control.get("value", ""))
        if nomor_mb_control: data["nomor_mb"] = extract_nomor_mb_value(nomor_mb_control.get("value", ""))
        if master_box_control: data["master_box"] = extract_master_box_value(master_box_control.get("value", ""))

        data = apply_v1_fallback(controls, data, selected_controls)
        incomplete_button = selected_controls["incomplete_button"]
        last_mb_button = selected_controls["last_mb_button"]
        data["incomplete_mb_fallback"] = detect_incomplete_mb_fallback(controls)

        incomplete_state = button_state(incomplete_button)
        last_mb_state = button_state(last_mb_button)

        data["incomplete_mb"] = "enabled" if incomplete_state["enabled"] else ("disabled" if incomplete_state["exists"] else "")
        data["last_mb"] = "enabled" if last_mb_state["enabled"] else ("disabled" if last_mb_state["exists"] else "")

        if not (data["work_order"] and (data["batch"] or data["formula"] or data["product_code"])):
            return None
        return data