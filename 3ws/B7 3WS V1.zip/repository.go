package main

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"regexp"
	"strings"
	"time"
)

// ErrEventAlreadyProcessed dikembalikan jika event_id sudah ada di database (idempotent duplicate)
var ErrEventAlreadyProcessed = errors.New("event_id has already been processed")

// BatchRepository interface kontrak untuk akses data PostgreSQL
type BatchRepository interface {
	// Agent Operations
	UpsertAgent(ctx context.Context, agent *AgentRecord) error
	UpdateHeartbeat(ctx context.Context, agentID string, hostname string, agentVersion string, workStation string) error
	GetAgentByID(ctx context.Context, agentID string) (*AgentRecord, error)
	GetAllAgents(ctx context.Context) ([]AgentRecord, error)
	DeleteAgent(ctx context.Context, id int64) error

	// Idempotency & Event Processing
	IsEventProcessed(ctx context.Context, eventID string) (bool, error)
	ProcessAgentEvent(ctx context.Context, req *AgentEventRequest) error
	UpdateBatchProgress(ctx context.Context, req *ProgressRequest) error

	// Batch Queries & Search
	GetBatchByID(ctx context.Context, id int64) (*BatchRecord, error)
	GetBatchByIdentity(ctx context.Context, workOrder string, batch string, formula string, workStation string) (*BatchRecord, error)
	GetLatestBatches(ctx context.Context, limit int) ([]BatchRecord, error)
	SearchBatches(ctx context.Context, query string, page int, limit int) ([]BatchRecord, int, error)
}

// PostgresRepository struktur konkret pembungkus koneksi PostgreSQL
type PostgresRepository struct {
	db *sql.DB
}

// NewPostgresRepository instansiasi repository baru
func NewPostgresRepository(db *sql.DB) *PostgresRepository {
	return &PostgresRepository{
		db: db,
	}
}

// Helper untuk memastikan string tidak melebihi batas maksimum kolom VARCHAR database
func truncateString(s string, maxLen int) string {
	if len(s) > maxLen {
		return s[:maxLen]
	}
	return s
}

// ============================================================
// SERVER-SIDE BATCH DATA SANITATION
// ============================================================

// Regex identity batch yang dianggap valid.
// Work Order contoh: 262005801-100
var (
	reWorkOrder = regexp.MustCompile(`^\d{6,}-\d+$`)

	// Formula harus berupa identifier, bukan teks UI seperti "BOX"
	// atau "COM1: Sartorius".
	reFormula = regexp.MustCompile(`^[A-Za-z0-9][A-Za-z0-9._/-]*$`)

	// Batch minimal terdiri dari 2 token alphanumeric.
	// Contoh valid: "JH100 1G", "JH968 1G"
	reBatch = regexp.MustCompile(`^[A-Za-z0-9]+(?:[[:space:]]+[A-Za-z0-9]+)+$`)

	// Work Station optional, tetapi kalau dikirim harus format B7-...
	reWorkStation = regexp.MustCompile(`^B7-[A-Za-z0-9]+$`)
)

var invalidIdentityValues = map[string]struct{}{
	"":                {},
	"-":               {},
	"N/A":             {},
	"NA":              {},
	"NONE":            {},
	"NULL":            {},
	"UNKNOWN":         {},
	"BOX":             {},
	"COM1":            {},
	"COM2":            {},
	"COM3":            {},
	"COM4":            {},
	"SARTORIUS":       {},
	"COM1: SARTORIUS": {},
	"COM1 SARTORIUS":  {},
	"COM2: SARTORIUS": {},
	"COM2 SARTORIUS":  {},
	"COM3: SARTORIUS": {},
	"COM3 SARTORIUS":  {},
	"COM4: SARTORIUS": {},
	"COM4 SARTORIUS":  {},
}

// isJunkIdentityValue mendeteksi nilai UI yang jelas bukan identity batch.
func isJunkIdentityValue(value string) bool {
	v := strings.ToUpper(strings.TrimSpace(value))

	if _, exists := invalidIdentityValues[v]; exists {
		return true
	}

	return strings.Contains(v, "SARTORIUS") ||
		strings.Contains(v, "COM1:") ||
		strings.Contains(v, "COM2:") ||
		strings.Contains(v, "COM3:") ||
		strings.Contains(v, "COM4:")
}

// validateBatchIdentity melakukan validasi keras sebelum INSERT/UPSERT.
//
// Identity batch:
//
//	work_order + batch + formula
//
// Kalau identity invalid, data tidak boleh masuk database.
func validateBatchIdentity(req *AgentEventRequest) error {
	if req == nil {
		return fmt.Errorf("event request cannot be nil")
	}

	workOrder := strings.TrimSpace(req.WorkOrder)
	formula := strings.TrimSpace(req.Formula)
	batch := strings.TrimSpace(req.Batch)
	workStation := strings.TrimSpace(req.WorkStation)

	if isJunkIdentityValue(workOrder) {
		return fmt.Errorf("invalid work_order: %q", req.WorkOrder)
	}

	if isJunkIdentityValue(formula) {
		return fmt.Errorf("invalid formula: %q", req.Formula)
	}

	if isJunkIdentityValue(batch) {
		return fmt.Errorf("invalid batch: %q", req.Batch)
	}

	if !reWorkOrder.MatchString(workOrder) {
		return fmt.Errorf("invalid work_order format: %q", req.WorkOrder)
	}

	if !reFormula.MatchString(formula) {
		return fmt.Errorf("invalid formula format: %q", req.Formula)
	}

	if !reBatch.MatchString(batch) {
		return fmt.Errorf("invalid batch format: %q", req.Batch)
	}

	// Identity field tidak boleh sama persis.
	if strings.EqualFold(workOrder, formula) ||
		strings.EqualFold(workOrder, batch) ||
		strings.EqualFold(formula, batch) {
		return fmt.Errorf(
			"invalid batch identity: work_order, formula, and batch must be different",
		)
	}

	// Work Station optional.
	// Kalau ada, harus berupa B7-....
	if workStation != "" && !reWorkStation.MatchString(workStation) {
		return fmt.Errorf("invalid work_station format: %q", req.WorkStation)
	}

	return nil
}

// scanBatchRecord helper internal untuk membaca row BatchRecord dengan penanganan NULL pada field END
func scanBatchRecord(scanner interface {
	Scan(dest ...interface{}) error
}) (*BatchRecord, error) {
	var b BatchRecord
	var endTimestamp sql.NullTime
	var endType sql.NullString

	err := scanner.Scan(
		&b.ID,
		&b.EventID,
		&b.WorkOrder,
		&b.ProductCode,
		&b.Formula,
		&b.Batch,
		&b.WorkStation,
		&b.StartTimestamp,
		&b.StartType,
		&endTimestamp,
		&endType,
		&b.Pallet,
		&b.NomorMB,
		&b.MasterBox,
		&b.Status,
		&b.CreatedAt,
		&b.UpdatedAt,
	)
	if err != nil {
		return nil, err
	}

	if endTimestamp.Valid {
		t := endTimestamp.Time
		b.EndTimestamp = &t
	} else {
		b.EndTimestamp = nil
	}

	if endType.Valid {
		b.EndType = endType.String
	} else {
		b.EndType = ""
	}

	return &b, nil
}

// ============================================================
// AGENT OPERATIONS
// ============================================================

// UpsertAgent mendaftarkan atau memperbarui data metadata PC Agent
func (r *PostgresRepository) UpsertAgent(ctx context.Context, agent *AgentRecord) error {
	query := `
        INSERT INTO agents (
            agent_id,
            hostname,
            work_station,
            username,
            agent_version,
            first_seen,
            last_seen,
            last_heartbeat,
            created_at,
            updated_at
        )
        VALUES (
            $1, $2, $3, $4, $5,
            NOW(), NOW(), NOW(), NOW(), NOW()
        )
        ON CONFLICT (agent_id) DO UPDATE SET
            hostname = EXCLUDED.hostname,
            work_station = CASE
                WHEN EXCLUDED.work_station <> ''
                THEN EXCLUDED.work_station
                ELSE agents.work_station
            END,
            username = EXCLUDED.username,
            agent_version = EXCLUDED.agent_version,
            last_seen = NOW(),
            last_heartbeat = NOW(),
            updated_at = NOW()
        RETURNING
            id,
            first_seen,
            last_seen,
            last_heartbeat,
            created_at,
            updated_at;
    `

	err := r.db.QueryRowContext(
		ctx,
		query,
		truncateString(agent.AgentID, 50),
		truncateString(agent.Hostname, 50),
		truncateString(agent.WorkStation, 100),
		truncateString(agent.Username, 50),
		truncateString(agent.AgentVersion, 50),
	).Scan(
		&agent.ID,
		&agent.FirstSeen,
		&agent.LastSeen,
		&agent.LastHeartbeat,
		&agent.CreatedAt,
		&agent.UpdatedAt,
	)

	if err != nil {
		return fmt.Errorf("repository: failed to upsert agent: %w", err)
	}

	return nil
}

// UpdateHeartbeat memperbarui timestamp last_heartbeat dan last_seen agent
// sekaligus memperbarui WorkStation jika dikirim oleh Agent.
func (r *PostgresRepository) UpdateHeartbeat(
	ctx context.Context,
	agentID string,
	hostname string,
	agentVersion string,
	workStation string,
) error {
	query := `
        UPDATE agents
        SET
            last_heartbeat = NOW(),
            last_seen = NOW(),

            hostname = CASE
                WHEN $2 <> ''
                THEN $2
                ELSE hostname
            END,

            agent_version = CASE
                WHEN $3 <> ''
                THEN $3
                ELSE agent_version
            END,

            work_station = CASE
                WHEN $4 <> ''
                THEN $4
                ELSE work_station
            END,

            updated_at = NOW()
        WHERE agent_id = $1;
    `

	result, err := r.db.ExecContext(
		ctx,
		query,
		truncateString(agentID, 50),
		truncateString(hostname, 50),
		truncateString(agentVersion, 50),
		truncateString(workStation, 100),
	)
	if err != nil {
		return fmt.Errorf(
			"repository: failed to update agent heartbeat: %w",
			err,
		)
	}

	rowsAffected, err := result.RowsAffected()
	if err != nil {
		return fmt.Errorf(
			"repository: failed to check rows affected on heartbeat: %w",
			err,
		)
	}

	if rowsAffected == 0 {
		return fmt.Errorf(
			"repository: agent with id '%s' not found for heartbeat",
			agentID,
		)
	}

	return nil
}

// GetAgentByID mengambil data detail Agent berdasarkan agent_id
func (r *PostgresRepository) GetAgentByID(ctx context.Context, agentID string) (*AgentRecord, error) {
	query := `
        SELECT
            id,
            agent_id,
            hostname,
            work_station,
            username,
            agent_version,
            first_seen,
            last_seen,
            last_heartbeat,
            created_at,
            updated_at
        FROM agents
        WHERE agent_id = $1;
    `

	var agent AgentRecord

	err := r.db.QueryRowContext(
		ctx,
		query,
		truncateString(agentID, 50),
	).Scan(
		&agent.ID,
		&agent.AgentID,
		&agent.Hostname,
		&agent.WorkStation,
		&agent.Username,
		&agent.AgentVersion,
		&agent.FirstSeen,
		&agent.LastSeen,
		&agent.LastHeartbeat,
		&agent.CreatedAt,
		&agent.UpdatedAt,
	)

	if err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, nil
		}

		return nil, fmt.Errorf(
			"repository: failed to get agent by id: %w",
			err,
		)
	}

	return &agent, nil
}

// GetAllAgents mengambil seluruh daftar Agent untuk dipantau pada monitor.html.
// Jika agents.work_station kosong, ambil Work Station terakhir dari batch_records
// melalui event_records.agent_id.
func (r *PostgresRepository) GetAllAgents(ctx context.Context) ([]AgentRecord, error) {
	query := `
        SELECT
            a.id,
            a.agent_id,
            a.hostname,

            COALESCE(
                NULLIF(TRIM(a.work_station), ''),
                latest_ws.work_station,
                ''
            ) AS work_station,

            a.username,
            a.agent_version,
            a.first_seen,
            a.last_seen,
            a.last_heartbeat,
            a.created_at,
            a.updated_at

        FROM agents a

        LEFT JOIN (
            SELECT
                er.agent_id,
                br.work_station,
                ROW_NUMBER() OVER (
                    PARTITION BY er.agent_id
                    ORDER BY br.start_timestamp DESC, br.id DESC
                ) AS rn
            FROM batch_records br
            INNER JOIN event_records er
                ON er.event_id = br.event_id
            WHERE TRIM(br.work_station) <> ''
        ) latest_ws
            ON latest_ws.agent_id = a.agent_id
            AND latest_ws.rn = 1

        ORDER BY a.last_seen DESC;
    `

	rows, err := r.db.QueryContext(ctx, query)
	if err != nil {
		return nil, fmt.Errorf("repository: failed to query agents: %w", err)
	}
	defer rows.Close()

	agents := make([]AgentRecord, 0)

	for rows.Next() {
		var a AgentRecord

		if err := rows.Scan(
			&a.ID,
			&a.AgentID,
			&a.Hostname,
			&a.WorkStation,
			&a.Username,
			&a.AgentVersion,
			&a.FirstSeen,
			&a.LastSeen,
			&a.LastHeartbeat,
			&a.CreatedAt,
			&a.UpdatedAt,
		); err != nil {
			return nil, fmt.Errorf("repository: failed to scan agent row: %w", err)
		}

		agents = append(agents, a)
	}

	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("repository: rows iteration error: %w", err)
	}

	return agents, nil
}

// DeleteAgent menghapus record Agent berdasarkan primary key ID.
func (r *PostgresRepository) DeleteAgent(ctx context.Context, id int64) error {
	if id <= 0 {
		return fmt.Errorf("repository: invalid agent id: %d", id)
	}

	query := `
        DELETE FROM agents
        WHERE id = $1;
    `

	result, err := r.db.ExecContext(ctx, query, id)
	if err != nil {
		return fmt.Errorf(
			"repository: failed to delete agent: %w",
			err,
		)
	}

	rowsAffected, err := result.RowsAffected()
	if err != nil {
		return fmt.Errorf(
			"repository: failed to check deleted agent: %w",
			err,
		)
	}

	if rowsAffected == 0 {
		return fmt.Errorf(
			"repository: agent with id %d not found",
			id,
		)
	}

	return nil
}

// ============================================================
// IDEMPOTENCY & EVENT PROCESSING
// ============================================================

// IsEventProcessed mengecek apakah event_id tertentu sudah pernah dicatat
func (r *PostgresRepository) IsEventProcessed(ctx context.Context, eventID string) (bool, error) {
	query := `SELECT EXISTS(SELECT 1 FROM event_records WHERE event_id = $1);`
	var exists bool
	err := r.db.QueryRowContext(ctx, query, truncateString(eventID, 50)).Scan(&exists)
	if err != nil {
		return false, fmt.Errorf("repository: failed to check event idempotency: %w", err)
	}
	return exists, nil
}

// ProcessAgentEvent mengeksekusi idempotency check dan batch record update dalam satu transaksi atomic.
func (r *PostgresRepository) ProcessAgentEvent(ctx context.Context, req *AgentEventRequest) error {
	// ------------------------------------------------------------
	// 0. Server-side validation
	// ------------------------------------------------------------
	if req == nil {
		return fmt.Errorf("repository: event request cannot be nil")
	}

	if err := req.Validate(); err != nil {
		return fmt.Errorf("repository: invalid event request: %w", err)
	}

	if err := validateBatchIdentity(req); err != nil {
		return fmt.Errorf("repository: rejected invalid batch identity: %w", err)
	}

	tx, err := r.db.BeginTx(ctx, nil)
	if err != nil {
		return fmt.Errorf("repository: failed to begin event processing tx: %w", err)
	}

	defer func() {
		if p := recover(); p != nil {
			_ = tx.Rollback()
			panic(p)
		}
	}()

	// Sanitasi string maks 50 karakter untuk mencegah eror VARCHAR(50)
	safeEventID := truncateString(req.EventID, 50)
	safeAgentID := truncateString(req.AgentID, 50)
	safeEventType := truncateString(string(req.EventType), 50)
	safeWorkOrder := truncateString(req.WorkOrder, 50)
	safeBatch := truncateString(req.Batch, 50)
	safeFormula := truncateString(req.Formula, 50)
	safeProductCode := truncateString(req.ProductCode, 50)
	safeWorkStation := truncateString(req.WorkStation, 50)
	safePallet := truncateString(req.Pallet, 50)
	safeNomorMB := truncateString(req.NomorMB, 50)
	safeMasterBox := truncateString(req.MasterBox, 50)

	// ------------------------------------------------------------
	// 1. Simpan event_id ke event_records (Idempotency Guard)
	// ------------------------------------------------------------
	insertEventQuery := `
        INSERT INTO event_records (
            event_id,
            agent_id,
            event_type,
            work_order,
            batch,
            formula,
            created_at
        )
        VALUES ($1, $2, $3, $4, $5, $6, NOW())
        ON CONFLICT (event_id) DO NOTHING;
    `

	res, err := tx.ExecContext(
		ctx,
		insertEventQuery,
		safeEventID,
		safeAgentID,
		safeEventType,
		safeWorkOrder,
		safeBatch,
		safeFormula,
	)
	if err != nil {
		_ = tx.Rollback()
		return fmt.Errorf("repository: failed to insert event_record: %w", err)
	}

	rowsAffected, err := res.RowsAffected()
	if err != nil {
		_ = tx.Rollback()
		return fmt.Errorf("repository: failed to check rows affected on event: %w", err)
	}

	if rowsAffected == 0 {
		_ = tx.Rollback()
		return ErrEventAlreadyProcessed
	}

	// ------------------------------------------------------------
	// 2. Tentukan timestamp event
	// ------------------------------------------------------------
	eventTime := req.Timestamp
	if eventTime.IsZero() {
		eventTime = time.Now()
	}

	startType := req.StartType

	if startType == "" && req.EventType == EventTypeMidProcess {
		startType = StartTypeMidProcess
	} else if startType == "" && req.EventType == EventTypeStart {
		startType = StartTypeStartProcess
	}

	safeStartType := truncateString(startType, 50)

	// ------------------------------------------------------------
	// 3. Olah State Batch berdasarkan Event Type
	// ------------------------------------------------------------
	switch req.EventType {

	case EventTypeMidProcess, EventTypeStart:

		upsertBatchQuery := `
            INSERT INTO batch_records (
                event_id,
                work_order,
                product_code,
                formula,
                batch,
                work_station,
                start_timestamp,
                start_type,
                pallet,
                nomor_mb,
                master_box,
                status,
                created_at,
                updated_at
            )
            VALUES (
                $1, $2, $3, $4, $5, $6,
                $7, $8, $9, $10, $11, $12,
                NOW(), NOW()
            )
            ON CONFLICT (work_order, batch, formula, work_station) DO UPDATE SET
                event_id = EXCLUDED.event_id,

                product_code = CASE
                    WHEN EXCLUDED.product_code <> ''
                    THEN EXCLUDED.product_code
                    ELSE batch_records.product_code
                END,

                work_station = CASE
                    WHEN EXCLUDED.work_station <> ''
                    THEN EXCLUDED.work_station
                    ELSE batch_records.work_station
                END,

                start_timestamp = CASE
                    WHEN $13 = 'START'
                    THEN EXCLUDED.start_timestamp
                    ELSE batch_records.start_timestamp
                END,

                start_type = CASE
                    WHEN $13 = 'START'
                    THEN EXCLUDED.start_type
                    ELSE batch_records.start_type
                END,

                pallet = EXCLUDED.pallet,
                nomor_mb = EXCLUDED.nomor_mb,
                master_box = EXCLUDED.master_box,
                updated_at = NOW();
        `

		_, err = tx.ExecContext(
			ctx,
			upsertBatchQuery,
			safeEventID,
			safeWorkOrder,
			safeProductCode,
			safeFormula,
			safeBatch,
			safeWorkStation,
			eventTime,
			safeStartType,
			safePallet,
			safeNomorMB,
			safeMasterBox,
			truncateString(string(BatchStatusRunning), 50),
			safeEventType,
		)

	case EventTypeEnd:

		endType := req.EndType
		if endType == "" {
			endType = "normal completion"
		}
		safeEndType := truncateString(endType, 50)
		updatedExisting := false

		if safeWorkStation == "" {
			fallbackUpdateQuery := `
                UPDATE batch_records
                SET
                    event_id = $1,
                    product_code = CASE
                        WHEN $4 <> '' THEN $4
                        ELSE product_code
                    END,
                    end_timestamp = $5,
                    end_type = $6,
                    pallet = $7,
                    nomor_mb = $8,
                    master_box = $9,
                    status = $10,
                    updated_at = NOW()
                WHERE id = (
                    SELECT id
                    FROM batch_records
                    WHERE work_order = $2
                      AND batch = $3
                      AND formula = $11
                      AND work_station <> ''
                      AND status IN ('Running', 'Idle')
                    ORDER BY updated_at DESC
                    LIMIT 1
                )
            `

			fallbackResult, fallbackErr := tx.ExecContext(
				ctx,
				fallbackUpdateQuery,
				safeEventID,
				safeWorkOrder,
				safeBatch,
				safeProductCode,
				eventTime,
				safeEndType,
				safePallet,
				safeNomorMB,
				safeMasterBox,
				truncateString(string(BatchStatusCompleted), 50),
				safeFormula,
			)
			if fallbackErr != nil {
				err = fallbackErr
			} else {
				rowsAffected, rowsErr := fallbackResult.RowsAffected()
				if rowsErr != nil {
					err = rowsErr
				} else {
					updatedExisting = rowsAffected > 0
				}
			}
		}

		endBatchQuery := `
            INSERT INTO batch_records (
                event_id,
                work_order,
                product_code,
                formula,
                batch,
                work_station,
                start_timestamp,
                start_type,
                end_timestamp,
                end_type,
                pallet,
                nomor_mb,
                master_box,
                status,
                created_at,
                updated_at
            )
            VALUES (
                $1, $2, $3, $4, $5, $6,
                $7, $8, $9, $10, $11, $12, $13,
                $14, NOW(), NOW()
            )
            ON CONFLICT (work_order, batch, formula, work_station) DO UPDATE SET
                event_id = EXCLUDED.event_id,

                product_code = CASE
                    WHEN EXCLUDED.product_code <> ''
                    THEN EXCLUDED.product_code
                    ELSE batch_records.product_code
                END,

                work_station = CASE
                    WHEN EXCLUDED.work_station <> ''
                    THEN EXCLUDED.work_station
                    ELSE batch_records.work_station
                END,

                end_timestamp = EXCLUDED.end_timestamp,
                end_type = EXCLUDED.end_type,
                pallet = EXCLUDED.pallet,
                nomor_mb = EXCLUDED.nomor_mb,
                master_box = EXCLUDED.master_box,
                status = EXCLUDED.status,
                updated_at = NOW();
        `

		if err == nil && !updatedExisting {
			_, err = tx.ExecContext(
				ctx,
				endBatchQuery,
				safeEventID,
				safeWorkOrder,
				safeProductCode,
				safeFormula,
				safeBatch,
				safeWorkStation,
				eventTime,
				safeStartType,
				eventTime,
				safeEndType,
				safePallet,
				safeNomorMB,
				safeMasterBox,
				truncateString(string(BatchStatusCompleted), 50),
			)
		}

		if err == nil && safeWorkStation != "" {
			_, err = tx.ExecContext(
				ctx,
				`UPDATE batch_records
				 SET
					end_timestamp = $5,
					end_type = 'completed on another workstation',
					status = $6,
					updated_at = NOW()
				 WHERE work_order = $1
				   AND batch = $2
				   AND formula = $3
				   AND work_station <> $4
				   AND end_timestamp IS NULL
				   AND status IN ('Running', 'Idle')`,
				safeWorkOrder,
				safeBatch,
				safeFormula,
				safeWorkStation,
				eventTime,
				truncateString(string(BatchStatusCompleted), 50),
			)
		}

	default:
		_ = tx.Rollback()
		return fmt.Errorf("repository: unsupported event_type '%s'", req.EventType)
	}

	if err != nil {
		_ = tx.Rollback()
		return fmt.Errorf(
			"repository: failed to execute batch upsert for event %s: %w",
			req.EventType,
			err,
		)
	}

	// ------------------------------------------------------------
	// 4. Update last_seen & last_heartbeat agent terkait
	// ------------------------------------------------------------
	updateAgentQuery := `
        UPDATE agents
        SET
            last_seen = NOW(),
            last_heartbeat = NOW(),
            updated_at = NOW()
        WHERE agent_id = $1;
    `

	_, _ = tx.ExecContext(ctx, updateAgentQuery, safeAgentID)

	// ------------------------------------------------------------
	// 5. Commit
	// ------------------------------------------------------------
	if err := tx.Commit(); err != nil {
		return fmt.Errorf("repository: failed to commit event tx: %w", err)
	}

	return nil
}

// UpdateBatchProgress memperbarui realtime progress batch.
//
// Identity batch:
// work_order + batch + formula + work_station
//
// Normal:
//
//	Running -> update pallet/nomor_mb
//
// Recovery dari ghost END:
//
//	Completed + pallet/nomor_mb berubah
//	-> clear END
//	-> kembali Running
//	-> update progress
//
// Completed + tidak ada perubahan:
//
//	-> tetap Completed
func (r *PostgresRepository) UpdateBatchProgress(
	ctx context.Context,
	req *ProgressRequest,
) error {
	tx, err := r.db.BeginTx(ctx, nil)
	if err != nil {
		return fmt.Errorf(
			"repository: failed to begin progress tx: %w",
			err,
		)
	}

	defer func() {
		if p := recover(); p != nil {
			_ = tx.Rollback()
			panic(p)
		}
	}()

	workOrder := truncateString(req.WorkOrder, 50)
	batch := truncateString(req.Batch, 50)
	formula := truncateString(req.Formula, 50)
	workStation := truncateString(req.WorkStation, 100)
	newPallet := truncateString(req.Pallet, 50)
	newNomorMB := truncateString(req.NomorMB, 50)

	var (
		currentStatus  string
		currentPallet  string
		currentNomorMB string
		currentEndType string
	)

	// ============================================================
	// Ambil batch berdasarkan FULL identity.
	//
	// WAJIB menggunakan work_station agar progress agent tidak
	// mengambil batch milik workstation lain.
	// ============================================================
	err = tx.QueryRowContext(ctx, `
        SELECT
            status,
            COALESCE(pallet, ''),
			COALESCE(nomor_mb, ''),
			COALESCE(end_type, '')
        FROM batch_records
        WHERE work_order = $1
          AND batch = $2
          AND formula = $3
          AND work_station = $4
        ORDER BY id DESC
        LIMIT 1;
    `,
		workOrder,
		batch,
		formula,
		workStation,
	).Scan(
		&currentStatus,
		&currentPallet,
		&currentNomorMB,
		&currentEndType,
	)

	if err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			_ = tx.Rollback()

			return fmt.Errorf(
				"running batch not found for progress: work_order=%s batch=%s formula=%s work_station=%s",
				req.WorkOrder,
				req.Batch,
				req.Formula,
				req.WorkStation,
			)
		}

		_ = tx.Rollback()

		return fmt.Errorf(
			"repository: failed to read batch state for progress: %w",
			err,
		)
	}

	// ============================================================
	// CASE 1: NORMAL RUNNING
	// ============================================================
	if currentStatus == string(BatchStatusRunning) {

		_, err = tx.ExecContext(ctx, `
            UPDATE batch_records
            SET
                pallet = $1,
                nomor_mb = $2,
                updated_at = NOW()
            WHERE work_order = $3
              AND batch = $4
              AND formula = $5
              AND work_station = $6
              AND status = $7;
        `,
			newPallet,
			newNomorMB,
			workOrder,
			batch,
			formula,
			workStation,
			string(BatchStatusRunning),
		)

		if err != nil {
			_ = tx.Rollback()

			return fmt.Errorf(
				"repository: failed to update batch progress: %w",
				err,
			)
		}

	} else if currentStatus == string(BatchStatusCompleted) {
		if currentEndType == "completed on another workstation" {
			_ = tx.Rollback()
			return nil
		}

		// ========================================================
		// CASE 2: COMPLETED TAPI PROGRESS BERUBAH
		//
		// Ini indikasi END sebelumnya adalah stale/ghost END.
		// ========================================================
		progressChanged :=
			newPallet != currentPallet ||
				newNomorMB != currentNomorMB

		if !progressChanged {
			_ = tx.Rollback()

			return fmt.Errorf(
				"completed batch has no new progress: work_order=%s batch=%s formula=%s work_station=%s",
				req.WorkOrder,
				req.Batch,
				req.Formula,
				req.WorkStation,
			)
		}

		_, err = tx.ExecContext(ctx, `
            UPDATE batch_records
            SET
                status = $1,
                end_timestamp = NULL,
                end_type = '',
                pallet = $2,
                nomor_mb = $3,
                updated_at = NOW()
            WHERE work_order = $4
              AND batch = $5
              AND formula = $6
              AND work_station = $7
              AND status = $8;
        `,
			string(BatchStatusRunning),
			newPallet,
			newNomorMB,
			workOrder,
			batch,
			formula,
			workStation,
			string(BatchStatusCompleted),
		)

		if err != nil {
			_ = tx.Rollback()

			return fmt.Errorf(
				"repository: failed to reopen completed batch: %w",
				err,
			)
		}

	} else {
		_ = tx.Rollback()

		return fmt.Errorf(
			"unsupported batch status for progress: status=%s work_order=%s batch=%s formula=%s work_station=%s",
			currentStatus,
			req.WorkOrder,
			req.Batch,
			req.Formula,
			req.WorkStation,
		)
	}

	// ============================================================
	// REFRESH AGENT HEARTBEAT
	// ============================================================
	_, _ = tx.ExecContext(ctx, `
        UPDATE agents
        SET
            last_seen = NOW(),
            last_heartbeat = NOW(),
            updated_at = NOW()
        WHERE agent_id = $1;
    `,
		truncateString(req.AgentID, 100),
	)

	// ============================================================
	// COMMIT
	// ============================================================
	if err := tx.Commit(); err != nil {
		return fmt.Errorf(
			"repository: failed to commit progress tx: %w",
			err,
		)
	}

	return nil
}

// ============================================================
// BATCH QUERIES & SEARCH
// ============================================================

// GetBatchByID mengambil 1 row BatchRecord berdasarkan ID primary key
func (r *PostgresRepository) GetBatchByID(ctx context.Context, id int64) (*BatchRecord, error) {
	query := `
        SELECT id, event_id, work_order, product_code, formula, batch,
               work_station,
               start_timestamp, start_type, end_timestamp, end_type,
               pallet, nomor_mb, master_box, status, created_at, updated_at
        FROM batch_records
        WHERE id = $1;
    `

	row := r.db.QueryRowContext(ctx, query, id)
	b, err := scanBatchRecord(row)

	if err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, nil
		}
		return nil, fmt.Errorf("repository: failed to get batch by id: %w", err)
	}

	return b, nil
}

// GetBatchByIdentity mengambil batch berdasarkan identity + workstation.
// Workstation digunakan sebagai guard agar agent tidak attach ke batch
// milik workstation lain.
func (r *PostgresRepository) GetBatchByIdentity(
	ctx context.Context,
	workOrder string,
	batch string,
	formula string,
	workStation string,
) (*BatchRecord, error) {
	query := `
        SELECT id, event_id, work_order, product_code, formula, batch,
               work_station,
               start_timestamp, start_type, end_timestamp, end_type,
               pallet, nomor_mb, master_box, status, created_at, updated_at
        FROM batch_records
        WHERE work_order = $1
          AND batch = $2
          AND formula = $3
          AND work_station = $4
        ORDER BY id DESC
        LIMIT 1;
    `

	row := r.db.QueryRowContext(
		ctx,
		query,
		truncateString(strings.TrimSpace(workOrder), 50),
		truncateString(strings.TrimSpace(batch), 50),
		truncateString(strings.TrimSpace(formula), 50),
		truncateString(strings.TrimSpace(workStation), 50),
	)

	b, err := scanBatchRecord(row)
	if err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, nil
		}

		return nil, fmt.Errorf(
			"repository: failed to get batch by identity: %w",
			err,
		)
	}

	return b, nil
}

// GetLatestBatches mengambil daftar batch terbaru sesuai limit
func (r *PostgresRepository) GetLatestBatches(ctx context.Context, limit int) ([]BatchRecord, error) {
	if limit <= 0 || limit > 300 {
		limit = 30
	}

	query := `
        SELECT id, event_id, work_order, product_code, formula, batch,
               work_station,
               start_timestamp, start_type, end_timestamp, end_type,
               pallet, nomor_mb, master_box, status, created_at, updated_at
        FROM batch_records
        ORDER BY
    CASE
        WHEN status = 'Running' THEN 0
        ELSE 1
    END,
    start_timestamp DESC,
    id DESC
        LIMIT $1;
    `

	rows, err := r.db.QueryContext(ctx, query, limit)
	if err != nil {
		return nil, fmt.Errorf("repository: failed to fetch latest batches: %w", err)
	}
	defer rows.Close()

	batches := make([]BatchRecord, 0)
	for rows.Next() {
		b, err := scanBatchRecord(rows)
		if err != nil {
			return nil, fmt.Errorf("repository: failed to scan batch row: %w", err)
		}
		batches = append(batches, *b)
	}

	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("repository: rows iteration error: %w", err)
	}

	return batches, nil
}

// SearchBatches melakukan pencarian global case-insensitive dengan pagination
func (r *PostgresRepository) SearchBatches(ctx context.Context, query string, page int, limit int) ([]BatchRecord, int, error) {
	if page < 1 {
		page = 1
	}
	if limit <= 0 || limit > 30 {
		limit = 30
	}
	offset := (page - 1) * limit

	cleanQuery := strings.TrimSpace(query)
	var countQuery string
	var dataQuery string
	var args []interface{}

	if cleanQuery == "" {
		countQuery = `SELECT COUNT(*) FROM batch_records;`
		dataQuery = `
            SELECT id, event_id, work_order, product_code, formula, batch,
                   work_station,
                   start_timestamp, start_type, end_timestamp, end_type,
                   pallet, nomor_mb, master_box, status, created_at, updated_at
            FROM batch_records
            ORDER BY
    CASE
        WHEN status = 'Running' THEN 0
        ELSE 1
    END,
    start_timestamp DESC,
    id DESC
            LIMIT $1 OFFSET $2;
        `
		args = []interface{}{limit, offset}
	} else {
		searchPattern := "%" + cleanQuery + "%"
		whereClause := `
            WHERE work_order ILIKE $1
               OR product_code ILIKE $1
               OR formula ILIKE $1
               OR batch ILIKE $1
               OR work_station ILIKE $1
               OR pallet ILIKE $1
               OR nomor_mb ILIKE $1
               OR master_box ILIKE $1
        `

		countQuery = fmt.Sprintf("SELECT COUNT(*) FROM batch_records %s;", whereClause)
		dataQuery = fmt.Sprintf(`
            SELECT id, event_id, work_order, product_code, formula, batch,
                   work_station,
                   start_timestamp, start_type, end_timestamp, end_type,
                   pallet, nomor_mb, master_box, status, created_at, updated_at
            FROM batch_records
            %s
            ORDER BY
    CASE
        WHEN status = 'Running' THEN 0
        ELSE 1
    END,
    start_timestamp DESC,
    id DESC
            LIMIT $2 OFFSET $3;
        `, whereClause)

		args = []interface{}{searchPattern, limit, offset}
	}

	// 1. Hitung total data (setelah dipotong query search)
	var total int
	if cleanQuery == "" {
		err := r.db.QueryRowContext(ctx, countQuery).Scan(&total)
		if err != nil {
			return nil, 0, fmt.Errorf("repository: failed to count batches: %w", err)
		}
	} else {
		err := r.db.QueryRowContext(ctx, countQuery, "%"+cleanQuery+"%").Scan(&total)
		if err != nil {
			return nil, 0, fmt.Errorf("repository: failed to count search batches: %w", err)
		}
	}

	if total == 0 {
		return []BatchRecord{}, 0, nil
	}

	// 2. Ambil data terpaginasi
	rows, err := r.db.QueryContext(ctx, dataQuery, args...)
	if err != nil {
		return nil, 0, fmt.Errorf("repository: failed to search batches: %w", err)
	}
	defer rows.Close()

	batches := make([]BatchRecord, 0)
	for rows.Next() {
		b, err := scanBatchRecord(rows)
		if err != nil {
			return nil, 0, fmt.Errorf("repository: failed to scan searched batch row: %w", err)
		}
		batches = append(batches, *b)
	}

	if err := rows.Err(); err != nil {
		return nil, 0, fmt.Errorf("repository: search rows iteration error: %w", err)
	}

	return batches, total, nil
}
