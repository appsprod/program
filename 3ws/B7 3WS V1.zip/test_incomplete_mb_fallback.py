from capture_core import detect_incomplete_mb_fallback


def test_detect_incomplete_mb_fallback_accepts_gate_2_screen_patterns():
    controls = [
        {"name": "Confirm", "value": "Confirm", "ancestor_text": "", "control_type": "button"},
        {"name": "Master box is incomplete", "value": "PLEASE CONFIRM THIS IS THE LAST MASTER BOX.", "ancestor_text": "", "control_type": "text"},
        {"name": "Electronic Signature", "value": "", "ancestor_text": "", "control_type": "text"},
        {"name": "Check Weighing - Select Work Order", "value": "", "ancestor_text": "", "control_type": "text"},
        {"name": "Penimbang DKU072", "value": "", "ancestor_text": "", "control_type": "text"},
    ]

    assert detect_incomplete_mb_fallback(controls) is True


def test_detect_incomplete_mb_fallback_rejects_unrelated_ui():
    controls = [
        {"name": "Dashboard", "value": "App overview", "ancestor_text": "", "control_type": "text"},
        {"name": "Idle", "value": "00:10:00", "ancestor_text": "", "control_type": "text"},
    ]

    assert detect_incomplete_mb_fallback(controls) is False
