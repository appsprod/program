package main

import (
	"context"
	"database/sql"
	"fmt"
	"strconv"
	"strings"
	"time"
)

type CompoundingService struct {
	repo *CompoundingRepository
}

func NewCompoundingService(
	repo *CompoundingRepository,
) *CompoundingService {
	return &CompoundingService{
		repo: repo,
	}
}

func (s *CompoundingService) EnsureSchema(
	ctx context.Context,
) error {
	return s.repo.EnsureSchema(ctx)
}

func (s *CompoundingService) GetBatches(
	ctx context.Context,
	page int,
	limit int,
) ([]CompoundingRecord, int, int, error) {

	data, total, err := s.repo.GetPaginated(
		ctx,
		page,
		limit,
	)

	if err != nil {
		return nil, 0, 0, err
	}

	return data, total, compoundingTotalPages(total, limit), nil
}

func (s *CompoundingService) Start(
	ctx context.Context,
	event *CompoundingEvent,
) error {

	if event.SessionID == "" {
		return fmt.Errorf("session_id kosong")
	}

	existing, err := s.repo.GetBySessionID(
		ctx,
		event.SessionID,
	)

	if err == nil && existing != nil {
		return nil
	}

	if err != sql.ErrNoRows && err != nil {
		return err
	}

	rec := snapshotToCompoundingRecord(event)

	rec.Status = "Running"

	if rec.StartTimestamp == nil {
		ts := event.Timestamp
		rec.StartTimestamp = &ts
	}

	return s.repo.Create(
		ctx,
		rec,
	)
}

func (s *CompoundingService) Progress(
	ctx context.Context,
	event *CompoundingEvent,
) error {

	if event.SessionID == "" {
		return fmt.Errorf("session_id kosong")
	}

	rec, err := s.repo.GetBySessionID(
		ctx,
		event.SessionID,
	)

	if err == sql.ErrNoRows {
		// PROGRESS tidak boleh membuat lifecycle baru.
		// START harus datang lebih dahulu.
		return fmt.Errorf(
			"compounding session belum START: %s",
			event.SessionID,
		)
	}

	if err != nil {
		return err
	}

	if rec.Status != "Running" {
		return nil
	}

	update := snapshotToCompoundingRecord(event)

	update.SessionID = event.SessionID

	return s.repo.UpdateProgress(
		ctx,
		update,
	)
}

func (s *CompoundingService) Complete(
	ctx context.Context,
	event *CompoundingEvent,
) error {

	if event.SessionID == "" {
		return fmt.Errorf("session_id kosong")
	}

	rec, err := s.repo.GetBySessionID(
		ctx,
		event.SessionID,
	)

	if err == sql.ErrNoRows {
		return fmt.Errorf(
			"END tanpa session START: %s",
			event.SessionID,
		)
	}

	if err != nil {
		return err
	}

	if rec.Status == "Completed" {
		return nil
	}

	endTimestamp := event.Timestamp

	return s.repo.Complete(
		ctx,
		event.SessionID,
		endTimestamp,
	)
}

func snapshotToCompoundingRecord(
	event *CompoundingEvent,
) *CompoundingRecord {

	data := event.Data

	rec := &CompoundingRecord{
		Order:              stringValue(data["order"]),
		ProductName:        stringValue(data["product_name"]),
		Formula:            stringValue(data["formula"]),
		Location:           stringValue(data["location"]),
		Dispensed:          stringValue(data["dispensed"]),
		TotalValidasi:      intValue(data["total_validasi"]),
		TotalMaterials:     intValue(data["total_materials"]),
		CompletedMaterials: intValue(data["completed_materials"]),
		Progress:           stringValue(data["progress"]),
		SessionID:          event.SessionID,
		AgentID:            event.AgentID,
		Hostname:           event.Hostname,
	}

	if rec.Progress == "" &&
		rec.TotalMaterials > 0 {

		rec.Progress = fmt.Sprintf(
			"%d/%d",
			rec.CompletedMaterials,
			rec.TotalMaterials,
		)
	}

	if event.Timestamp.IsZero() {
		now := time.Now().UTC()
		rec.StartTimestamp = &now
	} else {
		ts := event.Timestamp
		rec.StartTimestamp = &ts
	}

	return rec
}

func stringValue(v interface{}) string {
	if v == nil {
		return ""
	}

	switch value := v.(type) {
	case string:
		return strings.TrimSpace(value)

	case []byte:
		return strings.TrimSpace(string(value))

	case float64:
		return strconv.FormatFloat(
			value,
			'f',
			-1,
			64,
		)

	case float32:
		return strconv.FormatFloat(
			float64(value),
			'f',
			-1,
			32,
		)

	case int:
		return strconv.Itoa(value)

	case int64:
		return strconv.FormatInt(
			value,
			10,
		)

	default:
		return fmt.Sprintf(
			"%v",
			value,
		)
	}
}

func intValue(v interface{}) int {
	if v == nil {
		return 0
	}

	switch value := v.(type) {
	case int:
		return value

	case int64:
		return int(value)

	case float64:
		return int(value)

	case float32:
		return int(value)

	case string:
		n, _ := strconv.Atoi(
			strings.TrimSpace(value),
		)
		return n

	default:
		n, _ := strconv.Atoi(
			stringValue(value),
		)
		return n
	}
}