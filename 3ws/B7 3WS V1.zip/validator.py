# validator.py
#
# B7 3WS Capture - Data Validator
#
# Fungsi:
# - Memvalidasi hasil extraction dari B7CaptureAgent.py
# - Mendeteksi data UI junk / false extraction
# - Menentukan apakah data layak dikirim ke server
#
# TIDAK menangani:
# - START
# - MID_PROCESS
# - PROGRESS
# - END
# - Mouse detector
# - Session lifecycle
#
# Usage dari B7CaptureAgent.py:
#
#     from validator import validate_capture_data, is_valid_capture_data
#
#     result = validate_capture_data(data)
#     if not result["valid"]:
#         return None
#
# atau cukup:
#
#     if not is_valid_capture_data(data):
#         return None
#

import re
from typing import Any, Dict

# ============================================================
# CONFIG
# ============================================================

# Work Order normal 3WS umumnya berbentuk:
#   262005801-100
#   262005802-100
#   262005767-100
#
# Jangan dibuat terlalu ketat terhadap jumlah digit,
# supaya tidak merusak jika format WO berubah di kemudian hari.
WORK_ORDER_PATTERN = re.compile(
    r"^\d{6,}-\d+$",
    re.IGNORECASE
)

# Work Station normal:
#   B7-PGDPRDD13
#   B7-PGDBKPD13
WORK_STATION_PATTERN = re.compile(
    r"^B7-[A-Z0-9]+$",
    re.IGNORECASE
)

# Formula/kode produk normal.
# Contoh:
#   LNKOA
#   LKNTA
#   LKKSB
#   LKJTA
FORMULA_PATTERN = re.compile(
    r"^[A-Z0-9][A-Z0-9._/-]{1,30}$",
    re.IGNORECASE
)

# Batch normal umumnya terdiri dari minimal dua token:
#   JH100 1G
#   JH101 1G
#   JH991 1M
#   JH103 1A
BATCH_PATTERN = re.compile(
    r"^[A-Z0-9]+(?:\s+[A-Z0-9]+)+$",
    re.IGNORECASE
)

# ============================================================
# JUNK VALUES
# ============================================================

# Nilai yang jelas merupakan hasil salah capture / UI text.
# Comparison dilakukan case-insensitive.
JUNK_EXACT_VALUES = {
    "",
    "-",
    "N/A",
    "NA",
    "NONE",
    "NULL",
    "UNKNOWN",

    # Contoh anomaly yang sudah ditemukan
    "BOX",
    "COM1: SARTORIUS",
    "COM1 SARTORIUS",

    # Generic UI/device text
    "SARTORIUS",
    "COM1",
    "COM2",
    "COM3",
    "COM4",
}

# Potongan text yang tidak boleh muncul sebagai nilai bisnis.
JUNK_CONTAINS_VALUES = (
    "sartorius",
    "com1:",
    "com2:",
    "com3:",
    "com4:",
)

# ============================================================
# BASIC HELPERS
# ============================================================

def normalize(value: Any) -> str:
    """
    Normalisasi value menjadi string bersih.

    Tidak mengubah isi bisnis selain:
    - None -> ""
    - trim whitespace
    - whitespace berulang -> satu spasi
    """
    if value is None:
        return ""

    value = str(value).strip()

    if not value:
        return ""

    value = re.sub(r"\s+", " ", value)

    return value

def normalized_upper(value: Any) -> str:
    return normalize(value).upper()

def is_empty(value: Any) -> bool:
    return not bool(normalize(value))

# ============================================================
# JUNK DETECTION
# ============================================================

def is_junk_value(value: Any) -> bool:
    """
    True jika value jelas merupakan UI/device junk.
    """
    value = normalize(value)

    if not value:
        return True

    upper = value.upper()

    if upper in JUNK_EXACT_VALUES:
        return True

    for junk in JUNK_CONTAINS_VALUES:
        if junk.upper() in upper:
            return True

    return False

# ============================================================
# WORK ORDER VALIDATION
# ============================================================

def is_valid_work_order(value: Any) -> bool:
    """
    Validasi Work Order.

    Contoh VALID:
        262005801-100
        262005802-100
        262005767-100

    Contoh INVALID:
        3
        BOX
        COM1: Sartorius
        ""
    """
    value = normalize(value)

    if not value:
        return False

    if is_junk_value(value):
        return False

    return bool(WORK_ORDER_PATTERN.fullmatch(value))

# ============================================================
# FORMULA VALIDATION
# ============================================================

def is_valid_formula(value: Any) -> bool:
    """
    Validasi formula/kode produk.

    Contoh VALID:
        LNKOA
        LKNTA
        LKKSB
        LKJTA

    Contoh INVALID:
        BOX
        COM1: Sartorius
        ""
    """
    value = normalize(value)

    if not value:
        return False

    if is_junk_value(value):
        return False

    if not FORMULA_PATTERN.fullmatch(value):
        return False

    # Jangan menerima string yang terlihat seperti device text.
    if ":" in value:
        return False

    return True

# ============================================================
# BATCH VALIDATION
# ============================================================

def is_valid_batch(value: Any) -> bool:
    """
    Validasi Nomor Batch.

    Contoh VALID:
        JH100 1G
        JH101 1G
        JH991 1M
        JH103 1A

    Contoh INVALID:
        BOX
        3
        COM1: Sartorius
    """
    value = normalize(value)

    if not value:
        return False

    if is_junk_value(value):
        return False

    return bool(BATCH_PATTERN.fullmatch(value))

# ============================================================
# WORK STATION VALIDATION
# ============================================================

def is_valid_work_station(value: Any) -> bool:
    """
    Work Station bersifat optional.

    Kalau kosong:
        masih dianggap valid.

    Kalau terisi:
        harus berbentuk B7-XXXX.
    """
    value = normalize(value)

    if not value:
        return True

    if is_junk_value(value):
        return False

    return bool(WORK_STATION_PATTERN.fullmatch(value))

# ============================================================
# PALLET VALIDATION
# ============================================================

def is_valid_pallet(value: Any) -> bool:
    """
    Pallet optional.

    Contoh:
        PP-262005631-100-01
        PP-262005631-100-06
        01
        06
    """
    value = normalize(value)

    if not value:
        return True

    if is_junk_value(value):
        return False

    # Pallet 3WS umumnya memiliki angka di bagian akhir.
    return bool(re.search(r"\d+$", value))

# ============================================================
# NOMOR MB VALIDATION
# ============================================================

def is_valid_nomor_mb(value: Any) -> bool:
    """
    Nomor MB optional.

    Leading zero tetap dipertahankan oleh agent.
    Contoh:
        0001
        0002
        0013
    """
    value = normalize(value)

    if not value:
        return True

    if is_junk_value(value):
        return False

    return bool(re.fullmatch(r"\d+", value))

# ============================================================
# IDENTITY VALIDATION
# ============================================================

def has_valid_identity(data: Dict[str, Any]) -> bool:
    """
    Identity batch wajib memiliki:
        Work Order
        dan Formula
        dan Batch

    Ini sengaja dibuat ketat agar data sampah seperti:

        3 | BOX | BOX

    tidak dianggap sebagai batch.
    """
    work_order = normalize(data.get("work_order"))
    formula = normalize(data.get("formula"))
    batch = normalize(data.get("batch"))

    if not work_order:
        return False

    if not formula:
        return False

    if not batch:
        return False

    if not is_valid_work_order(work_order):
        return False

    if not is_valid_formula(formula):
        return False

    if not is_valid_batch(batch):
        return False

    return True

# ============================================================
# RELATIONSHIP VALIDATION
# ============================================================

def has_invalid_relationship(data: Dict[str, Any]) -> bool:
    """
    Mendeteksi kombinasi field yang secara struktur tidak masuk akal.

    Contoh:
        work_order = COM1: Sartorius
        formula    = BOX
        batch      = COM1: Sartorius

    atau:

        work_order = 3
        formula    = BOX
        batch      = BOX
    """
    work_order = normalized_upper(data.get("work_order"))
    formula = normalized_upper(data.get("formula"))
    batch = normalized_upper(data.get("batch"))

    if not work_order or not formula or not batch:
        return True

    # Dua atau lebih field identik biasanya merupakan salah extraction.
    if work_order == formula:
        return True

    if work_order == batch:
        return True

    if formula == batch:
        return True

    # Semua field sama = hampir pasti junk.
    if work_order == formula == batch:
        return True

    return False

# ============================================================
# MAIN VALIDATOR
# ============================================================

def validate_capture_data(data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Validasi satu hasil extraction.

    Return:

        {
            "valid": True/False,
            "reason": "...",
            "field": "..."
        }

    Validator ini TIDAK mengubah data asli.
    """

    if not isinstance(data, dict):
        return {
            "valid": False,
            "reason": "capture_data_is_not_dict",
            "field": ""
        }

    work_order = normalize(data.get("work_order"))
    formula = normalize(data.get("formula"))
    batch = normalize(data.get("batch"))
    work_station = normalize(data.get("work_station"))
    pallet = normalize(data.get("pallet"))
    nomor_mb = normalize(data.get("nomor_mb"))

    # --------------------------------------------------------
    # Identity
    # --------------------------------------------------------

    if not work_order:
        return {
            "valid": False,
            "reason": "missing_work_order",
            "field": "work_order"
        }

    if not is_valid_work_order(work_order):
        return {
            "valid": False,
            "reason": f"invalid_work_order: {work_order}",
            "field": "work_order"
        }

    if not formula:
        return {
            "valid": False,
            "reason": "missing_formula",
            "field": "formula"
        }

    if not is_valid_formula(formula):
        return {
            "valid": False,
            "reason": f"invalid_formula: {formula}",
            "field": "formula"
        }

    if not batch:
        return {
            "valid": False,
            "reason": "missing_batch",
            "field": "batch"
        }

    if not is_valid_batch(batch):
        return {
            "valid": False,
            "reason": f"invalid_batch: {batch}",
            "field": "batch"
        }

    # --------------------------------------------------------
    # Relationship
    # --------------------------------------------------------

    if has_invalid_relationship(data):
        return {
            "valid": False,
            "reason": "invalid_field_relationship",
            "field": "identity"
        }

    # --------------------------------------------------------
    # Optional fields
    # --------------------------------------------------------

    if not is_valid_work_station(work_station):
        return {
            "valid": False,
            "reason": f"invalid_work_station: {work_station}",
            "field": "work_station"
        }

    if not is_valid_pallet(pallet):
        return {
            "valid": False,
            "reason": f"invalid_pallet: {pallet}",
            "field": "pallet"
        }

    if not is_valid_nomor_mb(nomor_mb):
        return {
            "valid": False,
            "reason": f"invalid_nomor_mb: {nomor_mb}",
            "field": "nomor_mb"
        }

    # --------------------------------------------------------
    # Valid
    # --------------------------------------------------------

    return {
        "valid": True,
        "reason": "ok",
        "field": ""
    }

# ============================================================
# SIMPLE BOOLEAN API
# ============================================================

def is_valid_capture_data(data: Dict[str, Any]) -> bool:
    """
    Shortcut:

        if not is_valid_capture_data(data):
            return None
    """
    return validate_capture_data(data)["valid"]

# ============================================================
# SERVER / EXISTING DB CLEANUP HELPER
# ============================================================
#
# Fungsi di bawah ini TIDAK menghapus database.
#
# Dipakai kalau suatu saat server mengirim record lama
# ke validator.
#
# Contoh:
#
#     invalid = find_invalid_record_fields(record)
#
# ============================================================

def find_invalid_record_fields(data: Dict[str, Any]) -> list:
    """
    Mengembalikan daftar field yang invalid.

    Contoh:
        ["work_order", "formula", "batch"]
    """
    invalid_fields = []

    if not is_valid_work_order(data.get("work_order")):
        invalid_fields.append("work_order")

    if not is_valid_formula(data.get("formula")):
        invalid_fields.append("formula")

    if not is_valid_batch(data.get("batch")):
        invalid_fields.append("batch")

    if has_invalid_relationship(data):
        if "identity" not in invalid_fields:
            invalid_fields.append("identity")

    if not is_valid_work_station(data.get("work_station")):
        invalid_fields.append("work_station")

    if not is_valid_pallet(data.get("pallet")):
        invalid_fields.append("pallet")

    if not is_valid_nomor_mb(data.get("nomor_mb")):
        invalid_fields.append("nomor_mb")

    return invalid_fields

# ============================================================
# TEST / SELF CHECK
# ============================================================

if __name__ == "__main__":

    test_cases = [
        {
            "name": "VALID",
            "data": {
                "work_order": "262005801-100",
                "formula": "LNKOA",
                "batch": "JH100 1G",
                "work_station": "B7-PGDPRDD13",
                "pallet": "PP-262005631-100-06",
                "nomor_mb": "0013",
            }
        },
        {
            "name": "INVALID SHORT WO",
            "data": {
                "work_order": "3",
                "formula": "BOX",
                "batch": "BOX",
            }
        },
        {
            "name": "INVALID SARTORIUS",
            "data": {
                "work_order": "COM1: Sartorius",
                "formula": "BOX",
                "batch": "COM1: Sartorius",
            }
        },
        {
            "name": "VALID WITHOUT OPTIONAL",
            "data": {
                "work_order": "262005802-100",
                "formula": "LNKOA",
                "batch": "JH101 1G",
            }
        },
    ]

    print("=" * 70)
    print("B7 3WS VALIDATOR SELF TEST")
    print("=" * 70)

    for test in test_cases:
        result = validate_capture_data(test["data"])

        print(f"\n[{test['name']}]")
        print(f"VALID : {result['valid']}")
        print(f"REASON: {result['reason']}")

    print("\n" + "=" * 70)