"""
batch_pc.py - Independent Local Forensic/Debug Recorder for B7 3WS Capture Agent.

File ini berfungsi sebagai recorder/debugger independen di PC lokal.
Merekam timeline peristiwa teknis (batch detection, 3WS window state, agent lifecycle)
ke %APPDATA%\\B7_3WS\\batch_record_pc.json tanpa mengganggu logika bisnis, queue SQLite,
maupun server API yang ada pada B7CaptureAgent.py.
"""

import os
import json
import socket
import threading
import tempfile
import shutil
import ctypes
from datetime import datetime, timezone


# ============================================================
# HELPER PARSER & UTILITIES
# ============================================================

def get_appdata_file_path(filename: str = "batch_record_pc.json") -> str:
    """Mendapatkan path file di folder %APPDATA%\\B7_3WS\\."""
    appdata_dir = os.path.join(
        os.environ.get("APPDATA", os.path.expanduser("~")),
        "B7_3WS"
    )
    os.makedirs(appdata_dir, exist_ok=True)
    return os.path.join(appdata_dir, filename)


def parse_pallet_suffix(pallet_str: str) -> int:
    """Mengambil angka suffix paling akhir dari string pallet (misal PP-262005889-100-01 -> 1)."""
    if not pallet_str or not isinstance(pallet_str, str):
        return 0
    parts = pallet_str.strip().replace("-", " ").replace("_", " ").split()
    if not parts:
        return 0
    last_part = parts[-1]
    try:
        return int(last_part)
    except ValueError:
        return 0


def parse_nomor_mb(nomor_mb_str: str) -> int:
    """Mengambil nilai integer dari string nomor_mb (misal 0002 -> 2)."""
    if not nomor_mb_str or not isinstance(nomor_mb_str, str):
        return 0
    try:
        return int(nomor_mb_str.strip())
    except ValueError:
        return 0


def is_pc_recently_booted(threshold_seconds: int = 300) -> bool:
    """Mendeteksi apakah Windows baru saja di-boot dalam n detik terakhir menggunakan GetTickCount64."""
    try:
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        GetTickCount64 = getattr(kernel32, "GetTickCount64", None)
        if GetTickCount64:
            uptime_ms = GetTickCount64()
            uptime_seconds = uptime_ms / 1000.0
            return uptime_seconds <= threshold_seconds
    except Exception:
        pass
    return False


# ============================================================
# BATCH PC RECORDER CLASS
# ============================================================

class BatchPCRecorder:
    """
    Forensic recorder independen untuk merekam riwayat dan log teknis batch di PC lokal.
    Sifat: Thread-safe, Fail-silent, Atomic-write, Zero-external-dependency.
    """

    MAX_BATCH_HISTORY = 50  # Batas penyimpanan batch lokal
    MAX_LOGS_PER_BATCH = 30 # Batas log event per batch

    def __init__(self, file_path: str = None, agent_id: str = ""):
        self.file_path = file_path or get_appdata_file_path("batch_record_pc.json")
        self.agent_id = agent_id
        self.hostname = socket.gethostname()
        self._lock = threading.Lock()

        # State runtime internal untuk throttling & transition tracking
        self._last_3ws_state = None  # "FOUND", "LOST", "CLOSED"
        self._last_process_id = None
        self._active_identity = None
        self._last_pallet = None
        self._last_nomor_mb = None

        # Load atau inisialisasi data
        self._data = self._load_data()

    # ------------------------------------------------------------
    # PUBLIC API - MAIN OBSERVER
    # ------------------------------------------------------------

    def observe(self, extracted_data: dict):
        """
        Menerima snapshot hasil extraction dari agent.
        Memproses pendaftaran batch baru, deteksi start condition, dan progress.
        """
        if not extracted_data or not isinstance(extracted_data, dict):
            return

        with self._lock:
            try:
                work_order = str(extracted_data.get("work_order", "")).strip()
                batch = str(extracted_data.get("batch", "")).strip()
                formula = str(extracted_data.get("formula", "")).strip()
                product_code = str(extracted_data.get("product_code", "")).strip()
                work_station = str(extracted_data.get("work_station", "")).strip()

                if not work_order or not (batch or formula or product_code):
                    return

                identity = f"{work_order}|{batch}|{formula}"
                now_iso = datetime.now(timezone.utc).isoformat()

                # Detect Identity Switch
                if self._active_identity and self._active_identity != identity:
                    self._internal_log_event(self._active_identity, "BATCH_IDENTITY_CHANGED", now_iso)

                self._active_identity = identity

                # Fetch or create batch record
                batch_rec = self._get_or_create_batch_record(
                    identity=identity,
                    work_order=work_order,
                    batch=batch,
                    formula=formula,
                    product_code=product_code,
                    work_station=work_station,
                    now_iso=now_iso
                )

                # Check START Condition (Pallet Suffix == 1 AND Nomor MB == 2)
                pallet_raw = str(extracted_data.get("pallet", ""))
                nomor_mb_raw = str(extracted_data.get("nomor_mb", ""))

                pallet_suffix = parse_pallet_suffix(pallet_raw)
                nomor_mb = parse_nomor_mb(nomor_mb_raw)

                if pallet_suffix == 1 and nomor_mb == 2:
                    if not self._has_event_logged(batch_rec, "START_CONDITION_DETECTED"):
                        self._internal_add_log(batch_rec, "START_CONDITION_DETECTED", now_iso)

                # Check PROGRESS (perubahan pallet atau nomor_mb)
                pallet_norm = pallet_raw.strip()
                nomor_mb_norm = nomor_mb_raw.strip()

                if self._last_pallet is not None and self._last_nomor_mb is not None:
                    if (pallet_norm != self._last_pallet or nomor_mb_norm != self._last_nomor_mb) and (pallet_norm or nomor_mb_norm):
                        self._internal_add_log(batch_rec, "PROGRESS_DETECTED", now_iso)

                self._last_pallet = pallet_norm
                self._last_nomor_mb = nomor_mb_norm

                self._save_data_atomic()
            except Exception:
                pass  # Fail silently to protect caller

    # ------------------------------------------------------------
    # PUBLIC API - LIFECYCLE & EVENT NOTIFIERS
    # ------------------------------------------------------------

    def record_start_condition(self, extracted_data: dict = None):
        """Mencatat event START_CONDITION_DETECTED secara eksplisit."""
        with self._lock:
            try:
                now_iso = datetime.now(timezone.utc).isoformat()
                identity = self._resolve_identity(extracted_data)
                if identity:
                    rec = self._get_batch_by_identity(identity)
                    if rec:
                        self._internal_add_log(rec, "START_CONDITION_DETECTED", now_iso)
                        self._save_data_atomic()
            except Exception:
                pass

    def record_progress(self, extracted_data: dict = None):
        """Mencatat event PROGRESS_DETECTED secara eksplisit."""
        with self._lock:
            try:
                now_iso = datetime.now(timezone.utc).isoformat()
                identity = self._resolve_identity(extracted_data)
                if identity:
                    rec = self._get_batch_by_identity(identity)
                    if rec:
                        self._internal_add_log(rec, "PROGRESS_DETECTED", now_iso)
                        self._save_data_atomic()
            except Exception:
                pass

    def record_end_click(self, label: str = None, timestamp: str = None):
        """Mencatat deteksi klik tombol END (seperti INCOMPLETE MB / LAST MB)."""
        with self._lock:
            try:
                now_iso = timestamp or datetime.now(timezone.utc).isoformat()
                if self._active_identity:
                    rec = self._get_batch_by_identity(self._active_identity)
                    if rec:
                        evt_name = f"END_CLICK_DETECTED ({label})" if label else "END_CLICK_DETECTED"
                        self._internal_add_log(rec, evt_name, now_iso)
                        self._save_data_atomic()
            except Exception:
                pass

    def record_end(self, timestamp: str = None):
        """Mencatat bahwa batch telah resmi ditutup/diakhiri."""
        with self._lock:
            try:
                now_iso = timestamp or datetime.now(timezone.utc).isoformat()
                if self._active_identity:
                    rec = self._get_batch_by_identity(self._active_identity)
                    if rec:
                        rec["end_timestamp"] = now_iso
                        self._internal_add_log(rec, "END_RECORDED", now_iso)
                        self._save_data_atomic()
            except Exception:
                pass

    def record_3ws_found(self, process_id: int = None):
        """Mencatat transition saat window 3WS ditemukan/terdeteksi."""
        with self._lock:
            try:
                now_iso = datetime.now(timezone.utc).isoformat()
                if self._last_3ws_state == "LOST" or self._last_3ws_state == "CLOSED":
                    evt = "3WS_REOPENED" if self._last_3ws_state == "CLOSED" else "3WS_FOUND"
                    self._log_active_or_system_event(evt, now_iso)
                elif self._last_3ws_state is None:
                    self._log_active_or_system_event("3WS_FOUND", now_iso)

                if process_id and self._last_process_id and process_id != self._last_process_id:
                    self._log_active_or_system_event("3WS_PROCESS_CHANGED", now_iso)

                self._last_3ws_state = "FOUND"
                if process_id:
                    self._last_process_id = process_id
                self._save_data_atomic()
            except Exception:
                pass

    def record_3ws_lost(self):
        """Mencatat transition saat window 3WS hilang dari pencarian UI Automation."""
        with self._lock:
            try:
                if self._last_3ws_state != "LOST":
                    now_iso = datetime.now(timezone.utc).isoformat()
                    self._log_active_or_system_event("3WS_WINDOW_LOST", now_iso)
                    self._last_3ws_state = "LOST"
                    self._save_data_atomic()
            except Exception:
                pass

    def record_3ws_closed(self):
        """Mencatat saat window 3WS diketahui ditutup secara definitif."""
        with self._lock:
            try:
                if self._last_3ws_state != "CLOSED":
                    now_iso = datetime.now(timezone.utc).isoformat()
                    self._log_active_or_system_event("3WS_CLOSED", now_iso)
                    self._last_3ws_state = "CLOSED"
                    self._save_data_atomic()
            except Exception:
                pass

    def record_agent_started(self):
        """Mencatat saat Capture Agent pertama kali/re-start dijalankan."""
        with self._lock:
            try:
                now_iso = datetime.now(timezone.utc).isoformat()
                
                # Cek apakah PC baru saja reboot/booting
                if is_pc_recently_booted():
                    self._log_active_or_system_event("PC_BOOT_DETECTED", now_iso)

                # Jika sudah ada record batch dan agent menyala lagi -> AGENT_RESTARTED
                if len(self._data.get("batches", [])) > 0:
                    self._log_active_or_system_event("AGENT_RESTARTED", now_iso)
                else:
                    self._log_active_or_system_event("AGENT_STARTED", now_iso)

                self._save_data_atomic()
            except Exception:
                pass

    def record_agent_stopped(self):
        """Mencatat saat Capture Agent dihentikan secara normal."""
        with self._lock:
            try:
                now_iso = datetime.now(timezone.utc).isoformat()
                self._log_active_or_system_event("AGENT_STOPPED", now_iso)
                self._save_data_atomic()
            except Exception:
                pass

    def flush(self):
        """Memaksa penyimpanan data saat ini secara atomic ke disk."""
        with self._lock:
            try:
                self._save_data_atomic()
            except Exception:
                pass

    # ------------------------------------------------------------
    # INTERNAL METHODS & FORENSIC LOGIC
    # ------------------------------------------------------------

    def _get_or_create_batch_record(self, identity, work_order, batch, formula, product_code, work_station, now_iso):
        """Mendapatkan record batch yang ada atau membuat record baru jika belum ada."""
        rec = self._get_batch_by_identity(identity)
        if not rec:
            rec = {
                "identity": identity,
                "work_order": work_order,
                "batch": batch,
                "formula": formula,
                "product_code": product_code,
                "work_station": work_station,
                "start_timestamp": now_iso,
                "end_timestamp": None,
                "logs": []
            }
            self._data["batches"].append(rec)
            self._internal_add_log(rec, "BATCH_DETECTED", now_iso)
            self._trim_batch_history()
        else:
            # Update data atribut jika sebelumnya kosong
            if not rec.get("product_code") and product_code:
                rec["product_code"] = product_code
            if not rec.get("work_station") and work_station:
                rec["work_station"] = work_station

        return rec

    def _get_batch_by_identity(self, identity):
        """Mencari batch record berdasarkan identity string."""
        for b in self._data.get("batches", []):
            if b.get("identity") == identity:
                return b
        return None

    def _internal_add_log(self, batch_rec, event_name, timestamp):
        """Menambahkan event log ke dalam batch record dengan throttling/deduplikasi."""
        logs = batch_rec.setdefault("logs", [])

        # Throttling/Deduplication: Cegah nama event yang sama berturut-turut
        if logs and logs[-1].get("event") == event_name:
            return

        logs.append({
            "timestamp": timestamp,
            "event": event_name
        })

        # Pembatasan jumlah log per batch
        if len(logs) > self.MAX_LOGS_PER_BATCH:
            batch_rec["logs"] = logs[-self.MAX_LOGS_PER_BATCH:]

    def _internal_log_event(self, identity, event_name, timestamp):
        """Menambahkan log ke batch tertentu berdasarkan identity."""
        rec = self._get_batch_by_identity(identity)
        if rec:
            self._internal_add_log(rec, event_name, timestamp)

    def _log_active_or_system_event(self, event_name, timestamp):
        """Menambahkan log ke batch aktif jika ada, atau mencatat log umum jika tidak ada batch aktif."""
        if self._active_identity:
            rec = self._get_batch_by_identity(self._active_identity)
            if rec:
                self._internal_add_log(rec, event_name, timestamp)
                return

        # Jika belum ada batch aktif, buat/gunakan system batch placeholder
        sys_rec = self._get_batch_by_identity("SYSTEM_LOGS")
        if not sys_rec:
            sys_rec = {
                "identity": "SYSTEM_LOGS",
                "work_order": "SYSTEM",
                "batch": "SYSTEM",
                "formula": "SYSTEM",
                "product_code": "SYSTEM",
                "work_station": self.hostname,
                "start_timestamp": timestamp,
                "end_timestamp": None,
                "logs": []
            }
            self._data["batches"].append(sys_rec)

        self._internal_add_log(sys_rec, event_name, timestamp)

    def _has_event_logged(self, batch_rec, event_name):
        """Mengecek apakah event tertentu sudah pernah dicatat pada batch ini."""
        for l in batch_rec.get("logs", []):
            if l.get("event") == event_name:
                return True
        return False

    def _resolve_identity(self, extracted_data):
        """Mendapatkan identity dari data snapshot atau dari active identity."""
        if extracted_data and isinstance(extracted_data, dict):
            wo = str(extracted_data.get("work_order", "")).strip()
            bt = str(extracted_data.get("batch", "")).strip()
            fm = str(extracted_data.get("formula", "")).strip()
            if wo and (bt or fm):
                return f"{wo}|{bt}|{fm}"
        return self._active_identity

    def _trim_batch_history(self):
        """Menjaga agar jumlah simpanan batch tidak melebihi MAX_BATCH_HISTORY (FIFO)."""
        batches = self._data.get("batches", [])
        if len(batches) > self.MAX_BATCH_HISTORY:
            # Tetap pertahankan SYSTEM_LOGS jika ada
            sys_batches = [b for b in batches if b.get("identity") == "SYSTEM_LOGS"]
            user_batches = [b for b in batches if b.get("identity") != "SYSTEM_LOGS"]

            keep_count = self.MAX_BATCH_HISTORY - len(sys_batches)
            user_batches = user_batches[-keep_count:] if keep_count > 0 else []

            self._data["batches"] = sys_batches + user_batches

    # ------------------------------------------------------------
    # STORAGE & ATOMIC WRITE HANDLING
    # ------------------------------------------------------------

    def _load_data(self) -> dict:
        """Membaca file JSON dari disk dengan penanganan proteksi kerusakan data."""
        default_structure = {
            "version": 1,
            "hostname": self.hostname,
            "agent_id": self.agent_id,
            "updated_at": datetime.now(timezone.utc).isoformat(),
            "batches": []
        }

        if not os.path.exists(self.file_path):
            return default_structure

        try:
            with open(self.file_path, "r", encoding="utf-8") as f:
                content = json.load(f)
                if isinstance(content, dict) and "batches" in content and isinstance(content["batches"], list):
                    return content
                else:
                    raise ValueError("Invalid JSON structure")
        except Exception:
            # Backup file yang corrupt
            try:
                corrupted_bak = f"{self.file_path}.corrupted.{int(datetime.now().timestamp())}"
                shutil.copy2(self.file_path, corrupted_bak)
            except Exception:
                pass
            return default_structure

    def _save_data_atomic(self):
        """Menulis data ke disk secara aman menggunakan teknik Atomic Swap (Temp File -> Replace)."""
        try:
            self._data["updated_at"] = datetime.now(timezone.utc).isoformat()
            if self.agent_id:
                self._data["agent_id"] = self.agent_id

            target_dir = os.path.dirname(self.file_path)
            os.makedirs(target_dir, exist_ok=True)

            # Buat file temporer di direktori yang sama
            fd, temp_path = tempfile.mkstemp(dir=target_dir, prefix="batch_pc_", suffix=".tmp")
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                json.dump(self._data, f, indent=2, ensure_ascii=False)
                f.flush()
                os.fsync(f.fileno())

            # Timpa file target secara atomic
            os.replace(temp_path, self.file_path)
        except Exception:
            pass  # Isolasi exception agar caller aman


# ============================================================
# READ-ONLY QUERY HELPERS
# ============================================================

def get_batch_record(identity: str, file_path: str = None) -> dict:
    """Helper untuk membaca record batch tertentu dari disk (read-only)."""
    batches = get_all_batches(file_path)
    for b in batches:
        if b.get("identity") == identity:
            return b
    return {}


def get_all_batches(file_path: str = None) -> list:
    """Helper untuk membaca seluruh riwayat batch lokal dari disk (read-only)."""
    target_path = file_path or get_appdata_file_path("batch_record_pc.json")
    if not os.path.exists(target_path):
        return []

    try:
        with open(target_path, "r", encoding="utf-8") as f:
            data = json.load(f)
            if isinstance(data, dict) and "batches" in data:
                return data["batches"]
    except Exception:
        pass
    return []


# ============================================================
# SELF TEST / DEMO
# ============================================================

if __name__ == "__main__":
    print("=== Running Independent Self-Test for batch_pc.py ===")

    # Buat direktori temporer khusus untuk pengujian (tidak mengganggu %APPDATA% produksi)
    temp_dir = tempfile.mkdtemp(prefix="b7_test_")
    test_json_path = os.path.join(temp_dir, "batch_record_pc_test.json")

    try:
        recorder = BatchPCRecorder(file_path=test_json_path, agent_id="TEST-AGENT-001")

        # 1. Test Start Agent & Window State
        recorder.record_agent_started()
        recorder.record_3ws_found(process_id=4120)

        # 2. Test Extraction Snapshots
        sample_data_1 = {
            "work_order": "262005889-100",
            "batch": "JJ163 1H",
            "formula": "LKXNA",
            "product_code": "PRODUCT-X",
            "work_station": "B7-PGDBKPD13",
            "pallet": "PP-262005889-100-01",
            "nomor_mb": "0002"
        }
        recorder.observe(sample_data_1)

        sample_data_2 = {
            "work_order": "262005889-100",
            "batch": "JJ163 1H",
            "formula": "LKXNA",
            "product_code": "PRODUCT-X",
            "work_station": "B7-PGDBKPD13",
            "pallet": "PP-262005889-100-01",
            "nomor_mb": "0003"
        }
        recorder.observe(sample_data_2)

        # 3. Test Window Lost & Reopened
        recorder.record_3ws_lost()
        recorder.record_3ws_found(process_id=4120)

        # 4. Test End Click & Record End
        recorder.record_end_click(label="INCOMPLETE MB")
        recorder.record_end()

        # 5. Verify & Assert Result
        batches = get_all_batches(test_json_path)
        print(f"Total recorded batches: {len(batches)}")
        assert len(batches) == 1, "Expected exactly 1 batch record"

        rec = batches[0]
        print(f"Identity: {rec.get('identity')}")
        print(f"Start Timestamp: {rec.get('start_timestamp')}")
        print(f"End Timestamp: {rec.get('end_timestamp')}")
        print("Timeline Logs:")
        for log_item in rec.get("logs", []):
            print(f"  - [{log_item['timestamp']}] {log_item['event']}")

        assert rec["identity"] == "262005889-100|JJ163 1H|LKXNA"
        assert rec["end_timestamp"] is not None

        events = [l["event"] for l in rec["logs"]]
        assert "BATCH_DETECTED" in events
        assert "START_CONDITION_DETECTED" in events
        assert "PROGRESS_DETECTED" in events
        assert "3WS_WINDOW_LOST" in events
        assert "3WS_REOPENED" in events
        assert "END_CLICK_DETECTED (INCOMPLETE MB)" in events
        assert "END_RECORDED" in events

        print("\n=== SELF-TEST PASSED SUCCESSFULLY ===")
    finally:
        # Bersihkan direktori pengujian
        shutil.rmtree(temp_dir, ignore_errors=True)