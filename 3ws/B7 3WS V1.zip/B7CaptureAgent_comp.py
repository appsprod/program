import sys
import types

# Bypass modul win32ui agar pywinauto tidak error saat load DLL
sys.modules['win32ui'] = types.ModuleType('win32ui')

import os
import time
import json
import uuid
import socket
import getpass
import sqlite3
import re
import threading
from datetime import datetime, timezone

import requests
from pywinauto import Desktop

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

from capture_core import collect_controls, normalize_text

APP_NAME = "B7_3WS_COMP"
AGENT_VERSION = "1.0.0-comp"
DEFAULT_SERVER_URL = "http://localhost:2005"
HEARTBEAT_INTERVAL = 30
EXTRACTION_INTERVAL = 1.0
QUEUE_FLUSH_INTERVAL = 5.0

TARGET_PROCESS_NAMES = {"3ws.net.exe", "3ws.exe"}
TARGET_WINDOW_KEYWORDS = ["mfg tipping"]
FINISHED_WINDOW_KEYWORDS = ["order finished"]

WORK_STATION = ""
DEFAULT_USERNAME = getpass.getuser()
START_ON_ORDER_VISIBLE = False

APPDATA_ROOT = os.path.join(os.environ.get("APPDATA", os.path.expanduser("~")), APP_NAME)
os.makedirs(APPDATA_ROOT, exist_ok=True)

CONFIG_PATH = os.path.join(APPDATA_ROOT, "config.json")
DB_PATH = os.path.join(APPDATA_ROOT, "comp_queue.db")

LOG_DIR = os.path.join(BASE_DIR, "debugging")
try:
    os.makedirs(LOG_DIR, exist_ok=True)
except Exception:
    LOG_DIR = BASE_DIR

LOG_PATH = os.path.join(LOG_DIR, "compounding_agent.log")

def log(message):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
    line = f"[{timestamp}] {message}"
    print(line, flush=True)
    try:
        with open(LOG_PATH, "a", encoding="utf-8", errors="ignore") as f:
            f.write(line + "\n")
    except Exception:
        pass

def load_config():
    config = {
        "server_url": DEFAULT_SERVER_URL,
        "work_station": WORK_STATION,
        "username": DEFAULT_USERNAME,
    }
    try:
        if os.path.exists(CONFIG_PATH):
            with open(CONFIG_PATH, "r", encoding="utf-8") as f:
                loaded = json.load(f)
            if isinstance(loaded, dict):
                config.update(loaded)
        else:
            with open(CONFIG_PATH, "w", encoding="utf-8") as f:
                json.dump(config, f, indent=4)
    except Exception as exc:
        log(f"CONFIG ERROR: {exc}")
    return config

CONFIG = load_config()
SERVER_URL = str(CONFIG.get("server_url", DEFAULT_SERVER_URL)).rstrip("/")
USERNAME = getpass.getuser()
WORK_STATION = ""
HOSTNAME = socket.gethostname()

AGENT_ID = ""
try:
    AGENT_ID = str(CONFIG.get("agent_id", "")).strip()
except Exception:
    AGENT_ID = ""

if not AGENT_ID:
    AGENT_ID = f"COMP-{HOSTNAME}-{uuid.uuid4().hex[:8].upper()}"
    try:
        CONFIG["agent_id"] = AGENT_ID
        with open(CONFIG_PATH, "w", encoding="utf-8") as f:
            json.dump(CONFIG, f, indent=4)
    except Exception as exc:
        log(f"AGENT ID SAVE ERROR: {exc}")

HTTP = requests.Session()
HTTP.headers.update({"User-Agent": f"{APP_NAME}/{AGENT_VERSION}"})

REGISTER_ENDPOINT = "/api/agent/register"
HEARTBEAT_ENDPOINT = "/api/agent/heartbeat"
EVENT_ENDPOINT = "/api/agent/compounding/events"
PROGRESS_ENDPOINT = "/api/agent/compounding/progress"

def init_queue():
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS queue_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                event_id TEXT UNIQUE NOT NULL,
                event_type TEXT NOT NULL,
                payload TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'PENDING',
                attempts INTEGER NOT NULL DEFAULT 0,
                last_error TEXT,
                created_at TEXT NOT NULL
            )
            """
        )
        conn.commit()
        conn.close()
    except Exception as exc:
        log(f"QUEUE INIT ERROR: {exc}")

def queue_event(event_type, payload):
    event_id = payload.get("event_id")
    if not event_id:
        event_id = str(uuid.uuid4())
        payload["event_id"] = event_id
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.execute(
            """
            INSERT OR IGNORE INTO queue_events
            (event_id, event_type, payload, status, attempts, created_at)
            VALUES (?, ?, ?, 'PENDING', 0, ?)
            """,
            (
                event_id,
                event_type,
                json.dumps(payload, ensure_ascii=False),
                datetime.now(timezone.utc).isoformat(),
            ),
        )
        conn.commit()
        conn.close()
        return True
    except Exception as exc:
        log(f"QUEUE INSERT ERROR: {exc}")
        return False

def get_pending_events(limit=50):
    try:
        conn = sqlite3.connect(DB_PATH)
        rows = conn.execute(
            """
            SELECT id, event_id, event_type, payload, attempts
            FROM queue_events
            WHERE status = 'PENDING'
            ORDER BY id ASC
            LIMIT ?
            """,
            (limit,),
        ).fetchall()
        conn.close()
        return rows
    except Exception as exc:
        log(f"QUEUE READ ERROR: {exc}")
        return []

def mark_event_sent(row_id):
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.execute("UPDATE queue_events SET status = 'SENT' WHERE id = ?", (row_id,))
        conn.commit()
        conn.close()
    except Exception as exc:
        log(f"QUEUE SENT ERROR: {exc}")

def mark_event_failed(row_id, error):
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.execute(
            "UPDATE queue_events SET attempts = attempts + 1, last_error = ? WHERE id = ?",
            (str(error)[:1000], row_id),
        )
        conn.commit()
        conn.close()
    except Exception as exc:
        log(f"QUEUE FAIL ERROR: {exc}")

def lower(value):
    return normalize_text(value).lower()

def contains_any(value, keywords):
    text = lower(value)
    return any(lower(keyword) in text for keyword in keywords)

def first_non_empty(*values):
    for value in values:
        value = normalize_text(value)
        if value:
            return value
    return ""

def get_process_name(pid):
    try:
        import psutil
        return psutil.Process(pid).name()
    except Exception:
        return ""

def is_target_process(pid):
    name = get_process_name(pid)
    if not name:
        return True
    return name.lower() in {x.lower() for x in TARGET_PROCESS_NAMES}

def get_visible_windows():
    try:
        desktop = Desktop(backend="uia")
        return desktop.windows(visible_only=True)
    except Exception as exc:
        log(f"WINDOW ENUM ERROR: {exc}")
        return []

def find_compounding_window():
    windows = get_visible_windows()
    candidates = []
    for win in windows:
        try:
            title = normalize_text(win.window_text())
            if not title:
                continue
            pid = win.element_info.process_id
            if not is_target_process(pid):
                continue
            if contains_any(title, TARGET_WINDOW_KEYWORDS):
                candidates.append(win)
        except Exception:
            continue

    if not candidates:
        return None

    order_candidates = []
    for win in candidates:
        try:
            title = normalize_text(win.window_text())
            if "order:" in lower(title):
                order_candidates.append(win)
        except Exception:
            pass

    if order_candidates:
        return order_candidates[0]
    return candidates[0]

def find_finished_window():
    windows = get_visible_windows()
    for win in windows:
        try:
            title = normalize_text(win.window_text())
            if not title:
                continue
            pid = win.element_info.process_id
            if not is_target_process(pid):
                continue
            if contains_any(title, FINISHED_WINDOW_KEYWORDS):
                return win
        except Exception:
            continue
    return None

def control_text(control):
    return first_non_empty(control.get("value", ""), control.get("name", ""))

def control_full_text(control):
    return " ".join(
        x for x in [
            control.get("name", ""),
            control.get("value", ""),
            control.get("automation_id", ""),
            control.get("ancestor_text", ""),
        ] if normalize_text(x)
    )

def controls_matching(controls, keywords):
    result = []
    for control in controls:
        text = control_full_text(control)
        if contains_any(text, keywords):
            result.append(control)
    return result

def best_control_value(controls, keywords, value_pattern=None):
    candidates = []
    for control in controls:
        text = control_full_text(control)
        if not contains_any(text, keywords):
            continue
        value = control_text(control)
        if not value:
            continue
        if value_pattern:
            try:
                if not re.search(value_pattern, value, re.IGNORECASE):
                    continue
            except Exception:
                continue
        candidates.append((len(value), control))

    if not candidates:
        return ""
    candidates.sort(key=lambda x: x[0])
    return control_text(candidates[0][1])

ORDER_PATTERN = re.compile(
    r"Order\s*:?\s*([A-Za-z0-9]+(?:\s*-\s*[A-Za-z0-9]+)+)",
    re.IGNORECASE,
)

def extract_order_from_title(title):
    title = normalize_text(title)
    match = ORDER_PATTERN.search(title)
    if not match:
        return ""
    return normalize_text(match.group(1)).replace(" ", "")

def extract_order(controls, title):
    order = extract_order_from_title(title)
    if order:
        return order

    for control in controls:
        text = control_full_text(control)
        match = ORDER_PATTERN.search(text)
        if match:
            return normalize_text(match.group(1)).replace(" ", "")

    for control in controls:
        text = control_text(control)
        match = re.search(r"\b\d{6,}\s*-\s*\d+\b", text)
        if match:
            return normalize_text(match.group(0)).replace(" ", "")

    return ""

def extract_product_from_title(title):
    title = normalize_text(title)
    match = re.search(r"Name\s*:?\s*(.+)$", title, re.IGNORECASE)
    if match:
        return normalize_text(match.group(1))
    return ""

def extract_product(controls, title):
    product = extract_product_from_title(title)
    if product:
        return product

    for control in controls:
        name = lower(control.get("name", ""))
        value = control_text(control)
        context = lower(control.get("ancestor_text", ""))
        if ("name" in name or "name" in context) and value:
            if "order" not in lower(value):
                return value
    return ""

def extract_formula(controls):
    for control in controls:
        text = control_full_text(control)
        if "formula" not in lower(text):
            continue
        value = control_text(control)
        if not value:
            continue
        match = re.search(r"Formula\s*:?\s*([A-Za-z0-9_-]+)", value, re.IGNORECASE)
        if match:
            return normalize_text(match.group(1))
        if re.fullmatch(r"[A-Za-z0-9_-]{3,20}", value):
            return value
    return ""

def extract_location(controls):
    for index, control in enumerate(controls):
        full_text = control_full_text(control)
        name = normalize_text(control.get("name", ""))
        value = normalize_text(control.get("value", ""))

        # Case 1:
        # Satu control berisi:
        # "Location B7-PGDPRDD51 -"
        match = re.search(
            r"\bLocation\b\s*:?\s*(B7[-\s]PGDPRDD\d+)",
            full_text,
            re.IGNORECASE,
        )
        if match:
            return normalize_text(
                match.group(1)
            ).replace(" ", "-").upper()

        # Case 2:
        # Label dan value dipisah:
        # name  = "Location"
        # value = "B7-PGDPRDD51"
        if "location" in lower(name):
            candidate = value

            if not candidate and index + 1 < len(controls):
                candidate = normalize_text(
                    controls[index + 1].get("value", "")
                )

            match = re.search(
                r"(B7[-\s]PGDPRDD\d+)",
                candidate,
                re.IGNORECASE,
            )
            if match:
                return normalize_text(
                    match.group(1)
                ).replace(" ", "-").upper()

        # Case 3:
        # Location ada di ancestor, value control adalah kode station
        if "location" in lower(
            control.get("ancestor_text", "")
        ):
            match = re.search(
                r"(B7[-\s]PGDPRDD\d+)",
                value,
                re.IGNORECASE,
            )
            if match:
                return normalize_text(
                    match.group(1)
                ).replace(" ", "-").upper()

    return ""

def extract_dispensed(controls):
    for control in controls:
        text = control_full_text(control)
        if "dispensed" not in lower(text):
            continue
        value = control_text(control)
        if not value:
            continue
        match = re.search(r"(\d+(?:[.,]\d+)?)\s*(KG|G|MG|L|ML)?", value, re.IGNORECASE)
        if match:
            number = match.group(1)
            unit = match.group(2) or ""
            return f"{number} {unit}".strip()
    return ""

def extract_total_validasi(controls):
    for control in controls:
        text = control_full_text(control)
        if "total validasi" not in lower(text):
            continue
        value = control_text(control)
        if not value:
            continue
        match = re.search(r"\b(\d+)\b", value)
        if match:
            try:
                return int(match.group(1))
            except Exception:
                pass
    return 0

MATERIAL_KEYWORDS = ["material id", "material name", "nett weight", "uom"]

def looks_like_material_text(text):
    text = lower(text)
    return "material" in text or "nett weight" in text

def extract_material_controls(controls):
    result = []
    for control in controls:
        ctype = lower(control.get("control_type", ""))
        name = lower(control.get("name", ""))
        value = lower(control.get("value", ""))
        context = lower(control.get("ancestor_text", ""))
        combined = " ".join([name, value, context])

        if "material id" in combined or "material name" in combined or "nett weight" in combined:
            continue

        if ctype in {"list item", "data item", "custom"} and looks_like_material_text(combined):
            result.append(control)
    return result

def parse_material_rows(controls):
    candidates = extract_material_controls(controls)
    rows = []
    seen = set()

    for control in candidates:
        text = normalize_text(control_full_text(control))
        if not text:
            continue
        key = (text, control.get("automation_id", ""))
        if key in seen:
            continue
        seen.add(key)

        rows.append({
            "text": text,
            "value": control_text(control),
            "control_type": control.get("control_type", ""),
            "automation_id": control.get("automation_id", ""),
            "depth": control.get("depth", 0),
        })

    return rows

def infer_material_total(controls, rows):
    if rows:
        return len(rows)

    indexes = set()
    for control in controls:
        match = re.match(r"^\s*(\d+)\s*$", control_text(control))
        if match:
            try:
                indexes.add(int(match.group(1)))
            except Exception:
                pass

    if indexes:
        return max(indexes)

    return 0

def looks_completed_material(row):
    text = lower(row.get("text", ""))
    value = lower(row.get("value", ""))
    combined = f"{text} {value}"
    completed_words = ["complete", "completed", "done", "finished", "valid", "validated"]

    if any(word in combined for word in completed_words):
        return True

    weight_pattern = re.search(r"\b\d+(?:[.,]\d+)?\s*(?:kg|g|mg)\b", combined, re.IGNORECASE)
    if weight_pattern:
        return True

    return False

def infer_material_completed(rows):
    if not rows:
        return 0

    completed = sum(1 for row in rows if looks_completed_material(row))
    return min(completed, len(rows))

def read_finished_message(window):
    if not window:
        return ""
    try:
        controls = collect_controls(window)
        texts = [control_full_text(control) for control in controls if control_full_text(control)]
        return " | ".join(texts)
    except Exception:
        return ""

def extract_compounding_snapshot(window):
    if not window:
        return None
    try:
        title = normalize_text(window.window_text())
        pid = window.element_info.process_id
    except Exception:
        return None

    try:
        controls = collect_controls(window)
    except Exception as exc:
        log(f"CONTROL SCAN ERROR: {exc}")
        return None

    if not controls:
        return None

    order = extract_order(controls, title)
    product = extract_product(controls, title)
    formula = extract_formula(controls)
    location = extract_location(controls)
    dispensed = extract_dispensed(controls)
    total_validasi = extract_total_validasi(controls)
    material_rows = parse_material_rows(controls)
    total_materials = infer_material_total(controls, material_rows)
    completed_materials = infer_material_completed(material_rows)

    return {
        "window_title": title,
        "pid": pid,
        "order": order,
        "product_name": product,
        "formula": formula,
        "location": location,
        "dispensed": dispensed,
        "total_validasi": total_validasi,
        "total_materials": total_materials,
        "completed_materials": completed_materials,
        "progress": f"{completed_materials}/{total_materials}" if total_materials > 0 else "0/0",
        "material_rows": material_rows,
        "control_count": len(controls),
    }

def update_work_station_from_snapshot(snapshot):
    global WORK_STATION
    if not snapshot:
        return False

    location = normalize_text(snapshot.get("location", ""))
    if not location or location == WORK_STATION:
        return False

    WORK_STATION = location
    log(f"WORK STATION UPDATED FROM UI: {WORK_STATION}")
    return True

def now_iso():
    return datetime.now(timezone.utc).isoformat()

def create_event(event_type, snapshot, session_id, reason=""):
    return {
        "event_id": str(uuid.uuid4()),
        "event_type": event_type,
        "process": "COMPOUNDING",
        "agent_id": AGENT_ID,
        "hostname": HOSTNAME,
        "agent_version": AGENT_VERSION,
        "session_id": session_id,
        "timestamp": now_iso(),
        "reason": reason,
        "data": snapshot,
    }

def register_agent():
    payload = {
        "agent_id": AGENT_ID,
        "hostname": HOSTNAME,
        "work_station": WORK_STATION,
        "username": USERNAME,
        "agent_version": AGENT_VERSION,
    }
    try:
        response = HTTP.post(SERVER_URL + REGISTER_ENDPOINT, json=payload, timeout=5)
        if 200 <= response.status_code < 300:
            log(f"AGENT REGISTER SUCCESS id={AGENT_ID} hostname={HOSTNAME} work_station={WORK_STATION} version={AGENT_VERSION}")
            return True
        log(f"AGENT REGISTER ERROR {response.status_code}: {response.text[:300]}")
    except Exception as exc:
        log(f"AGENT REGISTER EXCEPTION: {exc}")
    return False

def send_event(event):
    url = SERVER_URL + EVENT_ENDPOINT
    try:
        response = HTTP.post(url, json=event, timeout=5)
        if 200 <= response.status_code < 300:
            return True
        log(f"SERVER EVENT ERROR {response.status_code}: {response.text[:300]}")
    except Exception as exc:
        log(f"SERVER EVENT EXCEPTION: {exc}")
    return False

def send_progress(event):
    url = SERVER_URL + PROGRESS_ENDPOINT
    try:
        response = HTTP.post(url, json=event, timeout=5)
        if 200 <= response.status_code < 300:
            return True
        log(f"SERVER PROGRESS ERROR {response.status_code}: {response.text[:300]}")
    except Exception as exc:
        log(f"SERVER PROGRESS EXCEPTION: {exc}")
    return False

def emit(event_type, snapshot, session_id, reason=""):
    event = create_event(event_type=event_type, snapshot=snapshot, session_id=session_id, reason=reason)
    success = send_progress(event) if event_type == "PROGRESS" else send_event(event)
    if not success:
        queue_event(event_type, event)
    return success

def flush_queue():
    rows = get_pending_events(limit=30)
    for row_id, event_id, event_type, payload_text, attempts in rows:
        try:
            payload = json.loads(payload_text)
        except Exception as exc:
            mark_event_failed(row_id, f"invalid payload: {exc}")
            continue

        success = send_progress(payload) if event_type == "PROGRESS" else send_event(payload)
        if success:
            mark_event_sent(row_id)
            log(f"QUEUE SENT {event_type} {event_id}")
        else:
            mark_event_failed(row_id, "server unavailable")

def queue_worker(stop_event):
    while not stop_event.is_set():
        try:
            flush_queue()
        except Exception as exc:
            log(f"QUEUE WORKER ERROR: {exc}")
        stop_event.wait(QUEUE_FLUSH_INTERVAL)

def send_heartbeat():
    payload = {
        "agent_id": AGENT_ID,
        "hostname": HOSTNAME,
        "work_station": WORK_STATION,
        "agent_version": AGENT_VERSION,
    }
    try:
        response = HTTP.post(SERVER_URL + HEARTBEAT_ENDPOINT, json=payload, timeout=5)
        if 200 <= response.status_code < 300:
            log(f"HEARTBEAT OK id={AGENT_ID} work_station={WORK_STATION}")
            return True
        log(f"HEARTBEAT ERROR {response.status_code}: {response.text[:300]}")
    except Exception as exc:
        log(f"HEARTBEAT EXCEPTION: {exc}")
    return False

def heartbeat_worker(stop_event):
    while not stop_event.is_set():
        try:
            send_heartbeat()
        except Exception as exc:
            log(f"HEARTBEAT WORKER ERROR: {exc}")
        stop_event.wait(HEARTBEAT_INTERVAL)

class CompoundingSession:
    def __init__(self):
        self.reset()

    def reset(self):
        self.session_id = None
        self.active = False
        self.has_start = False
        self.has_end = False
        self.order = ""
        self.last_progress_signature = ""
        self.start_timestamp = None
        self.end_timestamp = None

    def new_session(self, order):
        self.session_id = str(uuid.uuid4())
        self.active = True
        self.has_start = False
        self.has_end = False
        self.order = order
        self.last_progress_signature = ""
        self.start_timestamp = None
        self.end_timestamp = None

SESSION = CompoundingSession()

def detect_start_condition(snapshot):
    if not START_ON_ORDER_VISIBLE or not snapshot or not snapshot.get("order"):
        return False
    return True

def build_progress_signature(snapshot):
    return (
        snapshot.get("order", ""),
        snapshot.get("completed_materials", 0),
        snapshot.get("total_materials", 0),
        snapshot.get("progress", ""),
        snapshot.get("dispensed", ""),
        snapshot.get("total_validasi", 0),
    )

def progress_changed(snapshot):
    signature = build_progress_signature(snapshot)
    if signature == SESSION.last_progress_signature:
        return False
    SESSION.last_progress_signature = signature
    return True

def detect_end_condition():
    window = find_finished_window()
    if not window:
        return None
    message = read_finished_message(window)
    return {
        "window_title": normalize_text(window.window_text()),
        "message": message,
    }

def print_snapshot(snapshot):
    if not snapshot:
        return
    log(
        f"COMP order={snapshot.get('order', '')!r} "
        f"product={snapshot.get('product_name', '')!r} "
        f"formula={snapshot.get('formula', '')!r} "
        f"location={snapshot.get('location', '')!r} "
        f"progress={snapshot.get('progress', '')} "
        f"dispensed={snapshot.get('dispensed', '')!r} "
        f"validasi={snapshot.get('total_validasi', 0)} "
        f"controls={snapshot.get('control_count', 0)}"
    )

def process_compounding():
    window = find_compounding_window()
    if not window:
        return

    snapshot = extract_compounding_snapshot(window)
    if not snapshot:
        return

    update_work_station_from_snapshot(snapshot)
    order = snapshot.get("order", "")
    if not order:
        log("MFG TIPPING FOUND BUT ORDER NOT DETECTED")
        return

    print_snapshot(snapshot)

    if not SESSION.active or SESSION.order != order or SESSION.has_end:
        SESSION.new_session(order)
        log(f"NEW COMPOUNDING SESSION order={order} session={SESSION.session_id}")

    if not SESSION.has_start and detect_start_condition(snapshot):
        SESSION.has_start = True
        SESSION.start_timestamp = now_iso()
        emit("START", snapshot, SESSION.session_id, reason="mfg_tipping_order_detected")
        log(f"COMPOUNDING START order={order}")

    if SESSION.has_start and not SESSION.has_end and progress_changed(snapshot):
        emit("PROGRESS", snapshot, SESSION.session_id, reason="compounding_state_changed")
        log(f"COMPOUNDING PROGRESS order={order} {snapshot.get('progress', '0/0')}")

def process_finished():
    finished = detect_end_condition()
    if not finished:
        return

    if not SESSION.active:
        log("ORDER FINISHED DETECTED BUT NO ACTIVE SESSION")
        return

    if SESSION.has_end:
        return

    SESSION.has_end = True
    SESSION.end_timestamp = now_iso()
    snapshot = {
        "order": SESSION.order,
        "finished_window": finished.get("window_title", ""),
        "finished_message": finished.get("message", ""),
    }

    emit("END", snapshot, SESSION.session_id, reason="order_finished_dialog_detected")
    log(f"COMPOUNDING END order={SESSION.order} session={SESSION.session_id}")

def dump_current_controls():
    window = find_compounding_window()
    if not window:
        print("Mfg Tipping window not found.")
        return

    try:
        title = normalize_text(window.window_text())
        controls = collect_controls(window)
        print("\n===== COMPOUNDING UIA =====")
        print(f"TITLE: {title}")
        print(f"PID: {window.element_info.process_id}")
        print(f"CONTROLS: {len(controls)}\n")

        for index, control in enumerate(controls):
            name = normalize_text(control.get("name", ""))
            value = normalize_text(control.get("value", ""))
            ctype = normalize_text(control.get("control_type", ""))
            aid = normalize_text(control.get("automation_id", ""))
            context = normalize_text(control.get("ancestor_text", ""))

            if not any([name, value, aid]):
                continue

            print(f"[{index:04}] type={ctype!r} name={name!r} value={value!r} aid={aid!r} context={context!r}")
    except Exception as exc:
        print(f"DIAGNOSTIC ERROR: {exc}")

STOP_EVENT = threading.Event()

def shutdown():
    if STOP_EVENT.is_set():
        return
    log("COMPOUNDING AGENT STOPPING")
    STOP_EVENT.set()

def main():
    log("=" * 70)
    log("B7 COMPOUNDING AGENT START")
    log(f"APP={APP_NAME}")
    log(f"VERSION={AGENT_VERSION}")
    log(f"HOSTNAME={HOSTNAME}")
    log(f"AGENT_ID={AGENT_ID}")
    log(f"WORK_STATION={WORK_STATION}")
    log(f"USERNAME={USERNAME}")
    log(f"SERVER={SERVER_URL}")
    log(f"START_ON_ORDER_VISIBLE={START_ON_ORDER_VISIBLE}")
    log("=" * 70)

    init_queue()

    try:
        initial_window = find_compounding_window()
        if initial_window:
            initial_snapshot = extract_compounding_snapshot(initial_window)
            update_work_station_from_snapshot(initial_snapshot)
    except Exception as exc:
        log(f"INITIAL WORK STATION DETECTION ERROR: {exc}")

    register_agent()

    queue_thread = threading.Thread(
        target=queue_worker,
        args=(STOP_EVENT,),
        daemon=True,
        name="CompQueueWorker",
    )

    heartbeat_thread = threading.Thread(
        target=heartbeat_worker,
        args=(STOP_EVENT,),
        daemon=True,
        name="CompHeartbeatWorker",
    )

    queue_thread.start()
    heartbeat_thread.start()

    last_window_state = False

    try:
        while not STOP_EVENT.is_set():
            try:
                window = find_compounding_window()
                current_window_state = window is not None

                if current_window_state and not last_window_state:
                    log("MFG TIPPING DETECTED")
                if not current_window_state and last_window_state:
                    log("MFG TIPPING NOT VISIBLE")

                last_window_state = current_window_state

                process_compounding()
                process_finished()
            except KeyboardInterrupt:
                break
            except Exception as exc:
                log(f"MAIN LOOP ERROR: {exc}")

            STOP_EVENT.wait(EXTRACTION_INTERVAL)
    finally:
        shutdown()
        log("B7 COMPOUNDING AGENT STOPPED")

if __name__ == "__main__":
    main()
