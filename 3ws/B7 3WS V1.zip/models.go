package main

import (
	"fmt"
	"strings"
	"time"
)

// ============================================================
// CONSTANTS & VALIDATION TYPES
// ============================================================

// Event Types yang diizinkan sesuai Contract
const (
	EventTypeMidProcess = "MID_PROCESS"
	EventTypeStart      = "START"
	EventTypeEnd        = "END"
)

// Start Types
const (
	StartTypeMidProcess   = "mid process"
	StartTypeStartProcess = "start process"
)

// Batch Statuses
const (
	BatchStatusRunning   = "Running"
	BatchStatusCompleted = "Completed"
	BatchStatusIdle      = "Idle"
)

// Agent Statuses
const (
	AgentStatusOnline  = "ONLINE"
	AgentStatusOffline = "OFFLINE"
)

// Threshold Waktu Heartbeat untuk Status ONLINE (misal 90 detik)
const HeartbeatOnlineThreshold = 90 * time.Second

// ============================================================
// BATCH DOMAIN MODEL
// ============================================================

// BatchRecord merepresentasikan 1 row batch penimbangan FG yang ditampilkan pada Dashboard.
type BatchRecord struct {
	ID             int64      `json:"id" db:"id"`
	EventID        string     `json:"event_id" db:"event_id"`
	WorkOrder      string     `json:"work_order" db:"work_order"`
	ProductCode    string     `json:"product_code" db:"product_code"`
	Formula        string     `json:"formula" db:"formula"`
	Batch          string     `json:"batch" db:"batch"`
	WorkStation    string     `json:"work_station" db:"work_station"`
	StartTimestamp time.Time  `json:"start_timestamp" db:"start_timestamp"`
	StartType      string     `json:"start_type" db:"start_type"` // "mid process" atau "start process"
	EndTimestamp   *time.Time `json:"end_timestamp,omitempty" db:"end_timestamp"`
	EndType        string     `json:"end_type,omitempty" db:"end_type"`
	Pallet         string     `json:"pallet" db:"pallet"`
	NomorMB        string     `json:"nomor_mb" db:"nomor_mb"`
	MasterBox      string     `json:"master_box" db:"master_box"`
	Status         string     `json:"status" db:"status"` // "Running", "Completed", atau "Idle"
	CreatedAt      time.Time  `json:"created_at" db:"created_at"`
	UpdatedAt      time.Time  `json:"updated_at" db:"updated_at"`
}

// GetFormattedStart menampilkan string Start berformat untuk Dashboard, contoh: "(mid) 23:16:03" atau "23:16:03"
func (b *BatchRecord) GetFormattedStart() string {
	timeStr := b.StartTimestamp.Local().Format("15:04:05")
	if b.StartType == StartTypeMidProcess {
		return fmt.Sprintf("(mid) %s", timeStr)
	}
	return timeStr
}

// GetFormattedEnd menampilkan string End berformat untuk Dashboard, contoh: "Idle", "Running", atau "04:15:00"
func (b *BatchRecord) GetFormattedEnd() string {
	if b.EndTimestamp != nil {
		return b.EndTimestamp.Local().Format("15:04:05")
	}

	if b.Status == BatchStatusIdle {
		return "Idle"
	}

	return "Running"
}

// GetFormattedPallet display index 2 digit, contoh: "01"
func (b *BatchRecord) GetFormattedPallet() string {
	if len(b.Pallet) >= 2 {
		return b.Pallet[len(b.Pallet)-2:]
	}
	if b.Pallet != "" {
		return b.Pallet
	}
	return "-"
}

// GetFormattedBox menampilkan Nomor MB, contoh: "0005"
func (b *BatchRecord) GetFormattedBox() string {
	if b.NomorMB != "" {
		return b.NomorMB
	}
	return "-"
}

// ============================================================
// AGENT DOMAIN MODEL
// ============================================================

// AgentRecord merepresentasikan identitas dan health PC Agent yang ditampilkan di monitor.html.
type AgentRecord struct {
	ID            int64     `json:"id" db:"id"`
	AgentID       string    `json:"agent_id" db:"agent_id"`
	Hostname      string    `json:"hostname" db:"hostname"`
	WorkStation   string    `json:"work_station" db:"work_station"`
	Username      string    `json:"username" db:"username"`
	AgentVersion  string    `json:"agent_version" db:"agent_version"`
	Status        string    `json:"status"` // Evaluated dynamically: "ONLINE" / "OFFLINE"
	FirstSeen     time.Time `json:"first_seen" db:"first_seen"`
	LastSeen      time.Time `json:"last_seen" db:"last_seen"`
	LastHeartbeat time.Time `json:"last_heartbeat" db:"last_heartbeat"`
	CreatedAt     time.Time `json:"created_at" db:"created_at"`
	UpdatedAt     time.Time `json:"updated_at" db:"updated_at"`
}

// EvaluateStatus menentukan status ONLINE / OFFLINE berdasarkan interval LastHeartbeat
func (a *AgentRecord) EvaluateStatus() {
	if time.Since(a.LastHeartbeat) <= HeartbeatOnlineThreshold {
		a.Status = AgentStatusOnline
	} else {
		a.Status = AgentStatusOffline
	}
}

// ============================================================
// API REQUEST CONTRACTS
// ============================================================

// AgentRegisterRequest model payload POST /api/agent/register
type AgentRegisterRequest struct {
	AgentID      string `json:"agent_id"`
	Hostname     string `json:"hostname"`
	WorkStation  string `json:"work_station"`
	Username     string `json:"username"`
	AgentVersion string `json:"agent_version"`
}

// AgentHeartbeatRequest model payload POST /api/agent/heartbeat
type AgentHeartbeatRequest struct {
	AgentID      string `json:"agent_id"`
	Hostname     string `json:"hostname"`
	WorkStation  string `json:"work_station"`
	AgentVersion string `json:"agent_version"`
}

// AgentEventRequest model payload POST /api/agent/events
type AgentEventRequest struct {
	EventID     string    `json:"event_id"`
	AgentID     string    `json:"agent_id"`
	EventType   string    `json:"event_type"` // MID_PROCESS, START, END
	Timestamp   time.Time `json:"timestamp"`
	WorkOrder   string    `json:"work_order"`
	ProductCode string    `json:"product_code"`
	Formula     string    `json:"formula"`
	Batch       string    `json:"batch"`
	WorkStation string    `json:"work_station"`
	Pallet      string    `json:"pallet"`
	NomorMB     string    `json:"nomor_mb"`
	MasterBox   string    `json:"master_box"`
	StartType   string    `json:"start_type"`
	EndType     string    `json:"end_type"`
}

// Validate mendeteksi keabsahan field Event
func (e *AgentEventRequest) Validate() error {
	if e.EventID == "" {
		return fmt.Errorf("event_id is required")
	}
	if e.AgentID == "" {
		return fmt.Errorf("agent_id is required")
	}
	if e.EventType != EventTypeMidProcess && e.EventType != EventTypeStart && e.EventType != EventTypeEnd {
		return fmt.Errorf("invalid event_type: %s", e.EventType)
	}
	if e.WorkOrder == "" {
		return fmt.Errorf("work_order is required")
	}
	return nil
}

// ProgressRequest adalah payload realtime progress batch.
// PROGRESS hanya memperbarui pallet dan nomor_mb pada batch yang sedang berjalan.
// Lifecycle timestamp (start/end) tidak disentuh oleh request ini.
type ProgressRequest struct {
	EventID     string    `json:"event_id"`
	AgentID     string    `json:"agent_id"`
	Timestamp   time.Time `json:"timestamp"`
	WorkOrder   string    `json:"work_order"`
	Formula     string    `json:"formula"`
	Batch       string    `json:"batch"`
	WorkStation string    `json:"work_station"`
	Pallet      string    `json:"pallet"`
	NomorMB     string    `json:"nomor_mb"`
}

// Validate memvalidasi payload realtime progress.
func (p *ProgressRequest) Validate() error {
	if p == nil {
		return fmt.Errorf("progress request cannot be nil")
	}

	if strings.TrimSpace(p.EventID) == "" {
		return fmt.Errorf("event_id is required")
	}

	if strings.TrimSpace(p.AgentID) == "" {
		return fmt.Errorf("agent_id is required")
	}

	if strings.TrimSpace(p.WorkOrder) == "" {
		return fmt.Errorf("work_order is required")
	}

	if strings.TrimSpace(p.Formula) == "" {
		return fmt.Errorf("formula is required")
	}

	if strings.TrimSpace(p.Batch) == "" {
		return fmt.Errorf("batch is required")
	}

	return nil
}

// ============================================================
// API RESPONSE CONTRACTS
// ============================================================

// SuccessResponse model standar response JSON sukses
type SuccessResponse struct {
	Success    bool      `json:"success"`
	ServerTime time.Time `json:"server_time,omitempty"`
	Message    string    `json:"message,omitempty"`
}

// ErrorResponse model standar response JSON gagal
type ErrorResponse struct {
	Success bool   `json:"success"`
	Error   string `json:"error"`
}

// PaginatedBatchResponse struct wrapper pagination dashboard batch
type PaginatedBatchResponse struct {
	Success    bool          `json:"success"`
	Data       []BatchRecord `json:"data"`
	Page       int           `json:"page"`
	Limit      int           `json:"limit"`
	Total      int           `json:"total"`
	TotalPages int           `json:"total_pages"`
	Query      string        `json:"query,omitempty"`
}
