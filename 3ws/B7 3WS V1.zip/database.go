package main

import (
	"database/sql"
	"fmt"
	"log"
	"os"
	"strconv"
	"strings"
	"time"

	_ "github.com/lib/pq"
)

// Config Database PostgreSQL
type DBConfig struct {
	Host     string
	Port     int
	User     string
	Password string
	DBName   string
	SSLMode  string
}

// LoadDBConfigFromEnv mengambil konfigurasi database dari Environment Variables
func LoadDBConfigFromEnv() DBConfig {
	portStr := os.Getenv("DATABASE_PORT")
	port := 5432
	if p, err := strconv.Atoi(portStr); err == nil && p > 0 {
		port = p
	}

	host := os.Getenv("DATABASE_HOST")
	if host == "" {
		host = "localhost"
	}

	user := os.Getenv("DATABASE_USER")
	if user == "" {
		user = "postgres"
	}

	password := os.Getenv("DATABASE_PASSWORD")

	dbname := os.Getenv("DATABASE_NAME")
	if dbname == "" {
		dbname = "db_3ws"
	}

	sslmode := strings.TrimSpace(os.Getenv("DATABASE_SSLMODE"))
	if sslmode == "" {
		sslmode = "disable"
	}

	return DBConfig{
		Host:     host,
		Port:     port,
		User:     user,
		Password: password,
		DBName:   dbname,
		SSLMode:  sslmode,
	}
}

// OpenDatabase membuka koneksi PostgreSQL dengan Connection Pool yang dikonfigurasi
func OpenDatabase(cfg DBConfig) (*sql.DB, error) {
	// Memastikan sslmode tidak kosong
	sslMode := strings.TrimSpace(cfg.SSLMode)
	if sslMode == "" {
		sslMode = "disable"
	}

	connStr := fmt.Sprintf(
		"host=%s port=%d user=%s password=%s dbname=%s sslmode=%s timezone=Asia/Jakarta",
		cfg.Host, cfg.Port, cfg.User, cfg.Password, cfg.DBName, sslMode,
	)

	// Log tanpa mengekspos password
	log.Printf("[DB] Connecting to PostgreSQL at %s:%d/%s (user: %s, sslmode: %s)...",
		cfg.Host, cfg.Port, cfg.DBName, cfg.User, sslMode)

	db, err := sql.Open("postgres", connStr)
	if err != nil {
		return nil, fmt.Errorf("failed to open postgres connection: %w", err)
	}

	// Konfigurasi Connection Pool
	db.SetMaxOpenConns(25)
	db.SetMaxIdleConns(5)
	db.SetConnMaxLifetime(15 * time.Minute)
	db.SetConnMaxIdleTime(5 * time.Minute)

	// Verifikasi koneksi awal
	if err := PingDatabase(db); err != nil {
		db.Close()
		return nil, fmt.Errorf("database ping failed: %w", err)
	}

	log.Println("[DB] Database connection established successfully.")
	return db, nil
}

// PingDatabase melakukan verifikasi keaktifan koneksi PostgreSQL
func PingDatabase(db *sql.DB) error {
	if db == nil {
		return fmt.Errorf("database handle is nil")
	}
	return db.Ping()
}

// CloseDatabase menutup koneksi PostgreSQL secara aman
func CloseDatabase(db *sql.DB) {
	if db != nil {
		log.Println("[DB] Closing database connection pool...")
		if err := db.Close(); err != nil {
			log.Printf("[DB] Error closing database: %v", err)
		} else {
			log.Println("[DB] Database connection pool closed.")
		}
	}
}

// InitDatabaseSchema membuat tabel-tabel dan index yang dibutuhkan jika belum ada
func InitDatabaseSchema(db *sql.DB) error {
	log.Println("[DB] Initializing database schema and indexes...")

	schemaSQL := `
	-- Set Timezone default ke Asia/Jakarta
	SET timezone = 'Asia/Jakarta';

	-- 1. TABEL AGENTS (Health & Metadata PC)
	CREATE TABLE IF NOT EXISTS agents (
		id BIGSERIAL PRIMARY KEY,
		agent_id VARCHAR(64) UNIQUE NOT NULL,
		hostname VARCHAR(100) NOT NULL,
		work_station VARCHAR(100) NOT NULL DEFAULT '',
		username VARCHAR(100) NOT NULL,
		agent_version VARCHAR(20) NOT NULL,
		first_seen TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
		last_seen TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
		last_heartbeat TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
		created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
		updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
	);

	ALTER TABLE agents ADD COLUMN IF NOT EXISTS agent_version VARCHAR(20);
	ALTER TABLE agents ADD COLUMN IF NOT EXISTS work_station VARCHAR(100) DEFAULT '';

	UPDATE agents
	SET work_station = ''
	WHERE work_station IS NULL;

	CREATE INDEX IF NOT EXISTS idx_agents_agent_id ON agents(agent_id);

	-- 2. TABEL PROCESSED_EVENTS (Idempotency Key Engine)
	CREATE TABLE IF NOT EXISTS event_records (
		id BIGSERIAL PRIMARY KEY,
		event_id VARCHAR(64) UNIQUE NOT NULL,
		agent_id VARCHAR(64) NOT NULL,
		event_type VARCHAR(20) NOT NULL,
		work_order VARCHAR(100) NOT NULL,
		batch VARCHAR(100) NOT NULL,
		formula VARCHAR(100) NOT NULL,
		created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
	);

	ALTER TABLE event_records ADD COLUMN IF NOT EXISTS batch VARCHAR(100);
	ALTER TABLE event_records ADD COLUMN IF NOT EXISTS work_order VARCHAR(100);
	ALTER TABLE event_records ADD COLUMN IF NOT EXISTS formula VARCHAR(100);

	CREATE INDEX IF NOT EXISTS idx_event_records_event_id ON event_records(event_id);

	-- 3. TABEL BATCH_RECORDS (Dashboard Data)
	CREATE TABLE IF NOT EXISTS batch_records (
		id BIGSERIAL PRIMARY KEY,
		event_id VARCHAR(64) NOT NULL,
		work_order VARCHAR(100) NOT NULL,
		product_code VARCHAR(100) NOT NULL,
		formula VARCHAR(100) NOT NULL,
		batch VARCHAR(100) NOT NULL,
		work_station VARCHAR(100) NOT NULL DEFAULT '',
		start_timestamp TIMESTAMPTZ NOT NULL,
		start_type VARCHAR(30) NOT NULL,
		end_timestamp TIMESTAMPTZ,
		end_type VARCHAR(50),
		pallet VARCHAR(50) NOT NULL,
		nomor_mb VARCHAR(50),
		master_box VARCHAR(50) NOT NULL,
		status VARCHAR(20) NOT NULL DEFAULT 'Running',
		created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
		updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
	);

	-- Dynamic Schema Migration untuk batch_records legacy
	DO $$
	BEGIN
		-- 3a. Lepaskan constraint NOT NULL dari kolom-kolom legacy agar INSERT baru tidak gagal
		IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='batch_records' AND column_name='batch_code') THEN
			ALTER TABLE batch_records ALTER COLUMN batch_code DROP NOT NULL;
		END IF;

		IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='batch_records' AND column_name='start_time') THEN
			ALTER TABLE batch_records ALTER COLUMN start_time DROP NOT NULL;
		END IF;

		IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='batch_records' AND column_name='end_time') THEN
			ALTER TABLE batch_records ALTER COLUMN end_time DROP NOT NULL;
		END IF;

		IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='batch_records' AND column_name='box') THEN
			ALTER TABLE batch_records ALTER COLUMN box DROP NOT NULL;
		END IF;

		IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='batch_records' AND column_name='agent_id') THEN
			ALTER TABLE batch_records ALTER COLUMN agent_id DROP NOT NULL;
		END IF;

		IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='batch_records' AND column_name='operator_id') THEN
			ALTER TABLE batch_records ALTER COLUMN operator_id DROP NOT NULL;
		END IF;
	END $$;

	-- 3b. Auto Migration: Tambahkan kolom baru jika belum ada
	ALTER TABLE batch_records ADD COLUMN IF NOT EXISTS event_id VARCHAR(64);
	ALTER TABLE batch_records ADD COLUMN IF NOT EXISTS work_order VARCHAR(100);
	ALTER TABLE batch_records ADD COLUMN IF NOT EXISTS product_code VARCHAR(100);
	ALTER TABLE batch_records ADD COLUMN IF NOT EXISTS formula VARCHAR(100);
	ALTER TABLE batch_records ADD COLUMN IF NOT EXISTS batch VARCHAR(100);
	ALTER TABLE batch_records ADD COLUMN IF NOT EXISTS work_station VARCHAR(100) DEFAULT '';
	ALTER TABLE batch_records ADD COLUMN IF NOT EXISTS start_timestamp TIMESTAMPTZ;
	ALTER TABLE batch_records ADD COLUMN IF NOT EXISTS start_type VARCHAR(30);
	ALTER TABLE batch_records ADD COLUMN IF NOT EXISTS end_timestamp TIMESTAMPTZ;
	ALTER TABLE batch_records ADD COLUMN IF NOT EXISTS end_type VARCHAR(50);
	ALTER TABLE batch_records ADD COLUMN IF NOT EXISTS pallet VARCHAR(50);
	ALTER TABLE batch_records ADD COLUMN IF NOT EXISTS nomor_mb VARCHAR(50);
	ALTER TABLE batch_records ADD COLUMN IF NOT EXISTS master_box VARCHAR(50);
	ALTER TABLE batch_records ADD COLUMN IF NOT EXISTS status VARCHAR(20) DEFAULT 'Running';

	-- 3c. Salin data dari kolom legacy ke kolom baru jika ada data lama yang bernilai NULL
	DO $$
	BEGIN
		IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='batch_records' AND column_name='batch_code') THEN
			UPDATE batch_records SET batch = batch_code WHERE batch IS NULL AND batch_code IS NOT NULL;
		END IF;

		IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='batch_records' AND column_name='start_time') THEN
			UPDATE batch_records SET start_timestamp = start_time WHERE start_timestamp IS NULL AND start_time IS NOT NULL;
		END IF;

		IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='batch_records' AND column_name='end_time') THEN
			UPDATE batch_records SET end_timestamp = end_time WHERE end_timestamp IS NULL AND end_time IS NOT NULL;
		END IF;

		IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='batch_records' AND column_name='box') THEN
			UPDATE batch_records SET master_box = box WHERE master_box IS NULL AND box IS NOT NULL;
		END IF;
	END $$;

	-- 3d. Normalisasi default value untuk row legacy agar tidak melanggar constraint
	UPDATE batch_records SET event_id = '' WHERE event_id IS NULL;
	UPDATE batch_records SET work_order = '' WHERE work_order IS NULL;
	UPDATE batch_records SET product_code = '' WHERE product_code IS NULL;
	UPDATE batch_records SET formula = '' WHERE formula IS NULL;
	UPDATE batch_records SET batch = '' WHERE batch IS NULL;
	UPDATE batch_records SET work_station = '' WHERE work_station IS NULL;
	UPDATE batch_records SET start_timestamp = CURRENT_TIMESTAMP WHERE start_timestamp IS NULL;
	UPDATE batch_records SET start_type = 'SYSTEM' WHERE start_type IS NULL;
	UPDATE batch_records SET pallet = '' WHERE pallet IS NULL;
	UPDATE batch_records SET nomor_mb = '' WHERE nomor_mb IS NULL;
	UPDATE batch_records SET master_box = '' WHERE master_box IS NULL;
	UPDATE batch_records SET status = 'Running' WHERE status IS NULL;

	-- 3e. Cleanup record batch yang jelas-jelas invalid/junk.
	-- Hanya menghapus record yang identity-nya tidak valid.
	DELETE FROM batch_records
	WHERE
		UPPER(TRIM(work_order)) IN (
			'', '-', 'N/A', 'NA', 'NONE', 'NULL', 'UNKNOWN',
			'BOX', 'COM1', 'COM2', 'COM3', 'COM4',
			'SARTORIUS', 'COM1: SARTORIUS', 'COM1 SARTORIUS'
		)
		OR UPPER(TRIM(formula)) IN (
			'', '-', 'N/A', 'NA', 'NONE', 'NULL', 'UNKNOWN',
			'BOX', 'COM1', 'COM2', 'COM3', 'COM4',
			'SARTORIUS', 'COM1: SARTORIUS', 'COM1 SARTORIUS'
		)
		OR UPPER(TRIM(batch)) IN (
			'', '-', 'N/A', 'NA', 'NONE', 'NULL', 'UNKNOWN',
			'BOX', 'COM1', 'COM2', 'COM3', 'COM4',
			'SARTORIUS', 'COM1: SARTORIUS', 'COM1 SARTORIUS'
		)
		OR UPPER(TRIM(work_order)) = UPPER(TRIM(formula))
		OR UPPER(TRIM(work_order)) = UPPER(TRIM(batch))
		OR UPPER(TRIM(formula)) = UPPER(TRIM(batch))
		OR LOWER(work_order) LIKE '%sartorius%'
		OR LOWER(formula) LIKE '%sartorius%'
		OR LOWER(batch) LIKE '%sartorius%'
		OR LOWER(work_order) LIKE 'com1:%'
		OR LOWER(formula) LIKE 'com1:%'
		OR LOWER(batch) LIKE 'com1:%'
		OR LOWER(work_order) LIKE 'com2:%'
		OR LOWER(formula) LIKE 'com2:%'
		OR LOWER(batch) LIKE 'com2:%'
		OR LOWER(work_order) LIKE 'com3:%'
		OR LOWER(formula) LIKE 'com3:%'
		OR LOWER(batch) LIKE 'com3:%'
		OR LOWER(work_order) LIKE 'com4:%'
		OR LOWER(formula) LIKE 'com4:%'
		OR LOWER(batch) LIKE 'com4:%';

	-- 3f. Menambahkan Unique Constraint uq_batch_records_identity secara aman
	-- Identity batch: work_order + batch + formula + work_station
	-- Work Station WAJIB ikut identity karena batch yang sama dapat diproses pada workstation yang berbeda.
	DO $$
	BEGIN
		IF EXISTS (
			SELECT 1 FROM pg_constraint WHERE conname = 'uq_batch_records_identity'
		) THEN
			ALTER TABLE batch_records DROP CONSTRAINT uq_batch_records_identity;
		END IF;

		ALTER TABLE batch_records
		ADD CONSTRAINT uq_batch_records_identity
		UNIQUE (work_order, batch, formula, work_station);
	END $$;

	-- Index pendukung pencarian ILIKE dan sorting Dashboard
	CREATE INDEX IF NOT EXISTS idx_batch_records_start_timestamp ON batch_records(start_timestamp DESC);
	CREATE INDEX IF NOT EXISTS idx_batch_records_work_order ON batch_records(work_order);
	CREATE INDEX IF NOT EXISTS idx_batch_records_batch ON batch_records(batch);
	CREATE INDEX IF NOT EXISTS idx_batch_records_product_code ON batch_records(product_code);
	CREATE INDEX IF NOT EXISTS idx_batch_records_status ON batch_records(status);
	`

	tx, err := db.Begin()
	if err != nil {
		return fmt.Errorf("failed to begin schema transaction: %w", err)
	}

	if _, err := tx.Exec(schemaSQL); err != nil {
		tx.Rollback()
		return fmt.Errorf("failed to execute schema SQL: %w", err)
	}

	if err := tx.Commit(); err != nil {
		return fmt.Errorf("failed to commit schema transaction: %w", err)
	}

	log.Println("[DB] Database schema and indexes initialized successfully.")
	return nil
}

// ExecInTx helper untuk menjalankan beberapa instruksi SQL di dalam satu transaksi atomic
func ExecInTx(db *sql.DB, fn func(*sql.Tx) error) error {
	tx, err := db.Begin()
	if err != nil {
		return fmt.Errorf("failed to begin transaction: %w", err)
	}

	defer func() {
		if p := recover(); p != nil {
			tx.Rollback()
			panic(p) // re-throw panic setelah rollback
		}
	}()

	if err := fn(tx); err != nil {
		if rbErr := tx.Rollback(); rbErr != nil {
			return fmt.Errorf("tx err: %v, rollback err: %v", err, rbErr)
		}
		return err
	}

	if err := tx.Commit(); err != nil {
		return fmt.Errorf("failed to commit transaction: %w", err)
	}

	return nil
}
