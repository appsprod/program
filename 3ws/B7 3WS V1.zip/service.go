package main

import (
	"context"
	"errors"
	"fmt"
	"log"
	"math"
	"strings"
	"time"
)

// Service interface mendefinisikan kontrak business logic SERVER B7_3WS
type Service interface {
	// Agent Operations
	RegisterAgent(ctx context.Context, req *AgentRegisterRequest) (*SuccessResponse, error)
	UpdateHeartbeat(ctx context.Context, req *AgentHeartbeatRequest) (*SuccessResponse, error)
	GetAgents(ctx context.Context) ([]AgentRecord, error)
	DeleteAgent(ctx context.Context, id int64) (*SuccessResponse, error)

	// Event & Batch Workflow
	ReceiveBatchEvent(ctx context.Context, req *AgentEventRequest) (*SuccessResponse, error)
	CreateBatch(ctx context.Context, req *AgentEventRequest) error
	UpdateRunningBatch(ctx context.Context, req *AgentEventRequest) error
	CompleteBatch(ctx context.Context, req *AgentEventRequest) error
	UpdateBatchProgress(ctx context.Context, req *ProgressRequest) (*SuccessResponse, error)
	GetBatchByIdentity(ctx context.Context, workOrder string, batch string, formula string, workStation string) (*BatchRecord, error)

	// Dashboard & Search Queries
	GetDashboardBatches(ctx context.Context, page int, limit int) (*PaginatedBatchResponse, error)
	SearchBatches(ctx context.Context, query string, page int, limit int) (*PaginatedBatchResponse, error)
}

// AppService implementasi konkret dari Service interface
type AppService struct {
	repo BatchRepository
}

// NewAppService membuat instance baru dari AppService
func NewAppService(repo BatchRepository) *AppService {
	return &AppService{
		repo: repo,
	}
}

func (s *AppService) GetBatchByIdentity(
	ctx context.Context,
	workOrder string,
	batch string,
	formula string,
	workStation string,
) (*BatchRecord, error) {
	workOrder = strings.TrimSpace(workOrder)
	batch = strings.TrimSpace(batch)
	formula = strings.TrimSpace(formula)
	workStation = strings.TrimSpace(workStation)

	if workOrder == "" || batch == "" || formula == "" || workStation == "" {
		return nil, errors.New("batch identity lookup requires work_order, batch, formula, and work_station")
	}

	return s.repo.GetBatchByIdentity(
		ctx,
		workOrder,
		batch,
		formula,
		workStation,
	)
}

// ============================================================
// AGENT OPERATIONS
// ============================================================

func (s *AppService) RegisterAgent(ctx context.Context, req *AgentRegisterRequest) (*SuccessResponse, error) {
	if req == nil {
		return nil, errors.New("registration request cannot be nil")
	}

	req.AgentID = strings.TrimSpace(req.AgentID)
	req.Hostname = strings.TrimSpace(req.Hostname)
	req.WorkStation = strings.TrimSpace(req.WorkStation)
	req.Username = strings.TrimSpace(req.Username)
	req.AgentVersion = strings.TrimSpace(req.AgentVersion)

	if req.AgentID == "" {
		return nil, errors.New("agent_id is required for registration")
	}
	if req.Hostname == "" {
		return nil, errors.New("hostname is required for registration")
	}

	agent := &AgentRecord{
		AgentID:      req.AgentID,
		Hostname:     req.Hostname,
		WorkStation:  req.WorkStation,
		Username:     req.Username,
		AgentVersion: req.AgentVersion,
	}

	if err := s.repo.UpsertAgent(ctx, agent); err != nil {
		log.Printf("[SERVICE] Failed to register agent %s: %v", req.AgentID, err)
		return nil, fmt.Errorf("failed to register agent: %w", err)
	}

	log.Printf("[SERVICE] Agent registered successfully: %s (%s) workstation=%s", req.AgentID, req.Hostname, req.WorkStation)

	return &SuccessResponse{
		Success:    true,
		ServerTime: time.Now().Local(),
		Message:    "Agent registered successfully",
	}, nil
}

func (s *AppService) UpdateHeartbeat(ctx context.Context, req *AgentHeartbeatRequest) (*SuccessResponse, error) {
	if req == nil {
		return nil, errors.New("heartbeat request cannot be nil")
	}

	req.AgentID = strings.TrimSpace(req.AgentID)
	req.Hostname = strings.TrimSpace(req.Hostname)
	req.WorkStation = strings.TrimSpace(req.WorkStation)
	req.AgentVersion = strings.TrimSpace(req.AgentVersion)

	if req.AgentID == "" {
		return nil, errors.New("agent_id is required for heartbeat")
	}

	err := s.repo.UpdateHeartbeat(ctx, req.AgentID, req.Hostname, req.AgentVersion, req.WorkStation)
	if err != nil {
		if strings.Contains(strings.ToLower(err.Error()), "not found") {
			log.Printf("[SERVICE] Heartbeat received from unregistered agent %s. Auto-registering... workstation=%s", req.AgentID, req.WorkStation)

			regReq := &AgentRegisterRequest{
				AgentID:      req.AgentID,
				Hostname:     req.Hostname,
				WorkStation:  req.WorkStation,
				Username:     "Auto-Registered",
				AgentVersion: req.AgentVersion,
			}

			return s.RegisterAgent(ctx, regReq)
		}

		log.Printf("[SERVICE] Failed to update heartbeat for agent %s: %v", req.AgentID, err)
		return nil, fmt.Errorf("failed to update heartbeat: %w", err)
	}

	return &SuccessResponse{
		Success:    true,
		ServerTime: time.Now().Local(),
		Message:    "Heartbeat recorded",
	}, nil
}

func (s *AppService) GetAgents(ctx context.Context) ([]AgentRecord, error) {
	agents, err := s.repo.GetAllAgents(ctx)
	if err != nil {
		log.Printf("[SERVICE] Failed to fetch agents: %v", err)
		return nil, fmt.Errorf("failed to fetch agents: %w", err)
	}

	for i := range agents {
		agents[i].EvaluateStatus()
	}

	return agents, nil
}

func (s *AppService) DeleteAgent(ctx context.Context, id int64) (*SuccessResponse, error) {
	if id <= 0 {
		return nil, errors.New("invalid agent id")
	}

	if err := s.repo.DeleteAgent(ctx, id); err != nil {
		log.Printf("[SERVICE] Failed to delete agent ID %d: %v", id, err)
		return nil, fmt.Errorf("failed to delete agent: %w", err)
	}

	log.Printf("[SERVICE] Agent deleted successfully: ID=%d", id)

	return &SuccessResponse{
		Success:    true,
		ServerTime: time.Now().Local(),
		Message:    "Agent deleted successfully",
	}, nil
}

// ============================================================
// EVENT & BATCH WORKFLOW
// ============================================================

func (s *AppService) ReceiveBatchEvent(ctx context.Context, req *AgentEventRequest) (*SuccessResponse, error) {
	if req == nil {
		return nil, errors.New("event request cannot be nil")
	}

	if err := req.Validate(); err != nil {
		log.Printf("[SERVICE] Event validation failed: %v", err)
		return nil, fmt.Errorf("invalid event payload: %w", err)
	}

	req.AgentID = strings.TrimSpace(req.AgentID)
	req.WorkOrder = strings.TrimSpace(req.WorkOrder)
	req.Batch = strings.TrimSpace(req.Batch)
	req.ProductCode = strings.TrimSpace(req.ProductCode)
	req.Formula = strings.TrimSpace(req.Formula)
	req.WorkStation = strings.TrimSpace(req.WorkStation)
	req.Pallet = strings.TrimSpace(req.Pallet)
	req.NomorMB = strings.TrimSpace(req.NomorMB)
	req.MasterBox = strings.TrimSpace(req.MasterBox)

	if req.Timestamp.IsZero() {
		req.Timestamp = time.Now()
	}

	// SERVER-SIDE GUARD: Abaikan MID_PROCESS dengan identity invalid tanpa mengembalikan error.
	if req.EventType == EventTypeMidProcess {
		if err := validateBatchIdentity(req); err != nil {
			return &SuccessResponse{
				Success:    true,
				ServerTime: time.Now().Local(),
				Message:    "MID_PROCESS ignored: invalid batch identity",
			}, nil
		}
	}

	// 2. Cek Idempotency
	processed, err := s.repo.IsEventProcessed(ctx, req.EventID)
	if err != nil {
		log.Printf("[SERVICE] Error checking event idempotency [%s]: %v", req.EventID, err)
		return nil, fmt.Errorf("failed to verify event idempotency: %w", err)
	}

	if processed {
		log.Printf("[SERVICE] Idempotent trigger: Event %s already processed. Skipping.", req.EventID)
		return &SuccessResponse{
			Success:    true,
			ServerTime: time.Now().Local(),
			Message:    "Event already processed (idempotent response)",
		}, nil
	}

	switch req.EventType {
	case EventTypeMidProcess:
		if err := s.CreateBatch(ctx, req); err != nil {
			return nil, err
		}

	case EventTypeStart:
		if err := s.UpdateRunningBatch(ctx, req); err != nil {
			return nil, err
		}

	case EventTypeEnd:
		if err := s.CompleteBatch(ctx, req); err != nil {
			return nil, err
		}

	default:
		return nil, fmt.Errorf("unsupported event_type: %s", req.EventType)
	}

	log.Printf("[SERVICE] Event %s [%s] processed successfully for WO: %s, Batch: %s", req.EventType, req.EventID, req.WorkOrder, req.Batch)

	return &SuccessResponse{
		Success:    true,
		ServerTime: time.Now().Local(),
		Message:    fmt.Sprintf("Event %s processed successfully", req.EventType),
	}, nil
}

func (s *AppService) CreateBatch(ctx context.Context, req *AgentEventRequest) error {
	if req.StartType == "" {
		req.StartType = StartTypeMidProcess
	}

	err := s.repo.ProcessAgentEvent(ctx, req)
	if err != nil {
		if errors.Is(err, ErrEventAlreadyProcessed) {
			return nil
		}
		log.Printf("[SERVICE] Error creating batch record on MID_PROCESS: %v", err)
		return fmt.Errorf("failed to process MID_PROCESS event: %w", err)
	}

	return nil
}

func (s *AppService) UpdateRunningBatch(ctx context.Context, req *AgentEventRequest) error {
	req.StartType = StartTypeStartProcess

	err := s.repo.ProcessAgentEvent(ctx, req)
	if err != nil {
		if errors.Is(err, ErrEventAlreadyProcessed) {
			return nil
		}
		log.Printf("[SERVICE] Error updating batch record on START: %v", err)
		return fmt.Errorf("failed to process START event: %w", err)
	}

	return nil
}

func (s *AppService) CompleteBatch(ctx context.Context, req *AgentEventRequest) error {
	if req.EndType == "" {
		req.EndType = "end process"
	}

	err := s.repo.ProcessAgentEvent(ctx, req)
	if err != nil {
		if errors.Is(err, ErrEventAlreadyProcessed) {
			return nil
		}
		log.Printf("[SERVICE] Error completing batch record on END: %v", err)
		return fmt.Errorf("failed to process END event: %w", err)
	}

	return nil
}

// ============================================================
// PROGRESS
// ============================================================

func (s *AppService) UpdateBatchProgress(
	ctx context.Context,
	req *ProgressRequest,
) (*SuccessResponse, error) {
	if req == nil {
		return nil, errors.New("progress request cannot be nil")
	}

	if err := req.Validate(); err != nil {
		log.Printf("[SERVICE] Progress validation failed: %v", err)
		return nil, fmt.Errorf("invalid progress payload: %w", err)
	}

	// Normalisasi payload.
	req.AgentID = strings.TrimSpace(req.AgentID)
	req.WorkOrder = strings.TrimSpace(req.WorkOrder)
	req.Batch = strings.TrimSpace(req.Batch)
	req.Formula = strings.TrimSpace(req.Formula)
	req.WorkStation = strings.TrimSpace(req.WorkStation)
	req.Pallet = strings.TrimSpace(req.Pallet)
	req.NomorMB = strings.TrimSpace(req.NomorMB)

	if req.Timestamp.IsZero() {
		req.Timestamp = time.Now()
	}

	// ============================================================
	// SERVER-SIDE GUARD UNTUK PROGRESS
	//
	// Progress dengan identity sampah seperti:
	// Formula = "BOX"
	// Formula = "COM1: Sartorius"
	// Batch/WO invalid
	//
	// tidak boleh membuat fallback batch.
	// Cukup abaikan dengan response sukses.
	// ============================================================
	progressIdentity := &AgentEventRequest{
		EventID:     req.EventID,
		AgentID:     req.AgentID,
		EventType:   EventTypeMidProcess,
		Timestamp:   req.Timestamp,
		WorkOrder:   req.WorkOrder,
		Formula:     req.Formula,
		Batch:       req.Batch,
		WorkStation: req.WorkStation,
		Pallet:      req.Pallet,
		NomorMB:     req.NomorMB,
	}

	if err := validateBatchIdentity(progressIdentity); err != nil {
		return &SuccessResponse{
			Success:    true,
			ServerTime: time.Now().Local(),
			Message:    "PROGRESS ignored: invalid batch identity",
		}, nil
	}

	// ============================================================
	// 1. Normal update ke batch Running
	// ============================================================
	err := s.repo.UpdateBatchProgress(ctx, req)

	// ============================================================
	// 2. Kalau batch belum ada, buat provisional batch dari PROGRESS
	//
	// Ini penting untuk agent yang mulai kirim PROGRESS sebelum
	// server menerima MID_PROCESS.
	//
	// Timestamp provisional ini TIDAK menjadi timestamp START final
	// apabila event START berikutnya masuk.
	// ============================================================
	if err != nil &&
		strings.Contains(
			strings.ToLower(err.Error()),
			"running batch not found for progress",
		) {

		log.Printf(
			"[SERVICE] Running batch not found. Creating fallback batch from PROGRESS: WO=%s Batch=%s Formula=%s WorkStation=%s",
			req.WorkOrder,
			req.Batch,
			req.Formula,
			req.WorkStation,
		)

		fallbackEvent := &AgentEventRequest{
			EventID:     req.EventID,
			AgentID:     req.AgentID,
			EventType:   EventTypeMidProcess,
			Timestamp:   req.Timestamp,
			WorkOrder:   req.WorkOrder,
			ProductCode: "",
			Formula:     req.Formula,
			Batch:       req.Batch,
			WorkStation: req.WorkStation,
			Pallet:      req.Pallet,
			NomorMB:     req.NomorMB,
			MasterBox:   "",
			StartType:   StartTypeMidProcess,
		}

		if createErr := s.CreateBatch(ctx, fallbackEvent); createErr != nil {
			if errors.Is(createErr, ErrEventAlreadyProcessed) ||
				strings.Contains(
					strings.ToLower(createErr.Error()),
					"already processed",
				) {
				log.Printf(
					"[SERVICE] Fallback event already processed for WO=%s Batch=%s Formula=%s",
					req.WorkOrder,
					req.Batch,
					req.Formula,
				)
			} else {
				log.Printf(
					"[SERVICE] Fallback batch creation failed: %v",
					createErr,
				)

				return nil, fmt.Errorf(
					"failed to create fallback batch from progress: %w",
					createErr,
				)
			}
		}

		// Coba update progress sekali lagi setelah fallback batch dibuat.
		err = s.repo.UpdateBatchProgress(ctx, req)
	}

	// ============================================================
	// 3. Kalau setelah fallback masih gagal, baru benar-benar error.
	// ============================================================
	if err != nil {
		log.Printf(
			"[SERVICE] Progress update failed [%s]: WO=%s Batch=%s Formula=%s: %v",
			req.EventID,
			req.WorkOrder,
			req.Batch,
			req.Formula,
			err,
		)

		return nil, fmt.Errorf(
			"failed to update batch progress: %w",
			err,
		)
	}

	log.Printf(
		"[SERVICE] Progress updated: WO=%s Batch=%s Formula=%s WorkStation=%s Pallet=%s NomorMB=%s",
		req.WorkOrder,
		req.Batch,
		req.Formula,
		req.WorkStation,
		req.Pallet,
		req.NomorMB,
	)

	return &SuccessResponse{
		Success:    true,
		ServerTime: time.Now().Local(),
		Message:    "Batch progress updated successfully",
	}, nil
}

// ============================================================
// DASHBOARD & SEARCH QUERIES
// ============================================================

func (s *AppService) GetDashboardBatches(ctx context.Context, page int, limit int) (*PaginatedBatchResponse, error) {
	return s.SearchBatches(ctx, "", page, limit)
}

func (s *AppService) SearchBatches(ctx context.Context, query string, page int, limit int) (*PaginatedBatchResponse, error) {
	if page < 1 {
		page = 1
	}
	if limit <= 0 || limit > 30 {
		limit = 30
	}

	batches, total, err := s.repo.SearchBatches(ctx, query, page, limit)
	if err != nil {
		log.Printf("[SERVICE] Error searching batches (q='%s', page=%d): %v", query, page, err)
		return nil, fmt.Errorf("failed to retrieve batches: %w", err)
	}

	// ============================================================
	// IDLE DETECTION
	// Running batch menjadi Idle jika tidak ada perubahan
	// progress pallet / nomor MB selama lebih dari 10 menit.
	//
	// Idle hanya merupakan status tampilan/runtime.
	// Status database tetap Running agar batch dapat dilanjutkan
	// tanpa perlu migration atau background worker.
	// ============================================================
	const idleThreshold = 10 * time.Minute

	now := time.Now()

	for i := range batches {
		if batches[i].Status != BatchStatusRunning {
			continue
		}

		if batches[i].UpdatedAt.IsZero() {
			continue
		}

		if now.Sub(batches[i].UpdatedAt) > idleThreshold {
			batches[i].Status = BatchStatusIdle
		}
	}

	totalPages := 0
	if total > 0 {
		totalPages = int(math.Ceil(float64(total) / float64(limit)))
	}

	return &PaginatedBatchResponse{
		Success:    true,
		Data:       batches,
		Page:       page,
		Limit:      limit,
		Total:      total,
		TotalPages: totalPages,
		Query:      query,
	}, nil
}
