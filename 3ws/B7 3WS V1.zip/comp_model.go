package main

import "time"

type CompoundingRecord struct {
	ID                 int64      `json:"id"`
	Order              string     `json:"order"`
	ProductName        string     `json:"product_name"`
	Formula            string     `json:"formula"`
	Location           string     `json:"location"`
	Dispensed          string     `json:"dispensed"`
	TotalValidasi      int        `json:"total_validasi"`
	TotalMaterials     int        `json:"total_materials"`
	CompletedMaterials int        `json:"completed_materials"`
	Progress           string     `json:"progress"`
	StartTimestamp     *time.Time `json:"start_timestamp"`
	EndTimestamp       *time.Time `json:"end_timestamp"`
	Status             string     `json:"status"`
	SessionID          string     `json:"session_id"`
	AgentID            string     `json:"agent_id"`
	Hostname           string     `json:"hostname"`
	CreatedAt          time.Time  `json:"created_at"`
	UpdatedAt          time.Time  `json:"updated_at"`
}

type CompoundingEvent struct {
	EventID   string                 `json:"event_id"`
	EventType string                 `json:"event_type"`
	Process   string                 `json:"process"`
	AgentID   string                 `json:"agent_id"`
	Hostname  string                 `json:"hostname"`
	AgentVer  string                 `json:"agent_version"`
	SessionID string                 `json:"session_id"`
	Timestamp time.Time              `json:"timestamp"`
	Reason    string                 `json:"reason"`
	Data      map[string]interface{} `json:"data"`
}

type CompoundingListResponse struct {
	Success    bool                `json:"success"`
	Data       []CompoundingRecord `json:"data"`
	Page       int                 `json:"page"`
	Limit      int                 `json:"limit"`
	Total      int                 `json:"total"`
	TotalPages int                 `json:"total_pages"`
}
