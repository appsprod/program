package main

import (
	"context"
	"fmt"
	"log"
	"net/http"
	"os"
	"os/signal"
	"strconv"
	"strings"
	"syscall"
	"time"
)

// getEnv mengambil nilai dari environment variable dengan fallback default
func getEnv(key, defaultValue string) string {
	if value, exists := os.LookupEnv(key); exists && value != "" {
		return value
	}
	return defaultValue
}

func main() {
	log.Println("Initializing B7_3WS Server...")

	// 1. LOAD CONFIGURATION
	dbHost := getEnv("DATABASE_HOST", "127.0.0.1")
	dbPortStr := getEnv("DATABASE_PORT", "5432")
	dbUser := getEnv("DATABASE_USER", "b7_app")
	dbPass := getEnv("DATABASE_PASSWORD", "123456")
	dbName := getEnv("DATABASE_NAME", "db_3ws")

	dbPort, err := strconv.Atoi(dbPortStr)
	if err != nil {
		log.Printf("Invalid DATABASE_PORT '%s', fallbacking to default 5432", dbPortStr)
		dbPort = 5432
	}

	// Memastikan server binding ke 0.0.0.0 agar bisa diakses dari semua IP/PC dalam jaringan (LAN)
	rawPort := getEnv("PORT", "2005")
	rawPort = strings.TrimPrefix(rawPort, ":")
	serverAddr := fmt.Sprintf("0.0.0.0:%s", rawPort)

	// 2. CONNECT POSTGRESQL DATABASE
	dbConfig := DBConfig{
		Host:     dbHost,
		Port:     dbPort,
		User:     dbUser,
		Password: dbPass,
		DBName:   dbName,
	}

	db, err := OpenDatabase(dbConfig)
	if err != nil {
		log.Fatalf("Database connection failed: %v", err)
	}
	defer CloseDatabase(db)

	log.Println("Database: connected")

	// Inisialisasi skema & tabel database sebelum repo/service berjalan
	if err := InitDatabaseSchema(db); err != nil {
		log.Fatalf("Database schema initialization failed: %v", err)
	}

	// 3. INITIALIZE DEPENDENCIES (REPOSITORY -> SERVICE -> CONTROLLER)
	repo := NewPostgresRepository(db)
	svc := NewAppService(repo)
	ctrl := NewAppController(svc)

	// COMPOUNDING
	compRepo := NewCompoundingRepository(db)
	compSvc := NewCompoundingService(compRepo)
	compHandler := NewCompoundingHandler(compSvc)

	if err := compSvc.EnsureSchema(context.Background()); err != nil {
		log.Fatalf("Compounding schema initialization failed: %v", err)
	}

	// 4. REGISTER ROUTES
	mux := http.NewServeMux()
	SetupRoutes(mux, ctrl, compHandler)

	// 5. HTTP SERVER SETUP
	server := &http.Server{
		Addr:         serverAddr,
		Handler:      mux,
		ReadTimeout:  15 * time.Second,
		WriteTimeout: 15 * time.Second,
		IdleTimeout:  60 * time.Second,
	}

	// Channel untuk menangkap signal termination dari OS
	shutdownChan := make(chan os.Signal, 1)
	signal.Notify(shutdownChan, os.Interrupt, syscall.SIGTERM)

	// Start server dalam goroutine terpisah
	go func() {
		log.Printf("B7_3WS Server")
		log.Printf("HTTP Server listening on: %s", serverAddr)
		if err := server.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			log.Fatalf("HTTP server failed to start: %v", err)
		}
	}()

	// 6. GRACEFUL SHUTDOWN
	<-shutdownChan
	log.Println("\nShutting down B7_3WS Server cleanly...")

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	if err := server.Shutdown(ctx); err != nil {
		log.Printf("HTTP Server forced to shutdown: %v", err)
	} else {
		log.Println("HTTP Server stopped gracefully")
	}

	log.Println("B7_3WS Server exited successfully")
}