package main

import (
	"net/http"
	"strings"
)

// SetupRoutes mendaftarkan seluruh route HTTP ke http.ServeMux standar Go.
// Memastikan pemetaan endpoint sesuai dengan nama handler di controller.go dan compounding handler.
func SetupRoutes(
	mux *http.ServeMux,
	ctrl *AppController,
	compHandler *CompoundingHandler,
) {

	// ============================================================
	// STATIC FILES
	// ============================================================
	// Serving static assets dari folder ./static/ (misal: /static/layout.css)
	fs := http.FileServer(http.Dir("static"))
	mux.Handle("/static/", http.StripPrefix("/static/", fs))

	// ============================================================
	// HTML PAGES
	// ============================================================
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/" {
			http.NotFound(w, r)
			return
		}
		ctrl.IndexHandler(w, r)
	})

	mux.HandleFunc("/dashboard", func(w http.ResponseWriter, r *http.Request) {
		ctrl.DashboardHandler(w, r)
	})

	mux.HandleFunc("/monitor", func(w http.ResponseWriter, r *http.Request) {
		ctrl.MonitorHandler(w, r)
	})

	mux.HandleFunc("/dashboard_comp", func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/dashboard_comp" {
			http.NotFound(w, r)
			return
		}

		http.ServeFile(w, r, "templates/dashboard_comp.html")
	})

	mux.HandleFunc("/dashboard_comp.html", func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/dashboard_comp.html" {
			http.NotFound(w, r)
			return
		}

		http.ServeFile(w, r, "templates/dashboard_comp.html")
	})

	// ============================================================
	// BATCH API
	// ============================================================
	// Memisahkan /api/batches dan /api/batches/search
	mux.HandleFunc("/api/batches", func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path == "/api/batches/search" {
			ctrl.SearchBatchesHandler(w, r)
			return
		}

		if r.URL.Path == "/api/batches" {
			ctrl.GetBatchesHandler(w, r)
			return
		}

		http.NotFound(w, r)
	})

	mux.HandleFunc("/api/batches/search", func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/api/batches/search" {
			http.NotFound(w, r)
			return
		}
		ctrl.SearchBatchesHandler(w, r)
	})

	// ============================================================
	// AGENT API
	// ============================================================
	mux.HandleFunc("/api/agent/register", func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/api/agent/register" {
			http.NotFound(w, r)
			return
		}
		ctrl.RegisterAgentHandler(w, r)
	})

	mux.HandleFunc("/api/agent/heartbeat", func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/api/agent/heartbeat" {
			http.NotFound(w, r)
			return
		}
		ctrl.HeartbeatHandler(w, r)
	})

	mux.HandleFunc("/api/agent/events", func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/api/agent/events" {
			http.NotFound(w, r)
			return
		}
		ctrl.EventBatchHandler(w, r)
	})

	mux.HandleFunc("/api/agent/progress", func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/api/agent/progress" {
			http.NotFound(w, r)
			return
		}
		ctrl.ProgressHandler(w, r)
	})

	mux.HandleFunc("/api/agent/batch", func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/api/agent/batch" {
			http.NotFound(w, r)
			return
		}
		ctrl.GetBatchByIdentityHandler(w, r)
	})

	// ============================================================
	// MONITOR API
	// ============================================================
	mux.HandleFunc("/api/agents", func(w http.ResponseWriter, r *http.Request) {
		if strings.HasPrefix(r.URL.Path, "/api/agents/") && r.URL.Path != "/api/agents" {
			http.NotFound(w, r)
			return
		}
		ctrl.GetAgentsHandler(w, r)
	})

	// DELETE /api/agents/:id
	mux.HandleFunc("/api/agents/", func(w http.ResponseWriter, r *http.Request) {
		if !strings.HasPrefix(r.URL.Path, "/api/agents/") {
			http.NotFound(w, r)
			return
		}
		ctrl.DeleteAgentHandler(w, r)
	})

	// ============================================================
	// COMPOUNDING API
	// ============================================================
	mux.HandleFunc("/api/compounding", func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/api/compounding" {
			http.NotFound(w, r)
			return
		}

		if r.Method == http.MethodGet {
			compHandler.GetBatches(w, r)
			return
		}

		http.Error(
			w,
			"method not allowed",
			http.StatusMethodNotAllowed,
		)
	})

	mux.HandleFunc("/api/agent/compounding/events", func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/api/agent/compounding/events" {
			http.NotFound(w, r)
			return
		}

		compHandler.ReceiveEvent(w, r)
	})

	mux.HandleFunc("/api/agent/compounding/progress", func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/api/agent/compounding/progress" {
			http.NotFound(w, r)
			return
		}

		compHandler.ReceiveProgress(w, r)
	})
}
