package main

import (
	"context"
	"database/sql"
	"fmt"
	"math"
)

type CompoundingRepository struct {
	db *sql.DB
}

func NewCompoundingRepository(db *sql.DB) *CompoundingRepository {
	return &CompoundingRepository{db: db}
}

func (r *CompoundingRepository) EnsureSchema(ctx context.Context) error {
	_, err := r.db.ExecContext(ctx, `
		CREATE TABLE IF NOT EXISTS compounding_records (
			id BIGSERIAL PRIMARY KEY,

			order_no TEXT NOT NULL,
			product_name TEXT NOT NULL DEFAULT '',
			formula TEXT NOT NULL DEFAULT '',
			location TEXT NOT NULL DEFAULT '',

			dispensed TEXT NOT NULL DEFAULT '',
			total_validasi INTEGER NOT NULL DEFAULT 0,
			total_materials INTEGER NOT NULL DEFAULT 0,
			completed_materials INTEGER NOT NULL DEFAULT 0,
			progress TEXT NOT NULL DEFAULT '0/0',

			start_timestamp TIMESTAMPTZ NULL,
			end_timestamp TIMESTAMPTZ NULL,

			status TEXT NOT NULL DEFAULT 'Running',

			session_id TEXT NOT NULL UNIQUE,
			agent_id TEXT NOT NULL DEFAULT '',
			hostname TEXT NOT NULL DEFAULT '',

			created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
			updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
		);

		CREATE INDEX IF NOT EXISTS idx_compounding_created_at
			ON compounding_records (created_at DESC);

		CREATE INDEX IF NOT EXISTS idx_compounding_status
			ON compounding_records (status);

		CREATE INDEX IF NOT EXISTS idx_compounding_order
			ON compounding_records (order_no);

		CREATE INDEX IF NOT EXISTS idx_compounding_session
			ON compounding_records (session_id);
	`)
	return err
}

func (r *CompoundingRepository) Create(
	ctx context.Context,
	rec *CompoundingRecord,
) error {
	query := `
		INSERT INTO compounding_records (
			order_no,
			product_name,
			formula,
			location,
			dispensed,
			total_validasi,
			total_materials,
			completed_materials,
			progress,
			start_timestamp,
			end_timestamp,
			status,
			session_id,
			agent_id,
			hostname
		)
		VALUES (
			$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15
		)
		RETURNING
			id,
			created_at,
			updated_at
	`

	return r.db.QueryRowContext(
		ctx,
		query,
		rec.Order,
		rec.ProductName,
		rec.Formula,
		rec.Location,
		rec.Dispensed,
		rec.TotalValidasi,
		rec.TotalMaterials,
		rec.CompletedMaterials,
		rec.Progress,
		rec.StartTimestamp,
		rec.EndTimestamp,
		rec.Status,
		rec.SessionID,
		rec.AgentID,
		rec.Hostname,
	).Scan(
		&rec.ID,
		&rec.CreatedAt,
		&rec.UpdatedAt,
	)
}

func (r *CompoundingRepository) GetBySessionID(
	ctx context.Context,
	sessionID string,
) (*CompoundingRecord, error) {
	rec := &CompoundingRecord{}

	err := r.db.QueryRowContext(ctx, `
		SELECT
			id,
			order_no,
			product_name,
			formula,
			location,
			dispensed,
			total_validasi,
			total_materials,
			completed_materials,
			progress,
			start_timestamp,
			end_timestamp,
			status,
			session_id,
			agent_id,
			hostname,
			created_at,
			updated_at
		FROM compounding_records
		WHERE session_id = $1
	`, sessionID).Scan(
		&rec.ID,
		&rec.Order,
		&rec.ProductName,
		&rec.Formula,
		&rec.Location,
		&rec.Dispensed,
		&rec.TotalValidasi,
		&rec.TotalMaterials,
		&rec.CompletedMaterials,
		&rec.Progress,
		&rec.StartTimestamp,
		&rec.EndTimestamp,
		&rec.Status,
		&rec.SessionID,
		&rec.AgentID,
		&rec.Hostname,
		&rec.CreatedAt,
		&rec.UpdatedAt,
	)

	if err != nil {
		return nil, err
	}

	return rec, nil
}

func (r *CompoundingRepository) UpdateProgress(
	ctx context.Context,
	rec *CompoundingRecord,
) error {
	_, err := r.db.ExecContext(ctx, `
		UPDATE compounding_records
		SET
			product_name = $1,
			formula = $2,
			location = $3,
			dispensed = $4,
			total_validasi = $5,
			total_materials = $6,
			completed_materials = $7,
			progress = $8,
			updated_at = NOW()
		WHERE session_id = $9
		  AND status = 'Running'
	`,
		rec.ProductName,
		rec.Formula,
		rec.Location,
		rec.Dispensed,
		rec.TotalValidasi,
		rec.TotalMaterials,
		rec.CompletedMaterials,
		rec.Progress,
		rec.SessionID,
	)

	return err
}

func (r *CompoundingRepository) Complete(
	ctx context.Context,
	sessionID string,
	endTimestamp interface{},
) error {
	_, err := r.db.ExecContext(ctx, `
		UPDATE compounding_records
		SET
			end_timestamp = $1,
			status = 'Completed',
			updated_at = NOW()
		WHERE session_id = $2
		  AND status = 'Running'
	`,
		endTimestamp,
		sessionID,
	)

	return err
}

func (r *CompoundingRepository) GetPaginated(
	ctx context.Context,
	page int,
	limit int,
) ([]CompoundingRecord, int, error) {

	if page < 1 {
		page = 1
	}

	if limit < 1 || limit > 100 {
		limit = 30
	}

	offset := (page - 1) * limit

	var total int

	if err := r.db.QueryRowContext(
		ctx,
		`SELECT COUNT(*) FROM compounding_records`,
	).Scan(&total); err != nil {
		return nil, 0, err
	}

	rows, err := r.db.QueryContext(ctx, `
		SELECT
			id,
			order_no,
			product_name,
			formula,
			location,
			dispensed,
			total_validasi,
			total_materials,
			completed_materials,
			progress,
			start_timestamp,
			end_timestamp,
			status,
			session_id,
			agent_id,
			hostname,
			created_at,
			updated_at
		FROM compounding_records
		ORDER BY created_at DESC
		LIMIT $1 OFFSET $2
	`, limit, offset)

	if err != nil {
		return nil, 0, err
	}
	defer rows.Close()

	result := make([]CompoundingRecord, 0)

	for rows.Next() {
		var rec CompoundingRecord

		if err := rows.Scan(
			&rec.ID,
			&rec.Order,
			&rec.ProductName,
			&rec.Formula,
			&rec.Location,
			&rec.Dispensed,
			&rec.TotalValidasi,
			&rec.TotalMaterials,
			&rec.CompletedMaterials,
			&rec.Progress,
			&rec.StartTimestamp,
			&rec.EndTimestamp,
			&rec.Status,
			&rec.SessionID,
			&rec.AgentID,
			&rec.Hostname,
			&rec.CreatedAt,
			&rec.UpdatedAt,
		); err != nil {
			return nil, 0, err
		}

		result = append(result, rec)
	}

	if err := rows.Err(); err != nil {
		return nil, 0, err
	}

	return result, total, nil
}

func compoundingTotalPages(total, limit int) int {
	if limit <= 0 {
		return 0
	}

	return int(math.Ceil(float64(total) / float64(limit)))
}

func compoundingDBError(err error) error {
	return fmt.Errorf("compounding repository: %w", err)
}
