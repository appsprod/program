import sqlite3

db = r"D:\b7_3ws\shared_files\shared_files\ilapak 34\ilapak 34\agent_queue.db"

con = sqlite3.connect(db)

rows = con.execute("""
SELECT 
    event_type,
    status,
    created_at,
    payload_json
FROM queue_events
WHERE payload_json LIKE '%262006216-100%'
   OR payload_json LIKE '%262006282-100%'
""").fetchall()

for r in rows:
    print("=" * 80)
    print("EVENT :", r[0])
    print("STATUS:", r[1])
    print("TIME  :", r[2])
    print(r[3])

con.close()
