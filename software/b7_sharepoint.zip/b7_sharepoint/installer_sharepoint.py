import ctypes
import json
import os
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path


def get_root_dir() -> Path:
    """Return the directory containing the installer."""
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent


ROOT_DIR = get_root_dir()
RUN_SERVER_DIR = ROOT_DIR / "run_server"
SERVER_EXE = RUN_SERVER_DIR / "b7_sharepoint.exe"
NSSM_EXE = RUN_SERVER_DIR / "nssm.exe"
INSTALL_FILE = RUN_SERVER_DIR / "install.txt"
STATE_FILE = ROOT_DIR / "installer_state.json"
DEFAULT_SERVICE_NAME = "b7_sharepoint"
DEFAULT_PORT = 2030


def is_admin() -> bool:
    """Check whether this installer is running with Administrator privileges."""
    try:
        return ctypes.windll.shell32.IsUserAnAdmin() != 0
    except (AttributeError, OSError):
        return False


def run_elevated():
    """Relaunch the installer through UAC when it is not elevated."""
    if is_admin():
        return

    print("[!] Membutuhkan hak akses Administrator. Meminta izin UAC...")
    executable = sys.executable
    if getattr(sys, "frozen", False):
        parameters = subprocess.list2cmdline(sys.argv[1:])
    else:
        parameters = subprocess.list2cmdline(
            [str(Path(__file__).resolve()), *sys.argv[1:]]
        )

    result = ctypes.windll.shell32.ShellExecuteW(
        None, "runas", executable, parameters, str(ROOT_DIR), 1
    )
    if result > 32:
        sys.exit(0)

    print("[✗] ERROR: Gagal mendapatkan hak akses Administrator.")
    input("\nTekan ENTER untuk keluar...")
    sys.exit(1)


def print_step(step_num: int, total_steps: int, title: str):
    print(f"\n[{step_num}/{total_steps}] {title}")


def print_success(msg: str):
    print(f"      ✓ {msg}")


def print_error(msg: str):
    print(f"      ✗ {msg}")


def print_warning(msg: str):
    print(f"      ! {msg}")


def print_info(msg: str):
    print(f"      - {msg}")


def handle_exit(success: bool, step_msg: str = ""):
    print("\n========================================")
    if success:
        print("        INSTALLATION SUCCESSFUL        ")
        print("========================================")
        if step_msg:
            print(f"\n{step_msg}\n")
        print("Closing in 10 seconds...")
        for i in range(10, 0, -1):
            print(f"{i}...", end="\r", flush=True)
            time.sleep(1)
        print("\nDone.")
        sys.exit(0)

    print("          INSTALLATION FAILED          ")
    print("========================================")
    if step_msg:
        print(f"\n{step_msg}\n")
    print("========================================")
    print("Installer will remain open because an error occurred.")
    print("Copy the log above and use it for debugging.")
    input("\nPress ENTER to close...")
    sys.exit(1)


def run_cmd(
    cmd: str | list[str],
    cwd: Path | None = None,
    env: dict[str, str] | None = None,
) -> tuple[int, str, str]:
    """Run a command and capture its output."""
    try:
        proc = subprocess.run(
            cmd,
            cwd=str(cwd) if cwd else None,
            capture_output=True,
            text=True,
            shell=isinstance(cmd, str),
            env=env,
        )
        return proc.returncode, proc.stdout.strip(), proc.stderr.strip()
    except OSError as error:
        return -1, "", str(error)


def is_port_in_use(port: int) -> tuple[bool, int, str]:
    """Check whether a local TCP port is accepting connections."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.settimeout(1)
        if sock.connect_ex(("127.0.0.1", port)) != 0:
            return False, 0, ""

    code, output, _ = run_cmd(f"netstat -ano | findstr :{port}")
    pid = 0
    if code == 0:
        for line in output.splitlines():
            parts = line.split()
            if len(parts) >= 5 and "LISTENING" in parts:
                try:
                    pid = int(parts[-1])
                    break
                except ValueError:
                    continue

    process_name = "Unknown"
    if pid:
        code, output, _ = run_cmd(f'tasklist /FI "PID eq {pid}" /FO CSV /NH')
        if code == 0 and output:
            process_name = output.split(",", 1)[0].strip('"')
    return True, pid, process_name


def load_state() -> dict:
    if not STATE_FILE.is_file():
        return {}
    try:
        with STATE_FILE.open("r", encoding="utf-8") as state_file:
            state = json.load(state_file)
    except (OSError, json.JSONDecodeError) as error:
        print_warning(f"Gagal membaca installer_state.json: {error}")
        return {}
    return state if isinstance(state, dict) else {}


def save_state(state: dict):
    try:
        with STATE_FILE.open("w", encoding="utf-8") as state_file:
            json.dump(state, state_file, indent=2)
    except OSError as error:
        print_warning(f"Gagal menyimpan installer_state.json: {error}")


def print_install_instruction():
    if not INSTALL_FILE.is_file():
        return
    try:
        instruction = INSTALL_FILE.read_text(encoding="utf-8").strip()
    except (OSError, UnicodeDecodeError) as error:
        print_warning(f"Gagal membaca {INSTALL_FILE}: {error}")
        return
    if instruction:
        print_info(f"Instruksi build/deployment (run_server\\install.txt):\n{instruction}")


def validate_package() -> bool:
    """Validate the packaged Go server and its bundled service manager."""
    missing = [path for path in (SERVER_EXE, NSSM_EXE) if not path.is_file()]
    if not missing:
        print_success(f"Go SSR server ditemukan: {SERVER_EXE}")
        print_success(f"NSSM ditemukan: {NSSM_EXE}")
        print_install_instruction()
        return True

    for path in missing:
        print_error(f"File deployment tidak ditemukan: {path}")
    print_install_instruction()
    return False


def run_nssm(nssm_bin: Path, *args: str) -> tuple[int, str, str]:
    return run_cmd([str(nssm_bin), *args])


def get_service_status(nssm_bin: Path, service_name: str) -> str:
    code, stdout, _ = run_nssm(nssm_bin, "status", service_name)
    return stdout.strip() if code == 0 else "NOT_INSTALLED"


def configure_nssm_setting(
    nssm_bin: Path, service_name: str, setting: str, value: str
) -> bool:
    code, _, error = run_nssm(nssm_bin, "set", service_name, setting, value)
    if code != 0:
        print_error(f"Gagal mengatur {setting} untuk service {service_name}: {error}")
        return False
    return True


def register_or_update_service(
    nssm_bin: Path, service_name: str, app_path: Path, app_dir: Path, port: int
) -> bool:
    status = get_service_status(nssm_bin, service_name)
    if status == "NOT_INSTALLED":
        code, _, error = run_nssm(
            nssm_bin, "install", service_name, str(app_path)
        )
        if code != 0:
            print_error(f"Gagal mendaftarkan service {service_name}: {error}")
            return False
    elif not configure_nssm_setting(
        nssm_bin, service_name, "Application", str(app_path)
    ):
        return False

    settings = (
        ("AppDirectory", str(app_dir)),
        ("Start", "SERVICE_AUTO_START"),
        ("AppEnvironmentExtra", f"PORT={port}"),
    )
    for setting, value in settings:
        if not configure_nssm_setting(nssm_bin, service_name, setting, value):
            return False

    log_dir = ROOT_DIR / "logs"
    try:
        log_dir.mkdir(parents=True, exist_ok=True)
    except OSError as error:
        print_error(f"Gagal membuat folder log {log_dir}: {error}")
        return False

    log_settings = (
        ("AppStdout", str(log_dir / f"{service_name}.out.log")),
        ("AppStderr", str(log_dir / f"{service_name}.err.log")),
        ("AppRotateFiles", "1"),
        ("AppRotateOnline", "1"),
    )
    for setting, value in log_settings:
        if not configure_nssm_setting(nssm_bin, service_name, setting, value):
            return False
    return True


def start_service_if_needed(
    nssm_bin: Path, service_name: str, force_restart: bool = False
) -> bool:
    status = get_service_status(nssm_bin, service_name)
    if status == "SERVICE_RUNNING" and not force_restart:
        return True

    if status == "SERVICE_RUNNING":
        print_info(f"Stopping service {service_name} before restart...")
        code, _, error = run_nssm(nssm_bin, "stop", service_name)
        if code != 0:
            print_error(f"Gagal menghentikan service {service_name}: {error}")
            return False
        time.sleep(1)

    print_info(f"Starting service {service_name} from status {status}...")
    code, _, error = run_nssm(nssm_bin, "start", service_name)
    if code != 0:
        print_error(f"Gagal menjalankan service {service_name}: {error}")
        return False

    for _ in range(15):
        time.sleep(1)
        if get_service_status(nssm_bin, service_name) == "SERVICE_RUNNING":
            return True

    print_error(f"Service {service_name} tidak mencapai status SERVICE_RUNNING.")
    return False


def check_http_health(port: int) -> bool:
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/", timeout=2) as response:
            return response.status == 200
    except (urllib.error.URLError, TimeoutError, OSError):
        return False


def run_server_diagnostics(server_exe: Path):
    """Run the Go server briefly and report startup output if it exits."""
    print_info("Menjalankan diagnostik singkat server Go...")
    try:
        proc = subprocess.Popen(
            [str(server_exe)],
            cwd=str(ROOT_DIR),
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )
        try:
            stdout, stderr = proc.communicate(timeout=5)
        except subprocess.TimeoutExpired:
            proc.terminate()
            try:
                stdout, stderr = proc.communicate(timeout=3)
            except subprocess.TimeoutExpired:
                proc.kill()
                stdout, stderr = proc.communicate()
            print_info("Proses Go tetap berjalan selama tes diagnostik.")

        if stdout.strip():
            print(f"\n[Go STDOUT]:\n{stdout.strip()}")
        if stderr.strip():
            print(f"\n[Go STDERR]:\n{stderr.strip()}")
        if proc.returncode not in (None, 0, 1):
            print_info(f"Proses diagnostik berakhir dengan kode {proc.returncode}.")
    except OSError as error:
        print_error(f"Gagal menjalankan diagnostik server: {error}")


def run_deployment_pipeline(service_name: str):
    total_steps = 5

    print_step(1, total_steps, "Memeriksa aplikasi Go Echo SSR")
    print_success(f"Executable: {SERVER_EXE}")
    print_success(f"Working directory: {ROOT_DIR}")

    print_step(2, total_steps, "Memeriksa NSSM lokal")
    print_success(f"NSSM: {NSSM_EXE}")

    print_step(3, total_steps, f"Mengonfigurasi service [{service_name}]")
    if not register_or_update_service(
        NSSM_EXE, service_name, SERVER_EXE, ROOT_DIR, DEFAULT_PORT
    ):
        handle_exit(False, f"Gagal mengonfigurasi service '{service_name}'.")
    print_success(f"Service '{service_name}' terdaftar untuk port {DEFAULT_PORT}.")

    print_step(4, total_steps, f"Menjalankan service [{service_name}]")
    if not start_service_if_needed(NSSM_EXE, service_name, force_restart=True):
        in_use, pid, process_name = is_port_in_use(DEFAULT_PORT)
        if in_use:
            print_error(
                f"Port {DEFAULT_PORT} sedang digunakan oleh {process_name} "
                f"(PID {pid})."
            )
        run_server_diagnostics(SERVER_EXE)
        handle_exit(False, f"Service '{service_name}' gagal dijalankan.")
    print_success(f"Service '{service_name}' berstatus RUNNING.")

    print_step(5, total_steps, "Memeriksa service dan HTTP")
    if not check_http_health(DEFAULT_PORT):
        in_use, pid, process_name = is_port_in_use(DEFAULT_PORT)
        if in_use:
            print_error(
                f"Port {DEFAULT_PORT} merespons tetapi halaman SSR tidak sehat "
                f"(process: {process_name}, PID {pid})."
            )
        else:
            print_error(f"Server belum merespons pada port {DEFAULT_PORT}.")
        run_server_diagnostics(SERVER_EXE)
        handle_exit(False, "Pemeriksaan HTTP server gagal.")

    print_success(f"HTTP SSR merespons pada http://localhost:{DEFAULT_PORT}/")
    save_state(
        {
            "service_name": service_name,
            "server_executable": str(SERVER_EXE.resolve()),
            "port": DEFAULT_PORT,
        }
    )
    handle_exit(True, f"Service ✓ {service_name} (RUNNING)")


def main():
    run_elevated()
    os.system("cls" if os.name == "nt" else "clear")
    print("========================================")
    print("       B7 SHAREPOINT GO INSTALLER       ")
    print("========================================")
    print(f"Root Directory: {ROOT_DIR}\n")

    if not validate_package():
        handle_exit(False, "File aplikasi/NSSM tidak lengkap di folder run_server.")

    state = load_state()
    previous_service = (
        state.get("service_name")
        or state.get("backend_service_name")
        or DEFAULT_SERVICE_NAME
    )
    if state.get("service_name") or state.get("backend_service_name"):
        print("Deployment sebelumnya terdeteksi:")
        print(f"  Service: {previous_service}")
        print("\n[R] Repair / Update / Restart")
        print("[C] Ganti nama service")
        print("[X] Keluar")
        choice = input("\nPilih [R/C/X]: ").strip().upper()
        if choice == "X":
            return
        if choice == "C":
            previous_service = ""
        elif choice != "R":
            print_error("Pilihan tidak valid.")
            handle_exit(False, "Silakan jalankan installer kembali.")
    else:
        print("[R] Install / Repair / Update")
        print("[X] Keluar")
        if input("\nPilih [R/X]: ").strip().upper() != "R":
            return

    default_name = previous_service or DEFAULT_SERVICE_NAME
    service_name = input(f"\nNama Windows service [{default_name}]: ").strip()
    service_name = service_name or default_name
    if not service_name:
        handle_exit(False, "Nama service tidak boleh kosong.")

    print("\n----------------------------------------")
    print(f"Service        : {service_name}")
    print(f"Go SSR server  : {SERVER_EXE}")
    print(f"Port           : {DEFAULT_PORT}")
    print("----------------------------------------")
    if input("Tekan R untuk mulai deployment, X untuk batal: ").strip().upper() != "R":
        print("\nDeployment dibatalkan.")
        return

    run_deployment_pipeline(service_name)


if __name__ == "__main__":
    main()
